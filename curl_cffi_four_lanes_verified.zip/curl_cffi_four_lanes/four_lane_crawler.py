"""Run four independently scheduled property-list lanes with per-site state."""
from __future__ import annotations

import argparse
import asyncio
from contextlib import AsyncExitStack
from dataclasses import dataclass, field
from http.cookiejar import Cookie
import json
import logging
import math
import os
from pathlib import Path
import random
from typing import Any, Awaitable, Callable
from urllib.parse import urlsplit

from curl_cffi.requests import AsyncSession

from async_crawler import Config, Crawler, SiteState, Stats, USER_AGENTS

LOG = logging.getLogger("crawler.four_lanes")
SITE_PREFIXES = {"28hse": "HSE28", "house730": "HOUSE730"}
LANES = {
    "28hse-rent": ("28hse", "https://www.28hse.com/rent"),
    "28hse-buy": ("28hse", "https://www.28hse.com/buy"),
    "house730-rent": ("house730", "https://www.house730.com/rent/s1u14/"),
    "house730-buy": ("house730", "https://www.house730.com/buy/s1u14/"),
}


class PendingConfiguration(ValueError):
    def __init__(self, issues: list[str]) -> None:
        self.issues = issues
        super().__init__("四路配置尚未完成：\n" + "\n".join(f"- {issue}" for issue in issues))


@dataclass(frozen=True)
class BrowserCookie:
    name: str
    value: str = field(repr=False)
    domain: str
    path: str = "/"
    secure: bool = True
    expires: int | None = None


@dataclass(frozen=True)
class SiteConfig:
    name: str
    concurrency: int = 8
    impersonate: str = "chrome136"
    user_agent: str | None = None
    cf_clearance: str = field(default="", repr=False)
    cookies: tuple[BrowserCookie, ...] = field(default=(), repr=False)


@dataclass(frozen=True)
class LaneConfig:
    name: str
    site: str
    page_url: str
    config: Config = field(repr=False)


@dataclass(frozen=True)
class PreparedRun:
    sites: dict[str, SiteConfig]
    lanes: list[LaneConfig]


def _positive(value: Any, label: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value <= 0:
        raise ValueError(f"{label} 必須是有限的正數")
    return float(value)


def _site_headers(prefix: str) -> dict[str, str]:
    try:
        headers = json.loads(os.environ.get(f"{prefix}_HEADERS_JSON", "{}"))
    except ValueError:
        raise ValueError(f"{prefix}_HEADERS_JSON 必須是有效 JSON 物件") from None
    if not isinstance(headers, dict) or not all(isinstance(k, str) and isinstance(v, str) for k, v in headers.items()):
        raise ValueError(f"{prefix}_HEADERS_JSON 必須由字串名稱與字串值構成")
    return headers


def load_four_lanes(path: str | Path, *, interval: float | None = None) -> PreparedRun:
    """Validate all four lanes before constructing any HTTP session.

    verified=true is the operator's confirmation of the genuine request and
    filters. It is not evidence that this program has tested the live endpoint.
    endpoint_hint is descriptive metadata and is never used as a fallback URL.
    """
    try:
        document = json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        raise PendingConfiguration(["請提供可讀取且有效的四路 JSON 配置檔"]) from None
    if not isinstance(document, dict):
        raise PendingConfiguration(["配置根節點必須是 JSON 物件"])
    issues: list[str] = []
    try:
        default_interval = _positive(interval if interval is not None else document.get("interval", 0.5), "interval")
        timeout = _positive(document.get("timeout", 10.0), "timeout")
    except ValueError as exc:
        issues.append(str(exc))
        default_interval, timeout = 0.5, 10.0
    raw_sites = document.get("sites")
    if not isinstance(raw_sites, dict):
        issues.append("sites 必須包含 28hse 與 house730 兩站配置")
        raw_sites = {}
    if set(raw_sites) - set(SITE_PREFIXES):
        issues.append("sites 僅接受 28hse 與 house730")
    sites: dict[str, SiteConfig] = {}
    site_headers: dict[str, dict[str, str]] = {}
    for name, prefix in SITE_PREFIXES.items():
        source = raw_sites.get(name)
        if not isinstance(source, dict):
            issues.append(f"{name}：缺少網站配置")
            continue
        try:
            concurrency = source.get("concurrency", 8)
            if isinstance(concurrency, bool) or not isinstance(concurrency, int) or concurrency < 1:
                raise ValueError("concurrency 必須是正整數")
            impersonate = source.get("impersonate", "chrome136")
            if not isinstance(impersonate, str) or not impersonate:
                raise ValueError("impersonate 必須是非空字串")
            ua = os.environ.get(f"{prefix}_USER_AGENT") or None
            clearance = os.environ.get(f"{prefix}_CF_CLEARANCE", "")
            if clearance and not ua:
                raise ValueError(f"有 Cookie 時必須設定 {prefix}_USER_AGENT 為原瀏覽器 UA")
            site_headers[name] = _site_headers(prefix)
            sites[name] = SiteConfig(name, concurrency, impersonate, ua, clearance)
        except ValueError as exc:
            issues.append(f"{name}：{exc}")
    raw_lanes = document.get("lanes")
    if not isinstance(raw_lanes, list):
        issues.append("lanes 必須是包含四路配置的陣列")
        raw_lanes = []
    indexed: dict[str, dict[str, Any]] = {}
    for source in raw_lanes:
        if not isinstance(source, dict) or not isinstance(source.get("name"), str) or source["name"] not in LANES:
            issues.append("lanes 含有未知或無效的路線名稱")
            continue
        name = source["name"]
        if name in indexed:
            issues.append(f"{name}：重複配置")
        indexed[name] = source
    lanes: list[LaneConfig] = []
    for name, (site, page_url) in LANES.items():
        source = indexed.get(name)
        if source is None:
            issues.append(f"{name}：缺少整路配置")
            continue
        if source.get("site", site) != site:
            issues.append(f"{name}：site 與路線名稱不符")
        if source.get("verified") is not True:
            issues.append(f"{name}：尚未確認真實 Network 請求與租售／業主／最新篩選")
        request = source.get("request")
        if not isinstance(request, dict):
            issues.append(f"{name}：缺少真實 request（網址、方法、完整參數）")
            continue
        if site not in sites:
            continue
        try:
            if set(request) - {"url", "method", "headers", "params", "form", "json", "body"}:
                raise ValueError("request 僅接受 url、method、headers、params、form、json、body")
            url = request.get("url")
            if not isinstance(url, str):
                raise ValueError("request.url 必須是實際列表 API 網址；endpoint_hint 不會代填")
            parsed = urlsplit(url)
            domain = "28hse.com" if site == "28hse" else "house730.com"
            if parsed.scheme != "https" or not parsed.hostname or not (
                parsed.hostname == domain or parsed.hostname.endswith("." + domain)
            ):
                raise ValueError("request.url 必須是對應網站網域的 HTTPS API")
            method = request.get("method")
            if not isinstance(method, str):
                raise ValueError("request.method 必須是實際 GET 或 POST")
            method = method.upper()
            if method == "POST" and not any(request.get(key) is not None for key in ("form", "json", "body")):
                raise ValueError("POST 缺少完整 form、json 或原始 body")
            headers = request.get("headers", {})
            if not isinstance(headers, dict):
                raise ValueError("request.headers 必須是物件")
            site_config = sites[site]
            lane_interval = default_interval if interval is not None else _positive(source.get("interval", default_interval), "interval")
            config = Config(
                url=url, method=method,
                headers={**headers, **site_headers[site]},
                params=request.get("params", {}), form=request.get("form"),
                json_body=request.get("json"), raw_body=request.get("body"),
                expect_json=True,
                interval=lane_interval, concurrency=site_config.concurrency,
                timeout=timeout, impersonate=site_config.impersonate,
                user_agent=site_config.user_agent, cf_clearance=site_config.cf_clearance,
            )
            # The page URL is provenance only; it is never fetched in place of an API.
            lanes.append(LaneConfig(name, site, page_url, config))
        except (ValueError, TypeError):
            # Config errors can concern values supplied in private request files;
            # expose only a fixed description rather than echoing their content.
            issues.append(f"{name}：request 無效；請核對網址／方法、參數型別與互斥的 form/json/body")
    if issues:
        raise PendingConfiguration(issues)
    return PreparedRun(sites, lanes)


async def handle_lane_data(lane_name: str, data: Any, request_id: int) -> None:
    """Extend here with verified response parsing and storage for each lane."""
    LOG.info("%s #%d：取得 %s 資料", lane_name, request_id, type(data).__name__)


async def run_four_lanes(
    prepared: PreparedRun, max_requests: int | None = None,
    on_data: Callable[[str, Any, int], Awaitable[None]] | None = None,
) -> dict[str, Stats]:
    if max_requests is not None and max_requests < 1:
        raise ValueError("max_requests 必須是正整數")
    consume = on_data or handle_lane_data
    tasks: dict[str, asyncio.Task[Stats]] = {}
    async with AsyncExitStack() as stack:
        sessions: dict[str, AsyncSession] = {}
        states: dict[str, SiteState] = {}
        for name, site in prepared.sites.items():
            ua = site.user_agent or random.choice(USER_AGENTS)
            session = await stack.enter_async_context(AsyncSession(
                max_clients=site.concurrency, impersonate=site.impersonate,
                headers={"User-Agent": ua},
            ))
            if site.cf_clearance:
                hosts = {urlsplit(lane.config.url).hostname for lane in prepared.lanes if lane.site == name}
                for host in hosts:
                    session.cookies.set("cf_clearance", site.cf_clearance, domain=host, path="/")
            for cookie in site.cookies:
                site_domain = "28hse.com" if name == "28hse" else "house730.com"
                domain = cookie.domain.lstrip(".").lower()
                if not (domain == site_domain or domain.endswith("." + site_domain)):
                    raise ValueError("瀏覽器 Cookie 的網域與網站不符")
                session.cookies.jar.set_cookie(Cookie(
                    version=0, name=cookie.name, value=cookie.value,
                    port=None, port_specified=False,
                    domain=cookie.domain, domain_specified=cookie.domain.startswith("."),
                    domain_initial_dot=cookie.domain.startswith("."),
                    path=cookie.path, path_specified=True, secure=cookie.secure,
                    expires=cookie.expires, discard=cookie.expires is None,
                    comment=None, comment_url=None, rest={}, rfc2109=False,
                ))
            sessions[name] = session
            states[name] = SiteState(concurrency=site.concurrency)
        async with asyncio.TaskGroup() as group:
            for lane in prepared.lanes:
                async def dispatch(data: Any, request_id: int, name: str = lane.name) -> None:
                    await consume(name, data, request_id)

                crawler = Crawler(lane.config, dispatch, state=states[lane.site], name=lane.name)
                tasks[lane.name] = group.create_task(
                    crawler.run(max_requests=max_requests, session=sessions[lane.site]), name=lane.name,
                )
    return {name: task.result() for name, task in tasks.items()}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default="four_lanes.local.json", help="已確認的本機四路配置")
    parser.add_argument("--check", action="store_true", help="只檢查全部配置，不建立 HTTP 連線")
    parser.add_argument("--interval", type=float, help="覆寫四路間隔秒數；未指定時使用各路配置")
    parser.add_argument("--count", type=int, help="每路最多發起幾次；省略則持續執行")
    args = parser.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s")
    try:
        if args.count is not None and args.count < 1:
            raise ValueError("--count 必須是正整數")
        prepared = load_four_lanes(args.config, interval=args.interval)
        if args.check:
            print("四路配置結構已通過；未送出請求，尚未驗證登入、回應格式或實際篩選結果。")
            return 0
        stats = asyncio.run(run_four_lanes(prepared, max_requests=args.count))
    except PendingConfiguration as exc:
        print(str(exc))
        return 2
    except ValueError as exc:
        parser.error(str(exc))
    except KeyboardInterrupt:
        LOG.info("四路已停止並清理連線")
        return 130
    except ExceptionGroup:
        LOG.error("四路執行發生非預期錯誤；所有本次建立的任務與連線已清理")
        return 1
    for name, result in stats.items():
        LOG.info("%s：發起=%d 成功=%d 失敗=%d 跳過=%d", name,
                 result.started, result.succeeded, result.failed, result.skipped)
    return 2 if any(result.forbidden or result.blocked for result in stats.values()) else (
        1 if any(result.failed and not result.succeeded for result in stats.values()) else 0
    )


if __name__ == "__main__":
    raise SystemExit(main())
