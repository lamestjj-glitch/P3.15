"""Capture-parser checks and a real local CDP/browser integration fixture."""
from __future__ import annotations

import argparse
import asyncio
import importlib.util
import json
import os
from pathlib import Path
import shutil
import tempfile
import threading
import time
import unittest
from unittest.mock import patch
from urllib.parse import urlencode

from async_crawler import Config, Crawler, Stats, USER_AGENTS
from capture_four_lanes import CaptureError, listing_payload, owner_latest, page_lane, run
from four_lane_crawler import BrowserCookie, LANES, LaneConfig, PreparedRun, SiteConfig, run_four_lanes


class CaptureParserTests(unittest.TestCase):
    def test_nested_form_data_filters_and_conflicts(self):
        body = urlencode({'form_data': json.dumps({
            'landlordAgency': 'LANDLORD', 'sortBy': 'latest',
        })})
        self.assertTrue(owner_latest(body))
        self.assertFalse(owner_latest('landlordAgency=AGENCY&sortBy=latest'))
        self.assertFalse(owner_latest('landlordAgency=LANDLORD&landlordAgency=AGENCY&sortBy=latest'))
        self.assertFalse(owner_latest(None))

    def test_list_candidates_do_not_accept_contact_response_or_wrong_trade(self):
        self.assertTrue(listing_payload({'result': [{'propertyId': 1234567, 'title': 'Fixture'}]}, 'house730-rent'))
        self.assertFalse(listing_payload({'result': [{'propertyId': 1234567, 'telphone': 'test-only'}]}, 'house730-rent'))
        payload = {'data': '<a href="/buy/shop/property-1234567">fixture</a>'}
        self.assertTrue(listing_payload(payload, '28hse-buy'))
        self.assertFalse(listing_payload(payload, '28hse-rent'))
        self.assertFalse(listing_payload({'result': []}, 'house730-rent'))

    def test_page_identity_requires_the_expected_site_and_route(self):
        self.assertEqual(page_lane('https://www.28hse.com/rent'), '28hse-rent')
        self.assertEqual(page_lane('https://www.house730.com/buy/s1u14/'), 'house730-buy')
        self.assertIsNone(page_lane('https://example.com/rent'))


class APIChallengeTests(unittest.IsolatedAsyncioTestCase):
    async def test_copied_cookie_scope_secure_and_expiry_are_retained(self):
        from urllib.request import Request
        endpoints = {
            '28hse': 'https://www.28hse.com/property/dosearch',
            'house730': 'https://api.house730.com/Property/QueryProperty',
        }
        sites = {}
        for site in endpoints:
            domain = '.28hse.com' if site == '28hse' else '.house730.com'
            sites[site] = SiteConfig(site, user_agent=USER_AGENTS[0], cookies=(
                BrowserCookie('session', 'fixture-' + site, domain, '/', True, int(time.time()) + 60),
                BrowserCookie('expired', 'fixture-expired', domain, '/', True, int(time.time()) - 60),
                BrowserCookie('wrong_path', 'fixture-other-path', domain, '/other', True),
            ))
        lanes = [LaneConfig(name, site, page_url, Config(endpoints[site]))
                 for name, (site, page_url) in LANES.items()]

        async def probe(crawler, max_requests=None, *, session=None):
            own = '28hse' if '28hse.com' in crawler.config.url else 'house730'
            request = Request(crawler.config.url)
            session.cookies.jar.add_cookie_header(request)
            self.assertEqual(request.get_header('Cookie'), 'session=fixture-' + own)
            insecure = Request(crawler.config.url.replace('https:', 'http:'))
            session.cookies.jar.add_cookie_header(insecure)
            self.assertIsNone(insecure.get_header('Cookie'))
            other = Request(endpoints['house730' if own == '28hse' else '28hse'])
            session.cookies.jar.add_cookie_header(other)
            self.assertIsNone(other.get_header('Cookie'))
            return Stats(started=1, succeeded=1)

        with patch('four_lane_crawler.Crawler.run', new=probe):
            results = await run_four_lanes(PreparedRun(sites, lanes), max_requests=1)
        self.assertEqual(len(results), 4)

    async def test_http200_challenges_and_non_json_stop_json_api(self):
        from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *args):
                pass

            def do_GET(self):
                self.send_response(200)
                if self.path == '/challenge':
                    self.send_header('cf-mitigated', 'challenge')
                    body = b'{"fixture":true}'
                else:
                    body = b'<html>fixture challenge</html>'
                self.send_header('Content-Length', str(len(body)))
                self.end_headers()
                self.wfile.write(body)

        server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
        thread = threading.Thread(target=lambda: server.serve_forever(poll_interval=.02), daemon=True)
        thread.start()
        try:
            for path in ('/challenge', '/non-json'):
                with self.subTest(path=path), self.assertLogs('crawler', level='ERROR'):
                    crawler = Crawler(Config(f'http://127.0.0.1:{server.server_port}{path}',
                                             expect_json=True, interval=.03))
                    stats = await crawler.run(max_requests=3)
                    self.assertEqual((stats.started, stats.succeeded, stats.blocked), (1, 0, 1))
                    self.assertTrue(crawler.stop.is_set())
        finally:
            await asyncio.to_thread(server.shutdown)
            server.server_close()
            await asyncio.to_thread(thread.join, 1)


@unittest.skipUnless(shutil.which('chromium') and importlib.util.find_spec('playwright'),
                     'Optional Playwright/system Chromium unavailable; parser/runtime tests still run')
class RealCDPCaptureTests(unittest.IsolatedAsyncioTestCase):
    async def test_real_cdp_capture_detaches_without_closing_existing_browser(self):
        from playwright.async_api import async_playwright
        with tempfile.TemporaryDirectory(prefix='crawler-browser-') as directory:
            env = {**os.environ, 'XDG_CONFIG_HOME': directory + '/config',
                   'XDG_CACHE_HOME': directory + '/cache'}
            async with async_playwright() as playwright:
                context = await playwright.chromium.launch_persistent_context(
                    directory + '/profile', executable_path=shutil.which('chromium'),
                    headless=True, user_agent=USER_AGENTS[0], env=env,
                    args=['--remote-debugging-port=0', '--disable-dev-shm-usage'],
                )
                try:
                    async def fulfill(route):
                        request = route.request
                        if request.resource_type == 'document':
                            await route.fulfill(status=200, content_type='text/html', body='<html>local fixture</html>')
                        elif request.method == 'OPTIONS':
                            await route.fulfill(status=204, headers={
                                'Access-Control-Allow-Origin': 'https://www.house730.com',
                                'Access-Control-Allow-Credentials': 'true',
                                'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
                                'Access-Control-Allow-Headers': 'Content-Type',
                            })
                        else:
                            await route.fulfill(status=200, content_type='application/json', headers={
                                'Access-Control-Allow-Origin': 'https://www.house730.com',
                                'Access-Control-Allow-Credentials': 'true',
                            }, body=json.dumps({'result': [{'propertyId': 1234567, 'title': 'Fixture listing'}]}))
                    await context.route('**/*', fulfill)
                    await context.add_cookies([
                        {'name': 'cf_clearance', 'value': 'fixture-hse', 'domain': '.28hse.com', 'path': '/', 'secure': True},
                        {'name': 'cf_clearance', 'value': 'fixture-house', 'domain': '.house730.com', 'path': '/', 'secure': True},
                    ])
                    pages = {}
                    for lane, (_, page_url) in LANES.items():
                        page = await context.new_page()
                        await page.goto(page_url)
                        pages[lane] = page
                    port = (Path(directory) / 'profile' / 'DevToolsActivePort').read_text().splitlines()[0]
                    args = argparse.Namespace(
                        cdp='http://127.0.0.1:' + port, capture_seconds=8, house730_path=None,
                        interval=.5, concurrency=8, timeout=10,
                        hse28_impersonate=None, house730_impersonate=None, count=1,
                    )
                    received = []

                    async def consume(prepared, max_requests=None):
                        received.append(prepared)
                        self.assertEqual(set(lane.name for lane in prepared.lanes), set(LANES))
                        self.assertEqual(max_requests, 1)
                        self.assertEqual(prepared.sites['28hse'].user_agent, USER_AGENTS[0])
                        self.assertEqual({cookie.value for cookie in prepared.sites['28hse'].cookies}, {'fixture-hse'})
                        self.assertEqual({cookie.value for cookie in prepared.sites['house730'].cookies}, {'fixture-house'})
                        for lane in prepared.lanes:
                            if lane.site == '28hse':
                                self.assertTrue(owner_latest(lane.config.raw_body))
                            else:
                                self.assertTrue(lane.config.url.endswith('/fixture/current-list'))
                            self.assertFalse(any(key.lower() in ('cookie', 'user-agent') for key in lane.config.headers))
                        return {lane: Stats(started=1, succeeded=1) for lane in LANES}

                    with patch('four_lane_crawler.run_four_lanes', side_effect=consume):
                        task = asyncio.create_task(run(args))
                        # Wait for the second CDP client to subscribe before triggering searches.
                        await asyncio.sleep(.7)
                        for lane, page in pages.items():
                            if lane.startswith('28hse'):
                                url = 'https://www.28hse.com/property/dosearch'
                                body = urlencode({'form_data': json.dumps({
                                    'landlordAgency': 'LANDLORD', 'sortBy': 'latest',
                                })})
                            else:
                                url, body = 'https://api.house730.com/fixture/current-list', '{"fixture":true}'
                            await page.evaluate('''async ({url, body}) => {
                                const response = await fetch(url, {method:'POST', credentials:'include',
                                  headers:{'Content-Type':'application/x-www-form-urlencoded'}, body});
                                await response.text();
                            }''', {'url': url, 'body': body})
                        self.assertEqual(await asyncio.wait_for(task, 12), 0)
                    self.assertEqual(len(received), 1)
                    # Closing the second client's Playwright driver must only detach.
                    self.assertFalse(any(page.is_closed() for page in pages.values()))
                    self.assertEqual(await pages['28hse-rent'].title(), '')
                finally:
                    await context.close()  # This test owns the browser it launched.


if __name__ == '__main__':
    unittest.main()
