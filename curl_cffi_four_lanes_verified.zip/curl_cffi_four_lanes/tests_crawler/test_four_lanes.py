"""Shared-site scheduling checks using only real localhost HTTP requests."""
from __future__ import annotations

import asyncio
from pathlib import Path
import threading
import unittest
from unittest.mock import patch

from curl_cffi.requests import AsyncSession

from async_crawler import Config, Crawler, SiteState
from test_async_crawler import TestServer


class FourLaneIntegrationTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self) -> None:
        self.server = TestServer()
        self.thread = threading.Thread(
            target=lambda: self.server.serve_forever(poll_interval=0.02), daemon=True,
        )
        self.thread.start()
        self.url = f"http://127.0.0.1:{self.server.server_port}"

    async def asyncTearDown(self) -> None:
        await asyncio.to_thread(self.server.shutdown)
        self.server.server_close()
        await asyncio.to_thread(self.thread.join, 1)

    def crawler(self, path, state, callback=None, *, interval=0.05, concurrency=4):
        async def ignore(data, request_id):
            pass
        return Crawler(
            Config(self.url + path, interval=interval, concurrency=concurrency,
                   user_agent="TestBrowser/1"),
            callback or ignore, state=state,
        )

    async def test_four_lanes_share_two_site_limits(self) -> None:
        self.server.plan = lambda request: (200, 0.14, {}, {"ok": True})
        states = [SiteState(concurrency=2), SiteState(concurrency=2)]
        paths = ["/site-a/rent", "/site-a/buy", "/site-b/rent", "/site-b/buy"]
        crawlers = [self.crawler(path, states[index // 2])
                    for index, path in enumerate(paths)]
        maxima = [0, 0]
        finished = asyncio.Event()

        async def observe():
            while not finished.is_set():
                for index, state in enumerate(states):
                    maxima[index] = max(maxima[index], state.in_flight)
                await asyncio.sleep(0.005)

        observer = asyncio.create_task(observe())
        try:
            with self.assertLogs("crawler", level="WARNING"):
                async with AsyncSession(max_clients=2) as first, AsyncSession(max_clients=2) as second:
                    results = await asyncio.wait_for(asyncio.gather(*(
                        crawler.run(max_requests=3, session=first if index < 2 else second)
                        for index, crawler in enumerate(crawlers)
                    )), 5)
        finally:
            finished.set()
            await observer
        self.assertEqual([result.succeeded for result in results], [3, 3, 3, 3])
        for path in paths:
            self.assertEqual(sum(request["path"] == path for request in self.server.requests), 3)
        self.assertTrue(all(1 <= value <= 2 for value in maxima))
        self.assertGreaterEqual(self.server.max_active, 3)
        self.assertEqual([state.in_flight for state in states], [0, 0])

    async def test_orchestrator_maps_callbacks_and_keeps_site_credentials_separate(self) -> None:
        from four_lane_crawler import LaneConfig, PreparedRun, SiteConfig, run_four_lanes

        self.server.plan = lambda request: (200, 0.07, {}, {"path": request["path"]})
        sites = {
            "28hse": SiteConfig("28hse", concurrency=2, user_agent="SiteA/1", cf_clearance="clearance-a"),
            "house730": SiteConfig("house730", concurrency=2, user_agent="SiteB/1", cf_clearance="clearance-b"),
        }
        lanes = []
        expected_paths = {}
        for site_name, site in sites.items():
            for trade in ("rent", "buy"):
                name = f"{site_name}-{trade}"
                path = f"/{site_name}/{trade}"
                expected_paths[name] = path
                config = Config(
                    self.url + path, interval=0.03, concurrency=2, timeout=1,
                    user_agent=site.user_agent, cf_clearance=site.cf_clearance,
                )
                lanes.append(LaneConfig(name, site_name, "https://example.invalid/", config))
        received = []

        async def accept(lane_name, data, request_id):
            received.append((lane_name, data["path"], request_id))

        with self.assertLogs("crawler", level="WARNING"):
            results = await asyncio.wait_for(
                run_four_lanes(PreparedRun(sites, lanes), max_requests=2, on_data=accept), 3,
            )
        self.assertEqual(set(results), set(expected_paths))
        self.assertTrue(all(result.succeeded == 2 for result in results.values()))
        self.assertEqual(len(received), 8)
        self.assertTrue(all(expected_paths[name] == path for name, path, _ in received))
        for request in self.server.requests:
            site_name = request["path"].split("/")[1]
            site = sites[site_name]
            self.assertEqual(request["headers"]["User-Agent"], site.user_agent)
            cookie = request["headers"].get("Cookie", "")
            self.assertIn(f"cf_clearance={site.cf_clearance}", cookie)
            self.assertNotIn("clearance-b" if site_name == "28hse" else "clearance-a", cookie)

    async def test_shared_limit_one_gives_both_infinite_lanes_a_turn(self) -> None:
        self.server.plan = lambda request: (200, 0.09, {}, {"ok": True})
        state = SiteState(concurrency=1)
        successes = {"rent": 0, "buy": 0}

        def callback(name):
            async def accept(data, request_id):
                successes[name] += 1
                if min(successes.values()) >= 2:
                    state.stop.set()
            return accept

        crawlers = [self.crawler("/" + name, state, callback(name), interval=0.04)
                    for name in successes]
        with self.assertLogs("crawler", level="WARNING"):
            async with AsyncSession(max_clients=1) as session:
                await asyncio.wait_for(asyncio.gather(*(
                    crawler.run(session=session) for crawler in crawlers
                )), 3)
        self.assertTrue(all(value >= 2 for value in successes.values()))
        self.assertEqual(self.server.max_active, 1)
        self.assertEqual(state.in_flight, 0)

    async def test_site_403_stops_its_sibling_but_other_site_finishes(self) -> None:
        self.server.plan = lambda request: (
            403 if request["path"] == "/site-a/rent" else 200,
            0.01, {}, {"ok": True},
        )
        first_state, second_state = SiteState(concurrency=4), SiteState(concurrency=4)
        crawlers = [
            self.crawler("/site-a/rent", first_state),
            self.crawler("/site-a/buy", first_state),
            self.crawler("/site-b/rent", second_state),
            self.crawler("/site-b/buy", second_state),
        ]
        with self.assertLogs("crawler", level="ERROR"):
            async with AsyncSession(max_clients=4) as first, AsyncSession(max_clients=4) as second:
                results = await asyncio.wait_for(asyncio.gather(*(
                    crawler.run(max_requests=4, session=first if index < 2 else second)
                    for index, crawler in enumerate(crawlers)
                )), 3)
        self.assertTrue(first_state.stop.is_set())
        self.assertFalse(second_state.stop.is_set())
        self.assertEqual(sum(result.forbidden for result in results[:2]), 1)
        self.assertLessEqual(sum(result.started for result in results[:2]), 2)
        self.assertEqual([result.succeeded for result in results[2:]], [4, 4])
        self.assertEqual((first_state.in_flight, second_state.in_flight), (0, 0))

    async def test_site_429_cools_both_lanes_while_other_site_continues(self) -> None:
        limited = False

        def plan(request):
            nonlocal limited
            if request["path"] == "/site-a/rent" and not limited:
                limited = True
                return 429, 0.06, {"Retry-After": "1"}, {"limited": True}
            return 200, 0.01, {}, {"ok": True}

        self.server.plan = plan
        states = [SiteState(concurrency=4), SiteState(concurrency=4)]
        crawlers = [self.crawler(path, states[index // 2], interval=0.10)
                    for index, path in enumerate([
                        "/site-a/rent", "/site-a/buy", "/site-b/rent", "/site-b/buy",
                    ])]
        with self.assertLogs("crawler", level="WARNING"):
            async with AsyncSession(max_clients=4) as first, AsyncSession(max_clients=4) as second:
                results = await asyncio.wait_for(asyncio.gather(*(
                    crawler.run(max_requests=3 if index < 2 else 8,
                                session=first if index < 2 else second)
                    for index, crawler in enumerate(crawlers)
                )), 4)
        first = [request for request in self.server.requests
                 if request["path"].startswith("/site-a/")]
        other = [request for request in self.server.requests
                 if request["path"].startswith("/site-b/")]
        self.assertEqual(len(first), 6)
        self.assertEqual(sum(result.failed for result in results[:2]), 1)
        # Both initial site-a requests are already in flight before its 429.
        self.assertGreater(min(request["time"] for request in first[2:]) - first[0]["time"], 1.0)
        self.assertTrue(any(0.25 < request["time"] - first[0]["time"] < 0.9 for request in other))
        self.assertEqual([result.succeeded for result in results[2:]], [8, 8])

    async def test_raw_body_keeps_encoding_order_duplicate_keys_and_whitespace(self) -> None:
        body = 'form_data=%7B%22sortBy%22%3A%22latest%22%7D&x=a+b&x=a%20b&empty=\n'
        config = Config(
            self.url + "/raw", method="POST", raw_body=body,
            headers={"Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"},
        )
        result = await Crawler(config).run(max_requests=1)
        self.assertEqual(result.succeeded, 1)
        self.assertEqual(self.server.requests[0]["body"], body.encode("utf-8"))
        for extra in ({"form": {"page": 1}}, {"json_body": {"page": 1}}):
            with self.subTest(extra=extra), self.assertRaises(ValueError):
                Config(self.url + "/raw", method="POST", raw_body=body, **extra)

    async def test_cancellation_releases_shared_slots_and_keeps_injected_session_open(self) -> None:
        self.server.plan = lambda request: (
            200, 0.0 if request["path"] == "/probe" else 0.4, {}, {"ok": True},
        )
        state = SiteState(concurrency=3)
        crawlers = [self.crawler("/" + name, state, interval=0.03) for name in ("rent", "buy")]
        with patch.object(crawlers[0].log, "warning"):
            async with AsyncSession(max_clients=3) as session:
                async def both():
                    await asyncio.gather(*(crawler.run(session=session) for crawler in crawlers))

                runner = asyncio.create_task(both())
                deadline = asyncio.get_running_loop().time() + 2
                while len(self.server.requests) < 3:
                    self.assertLess(asyncio.get_running_loop().time(), deadline)
                    await asyncio.sleep(0.01)
                runner.cancel()
                with self.assertRaises(asyncio.CancelledError):
                    await runner
                self.assertEqual(state.in_flight, 0)
                remaining = [task for task in asyncio.all_tasks()
                             if getattr(task.get_coro(), "__qualname__", "").startswith("Crawler._fetch")]
                self.assertEqual(remaining, [])
                response = await session.get(self.url + "/probe", timeout=1)
                self.assertEqual(response.status_code, 200)


class FourLanePreflightTests(unittest.TestCase):
    def test_example_reports_all_pending_lanes_without_creating_a_session(self) -> None:
        from four_lane_crawler import PendingConfiguration, load_four_lanes
        example = Path(__file__).resolve().parents[1] / "four_lanes.example.json"
        with patch("four_lane_crawler.AsyncSession", side_effect=AssertionError("No HTTP allowed")):
            with self.assertRaises(PendingConfiguration) as caught:
                load_four_lanes(example)
        issues = " ".join(caught.exception.issues)
        for name in ("28hse-rent", "28hse-buy", "house730-rent", "house730-buy"):
            self.assertIn(name, issues)


if __name__ == "__main__":
    unittest.main()
