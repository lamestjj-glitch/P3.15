"""Integration checks against real localhost HTTP, never the target websites."""
from __future__ import annotations

import asyncio
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import threading
import time
import unittest
from urllib.parse import parse_qs, urlsplit

from async_crawler import Config, Crawler


class TestServer(ThreadingHTTPServer):
    daemon_threads = True

    def __init__(self) -> None:
        super().__init__(("127.0.0.1", 0), Handler)
        self.lock = threading.Lock()
        self.requests: list[dict] = []
        self.active = 0
        self.max_active = 0
        self.plan = lambda request: (200, 0.0, {}, {"ok": True})


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args) -> None:
        pass

    def do_GET(self) -> None:
        self._respond()

    def do_POST(self) -> None:
        self._respond()

    def _respond(self) -> None:
        server = self.server
        body = self.rfile.read(int(self.headers.get("Content-Length", 0)))
        with server.lock:
            request = {
                "number": len(server.requests) + 1,
                "time": time.monotonic(),
                "method": self.command,
                "path": self.path,
                "headers": dict(self.headers),
                "body": body,
            }
            server.requests.append(request)
            server.active += 1
            server.max_active = max(server.max_active, server.active)
        try:
            status, delay, headers, payload = server.plan(request)
            time.sleep(delay)
            encoded = json.dumps(payload).encode()
            self.send_response(status)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(encoded)))
            for name, value in headers.items():
                self.send_header(name, value)
            self.end_headers()
            try:
                self.wfile.write(encoded)
            except (BrokenPipeError, ConnectionResetError):
                # A timeout/cancellation intentionally closes the client early.
                pass
        finally:
            with server.lock:
                server.active -= 1


class CrawlerIntegrationTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self) -> None:
        self.server = TestServer()
        self.thread = threading.Thread(
            target=lambda: self.server.serve_forever(poll_interval=0.02), daemon=True,
        )
        self.thread.start()
        self.url = f"http://127.0.0.1:{self.server.server_port}/items"
        self.received = []

    async def asyncTearDown(self) -> None:
        await asyncio.to_thread(self.server.shutdown)
        self.server.server_close()
        await asyncio.to_thread(self.thread.join, 1)

    async def on_data(self, data, request_id) -> None:
        self.received.append((request_id, data))

    async def test_slow_responses_overlap_at_fixed_cadence(self) -> None:
        self.server.plan = lambda request: (200, 0.27, {}, {"id": request["number"]})
        crawler = Crawler(Config(self.url, interval=0.10, concurrency=4), self.on_data)
        stats = await crawler.run(max_requests=5)
        starts = [request["time"] for request in self.server.requests]
        self.assertEqual((stats.started, stats.succeeded, stats.failed), (5, 5, 0))
        self.assertGreaterEqual(self.server.max_active, 2)
        self.assertLessEqual(self.server.max_active, 4)
        # A serial implementation would take >= 1.08 s between first/last starts.
        self.assertLess(starts[-1] - starts[0], 0.80)
        self.assertGreater(starts[-1] - starts[0], 0.28)
        self.assertEqual(sorted(index for index, _ in self.received), list(range(1, 6)))

    async def test_concurrency_cap_skips_ticks_without_a_backlog(self) -> None:
        self.server.plan = lambda request: (200, 0.20, {}, {"ok": True})
        crawler = Crawler(Config(self.url, interval=0.04, concurrency=2), self.on_data)
        with self.assertLogs("crawler", level="WARNING"):
            stats = await crawler.run(max_requests=5)
        starts = [request["time"] for request in self.server.requests]
        self.assertEqual(stats.succeeded, 5)
        self.assertEqual(len(starts), 5)
        self.assertLessEqual(self.server.max_active, 2)
        self.assertGreater(stats.skipped, 0)
        self.assertTrue(all(b - a > 0.018 for a, b in zip(starts, starts[1:])))

    async def test_403_stops_and_does_not_log_secrets(self) -> None:
        self.server.plan = lambda request: (403, 0.0, {}, {"blocked": True})
        crawler = Crawler(Config(
            self.url + "?token=private-query", interval=0.10,
            user_agent="TestBrowser/1", cf_clearance="private-clearance",
        ), self.on_data)
        with self.assertLogs("crawler", level="ERROR") as logs:
            stats = await asyncio.wait_for(crawler.run(), 2)
        self.assertEqual((stats.started, stats.forbidden, stats.succeeded), (1, 1, 0))
        self.assertTrue(crawler.stop.is_set())
        self.assertIn("403", " ".join(logs.output))
        self.assertIn("可能", " ".join(logs.output))
        self.assertNotIn("private-clearance", " ".join(logs.output))
        self.assertNotIn("private-query", " ".join(logs.output))

    async def test_429_from_overlap_extends_a_sleeping_scheduler(self) -> None:
        def plan(request):
            if request["number"] == 1:
                return 429, 0.25, {"Retry-After": "1.03"}, {"limited": True}
            return 200, 0.01, {}, {"ok": True}
        self.server.plan = plan
        launches = []

        class RecordingCrawler(Crawler):
            async def _fetch(self, session, request_id):
                launches.append((asyncio.get_running_loop().time(), self.state.cooldown_until))
                await super()._fetch(session, request_id)

        crawler = RecordingCrawler(Config(self.url, interval=0.10, concurrency=3), self.on_data)
        with self.assertLogs("crawler", level="WARNING"):
            stats = await asyncio.wait_for(crawler.run(max_requests=6), 5)
        self.assertEqual((stats.started, stats.succeeded, stats.failed), (6, 5, 1))
        # Measure client launches: connection setup can reorder/delay server arrivals.
        self.assertLess(launches[1][0] - launches[0][0], 0.24)
        after_cooldown_known = [(started, until) for started, until in launches if until]
        self.assertTrue(after_cooldown_known)
        self.assertTrue(all(started >= until - 0.005 for started, until in after_cooldown_known))
        self.assertGreater(after_cooldown_known[0][0] - launches[0][0], 1.03)

    async def test_timeout_is_recorded_and_next_request_can_succeed(self) -> None:
        self.server.plan = lambda request: (
            200, 0.30 if request["number"] == 1 else 0.0, {}, {"ok": True},
        )
        crawler = Crawler(Config(self.url, interval=0.12, timeout=0.05), self.on_data)
        with self.assertLogs("crawler", level="WARNING"):
            stats = await crawler.run(max_requests=2)
        self.assertEqual((stats.started, stats.succeeded, stats.failed), (2, 1, 1))

    async def test_cancellation_cleans_up_owned_request_tasks(self) -> None:
        self.server.plan = lambda request: (200, 0.5, {}, {"ok": True})
        crawler = Crawler(Config(self.url, interval=0.04, concurrency=4), self.on_data)
        runner = asyncio.create_task(crawler.run())
        deadline = asyncio.get_running_loop().time() + 2
        while len(self.server.requests) < 3:
            self.assertLess(asyncio.get_running_loop().time(), deadline)
            await asyncio.sleep(0.01)
        runner.cancel()
        with self.assertRaises(asyncio.CancelledError):
            await runner
        leaked = [task for task in asyncio.all_tasks()
                  if getattr(task.get_coro(), "__qualname__", "").endswith("Crawler._fetch")]
        self.assertEqual(leaked, [])

    async def test_user_agent_and_clearance_are_fixed_for_the_session(self) -> None:
        crawler = Crawler(Config(
            self.url, interval=0.04, user_agent="TestBrowser/1",
            cf_clearance="test-clearance",
        ), self.on_data)
        stats = await crawler.run(max_requests=3)
        self.assertEqual(stats.succeeded, 3)
        for request in self.server.requests:
            self.assertEqual(request["headers"]["User-Agent"], "TestBrowser/1")
            self.assertIn("cf_clearance=test-clearance", request["headers"].get("Cookie", ""))

    async def test_post_form_json_and_get_query_are_sent_correctly(self) -> None:
        configs = [
            Config(self.url, method="POST", form={"ad_id": "123456", "action": "test"}),
            Config(self.url, method="POST", json_body={"page": 1, "kind": "rent"}),
            Config(self.url, params={"propertyId": "123456"}),
        ]
        for config in configs:
            stats = await Crawler(config, self.on_data).run(max_requests=1)
            self.assertEqual(stats.succeeded, 1)
        form_request, json_request, query_request = self.server.requests
        self.assertEqual(form_request["method"], "POST")
        self.assertEqual(parse_qs(form_request["body"].decode()),
                         {"ad_id": ["123456"], "action": ["test"]})
        self.assertEqual(json_request["method"], "POST")
        self.assertEqual(json.loads(json_request["body"]), {"page": 1, "kind": "rent"})
        self.assertEqual(query_request["method"], "GET")
        self.assertEqual(parse_qs(urlsplit(query_request["path"]).query),
                         {"propertyId": ["123456"]})


if __name__ == "__main__":
    unittest.main()
