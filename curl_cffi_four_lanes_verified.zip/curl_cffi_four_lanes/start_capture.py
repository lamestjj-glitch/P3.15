"""Standard-library bootstrap used by START_CAPTURE.cmd. No secret-value logs."""
from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
import os
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parent


def status(stage: str, *, code: int | None = None) -> None:
    # Stages are fixed strings. Never persist argv, CDP values, env or pip output.
    line = f"{datetime.now(timezone.utc).isoformat()} stage={stage}"
    if code is not None:
        line += f" exit={code}"
    for folder in (ROOT / "logs", Path(tempfile.gettempdir()) / "curl_cffi_four_lanes"):
        try:
            folder.mkdir(parents=True, exist_ok=True)
            with (folder / "startup.log").open("a", encoding="utf-8") as stream:
                stream.write(line + "\n")
            return
        except OSError:
            continue


def venv_python(root: Path) -> Path:
    folder = "Scripts" if os.name == "nt" else "bin"
    executable = "python.exe" if os.name == "nt" else "python"
    return root / ".crawler-venv" / folder / executable


def dependencies_ok(executable: Path) -> bool:
    probe = """import importlib, importlib.metadata, sys
try:
    assert sys.version_info >= (3, 12)
    importlib.import_module('curl_cffi.requests')
    importlib.import_module('playwright.async_api')
    assert importlib.metadata.version('curl_cffi') == '0.16.3'
    assert importlib.metadata.version('playwright') == '1.64.0'
except Exception:
    raise SystemExit(1)
"""
    result = subprocess.run([str(executable), "-c", probe], cwd=ROOT,
                            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    return result.returncode == 0


def ensure_pip(executable: Path) -> int:
    result = subprocess.run([str(executable), "-m", "pip", "--version"], cwd=ROOT,
                            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    if result.returncode == 0:
        return 0
    print("[SETUP] Restoring pip after an incomplete environment setup...", flush=True)
    result = subprocess.run([str(executable), "-m", "ensurepip", "--upgrade"], cwd=ROOT)
    status("restore_pip", code=result.returncode)
    if result.returncode:
        print("[ERROR] This Python installation cannot provide pip. Repair/install standard Python 3.13 and try again.", flush=True)
    return result.returncode


def main(arguments: list[str] | None = None) -> int:
    status("bootstrap")
    if sys.version_info < (3, 12):
        print("[ERROR] Python 3.12+ required. Install Python 3.13 and run START_CAPTURE.cmd again.", flush=True)
        status("unsupported_python", code=1)
        return 1
    if not all((ROOT / name).is_file() for name in (
        "capture_four_lanes.py", "async_crawler.py", "four_lane_crawler.py",
        "requirements-capture.txt", "requirements-crawler.txt",
    )):
        print("[ERROR] Extract the complete ZIP into a writable folder before starting.", flush=True)
        status("missing_files", code=1)
        return 1
    forwarded = sys.argv[1:] if arguments is None else arguments
    executable = venv_python(ROOT)
    try:
        if not executable.is_file():
            print("[SETUP] Creating isolated Python environment...", flush=True)
            result = subprocess.run([sys.executable, "-m", "venv", str(ROOT / ".crawler-venv")], cwd=ROOT)
            status("create_environment", code=result.returncode)
            if result.returncode:
                print("[ERROR] Environment creation failed. Check the message above and folder permissions.", flush=True)
                return result.returncode
        if not dependencies_ok(executable):
            pip_code = ensure_pip(executable)
            if pip_code:
                return pip_code
            print("[SETUP] Installing packages from requirements-capture.txt...", flush=True)
            result = subprocess.run([str(executable), "-m", "pip", "install", "--disable-pip-version-check",
                                     "-r", str(ROOT / "requirements-capture.txt")], cwd=ROOT)
            status("install_dependencies", code=result.returncode)
            if result.returncode:
                print("[ERROR] Package installation failed. The console remains open; inspect the message above.", flush=True)
                return result.returncode
            if not dependencies_ok(executable):
                print("[ERROR] Packages could not be imported. Check Python version and native-library support.", flush=True)
                status("dependency_import_failed", code=1)
                return 1
        status("dependencies_ready", code=0)
        print("[READY] Starting capture. The program will ask for the actual CDP port when no arguments are provided.", flush=True)
        process_env = {**os.environ, "PYTHONUTF8": "1", "PYTHONUNBUFFERED": "1", "CRAWLER_PARENT_PAUSES": "1"}
        result = subprocess.run([str(executable), "-u", str(ROOT / "capture_four_lanes.py"), *forwarded],
                                cwd=ROOT, env=process_env)
        status("capture_finished", code=result.returncode)
        print(f"[EXIT] Code {result.returncode}. Startup stages are recorded in logs/startup.log.", flush=True)
        return result.returncode
    except KeyboardInterrupt:
        status("cancelled", code=130)
        print("\n[STOP] Cancelled by user.", flush=True)
        return 130
    except OSError as exc:
        status("startup_os_error", code=1)
        print(f"[ERROR] Startup failed ({type(exc).__name__}); check folder permissions and installed Python.", flush=True)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
