@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
if errorlevel 1 goto folder_error
if not exist "start_capture.py" goto folder_error
if not exist "capture_four_lanes.py" goto folder_error
set "PYTHONUTF8=1"
set "PYTHONUNBUFFERED=1"
if exist ".crawler-venv\Scripts\python.exe" (
  ".crawler-venv\Scripts\python.exe" "%~dp0start_capture.py" %*
  goto finished
)
where py >nul 2>&1
if not errorlevel 1 (
  for %%V in (3.13 3.12 3.14 3.15 3) do (
    py -%%V -c "import sys; raise SystemExit(not sys.version_info.__ge__((3,12)))" >nul 2>&1
    if not errorlevel 1 (
      py -%%V "%~dp0start_capture.py" %*
      goto finished
    )
  )
)
where python >nul 2>&1
if not errorlevel 1 (
  python -c "import sys; raise SystemExit(not sys.version_info.__ge__((3,12)))" >nul 2>&1
  if not errorlevel 1 (
    python "%~dp0start_capture.py" %*
    goto finished
  )
)
echo [ERROR] Python 3.12+ was not found. Install Python 3.13 and try again.
set "CRAWLER_EXIT_CODE=1"
goto hold
:folder_error
echo [ERROR] Extract the complete ZIP to a normal writable folder first.
set "CRAWLER_EXIT_CODE=1"
goto hold
:finished
set "CRAWLER_EXIT_CODE=%ERRORLEVEL%"
echo.
echo [EXIT] Code %CRAWLER_EXIT_CODE%. Review the messages above.
:hold
echo.
pause
exit /b %CRAWLER_EXIT_CODE%
