"""Learn requests from four existing browser tabs; keep credentials in memory."""
from __future__ import annotations

import argparse
import asyncio
from collections import Counter
from dataclasses import dataclass, field
import importlib
import json
import logging
import math
import os
import re
import sys
import time
from typing import Any, TYPE_CHECKING
from urllib.parse import parse_qs, urlsplit

if TYPE_CHECKING:
    from four_lane_crawler import BrowserCookie, PreparedRun

LOG = logging.getLogger("crawler.capture")
MAX_RESPONSE_BYTES = 3_000_000
DROP_HEADERS = {"cookie", "user-agent", "host", "content-length", "connection",
                "accept-encoding", "transfer-encoding", "proxy-authorization"}


class CaptureError(ValueError):
    pass


@dataclass(frozen=True)
class Observation:
    lane: str
    url: str = field(repr=False)
    method: str
    headers: dict[str, str] = field(repr=False)
    body: str | None = field(repr=False)
    user_agent: str
    cookies: tuple[BrowserCookie, ...] = field(default=(), repr=False)
    observed_at: float = field(default_factory=time.monotonic, repr=False)
    sample: Any = field(default=None, repr=False)


def page_lane(url: str) -> str | None:
    parsed = urlsplit(url)
    if parsed.scheme != "https":
        return None
    path = parsed.path.rstrip("/")
    if parsed.hostname in ("www.28hse.com", "28hse.com"):
        return {"/rent": "28hse-rent", "/buy": "28hse-buy"}.get(path)
    if parsed.hostname in ("www.house730.com", "house730.com"):
        return {"/rent/s1u14": "house730-rent", "/buy/s1u14": "house730-buy"}.get(path)
    return None


def owner_latest(body: str | None) -> bool:
    """Recognize known filter values, including a JSON string in form_data."""
    found: dict[str, set[str]] = {"landlordAgency": set(), "sortBy": set()}

    def visit(value: Any, depth: int = 0) -> None:
        if depth > 8:
            return
        if isinstance(value, str):
            try:
                decoded = json.loads(value)
            except ValueError:
                if "=" not in value:
                    return
                decoded = parse_qs(value, keep_blank_values=True)
            if not isinstance(decoded, str):
                visit(decoded, depth + 1)
        elif isinstance(value, dict):
            for key, part in value.items():
                if key in found:
                    parts = part if isinstance(part, list) else [part]
                    found[key].update(item for item in parts if isinstance(item, str))
                visit(part, depth + 1)
        elif isinstance(value, list):
            for part in value[:100]:
                visit(part, depth + 1)

    visit(body)
    return found["landlordAgency"] == {"LANDLORD"} and found["sortBy"] == {"latest"}


def listing_payload(payload: Any, lane: str) -> bool:
    """Identify list candidates, not the correctness of undocumented filters."""
    trade = "rent" if lane.endswith("-rent") else "buy"
    pattern = (rf"/{trade}/[a-z0-9_-]+/property-\d{{6,10}}"
               if lane.startswith("28hse") else rf"/{trade}-property-\d+")
    queue = [(payload, 0)]
    examined = 0
    while queue and examined < 3000:
        value, depth = queue.pop()
        examined += 1
        if depth > 10:
            continue
        if isinstance(value, str):
            if re.search(pattern, value.replace("\\/", "/"), re.I):
                return True
        elif isinstance(value, dict):
            normalized = {str(key).replace("_", "").lower(): part for key, part in value.items()}
            hints = {"propertyname", "title", "address", "estatename", "price", "rentprice", "saleprice", "propertyurl"}
            if ("propertyid" in normalized and str(normalized["propertyid"]).isdigit()
                    and hints.intersection(normalized)):
                return True
            queue.extend((part, depth + 1) for part in value.values())
        elif isinstance(value, list):
            queue.extend((part, depth + 1) for part in value[:200])
    return False


def impersonation(user_agent: str, override: str | None, *, site: str = "browser") -> str:
    from curl_cffi.requests.impersonate import BrowserType
    supported = {profile.value for profile in BrowserType}
    match = re.search(r"(?:^|[\s(])(?:Headless)?Chrome/(\d+)\.", user_agent)
    other_browser = re.search(
        r"Android|Mobile|iPhone|iPad|iPod|CriOS/|Edg(?:e|A|iOS)?/|OPR/|Opera|"
        r"Firefox/|FxiOS/|SamsungBrowser/|Vivaldi/|YaBrowser/", user_agent, re.I,
    )
    major = int(match[1]) if match and not other_browser else None
    if override:
        if override not in supported | {"chrome", "edge", "safari", "firefox"}:
            raise CaptureError("指定的 impersonate 不受目前 curl_cffi 支援")
        LOG.info("%s：瀏覽器主版本=%s，使用指定 profile=%s", site,
                 major if major is not None else "未識別為桌面 Chrome", override)
        return override
    option = ("--hse28-impersonate" if site == "28hse" else
              "--house730-impersonate" if site == "house730" else
              "--hse28-impersonate／--house730-impersonate")
    if major is None:
        raise CaptureError(f"{site}：未識別為桌面 Chrome；請使用 {option} 指定相符的 profile")
    candidates = []
    for profile in supported:
        version = re.fullmatch(r"chrome(\d+)[a-z]?", profile)
        if version and int(version[1]) <= major:
            candidates.append((int(version[1]), profile))
    if not candidates:
        raise CaptureError(f"{site}：Chrome {major} 低於目前支援的桌面 Chrome profile；"
                           f"請使用相符的瀏覽器或以 {option} 明確指定 profile")
    selected_major = max(version for version, _ in candidates)
    profile = min(profile for version, profile in candidates if version == selected_major)
    if selected_major == major:
        LOG.info("%s：Chrome 主版本=%d，profile=%s", site, major, profile)
    else:
        LOG.warning("%s：Chrome 主版本=%d 沒有同主版本 profile，使用近似 profile=%s；"
                    "保留原 UA，此配對不保證驗證通過，仍可能收到 403 或驗證頁。",
                    site, major, profile)
    return profile


def prepare(
    observations: dict[str, Observation], *, interval: float = 0.5, concurrency: int = 8,
    timeout: float = 10.0, overrides: dict[str, str | None] | None = None,
) -> PreparedRun:
    from async_crawler import Config
    from four_lane_crawler import LANES, LaneConfig, PreparedRun, SiteConfig
    missing = set(LANES) - set(observations)
    if missing:
        raise CaptureError("尚未擷取：" + ", ".join(sorted(missing)))
    sites: dict[str, SiteConfig] = {}
    lanes: list[LaneConfig] = []
    for site in ("28hse", "house730"):
        related = sorted((observation for name, observation in observations.items() if LANES[name][0] == site),
                         key=lambda observation: observation.observed_at)
        uas = {observation.user_agent for observation in related}
        if len(uas) != 1 or not next(iter(uas)):
            raise CaptureError("同站兩路的瀏覽器 UA 不一致，請使用同一個瀏覽器環境重新擷取")
        ua = next(iter(uas))
        profile = impersonation(ua, (overrides or {}).get(site), site=site)
        cookies = {(cookie.name, cookie.domain, cookie.path): cookie
                   for observation in related for cookie in observation.cookies}
        sites[site] = SiteConfig(site, concurrency, profile, ua, cookies=tuple(cookies.values()))
    for name, (site, page_url) in LANES.items():
        observation = observations[name]
        setting = sites[site]
        config = Config(
            observation.url, method=observation.method, headers=observation.headers,
            raw_body=observation.body, expect_json=True, user_agent=setting.user_agent,
            impersonate=setting.impersonate, interval=interval, concurrency=concurrency, timeout=timeout,
        )
        lanes.append(LaneConfig(name, site, page_url, config))
    return PreparedRun(sites, lanes)


async def capture(
    browser: Any, seconds: float, house730_path: str | None = None, *,
    include_samples: bool = False,
) -> dict[str, Observation]:
    from four_lane_crawler import BrowserCookie, LANES
    pages: dict[str, Any] = {}
    for context in browser.contexts:
        for page in context.pages:
            lane = page_lane(page.url)
            if lane:
                pages.setdefault(lane, page)
    missing = set(LANES) - set(pages)
    if missing:
        raise CaptureError("請先開啟四個指定列表分頁；目前缺少：" + ", ".join(sorted(missing)))
    candidates: dict[str, dict[tuple[str, str, str], Observation]] = {lane: {} for lane in LANES}
    pending: set[asyncio.Task[None]] = set()
    handlers: list[tuple[Any, Any]] = []
    changed = asyncio.Event()
    diagnostics = {lane: Counter() for lane in LANES}
    http_statuses = {lane: Counter() for lane in LANES}
    warned: set[tuple[str, str, str]] = set()

    def diagnostic(lane: str) -> str:
        counts = diagnostics[lane]
        statuses = ",".join(f"{code}:{count}" for code, count in sorted(http_statuses[lane].items())) or "無"
        return (f"{lane}：等待列表候選；搜尋回應={counts['responses']}，"
                f"HTTP異常={statuses}，非JSON={counts['non_json']}，"
                f"非列表={counts['not_listing']}，篩選未匹配={counts['filters']}，"
                f"非UTF8本文={counts['encoding']}，讀取錯誤={counts['read_error']}，"
                f"頁面路徑改變={counts['page_changed']}，回應過大={counts['too_large']}，缺UA={counts['no_ua']}")

    async def observe(lane: str, page: Any, response: Any) -> None:
        stage = "讀取搜尋回應"
        try:
            request = response.request
            if request.resource_type not in ("xhr", "fetch"):
                return
            parsed = urlsplit(request.url)
            domain = "28hse.com" if lane.startswith("28hse") else "house730.com"
            if parsed.scheme != "https" or not parsed.hostname or not (
                parsed.hostname == domain or parsed.hostname.endswith("." + domain)
            ):
                return
            if request.method not in ("GET", "POST"):
                return
            path = parsed.path
            if lane.startswith("28hse"):
                if path != "/property/dosearch" or request.method != "POST":
                    return
            elif ("getpropertyuserinfobyid" in path.lower()
                  or (house730_path is not None and path != house730_path)):
                return
            diagnostics[lane]["responses"] += 1
            if page_lane(page.url) != lane:
                diagnostics[lane]["page_changed"] += 1
                return
            if response.status != 200:
                http_statuses[lane][response.status] += 1
                return
            response_bytes = await response.body()
            if len(response_bytes) > MAX_RESPONSE_BYTES:
                diagnostics[lane]["too_large"] += 1
                return
            try:
                payload = json.loads(response_bytes)
            except ValueError:
                diagnostics[lane]["non_json"] += 1
                return
            if not listing_payload(payload, lane):
                diagnostics[lane]["not_listing"] += 1
                return
            # Binary telemetry and other background POSTs must be ignored before
            # touching their request bytes. A real template is decoded strictly
            # so its UTF-8 round-trip remains byte-for-byte unchanged.
            stage = "讀取列表請求本文"
            try:
                raw_bytes = request.post_data_buffer
                body = raw_bytes.decode("utf-8") if raw_bytes is not None else None
            except UnicodeDecodeError:
                diagnostics[lane]["encoding"] += 1
                warning = (lane, stage, "non_utf8")
                if warning not in warned:
                    warned.add(warning)
                    LOG.warning("%s：已識別列表回應，但請求本文不是 UTF-8；略過此模板，未修改原始位元組。"
                                "請核對該列表請求的 Content-Type／Content-Encoding。", lane)
                return
            if lane.startswith("28hse") and not owner_latest(body):
                diagnostics[lane]["filters"] += 1
                return
            stage = "讀取列表標頭與Cookie"
            incoming = await request.all_headers()
            ua = incoming.get("user-agent") or incoming.get("User-Agent")
            if not ua:
                diagnostics[lane]["no_ua"] += 1
                return
            headers = {key: value for key, value in incoming.items()
                       if key.lower() not in DROP_HEADERS and not key.startswith(":")
                       and not key.lower().startswith("sec-")}
            # Preserve the browser's cookie domains, paths, secure flag and expiry.
            cookie_data = await page.context.cookies([request.url])
            cookies = tuple(BrowserCookie(
                cookie["name"], cookie["value"], cookie["domain"], cookie.get("path", "/"),
                cookie.get("secure", False),
                int(cookie["expires"]) if cookie.get("expires", -1) > 0 else None,
            ) for cookie in cookie_data)
            observation = Observation(lane, request.url, request.method, headers, body, ua, cookies,
                                      sample=payload if include_samples else None)
            route = (parsed.hostname, path, request.method)
            first = route not in candidates[lane]
            candidates[lane][route] = observation
            if first:
                LOG.info("%s：已擷取列表候選（URL、Body、Cookie 與標頭值不輸出）", lane)
            changed.set()
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            diagnostics[lane]["read_error"] += 1
            warning = (lane, stage, type(exc).__name__)
            if warning not in warned:
                warned.add(warning)
                LOG.warning("%s：%s未完成（%s）；未輸出請求或回應內容。", lane, stage, type(exc).__name__)

    def subscribe(lane: str, page: Any) -> None:
        def handler(response: Any) -> None:
            if len(pending) >= 32:
                return
            task = asyncio.create_task(observe(lane, page, response))
            pending.add(task)
            task.add_done_callback(pending.discard)
        page.on("response", handler)
        handlers.append((page, handler))

    try:
        for lane, page in pages.items():
            subscribe(lane, page)
        LOG.info("請在四個已設定業主＋最新的分頁各按一次搜尋；不會自動導覽或點擊驗證。")
        deadline = asyncio.get_running_loop().time() + seconds
        next_diagnostic = asyncio.get_running_loop().time() + 15.0
        complete_since: float | None = None
        while asyncio.get_running_loop().time() < deadline:
            if asyncio.get_running_loop().time() >= next_diagnostic:
                for lane in LANES:
                    if not candidates[lane]:
                        LOG.info("%s", diagnostic(lane))
                next_diagnostic = asyncio.get_running_loop().time() + 15.0
            if all(candidates.values()):
                if complete_since is None:
                    complete_since = asyncio.get_running_loop().time()
                elif asyncio.get_running_loop().time() - complete_since >= 1.0:
                    break
            changed.clear()
            try:
                await asyncio.wait_for(changed.wait(), 0.2)
            except TimeoutError:
                pass
        absent = [lane for lane, routes in candidates.items() if not routes]
        ambiguous = [lane for lane, routes in candidates.items() if len(routes) > 1]
        if absent:
            for lane in sorted(absent):
                LOG.warning("%s", diagnostic(lane))
            raise CaptureError("尚無可識別的非空列表回應：" + ", ".join(absent) + "；請確認篩選並重新搜尋")
        if ambiguous:
            raise CaptureError("列表候選不唯一：" + ", ".join(ambiguous) + "；請核對並用 --house730-path 指定實際列表路徑")
        return {lane: next(iter(routes.values())) for lane, routes in candidates.items()}
    finally:
        for page, handler in handlers:
            page.remove_listener("response", handler)
        for task in tuple(pending):
            task.cancel()
        await asyncio.gather(*pending, return_exceptions=True)


async def run_four_lanes(*args: Any, **kwargs: Any) -> Any:
    """Retain the original module callable without loading dependencies at startup."""
    from four_lane_crawler import run_four_lanes as execute
    return await execute(*args, **kwargs)


async def run(args: argparse.Namespace) -> int:
    from playwright.async_api import async_playwright
    export_target = getattr(args, "export_samples", None)
    # Stop the Playwright client to detach; do not close the user's Browser or pages.
    async with async_playwright() as playwright:
        browser = await playwright.chromium.connect_over_cdp(args.cdp, timeout=15_000)
        observations = await capture(browser, args.capture_seconds, args.house730_path,
                                     include_samples=export_target is not None)
    if export_target is not None:
        from sample_export import export_samples
        try:
            export_samples(observations, export_target)
        except FileExistsError:
            raise CaptureError("樣本 ZIP 已存在；請先移走舊檔或指定另一個輸出檔名，不會覆寫。") from None
        LOG.info("四路匿名樣本 ZIP 已建立，請先在本機檢查再上傳聊天；未啟動 curl_cffi 輪詢。")
        return 0
    prepared = prepare(observations, interval=args.interval, concurrency=args.concurrency,
                       timeout=args.timeout, overrides={
                           "28hse": args.hse28_impersonate, "house730": args.house730_impersonate,
                       })
    from listing_monitor import ListingMonitor, MonitorConfigurationError
    try:
        monitor = ListingMonitor(prepared)
    except MonitorConfigurationError as exc:
        raise CaptureError(str(exc)) from None
    LOG.info("四路擷取完成，開始第一頁監控；首次有效回應只建立基線，之後記錄首次發現的房源 ID。")
    try:
        results = await run_four_lanes(prepared, max_requests=args.count, on_data=monitor)
    finally:
        monitor.close()
    for name, stats in results.items():
        LOG.info("%s：發起=%d 成功=%d 失敗=%d 跳過=%d", name,
                 stats.started, stats.succeeded, stats.failed, stats.skipped)
    return 2 if any(stats.forbidden or stats.blocked for stats in results.values()) else (
        1 if any(stats.failed and not stats.succeeded for stats in results.values()) else 0
    )


def check_dependencies() -> bool:
    if sys.version_info < (3, 12):
        LOG.error("需要 Python 3.12 或更新版本；請以符合版本的 Python 執行此檔案。")
        return False
    try:
        importlib.import_module("curl_cffi.requests")
        importlib.import_module("playwright.async_api")
    except (ImportError, OSError):
        LOG.error("缺少依賴或無法載入套件。請使用執行此檔案的同一個 Python 安裝依賴："
                  "python -m pip install -r requirements-capture.txt")
        return False
    return True


def interactive_settings(args: argparse.Namespace) -> bool:
    print("\nFour-lane crawler / 四路列表擷取啟動")
    samples_only = getattr(args, "export_samples", None) is not None
    if samples_only:
        print("本次只擷取四路回應樣本並匯出，完成後退出，不啟動持續輪詢。")
    print("請先開啟 BitBrowser 的四個列表分頁，完成網站驗證並設定業主＋最新，停在第 1 頁。")
    print("需要的是該瀏覽器的 CDP 調試埠，不是 Local API 54345；9222 也只是範例。")
    try:
        value = input("輸入實際 CDP 埠或完整本機位址（直接 Enter 取消）：").strip()
        if not value:
            print("已取消，尚未連線。")
            return False
        if value.isdecimal():
            if not 1 <= int(value) <= 65535:
                raise CaptureError("CDP 埠必須介於 1 與 65535")
            value = "http://127.0.0.1:" + value
        args.cdp = value
        if not samples_only:
            interval = input("每路間隔秒數 [0.5]：").strip()
            args.interval = float(interval) if interval else 0.5
        confirmation = input("已確認四個分頁的租／售、業主、最新排序與第 1 頁？輸入 y 繼續：").strip().lower()
        if confirmation not in ("y", "yes"):
            print("已取消，尚未連線。")
            return False
        args.confirm_filters = True
        return True
    except (EOFError, RuntimeError):
        raise CaptureError("無法讀取互動輸入；請從終端執行 python capture_four_lanes.py") from None
    except ValueError:
        raise CaptureError("請輸入有效的 CDP 埠與正數間隔") from None


def main(argv: list[str] | None = None) -> int:
    arguments = sys.argv[1:] if argv is None else argv
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cdp", help="已開啟 BitBrowser 的本機 CDP 位址，非 Local API 54345")
    parser.add_argument("--check-setup", action="store_true", help="只檢查 Python／依賴，不連線瀏覽器")
    parser.add_argument("--export-samples", nargs="?", const="samples_for_review.zip", metavar="ZIP",
                        help="匯出四路匿名結構樣本後退出；不啟動 curl_cffi 輪詢")
    parser.add_argument("--confirm-filters", action="store_true", help="已在四個分頁核對租／售、業主與最新排序")
    parser.add_argument("--capture-seconds", type=float, default=90.0)
    parser.add_argument("--interval", type=float, default=0.5)
    parser.add_argument("--concurrency", type=int, default=8)
    parser.add_argument("--timeout", type=float, default=10.0)
    parser.add_argument("--count", type=int, help="每路最多請求次數；省略持續執行")
    parser.add_argument("--house730-path", help="候選不唯一時，指定實際列表 API 路徑，不含網域或 query")
    parser.add_argument("--hse28-impersonate")
    parser.add_argument("--house730-impersonate")
    args = parser.parse_args(arguments)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s")
    try:
        if not check_dependencies():
            return 1
        if args.check_setup:
            print("[CHECK_OK] Python 與擷取依賴可用；尚未連線瀏覽器。")
            return 0
        if (not arguments or args.export_samples is not None) and not args.cdp and not interactive_settings(args):
            return 0
        if args.export_samples is not None and (
            not args.export_samples.strip() or not args.export_samples.lower().endswith(".zip")
        ):
            raise CaptureError("--export-samples 請指定非空的 .zip 輸出路徑")
        if not args.cdp:
            raise CaptureError("缺少 --cdp；執行 python capture_four_lanes.py 可使用互動輸入")
        parsed = urlsplit(args.cdp)
        if (parsed.scheme not in ("http", "https", "ws", "wss")
                or parsed.hostname not in ("127.0.0.1", "localhost", "::1")
                or parsed.username is not None or parsed.password is not None):
            raise CaptureError("CDP 請使用原瀏覽器的本機調試位址")
        if not args.confirm_filters:
            raise CaptureError("請先在四個分頁核對篩選，再加 --confirm-filters")
        if any(not math.isfinite(value) or value <= 0 for value in (args.interval, args.timeout, args.capture_seconds)):
            raise CaptureError("間隔、逾時與擷取時間必須是有限正數")
        if args.concurrency < 1 or (args.count is not None and args.count < 1):
            raise CaptureError("並發上限與次數必須是正整數")
        if args.house730_path is not None and (not args.house730_path.startswith("/") or "?" in args.house730_path):
            raise CaptureError("--house730-path 請只填實際路徑")
        return asyncio.run(run(args))
    except CaptureError as exc:
        LOG.error("%s", exc)
        return 2
    except KeyboardInterrupt:
        LOG.info("已停止擷取／請求並清理本程序連線；原瀏覽器分頁保留")
        return 130
    except Exception as exc:
        LOG.error("執行未完成（%s）；請檢查本機 CDP、相依套件及瀏覽器狀態；未輸出秘密值。", type(exc).__name__)
        return 1


if __name__ == "__main__":
    exit_code = 1
    try:
        exit_code = main()
    finally:
        # A .cmd parent pauses once; a directly double-clicked .py must also stay visible.
        if os.name == "nt" and len(sys.argv) == 1 and os.environ.get("CRAWLER_PARENT_PAUSES") != "1":
            try:
                input("\n按 Enter 關閉視窗…")
            except (EOFError, RuntimeError, KeyboardInterrupt):
                if sys.stdin is None or sys.stderr is None:
                    import ctypes
                    ctypes.windll.user32.MessageBoxW(None,
                        "請從終端執行 python capture_four_lanes.py，讓互動輸入與錯誤訊息顯示在視窗中。",
                        "Four-lane crawler", 0x10)
    raise SystemExit(exit_code)
