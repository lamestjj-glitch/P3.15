"""Start capture through the same proxy as BitBrowser, without saving secrets."""
from __future__ import annotations

import getpass
import ipaddress
import os
from pathlib import Path
import re
import subprocess
import sys
from urllib.parse import quote
import warnings

ROOT = Path(__file__).resolve().parent


def proxy_url(protocol: str, host: str, port: str, username: str, password: str) -> str:
    """Build one proxy URL without interpolating input into error messages."""
    scheme = protocol.strip().lower() or "socks5"
    if scheme not in {"http", "https", "socks5", "socks5h"}:
        raise ValueError("代理類型請使用 http、https 或 socks5。")
    # SOCKS5 hostname resolution is deliberately performed by the proxy.
    if scheme == "socks5":
        scheme = "socks5h"
    hostname = host.strip()
    if hostname.startswith("[") and hostname.endswith("]"):
        hostname = hostname[1:-1]
    if not hostname or any(part in hostname for part in ("@", "/", "?", "#", "%")):
        raise ValueError("代理主機格式無效，請只填主機名稱或 IP。")
    if ":" in hostname:
        try:
            address = ipaddress.ip_address(hostname)
        except ValueError:
            raise ValueError("代理主機格式無效，請只填主機名稱或 IP。") from None
        if address.version != 6:
            raise ValueError("代理主機格式無效，請只填主機名稱或 IP。")
        hostname = "[" + str(address) + "]"
    else:
        try:
            hostname = hostname.encode("idna").decode("ascii")
        except UnicodeError:
            raise ValueError("代理主機格式無效，請只填主機名稱或 IP。") from None
        if not re.fullmatch(r"[A-Za-z0-9](?:[A-Za-z0-9.-]{0,251}[A-Za-z0-9])?", hostname):
            raise ValueError("代理主機格式無效，請只填主機名稱或 IP。")
    port_text = port.strip()
    if not port_text.isascii() or not port_text.isdecimal() or not 1 <= int(port_text) <= 65535:
        raise ValueError("代理埠必須介於 1 與 65535。")
    authentication = (quote(username, safe="") + ":" + quote(password, safe="") + "@"
                      if username else "")
    return f"{scheme}://{authentication}{hostname}:{int(port_text)}"


def hidden_input(prompt: str) -> str:
    # getpass normally warns and falls back to an echoed input when no secure
    # terminal is available. Refuse that fallback rather than expose a secret.
    with warnings.catch_warnings():
        warnings.simplefilter("error", getpass.GetPassWarning)
        return getpass.getpass(prompt)


def main(arguments: list[str] | None = None) -> int:
    forwarded = sys.argv[1:] if arguments is None else arguments
    if "--help" in forwarded or "-h" in forwarded:
        print("用法：py -3.15 start_with_proxy.py [start_capture.py 的參數]")
        print("在本機輸入與 BitBrowser 相同的代理類型、主機、埠及帳密。")
        print("SOCKS5 使用 socks5h，讓代理解析目標網域；代理資料不寫入檔案。")
        return 0
    print("請填入 BitBrowser 此瀏覽器環境正在使用的代理設定。")
    print("帳號及密碼輸入時不顯示；本程式不會儲存代理資料。")
    try:
        protocol = input("代理類型（http／https／socks5）[socks5]：")
        host = input("代理主機（只填主機名稱或 IP）：")
        port = input("代理埠：")
        # Validate public settings before asking for credentials.
        proxy_url(protocol, host, port, "", "")
        username = hidden_input("代理帳號（沒有則直接 Enter；輸入隱藏）：")
        password = hidden_input("代理密碼（輸入隱藏）：") if username else ""
        proxy = proxy_url(protocol, host, port, username, password)
        if (protocol.strip().lower() or "socks5") in {"socks5", "socks5h"}:
            print("SOCKS5 使用 socks5h：目標網域由代理解析。")
        child_environment = dict(os.environ)
        child_environment["CRAWLER_PROXY"] = proxy
        # An explicitly chosen common proxy must not be silently overridden by
        # per-site settings inherited from another terminal or previous task.
        child_environment.pop("HSE28_PROXY", None)
        child_environment.pop("HOUSE730_PROXY", None)
        print("本次四路使用同一代理；只傳入子程序環境，結束後不保留。", flush=True)
        result = subprocess.run(
            [sys.executable, str(ROOT / "start_capture.py"), *forwarded],
            cwd=ROOT, env=child_environment,
        )
        return result.returncode
    except KeyboardInterrupt:
        print("\n已取消。")
        return 130
    except (getpass.GetPassWarning, EOFError):
        print("無法安全讀取輸入。請在 CMD 執行 py -3.15 start_with_proxy.py。")
        return 2
    except ValueError as exc:
        # Only proxy_url's fixed messages are emitted; never print credentials,
        # environment contents, a proxy URL or an arbitrary exception message.
        if str(exc) in {
            "代理類型請使用 http、https 或 socks5。",
            "代理主機格式無效，請只填主機名稱或 IP。",
            "代理埠必須介於 1 與 65535。",
        }:
            print(str(exc))
        else:
            print("代理設定無效，請檢查本機設定。")
        return 2
    except OSError:
        print("無法啟動 start_capture.py，請將補丁放入原程式資料夾再執行。")
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
