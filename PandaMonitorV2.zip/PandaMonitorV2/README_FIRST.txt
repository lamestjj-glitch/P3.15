PandaMonitorV2 2.0.0 — 完整 Python 版

啟動
1. 把整個壓縮檔解壓，不要直接在壓縮檔內啟動。
2. 在 PandaMonitorV2 資料夾雙擊 START.cmd。
   也可在該資料夾的 CMD 執行：py -3.15 start_v2.py
3. 首次會建立獨立環境並安裝依賴；不需要另外安裝瀏覽器核心。
4. 在「V2 連線與排程」填實際 CDP 埠，以及和 BitBrowser 相同的代理。
   54345 通常是 BitBrowser Local API 埠，不是 CDP 埠。
5. 在原 BitBrowser 開啟兩站租售列表，設定業主＋最新並停在第 1 頁。
   按「開始監控」後，在各個已勾選的列表分頁各按一次搜尋。

你要求的三項均已整合進 V2
- curl_cffi.AsyncSession + asyncio，列表每路預設 0.5 秒，可各自調整。
- 原瀏覽器 UA／Cookie 自動擷取；另有隨機 UA 與 cf_clearance 配置位置。
  隨機 UA 每個站點 Session 選一次，有 cf_clearance 時保留相符原 UA。
- HTTP 403 或已識別的驗證回應會停止同站新增請求，介面提示 Cookie
  可能失效或網站拒絕存取；403 本身不能證明 Cookie 已失效。

監控與電話
- 保留原版介面、電話去重、歷史、剪貼簿及通知流程。
- 第一次有效列表只建立基線；之後比對首次發現的 ID，不自動翻頁掃全站。
- 新 ID 放入持久電話佇列，沿用老版已解析的兩站電話 API。
- 列表與電話獨立排程；電話保存處理完成後才確認工作，停止重啟可續處理。
- 卡片顯示本次有效列表與失敗數；載入歷史 ID 不會當成本次成功。
- 同站請求有並發上限；慢回應時跳過節拍，沒有積壓後補發。
- DNS 失敗退避 30 秒；HTTP 429 保留 Retry-After 退避。

代理與身份
- Python 不會自動讀取 BitBrowser 代理；請在 V2 頁填相同類型、主機、埠、帳密。
- SOCKS5 使用 socks5h，由代理解析目標網域。
- 也可由本機環境設定 CRAWLER_PROXY，或 HSE28_PROXY／HOUSE730_PROXY。
- V2 頁的代理帳密、cf_clearance 與 UA 只放在本次記憶體，不寫入一般設定。
- 沒有 cf_clearance 才可選隨機 UA；使用 Cookie 時請配對原瀏覽器 UA 與代理。
- Chrome 沒有同版本 impersonate 時會提示近似 profile，無法保證網站接受。

資料與舊版
- V2 資料在目前使用者的 LocalAppData\PandaMonitorV2；沒有 LocalAppData
  的環境則使用使用者目錄下 PandaMonitorV2。
- 首次會複製已知的老版電話去重／歷史檔到獨立 V2 資料夾，不修改原檔。
- 不匯入舊版 Cookie、Token、代理或自動發送設定；WhatsApp 每次開啟預設關閉。
  原版通知與 WhatsApp 控制項仍保留，需要使用時自行設定與啟用。
- V2 的速度以「V2 連線與排程」為準；舊設定頁的速度不控制新引擎。
- 本版整合範圍是 28Hse／House730；舊版擴展網站插件頁已隱藏。
- 停止／關閉只清理本程式連線，不會關閉原瀏覽器分頁。

驗證與限制
已執行離線整合、真實本機 HTTP／代理、Chromium CDP 與 Tk 介面測試。
沒有使用你的真實代理／Cookie，也未在原生 Windows 或實際兩站驗證 V2。
0.5 秒是發起目標，不保證回應在 0.5 秒完成；限流或驗證時按既有機制停止／退避。
只監控第一頁，離線或退避時可能漏過已滑出第一頁的盤。首次發現不等於剛發布。
不自動完成 Turnstile；若 API 或回應格式改變，會拒絕未知格式並提示確認。

補充檔案
SHA256SUMS.txt：壓縮檔內來源檔校驗清單。
requirements.txt：完整依賴；start_v2.py 會自動安裝。
tests_crawler／tests_v2：離線回歸與整合測試；不會存入你的真實會話。
