"""Public listing records parsed from verified response locations."""
from __future__ import annotations

from dataclasses import dataclass


class ListingParseError(ValueError):
    """The response cannot safely be treated as a listing page."""


@dataclass(frozen=True)
class Listing:
    listing_id: str
    url: str | None = None
    title: str | None = None
    price: str | int | float | None = None


@dataclass(frozen=True)
class ListingPage:
    listings: tuple[Listing, ...]
    page: int | None = None
    total: int | None = None
