"""V2 startup and data migration checks; no live browser or website access."""
from __future__ import annotations

import contextlib
import io
import os
from pathlib import Path
import sqlite3
import subprocess
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import PandaMonitorV2 as entry
import start_v2
import v2_paths


@contextlib.contextmanager
def database(path):
    cx = sqlite3.connect(path)
    try:
        with cx:
            yield cx
    finally:
        cx.close()


class DataPathTests(unittest.TestCase):
    def test_explicit_data_root_is_exact_and_default_is_separate(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            with patch.dict(os.environ, {"PANDAMONITOR_V2_DATA_DIR": str(root / "chosen")}, clear=True):
                self.assertEqual(v2_paths.data_root(), root / "chosen")
            with patch.dict(os.environ, {"LOCALAPPDATA": str(root)}, clear=True):
                self.assertEqual(v2_paths.data_root(), root / "PandaMonitorV2")

    def test_imports_only_known_history_and_keeps_originals(self):
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory)
            home, local, dest = base / "home", base / "local", base / "v2"
            old = home / "PandaMonitor_28Hse"
            old.mkdir(parents=True)
            old_phone = old / "seen_phones.json"
            old_phone.write_text('{"phones":["45670001"]}')
            (old / "config.json").write_text('{"token":"PRIVATE-OLD-TOKEN"}')
            (old / "bitbrowser_api_token.txt").write_text("PRIVATE-TOKEN")
            house = local / "House730Standalone173"
            house.mkdir(parents=True)
            for source in (old / "28hse_history.sqlite3", house / "house730.db"):
                with database(source) as cx:
                    cx.execute("CREATE TABLE fixture(value TEXT)")
                    cx.execute("INSERT INTO fixture VALUES ('retained')")
            report = v2_paths.bootstrap_legacy_data(root=dest, legacy_home=home, legacy_local=local)
            self.assertTrue(all(status == "imported" for status in report.values()))
            self.assertEqual((dest / "28hse/seen_phones.json").read_bytes(), old_phone.read_bytes())
            self.assertEqual((old / "config.json").read_text(), '{"token":"PRIVATE-OLD-TOKEN"}')
            self.assertFalse(list(dest.rglob("config.json")))
            self.assertFalse(list(dest.rglob("*token*")))
            for target in (dest / "28hse/28hse_history.sqlite3", dest / "house730/house730.db"):
                with database(target) as cx:
                    self.assertEqual(cx.execute("SELECT value FROM fixture").fetchone()[0], "retained")

    def test_live_wal_database_backup_contains_committed_rows(self):
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory)
            source, target = base / "old.sqlite3", base / "new.sqlite3"
            with database(source) as cx:
                cx.execute("PRAGMA journal_mode=WAL")
                cx.execute("CREATE TABLE fixture(value INTEGER)")
                cx.execute("INSERT INTO fixture VALUES (17)")
                cx.commit()
                self.assertTrue(Path(str(source) + "-wal").exists())
                self.assertEqual(v2_paths._import_one(source, target, database=True), "imported")
                self.assertEqual(cx.execute("SELECT value FROM fixture").fetchone()[0], 17)
            with database(target) as cx:
                self.assertEqual(cx.execute("SELECT value FROM fixture").fetchone()[0], 17)

    def test_existing_v2_files_are_not_replaced_and_invalid_database_is_not_published(self):
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory)
            source, target = base / "source.json", base / "target.json"
            source.write_text("old")
            target.write_text("existing-v2")
            self.assertEqual(v2_paths._import_one(source, target, database=False), "existing")
            self.assertEqual(target.read_text(), "existing-v2")
            source.write_text("not a database")
            bad_target = base / "invalid.sqlite3"
            self.assertEqual(v2_paths._import_one(source, bad_target, database=True), "error")
            self.assertFalse(bad_target.exists())
            self.assertFalse(list(base.glob(".history-*")))


class BootstrapTests(unittest.TestCase):
    def package(self, directory):
        root = Path(directory) / "中文 V2 folder"
        root.mkdir()
        for name in ("PandaMonitorV2.py", "v2_gui.py", "v2_runtime.py", "async_crawler.py", "requirements.txt"):
            (root / name).write_text("# offline fixture\n")
        return root

    def interpreter(self, root):
        exe = start_v2.venv_python(root)
        exe.parent.mkdir(parents=True)
        exe.touch()
        return exe

    def test_stale_environment_is_backed_up_and_rebuilt_with_selected_python(self):
        with tempfile.TemporaryDirectory() as directory:
            root = self.package(directory)
            exe = self.interpreter(root)
            (root / ".panda-v2-venv/retained.txt").write_text("old-environment")

            def execute(command, **kwargs):
                if command[:3] == [sys.executable, "-m", "venv"]:
                    backups = list(root.glob(".panda-v2-venv.backup-*"))
                    self.assertEqual(len(backups), 1)
                    self.assertEqual((backups[0] / "retained.txt").read_text(), "old-environment")
                    self.interpreter(root)
                return subprocess.CompletedProcess(command, 0)

            with patch.object(start_v2, "ROOT", root), \
                 patch.object(start_v2, "interpreter_ok", side_effect=[False, True]), \
                 patch.object(start_v2, "dependencies_ok", return_value=True), \
                 patch.object(start_v2.subprocess, "run", side_effect=execute) as run, \
                 contextlib.redirect_stdout(io.StringIO()):
                self.assertEqual(start_v2.main([]), 0)
            self.assertEqual(run.call_args_list[0].args[0],
                             [sys.executable, "-m", "venv", str(root / ".panda-v2-venv")])
            self.assertEqual(run.call_args_list[-1].args[0], [str(exe), "-u", str(root / "PandaMonitorV2.py")])

    def test_install_failure_does_not_launch_gui_or_log_secret_arguments(self):
        with tempfile.TemporaryDirectory() as directory:
            root = self.package(directory)
            self.interpreter(root)
            with patch.object(start_v2, "ROOT", root), \
                 patch.object(start_v2, "interpreter_ok", return_value=True), \
                 patch.object(start_v2, "dependencies_ok", return_value=False), \
                 patch.object(start_v2, "ensure_pip", return_value=0), \
                 patch.object(start_v2.subprocess, "run", return_value=subprocess.CompletedProcess([], 23)) as run, \
                 contextlib.redirect_stdout(io.StringIO()) as output:
                self.assertEqual(start_v2.main(["PRIVATE-ARGUMENT"]), 23)
            self.assertEqual(run.call_count, 1)
            self.assertEqual(run.call_args.args[0][-1], str(root / "requirements.txt"))
            self.assertNotIn("PRIVATE-ARGUMENT", output.getvalue())
            log = (root / "logs/startup.log").read_text()
            self.assertIn("stage=install_dependencies exit=23", log)
            self.assertNotIn("PRIVATE-ARGUMENT", log)
            self.assertNotIn("gui_finished", log)

    def test_child_arguments_and_environment_survive_without_shell_or_secret_logs(self):
        with tempfile.TemporaryDirectory() as directory:
            root = self.package(directory)
            exe = self.interpreter(root)
            with patch.object(start_v2, "ROOT", root), \
                 patch.object(start_v2, "interpreter_ok", return_value=True), \
                 patch.object(start_v2, "dependencies_ok", return_value=True), \
                 patch.dict(os.environ, {"PRIVATE_FIXTURE": "PRIVATE-ENV"}), \
                 patch.object(start_v2.subprocess, "run", return_value=subprocess.CompletedProcess([], 7)) as run, \
                 contextlib.redirect_stdout(io.StringIO()) as output:
                self.assertEqual(start_v2.main(["--self-test"]), 7)
            self.assertEqual(run.call_args.args[0], [str(exe), "-u", str(root / "PandaMonitorV2.py"), "--self-test"])
            self.assertEqual(run.call_args.kwargs["env"]["PANDAMONITOR_PARENT_PAUSES"], "1")
            self.assertEqual(run.call_args.kwargs["env"]["PRIVATE_FIXTURE"], "PRIVATE-ENV")
            self.assertFalse(run.call_args.kwargs.get("shell", False))
            self.assertNotIn("PRIVATE-ENV", output.getvalue() + (root / "logs/startup.log").read_text())


class EntryTests(unittest.TestCase):
    def test_help_does_not_import_dependencies(self):
        result = subprocess.run([sys.executable, "-S", str(Path(entry.__file__)), "--help"],
                                capture_output=True, text=True, timeout=10)
        self.assertEqual(result.returncode, 0)
        self.assertIn("--check-setup", result.stdout)
        self.assertNotIn("Traceback", result.stderr)

    def test_setup_check_never_opens_gui_or_migrates_data(self):
        with patch.object(entry, "check_setup", return_value=True), \
             patch.object(v2_paths, "bootstrap_legacy_data") as migrate, \
             contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(entry.main(["--check-setup"]), 0)
        migrate.assert_not_called()

    def test_self_test_updates_and_destroys_gui_without_starting_monitoring(self):
        calls = []

        class App:
            def update_idletasks(self): calls.append("idles")
            def update(self): calls.append("update")
            def destroy(self): calls.append("destroy")

        with patch.object(entry, "check_setup", return_value=True), \
             patch.object(v2_paths, "bootstrap_legacy_data") as migrate, \
             patch.dict(sys.modules, {"v2_gui": SimpleNamespace(PandaMonitorV2App=App)}), \
             contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(entry.main(["--self-test"]), 0)
        migrate.assert_called_once()
        self.assertEqual(calls, ["idles", "update", "destroy"])


if __name__ == "__main__":
    unittest.main()
