"""Durable discovery outbox checks, entirely synthetic and offline."""
from __future__ import annotations

import asyncio
import json
from pathlib import Path
import sqlite3
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

from listing_monitor import ListingMonitor, MonitorConfigurationError
from listing_types import Listing, ListingPage, ListingParseError


def configuration(label="owner"):
    return SimpleNamespace(lanes=[SimpleNamespace(
        name="house730-rent", site="house730", config=SimpleNamespace(
            url="https://api.house730.com/Property/QueryProperty", method="POST",
            raw_body=json.dumps({"pageIndex": 1, "searchText": label}),
            params={}, form=None, json_body=None,
        ),
    )])


def listing_page(*identifiers):
    return ListingPage(tuple(Listing(str(identifier),
        f"https://www.house730.com/rent-property-{identifier}/?token=PRIVATE-LINK",
        title="PRIVATE-NAME", price="PRIVATE-PRICE") for identifier in identifiers))


class DurableOutboxTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory(prefix="v2-outbox-tests-")
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name)
        self.state_path = self.root / "monitor.sqlite3"

    def monitor(self, *, label="owner", enabled=True):
        monitor = ListingMonitor(configuration(label), state_path=self.state_path,
                                 queue_contacts=enabled)
        self.addCleanup(monitor.close)
        return monitor

    async def deliver(self, monitor, request_id, *identifiers):
        with patch("listing_monitor.parse_page", return_value=listing_page(*identifiers)):
            return await monitor("house730-rent", {"fixture": True}, request_id)

    async def seed_and_discover(self, monitor):
        self.assertEqual(await self.deliver(monitor, 1, 1000001), ())
        return await self.deliver(monitor, 2, 1000001, 1000002)

    async def test_baseline_does_not_queue_and_new_discovery_commits_one_public_job(self):
        monitor = self.monitor()
        self.assertEqual(await self.deliver(monitor, 1, 1000001), ())
        self.assertEqual(monitor.claim_contacts(), [])
        discoveries = await self.deliver(monitor, 2, 1000001, 1000002)
        self.assertEqual(len(discoveries), 1)
        discovery = discoveries[0]
        self.assertEqual(discovery["listing_id"], "1000002")
        self.assertEqual(discovery["url"], "https://www.house730.com/rent-property-1000002/")
        self.assertIsInstance(discovery["job_id"], int)
        jobs = monitor.claim_contacts()
        self.assertEqual(len(jobs), 1)
        self.assertEqual(jobs[0]["job_id"], discovery["job_id"])
        self.assertEqual(jobs[0]["attempts"], 1)
        self.assertEqual(monitor.claim_contacts(), [])
        self.assertEqual(await self.deliver(monitor, 3, 1000002), ())
        self.assertEqual(monitor.lane_snapshot("house730-rent"), {
            "valid": 3, "seen": 2, "discoveries": 1, "stale": 0,
            "errors": 0, "initialized": True, "watermark": 3,
        })
        database_bytes = self.state_path.read_bytes()
        for private in (b"PRIVATE-LINK", b"PRIVATE-NAME", b"PRIVATE-PRICE"):
            self.assertNotIn(private, database_bytes)

    async def test_latest_listing_reuses_the_validated_page_and_rejects_stale_updates(self):
        monitor = self.monitor()
        self.assertIsNone(monitor.latest_listing("house730-rent"))
        with patch("listing_monitor.parse_page", return_value=listing_page(1000002, 1000001)) as parse:
            await monitor("house730-rent", {}, 2)
            first = monitor.latest_listing("house730-rent")
            self.assertEqual(first, {"listing_id": "1000002", "url": "https://www.house730.com/rent-property-1000002/"})
            first["listing_id"] = "PRIVATE-MUTATION"
            self.assertEqual(monitor.latest_listing("house730-rent")["listing_id"], "1000002")
            parse.assert_called_once()
        with patch("listing_monitor.parse_page", side_effect=AssertionError("must ignore old response")):
            await monitor("house730-rent", {}, 1)
        with patch("listing_monitor.parse_page", side_effect=ListingParseError("fixture")):
            with self.assertRaises(ListingParseError):
                await monitor("house730-rent", {}, 3)
        self.assertEqual(monitor.latest_listing("house730-rent")["listing_id"], "1000002")
        await self.deliver(monitor, 4)
        self.assertIsNone(monitor.latest_listing("house730-rent"))

    async def test_queue_disabled_does_not_create_jobs_or_backfill_old_events(self):
        disabled = self.monitor(enabled=False)
        discoveries = await self.seed_and_discover(disabled)
        self.assertIsNone(discoveries[0]["job_id"])
        self.assertEqual(disabled.claim_contacts(), [])
        self.assertIsNone(disabled._db.execute(
            "SELECT name FROM sqlite_master WHERE name='monitor_contact_jobs'").fetchone())
        enabled = self.monitor()
        self.assertEqual(enabled.claim_contacts(), [])
        new = await self.deliver(enabled, 1, 1000002, 1000003)
        self.assertEqual([job["listing_id"] for job in enabled.claim_contacts()], ["1000003"])
        self.assertEqual(len(new), 1)

    async def test_stale_and_invalid_responses_never_add_jobs(self):
        monitor = self.monitor()
        await self.deliver(monitor, 2, 1000001)
        with patch("listing_monitor.parse_page", side_effect=AssertionError("must ignore old response")):
            self.assertEqual(await monitor("house730-rent", {}, 1), ())
        with patch("listing_monitor.parse_page", side_effect=ListingParseError("fixture")):
            with self.assertRaises(ListingParseError):
                await monitor("house730-rent", {}, 3)
        self.assertEqual(monitor.claim_contacts(), [])
        snapshot = monitor.lane_snapshot("house730-rent")
        self.assertEqual((snapshot["stale"], snapshot["errors"], snapshot["seen"]), (1, 1, 1))

    async def test_job_insert_failure_rolls_back_event_and_seen_id_together(self):
        monitor = self.monitor()
        await self.deliver(monitor, 1, 1000001)
        with monitor._db:
            monitor._db.execute("""CREATE TRIGGER reject_fixture_job BEFORE INSERT ON monitor_contact_jobs
                BEGIN SELECT RAISE(ABORT, 'fixture'); END""")
        with self.assertRaises(sqlite3.IntegrityError):
            await self.deliver(monitor, 2, 1000001, 1000002)
        self.assertEqual(monitor._db.execute("SELECT COUNT(*) FROM monitor_seen").fetchone()[0], 1)
        self.assertEqual(monitor._db.execute("SELECT COUNT(*) FROM monitor_events").fetchone()[0], 0)
        self.assertEqual(monitor._db.execute("SELECT COUNT(*) FROM monitor_contact_jobs").fetchone()[0], 0)
        with monitor._db:
            monitor._db.execute("DROP TRIGGER reject_fixture_job")
        discoveries = await self.deliver(monitor, 2, 1000001, 1000002)
        self.assertEqual(len(discoveries), 1)

    async def test_export_failure_cannot_lose_the_already_committed_job(self):
        monitor = self.monitor()
        await self.deliver(monitor, 1, 1000001)
        with patch.object(monitor, "_write_output", side_effect=OSError("fixture")):
            with self.assertRaises(OSError):
                await self.deliver(monitor, 2, 1000001, 1000002)
        self.assertEqual([job["listing_id"] for job in monitor.claim_contacts()], ["1000002"])

    async def test_two_live_instances_do_not_claim_the_same_job(self):
        first = self.monitor()
        await self.seed_and_discover(first)
        job = first.claim_contacts()[0]
        second = self.monitor()
        self.assertEqual(second.claim_contacts(), [])
        # A foreign instance cannot acknowledge another owner's lease.
        second.ack_contact(job["job_id"])
        self.assertEqual(second.claim_contacts(), [])
        first.close()
        retried = second.claim_contacts()[0]
        self.assertEqual((retried["job_id"], retried["attempts"]), (job["job_id"], 2))

    async def test_acknowledged_and_finished_jobs_do_not_reappear_after_restart(self):
        first = self.monitor()
        await self.seed_and_discover(first)
        job = first.claim_contacts()[0]
        first.ack_contact(job["job_id"])
        await self.deliver(first, 3, 1000003)
        another = first.claim_contacts()[0]
        first.release_contact(another["job_id"], outcome="PRIVATE-CONTACT-MUST-NOT-BE-PERSISTED")
        first.close()
        second = self.monitor()
        self.assertEqual(second.claim_contacts(), [])
        self.assertNotIn(b"PRIVATE-CONTACT-MUST-NOT-BE-PERSISTED", self.state_path.read_bytes())

    async def test_retry_deadline_and_attempt_count_survive_restart(self):
        first = self.monitor()
        await self.seed_and_discover(first)
        with patch("listing_monitor.time.time", return_value=1000):
            job = first.claim_contacts()[0]
            first.release_contact(job["job_id"], retry_seconds=20)
        first.close()
        with patch("listing_monitor.time.time", return_value=1019):
            second = self.monitor()
            self.assertEqual(second.claim_contacts(), [])
        with patch("listing_monitor.time.time", return_value=1020):
            retried = second.claim_contacts()[0]
        self.assertEqual((retried["job_id"], retried["attempts"]), (job["job_id"], 2))

    async def test_expired_crashed_lease_recovers_without_stale_owner_ack(self):
        first = self.monitor()
        await self.seed_and_discover(first)
        with patch("listing_monitor.time.time", return_value=1000):
            original = first.claim_contacts()[0]
        with patch("listing_monitor.time.time", return_value=1301):
            second = self.monitor()
            retry = second.claim_contacts()[0]
            first.ack_contact(original["job_id"])
            self.assertEqual(second.claim_contacts(), [])
        self.assertEqual(retry["job_id"], original["job_id"])
        self.assertEqual(retry["attempts"], 2)
        self.assertEqual(second._db.execute("SELECT status FROM monitor_contact_jobs").fetchone()[0], "leased")

    async def test_other_search_scope_jobs_are_not_claimed_or_reset(self):
        owner = self.monitor(label="owner")
        await self.seed_and_discover(owner)
        owner_job = owner.claim_contacts()[0]
        different = self.monitor(label="different-filter")
        self.assertEqual(different.claim_contacts(), [])
        await self.deliver(different, 1, 2000001)
        await self.deliver(different, 2, 2000001, 2000002)
        different_jobs = different.claim_contacts()
        self.assertEqual([job["listing_id"] for job in different_jobs], ["2000002"])
        different.release_contact(owner_job["job_id"], outcome="finished")
        self.assertEqual(owner._db.execute("SELECT status FROM monitor_contact_jobs WHERE job_id=?",
                                          (owner_job["job_id"],)).fetchone()[0], "leased")

    async def test_claim_limit_and_fixed_validation_errors(self):
        monitor = self.monitor()
        await self.deliver(monitor, 1, 1000001)
        await self.deliver(monitor, 2, 1000001, 1000002, 1000003, 1000004)
        self.assertEqual(len(monitor.claim_contacts(2)), 2)
        self.assertEqual(len(monitor.claim_contacts(2)), 1)
        for invalid in (0, -1, 1001, True, 1.5, "PRIVATE"):
            with self.subTest(value=type(invalid).__name__), self.assertRaises(MonitorConfigurationError) as caught:
                monitor.claim_contacts(invalid)
            self.assertNotIn("PRIVATE", str(caught.exception))
        for seconds in (-1, float("nan"), float("inf"), True, "PRIVATE"):
            with self.subTest(value=type(seconds).__name__), self.assertRaises(MonitorConfigurationError):
                monitor.release_contact(1, retry_seconds=seconds)


if __name__ == "__main__":
    unittest.main()
