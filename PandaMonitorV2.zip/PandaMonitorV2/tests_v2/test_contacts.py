"""Offline contact parser and request isolation checks; no real people/data."""
from __future__ import annotations

import asyncio
import json
from types import SimpleNamespace
import unittest

from curl_cffi.requests.exceptions import RequestException

from v2_contacts import Contact, ContactResult, MAX_CONTACT_BYTES, fetch_contacts


HSE_URL = "https://www.28hse.com/rent/apartment/property-1000001"
HOUSE_URL = "https://www.house730.com/rent-property-1000001/fixture/"


class Session:
    def __init__(self, payload=None, *, status=200, headers=None, body=None, error=None):
        self.calls = []
        self.error = error
        self.response = SimpleNamespace(
            status_code=status, headers=headers or {"Content-Type": "application/json"},
            content=body if body is not None else json.dumps(payload, ensure_ascii=False).encode("utf-8"),
        )

    async def request(self, method, target, **kwargs):
        self.calls.append((method, target, kwargs))
        if self.error is not None:
            raise self.error
        return self.response


def hse_payload(*parts):
    return {"status": 1, "data": {"results": {"contacts": list(parts)}}}


class ContactTests(unittest.IsolatedAsyncioTestCase):
    async def test_hse_form_and_request_headers_are_exact_without_list_secrets(self):
        session = Session(hse_payload('<div class="content_phone_information"><span class="contact-name">Fixture A</span>'
                                      '<a href="tel:+85291234567">Call</a></div>'))
        result = await fetch_contacts("28hse-rent", "1000001", HSE_URL, session, {
            "Cookie": "PRIVATE-COOKIE", "Authorization": "PRIVATE-AUTH", "AppSignature": "PRIVATE-SIGNATURE",
            "User-Agent": "PRIVATE-UA", "Content-Type": "application/json",
        })
        self.assertEqual((result.kind, result.status), ("ok", 200))
        self.assertEqual(result.contacts, (Contact("Fixture A", "91234567"),))
        method, target, options = session.calls[0]
        self.assertEqual((method, target), ("POST", "https://www.28hse.com/property/detail/doaction"))
        self.assertEqual(options["data"], {"action": "statistic_inc", "user_action": "phone", "ad_id": "1000001",
                                          "event_name": "property_contact_phone"})
        self.assertEqual(options["headers"]["Referer"], HSE_URL)
        self.assertFalse(options["allow_redirects"])
        self.assertNotIn("PRIVATE", str(options))

    async def test_house_get_uses_stable_headers_and_never_copies_list_signatures(self):
        session = Session({"code": 0, "result": [{"telphone": "+852 9123 4567", "isShowTel": True,
                                                  "contactNameCN": "測試甲", "contactNameEN": "Fixture A"}]})
        result = await fetch_contacts("house730-rent", "1000001", HOUSE_URL, session, {
            "AppKey": "fixture-key", "Language": "fixture-language", "Authorization": "fixture-auth",
            "AppSignature": "PRIVATE-SIGNATURE", "TimeStamp": "PRIVATE-TIMESTAMP",
            "Cookie": "PRIVATE-COOKIE", "User-Agent": "PRIVATE-UA", "X-Token": "PRIVATE-TOKEN",
        })
        self.assertEqual(result.contacts, (Contact("測試甲 Fixture A", "91234567"),))
        method, target, options = session.calls[0]
        self.assertEqual((method, target), ("GET", "https://api.house730.com/Property/GetPropertyUserInfoById"))
        self.assertEqual(options["params"], {"propertyId": "1000001"})
        self.assertNotIn("data", options)
        self.assertEqual(options["headers"]["AppKey"], "fixture-key")
        self.assertNotIn("PRIVATE", str(options))

    async def test_house_missing_detail_url_uses_known_list_referer(self):
        session = Session({"code": 0, "result": []})
        result = await fetch_contacts("house730-buy", "1000001", None, session, {})
        self.assertEqual(result.kind, "empty")
        self.assertEqual(session.calls[0][2]["headers"]["Referer"], "https://www.house730.com/buy/s1u14/")

    async def test_hidden_masked_fixed_line_arbitrary_digits_and_duplicates_are_rejected(self):
        values = [
            {"telphone": "91234567", "isShowTel": False},
            {"telphone": "92345678", "isShowTel": "false"},
            {"telphone": "93456789", "isShowTel": 0},
            {"telphone": "9123****"}, {"telphone": "token91234567"},
            {"telphone": "21234567"}, {"telphone": "31234567"},
            {"telphone": "94567890", "contactNameEN": "Fixture"},
            {"customerTel": "9456-7890", "contactNameEN": "Duplicate"},
        ]
        result = await fetch_contacts("house730-rent", "1000001", HOUSE_URL,
                                      Session({"code": 0, "result": values}), {})
        self.assertEqual(result.contacts, (Contact("Fixture", "94567890"),))

    async def test_hse_scope_names_and_mobile_filter_are_preserved(self):
        payload = hse_payload(
            '<div class="content_phone_information"><span class="contact-name">測試小姐</span> '
            '電話：9123-4567 <span class="contact-name">樣本先生</span> 電話：9234 5678</div>',
            '<div class="content_phone_information"><span class="person-name">Fixture C</span>'
            '<span class="fullPhone">93456789</span><a href="tel:93456789">Duplicate</a>'
            '<a href="tel:21234567">Landline</a><a href="tel:9123****">Masked</a>'
            '<span hidden><a href="tel:94567890">Hidden</a></span>'
            '<script>telephone="95678901"</script><div>random token 96789012</div></div>',
        )
        result = await fetch_contacts("28hse-rent", "1000001", HSE_URL, Session(payload), {})
        self.assertEqual(result.contacts, (Contact("測試小姐", "91234567"), Contact("樣本先生", "92345678"),
                                           Contact("Fixture C", "93456789")))

    async def test_nested_contact_blocks_do_not_borrow_another_contact_name(self):
        payload = hse_payload(
            '<div class="content_phone_information"><span class="contact-name">Fixture A</span>'
            '<a href="tel:91234567">Call</a><div class="content_phone_information">'
            '<a href="tel:92345678">Another person</a></div></div>',
            '<div style="display:none"><span style="display:none"><a href="tel:93456789">Hidden</a></span></div>',
        )
        result = await fetch_contacts("28hse-rent", "1000001", HSE_URL, Session(payload), {})
        self.assertEqual(result.contacts, (Contact("Fixture A", "91234567"), Contact("未提供", "92345678")))

    async def test_invalid_inputs_never_send_requests(self):
        for lane, pid, url in (
            ("other", "1000001", HSE_URL),
            ("28hse-rent", "x1000001", HSE_URL),
            ("28hse-rent", "1000001", HSE_URL.replace("1000001", "1000002")),
            ("28hse-buy", "1000001", HSE_URL),
            ("28hse-rent", "1000001", HSE_URL + "?token=PRIVATE"),
            ("28hse-rent", "1000001", HSE_URL + "\n"),
            ("house730-rent", "1000001", HOUSE_URL.replace("www.house730.com", "evil.invalid")),
            ("house730-rent", "1000001", HOUSE_URL.replace("1000001", "1000002")),
            ("house730-rent", True, None),
        ):
            with self.subTest(lane=lane, pid=pid):
                session = Session({})
                result = await fetch_contacts(lane, pid, url, session, {})
                self.assertEqual(result.kind, "invalid-input")
                self.assertEqual(session.calls, [])

    async def test_forbidden_rate_and_challenge_results_do_not_read_contact_data(self):
        for status, headers, expected in (
            (401, {}, "forbidden"), (403, {}, "forbidden"),
            (429, {"Retry-After": "31"}, "rate"),
            (200, {"cf-mitigated": "challenge"}, "challenge"),
            (503, {}, "http"),
        ):
            with self.subTest(status=status, expected=expected):
                session = Session({"PRIVATE": "PRIVATE-RESPONSE"}, status=status, headers=headers)
                result = await fetch_contacts("28hse-rent", "1000001", HSE_URL, session, {})
                self.assertEqual((result.status, result.kind, result.contacts), (status, expected, ()))
                if status == 429:
                    self.assertEqual(result.retry_after, "31")
                self.assertNotIn("PRIVATE", repr(result))

    async def test_hse_need_verify_does_not_extract_contacts(self):
        payload = hse_payload('<a href="tel:91234567">Call</a>')
        payload["data"]["results"]["need_verify"] = True
        result = await fetch_contacts("28hse-rent", "1000001", HSE_URL, Session(payload), {})
        self.assertEqual((result.kind, result.contacts), ("challenge", ()))

    async def test_wrong_status_identity_and_unexpected_shapes_are_rejected(self):
        payloads = [
            {"code": False, "result": [{"telphone": "91234567"}]},
            {"code": 1, "result": [{"telphone": "91234567"}]},
            {"code": 0, "propertyId": "1000002", "result": [{"telphone": "91234567"}]},
            {"code": 0, "result": {"contacts": [{"propertyId": "1000002", "telphone": "91234567"}]}},
            {"code": 0, "result": {"private": "91234567"}},
            {"code": 0, "result": "91234567"},
        ]
        for payload in payloads:
            with self.subTest(code=payload.get("code")):
                result = await fetch_contacts("house730-rent", "1000001", HOUSE_URL, Session(payload), {})
                self.assertEqual((result.kind, result.contacts), ("invalid", ()))
        for status in (0, True, "1"):
            payload = hse_payload('<a href="tel:91234567">Call</a>')
            payload["status"] = status
            result = await fetch_contacts("28hse-rent", "1000001", HSE_URL, Session(payload), {})
            self.assertEqual(result.kind, "invalid")

    async def test_invalid_oversized_and_challenge_bodies_are_classified_without_raw_values(self):
        for body, expected in (
            (b"PRIVATE-NOT-JSON", "invalid"),
            (b"<html>Verify you are human PRIVATE-COOKIE</html>", "challenge"),
            (b"x" * (MAX_CONTACT_BYTES + 1), "invalid"),
            (b'{"code":NaN,"result":[]}', "invalid"),
            (b'{"code":1,"code":0,"result":[]}', "invalid"),
            (b"\xffPRIVATE", "invalid"),
        ):
            with self.subTest(expected=expected):
                result = await fetch_contacts("house730-rent", "1000001", HOUSE_URL, Session(body=body), {})
                self.assertEqual(result.kind, expected)
                self.assertNotIn("PRIVATE", repr(result))

    async def test_json_with_an_unexpected_content_type_is_not_accepted(self):
        session = Session({"code": 0, "result": [{"telphone": "91234567"}]},
                          headers={"Content-Type": "text/html"})
        result = await fetch_contacts("house730-rent", "1000001", HOUSE_URL, session, {})
        self.assertEqual((result.kind, result.contacts), ("invalid", ()))

    async def test_network_errors_and_cancellation_do_not_expose_secrets(self):
        for error, code in ((RequestException("PRIVATE-TOKEN PRIVATE-PROXY", code=6), 6),
                            (asyncio.TimeoutError("PRIVATE-TOKEN"), None)):
            with self.subTest(code=code):
                result = await fetch_contacts("28hse-rent", "1000001", HSE_URL, Session(error=error), {})
                self.assertEqual((result.kind, result.error_code), ("network", code))
                self.assertNotIn("PRIVATE", repr(result))
        with self.assertRaises(asyncio.CancelledError):
            await fetch_contacts("28hse-rent", "1000001", HSE_URL, Session(error=asyncio.CancelledError()), {})

    async def test_contacts_and_retry_values_are_redacted_from_dataclass_repr(self):
        result = ContactResult((Contact("PRIVATE-NAME", "PRIVATE-PHONE"),), status=200,
                               kind="ok", retry_after="PRIVATE-RETRY")
        self.assertNotIn("PRIVATE", repr(result))
        self.assertNotIn("PRIVATE", repr(result.contacts[0]))


if __name__ == "__main__":
    unittest.main()
