"""V2 controller integration: genuine parsers/storage with offline HTTP fakes."""
from __future__ import annotations

import asyncio
from contextlib import closing
from http.cookiejar import CookieJar
import json
from pathlib import Path
import queue
import sqlite3
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import AsyncMock, patch

from async_crawler import Config, SiteState, USER_AGENTS
from capture_four_lanes import capture, prepare
from four_lane_crawler import BrowserCookie, LANES, LaneConfig, PreparedRun, SiteConfig
from listing_monitor import ListingMonitor
from v2_contacts import Contact, ContactResult
import v2_runtime as runtime


def house_page(*identifiers):
    return {"code": 0, "result": {"count": len(identifiers), "data": [
        {"propertyID": identifier, "titleWithCulture": "Fixture", "rentPrice": 1}
        for identifier in identifiers
    ]}}


def hse_page(*identifiers):
    return {"status": 1, "data": {"results": {
        "resultContentHtml": "".join(f'<a href="/rent/apartment/property-{identifier}">Fixture</a>'
                                      for identifier in identifiers),
        "resultData": {"ListingPaginator": {"page": 1, "count": len(identifiers)}},
    }}}


def configuration(names=("house730-rent",), *, cookies=(), interval=.02):
    sites = {LANES[name][0]: SiteConfig(LANES[name][0], user_agent=USER_AGENTS[0], cookies=cookies)
             for name in names}
    lanes = []
    for name in names:
        site, page_url = LANES[name]
        body = ("page=1&landlordAgency=%5B%22LANDLORD%22%5D&sortBy=latest"
                if site == "28hse" else '{"pageIndex":1,"searchText":"fixture"}')
        # Paths remain real provenance; no request is actually sent outside fakes.
        target = ("https://www.28hse.com/property/dosearch" if site == "28hse" else
                  "https://api.house730.com/Property/QueryProperty")
        config = Config(target + "?fixture=" + name, method="POST", raw_body=body,
                        headers={"Content-Type": "application/json"}, interval=interval,
                        user_agent=USER_AGENTS[0])
        lanes.append(LaneConfig(name, site, page_url, config))
    return PreparedRun(sites, lanes)


class Response:
    def __init__(self, payload, status=200):
        self.status_code = status
        self.headers = {}
        self.payload = payload

    def json(self):
        return self.payload


class Session:
    def __init__(self, action, options):
        self.action, self.options = action, options
        self.cookies = SimpleNamespace(jar=CookieJar())
        self.calls, self.closed = [], False

    async def __aenter__(self):
        return self

    async def __aexit__(self, *args):
        self.closed = True

    async def request(self, method, url, **kwargs):
        self.calls.append((method, url, kwargs))
        return await self.action(self, url, kwargs)


class RuntimeOptionsTests(unittest.TestCase):
    def test_default_cadence_and_fixed_secret_free_diagnostics(self):
        options = runtime.RuntimeOptions(cdp="9222", proxy="http://user:PRIVATE-PROXY@127.0.0.1:8080",
                                         clearance={"28hse": "PRIVATE-COOKIE"},
                                         user_agents={"28hse": USER_AGENTS[0]})
        self.assertEqual(options.intervals, {name: .5 for name in LANES})
        self.assertNotIn("PRIVATE-COOKIE", repr(options))
        self.assertNotIn("PRIVATE-PROXY", repr(options))
        self.assertEqual(runtime.normalize_cdp("9222"), "http://127.0.0.1:9222")
        for value in ("http://example.com:9222", "http://user:PRIVATE-CDP@127.0.0.1:9222", "0"):
            with self.assertRaises(ValueError) as caught:
                runtime.normalize_cdp(value)
            self.assertNotIn("PRIVATE-CDP", str(caught.exception))

    def test_cookie_override_preserves_body_and_unrelated_cookie_scope(self):
        original = configuration(cookies=(
            BrowserCookie("cf_clearance", "PRIVATE-OLD", ".house730.com"),
            BrowserCookie("session", "PRIVATE-SESSION", "api.house730.com", "/Property", True, 1999999999),
        ))
        options = runtime.RuntimeOptions(cdp="9222", intervals={"house730-rent": .125},
                                         selected_lanes=("house730-rent",),
                                         clearance={"house730": "PRIVATE-NEW"},
                                         user_agents={"house730": USER_AGENTS[0]})
        changed = runtime.apply_session_settings(original, options)
        self.assertEqual(changed.lanes[0].config.raw_body, original.lanes[0].config.raw_body)
        self.assertEqual(changed.lanes[0].config.interval, .125)
        self.assertEqual(original.sites["house730"].cookies[0].value, "PRIVATE-OLD")
        cookies = {item.name: item for item in changed.sites["house730"].cookies}
        self.assertEqual(cookies["cf_clearance"].value, "PRIVATE-NEW")
        self.assertEqual((cookies["session"].domain, cookies["session"].path, cookies["session"].expires),
                         ("api.house730.com", "/Property", 1999999999))

    def test_random_ua_is_chosen_once_per_site_and_refused_with_clearance(self):
        names = ("house730-rent", "house730-buy")
        options = runtime.RuntimeOptions(cdp="9222", user_agents={"house730": "random"})
        with patch.object(runtime.random, "choice", return_value=USER_AGENTS[1]) as choose:
            changed = runtime.apply_session_settings(configuration(names), options)
        choose.assert_called_once_with(USER_AGENTS)
        self.assertEqual({lane.config.user_agent for lane in changed.lanes}, {USER_AGENTS[1]})
        authenticated = configuration(names, cookies=(BrowserCookie("cf_clearance", "PRIVATE", ".house730.com"),))
        with self.assertRaises(ValueError):
            runtime.apply_session_settings(authenticated, options)


class RuntimeFlowTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory(prefix="panda-v2-runtime-")
        self.addCleanup(temporary.cleanup)
        self.folder = Path(temporary.name)
        self.sessions = []

    def options(self, names=("house730-rent",), **changes):
        values = dict(cdp="9222", selected_lanes=names,
                      intervals={name: .02 for name in names}, data_dir=self.folder)
        values.update(changes)
        return runtime.RuntimeOptions(**values)

    def factory(self, action):
        def create(**options):
            session = Session(action, options)
            self.sessions.append(session)
            return session
        return create

    async def collect_until_contact(self, controller):
        events = []
        while True:
            try:
                event = controller.events.get_nowait()
            except queue.Empty:
                await asyncio.sleep(.005)
                continue
            events.append(event)
            if event["type"] == "contacts":
                controller.ack_contacts(event["job_id"])
                # The ACK is deliberately posted to the owning event loop.
                await asyncio.sleep(.02)
                controller.stop()
                return events

    async def test_new_listing_flows_to_durable_phone_job_and_gui_ack_once(self):
        calls = 0
        contact_calls = []

        async def action(session, url, request):
            nonlocal calls
            calls += 1
            await asyncio.sleep(.001)
            return Response(house_page(1000001) if calls == 1 else house_page(1000001, 1000002))

        async def contacts(lane, pid, url, session, headers, timeout):
            contact_calls.append((lane, pid, url, session))
            return ContactResult((Contact("Fixture", "61234567"),), 200, "ok")

        controller = runtime.MonitorController(self.options())
        prepared = configuration(cookies=(BrowserCookie("cf_clearance", "PRIVATE-SESSION-COOKIE", ".house730.com"),))
        with patch.object(runtime, "AsyncSession", side_effect=self.factory(action)), \
             patch.object(runtime, "fetch_contacts", side_effect=contacts):
            events, _ = await asyncio.wait_for(asyncio.gather(
                self.collect_until_contact(controller), controller.run_prepared(prepared),
            ), 3)
        discoveries = [event for event in events if event["type"] == "listing"]
        self.assertEqual([event["listing_id"] for event in discoveries], ["1000002"])
        self.assertEqual([call[1] for call in contact_calls], ["1000002"])
        self.assertIs(contact_calls[0][3], self.sessions[0])
        self.assertEqual(contact_calls[0][2], "https://www.house730.com/rent-property-1000002/")
        self.assertTrue(all(call[2]["data"] == prepared.lanes[0].config.raw_body.encode("utf-8")
                            for call in self.sessions[0].calls))
        self.assertEqual(self.sessions[0].options["headers"]["User-Agent"], USER_AGENTS[0])
        from urllib.request import Request
        probe = Request("https://api.house730.com/Property/QueryProperty")
        self.sessions[0].cookies.jar.add_cookie_header(probe)
        self.assertEqual(probe.get_header("Cookie"), "cf_clearance=PRIVATE-SESSION-COOKIE")
        with closing(sqlite3.connect(self.folder / "seen.sqlite3")) as database:
            self.assertEqual(database.execute("SELECT listing_id,status FROM monitor_contact_jobs").fetchall(),
                             [("1000002", "done")])
            self.assertEqual(database.execute("SELECT COUNT(*) FROM monitor_events").fetchone()[0], 1)
        self.assertNotIn(b"PRIVATE-SESSION-COOKIE", (self.folder / "seen.sqlite3").read_bytes())
        self.assertTrue(self.sessions[0].closed)
        self.assertEqual(controller._states["house730"].in_flight, 0)

    async def test_unacknowledged_job_resumes_after_controller_restart(self):
        prepared = configuration()
        first = ListingMonitor(prepared, state_path=self.folder / "seen.sqlite3", queue_contacts=True)
        await first("house730-rent", house_page(1000001), 1)
        discovery = await first("house730-rent", house_page(1000001, 1000002), 2)
        job = first.claim_contacts()[0]
        self.assertEqual(job["job_id"], discovery[0]["job_id"])
        first.close()  # The old process has released its unacknowledged lease.

        async def action(session, url, request):
            return Response(house_page(1000001, 1000002))

        controller = runtime.MonitorController(self.options())
        contacts = AsyncMock(return_value=ContactResult((Contact("Fixture", "61234567"),), 200, "ok"))
        with patch.object(runtime, "AsyncSession", side_effect=self.factory(action)), \
             patch.object(runtime, "fetch_contacts", contacts):
            events, _ = await asyncio.wait_for(asyncio.gather(
                self.collect_until_contact(controller), controller.run_prepared(prepared),
            ), 3)
        self.assertEqual([event for event in events if event["type"] == "listing"], [])
        contacts.assert_awaited_once()
        with closing(sqlite3.connect(self.folder / "seen.sqlite3")) as database:
            self.assertEqual(database.execute("SELECT status,attempts FROM monitor_contact_jobs").fetchone(), ("done", 2))

    async def test_list_403_alerts_once_and_other_site_keeps_monitoring(self):
        names = ("28hse-rent", "28hse-buy", "house730-rent", "house730-buy")

        async def action(session, url, request):
            await asyncio.sleep(.002)
            return Response({}, 403) if "28hse" in url else Response(house_page(1000001))

        controller = runtime.MonitorController(self.options(names, phone_enabled=False))
        with patch.object(runtime, "AsyncSession", side_effect=self.factory(action)), \
             self.assertLogs("crawler", level="ERROR"):
            await asyncio.wait_for(controller.run_prepared(configuration(names), max_requests=5), 2)
        events = []
        while not controller.events.empty():
            events.append(controller.events.get_nowait())
        alerts = [event for event in events if event["type"] == "alert"]
        self.assertEqual(len(alerts), 1)
        self.assertEqual((alerts[0]["site"], alerts[0]["kind"]), ("28hse", "403"))
        self.assertIn("cf_clearance", alerts[0]["text"])
        self.assertEqual(controller._crawlers["house730-rent"].stats.succeeded, 5)
        self.assertEqual(controller._crawlers["house730-buy"].stats.succeeded, 5)
        self.assertEqual(controller._crawlers["28hse-rent"].stats.started, 1)
        self.assertTrue(all(session.closed for session in self.sessions))

    async def test_contact_403_keeps_job_pending_and_alerts_without_returning_contacts(self):
        prepared = configuration()
        monitor = ListingMonitor(prepared, state_path=self.folder / "seen.sqlite3", queue_contacts=True)
        self.addCleanup(monitor.close)
        await monitor("house730-rent", house_page(1000001), 1)
        await monitor("house730-rent", house_page(1000001, 1000002), 2)
        job = monitor.claim_contacts()[0]
        controller = runtime.MonitorController(self.options())
        controller._monitor = monitor
        controller._states = {"house730": SiteState()}
        controller._sessions = {"house730": object()}
        controller._phone_gate = asyncio.Semaphore(1)
        controller._in_phone.add(job["job_id"])
        with patch.object(runtime, "fetch_contacts", AsyncMock(return_value=ContactResult(status=403, kind="forbidden"))):
            await controller._lookup(job)
        self.assertTrue(controller._states["house730"].stop.is_set())
        self.assertNotIn(job["job_id"], controller._in_phone)
        events = []
        while not controller.events.empty():
            events.append(controller.events.get_nowait())
        self.assertEqual([event["kind"] for event in events if event["type"] == "alert"], ["403"])
        self.assertFalse(any(event["type"] == "contacts" for event in events))
        self.assertEqual(monitor._db.execute("SELECT status FROM monitor_contact_jobs").fetchone(), ("pending",))

    async def test_auxiliary_failure_stops_list_requests_and_closes_resources(self):
        async def action(session, url, request):
            await asyncio.Event().wait()

        async def failing_dispatch():
            await asyncio.sleep(.01)
            raise RuntimeError("PRIVATE-INTERNAL-FAILURE")

        controller = runtime.MonitorController(self.options())
        with patch.object(runtime, "AsyncSession", side_effect=self.factory(action)), \
             patch.object(controller, "_dispatch_contacts", side_effect=failing_dispatch):
            with self.assertRaises(RuntimeError):
                await asyncio.wait_for(controller.run_prepared(configuration()), 1)
        self.assertTrue(all(session.closed for session in self.sessions))
        self.assertEqual(controller._states["house730"].in_flight, 0)
        self.assertIsNone(controller._monitor)

    async def test_stop_cancels_inflight_requests_and_closes_sessions(self):
        entered = asyncio.Event()
        canceled = asyncio.Event()

        async def action(session, url, request):
            entered.set()
            try:
                await asyncio.Event().wait()
            finally:
                canceled.set()

        controller = runtime.MonitorController(self.options(phone_enabled=False))
        with patch.object(runtime, "AsyncSession", side_effect=self.factory(action)):
            runner = asyncio.create_task(controller.run_prepared(configuration()))
            await asyncio.wait_for(entered.wait(), 1)
            controller.stop()
            await asyncio.wait_for(runner, 1)
        self.assertTrue(canceled.is_set())
        self.assertTrue(all(session.closed for session in self.sessions))
        self.assertEqual(controller._states["house730"].in_flight, 0)
        self.assertIsNone(controller._monitor)

    async def test_stop_while_capturing_detaches_without_closing_browser(self):
        entered, canceled, detached = asyncio.Event(), asyncio.Event(), asyncio.Event()
        browser = SimpleNamespace(close=AsyncMock())

        class Playwright:
            async def __aenter__(self):
                return SimpleNamespace(chromium=SimpleNamespace(connect_over_cdp=AsyncMock(return_value=browser)))

            async def __aexit__(self, *args):
                detached.set()

        async def waiting_capture(actual_browser, *args, **kwargs):
            self.assertIs(actual_browser, browser)
            entered.set()
            try:
                await asyncio.Event().wait()
            finally:
                canceled.set()

        controller = runtime.MonitorController(self.options())
        with patch("playwright.async_api.async_playwright", return_value=Playwright()), \
             patch.object(runtime, "capture", side_effect=waiting_capture):
            runner = asyncio.create_task(controller._run())
            await asyncio.wait_for(entered.wait(), 1)
            controller.stop()
            await asyncio.wait_for(runner, 1)
        self.assertTrue(canceled.is_set())
        self.assertTrue(detached.is_set())
        browser.close.assert_not_awaited()

    async def test_partial_capture_only_needs_selected_tab_and_prepares_its_site(self):
        from tests_crawler.test_capture_decode import Browser, valid_frames
        browser = Browser(valid_frames())
        browser.contexts[0].pages = [page for page in browser.contexts[0].pages if page.lane == "28hse-rent"]
        observations = await capture(browser, 2, selected_lanes=("28hse-rent",))
        self.assertEqual(set(observations), {"28hse-rent"})
        prepared = prepare(observations, selected_lanes=("28hse-rent",))
        self.assertEqual(set(prepared.sites), {"28hse"})
        self.assertEqual([lane.name for lane in prepared.lanes], ["28hse-rent"])
        self.assertTrue(all(not page.listeners for page in browser.contexts[0].pages))


if __name__ == "__main__":
    unittest.main()
