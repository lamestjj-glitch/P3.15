"""V2 dashboard contracts, without browsers, external requests or real secrets."""
from __future__ import annotations

import json
import os
from pathlib import Path
import queue
import re
import tempfile
import threading
from types import MethodType, SimpleNamespace
import unittest
from unittest.mock import Mock, patch

_IMPORT_DATA = tempfile.TemporaryDirectory(prefix="pandamonitor-v2-gui-import-")
os.environ.setdefault("PANDAMONITOR_V2_DATA_DIR", _IMPORT_DATA.name)

import v2_gui as gui
from v2_runtime import RuntimeOptions


class Variable:
    def __init__(self, value=""):
        self.value = value

    def get(self):
        if threading.current_thread() is not threading.main_thread():
            raise AssertionError("Tk variables must only be read on the main thread")
        return self.value

    def set(self, value):
        self.value = value


def settings_app():
    app = SimpleNamespace(
        VERSION="2.0.0", cdp_base=None, v2_cdp=Variable("56941"),
        v2_intervals={lane: Variable("0.5") for lane in gui.LANE_LABELS},
        v2_timeout=Variable("20"), v2_concurrency=Variable("8"),
        v2_capture_seconds=Variable("120"), v2_phone_enabled=Variable(True),
        v2_phone_concurrency=Variable("2"), v2_proxy_protocol=Variable("socks5"),
        v2_proxy_host=Variable(""), v2_proxy_port=Variable(""),
        v2_proxy_username=Variable(""), v2_proxy_password=Variable(""),
        v2_clearance={site: Variable("") for site in gui.SITE_LABELS},
        v2_user_agent={site: Variable("auto") for site in gui.SITE_LABELS},
        v2_impersonate={site: Variable("auto") for site in gui.SITE_LABELS},
        v2_random_ua=Variable(False), rent=Variable(True), buy=Variable(True),
        house_rent=Variable(True), house_buy=Variable(True), write=Mock(),
    )
    for name in ("_flags", "_plain_settings", "_settings_path", "_runtime_options"):
        setattr(app, name, MethodType(getattr(gui.PandaMonitorV2App, name), app))
    return app


def event_app():
    cards = {lane: Variable() for lane in gui.LANE_LABELS}
    app = SimpleNamespace(
        _v2_controller=SimpleNamespace(ack_contacts=Mock(), is_alive=lambda: True),
        _v2_lane_stats={}, _v2_tests={}, _v2_selected=tuple(gui.LANE_LABELS),
        _v2_phase="", running=True, lock=threading.Lock(),
        http_stats={trade: {"last_ok": 0.0, "polls": 0} for trade in ("rent", "buy")},
        house_queries=Variable(), house_status=Variable(), api_pause_banner=Variable(),
        _cards=lambda: cards, write=Mock(), toast=Mock(), set_monitor_controls=Mock(),
        normalize_phone=lambda value: re.sub(r"\D", "", str(value or "")),
        result=Mock(return_value=(True, "saved")), note_wa_phone_contact=Mock(),
        phone_lock=threading.Lock(), seen_phones=set(), pending_copy_phones=set(),
        publish_secondary_phone=Mock(return_value=True), hse28_history=SimpleNamespace(save=Mock(return_value=True)),
        house_store=SimpleNamespace(save_phone=Mock(return_value=True)),
        _new_house_result=Mock(), copy_auto_tail_with_defer=Mock(), test_popup=Mock(),
        _show_house_extra_contact=Mock(), extend_auto_clipboard_group=Mock(),
        bg=Mock(), _house_test_wa_job=Mock(),
    )
    app._apply_contacts = MethodType(gui.PandaMonitorV2App._apply_contacts, app)
    app._listing_row = Mock()
    return app


class SettingsTests(unittest.TestCase):
    def test_cdp_accepts_only_local_debugger_addresses(self):
        self.assertEqual(gui.cdp_address("56941"), "http://127.0.0.1:56941")
        self.assertEqual(gui.cdp_address("ws://localhost:9222/devtools/browser/fixture"),
                         "ws://localhost:9222/devtools/browser/fixture")
        for address in ("", "0", "65536", "http://example.invalid:9222", "http://user:PRIVATE@localhost:9222",
                        "http://localhost:9222/?token=PRIVATE", "file:///PRIVATE"):
            with self.subTest(kind=address.split(":", 1)[0]):
                with self.assertRaises(ValueError) as caught:
                    gui.cdp_address(address)
                self.assertNotIn("PRIVATE", str(caught.exception))

    def test_four_lane_defaults_are_snapshotted_into_runtime_options(self):
        app = settings_app()
        options = app._runtime_options()
        self.assertEqual(options.cdp, "http://127.0.0.1:56941")
        self.assertEqual(options.intervals, {lane: .5 for lane in gui.LANE_LABELS})
        self.assertEqual(set(options.selected_lanes), set(gui.LANE_LABELS))
        self.assertEqual((options.timeout, options.concurrency), (20, 8))
        self.assertTrue(options.phone_enabled)
        self.assertEqual(options.user_agents, {})
        self.assertTrue(all(not isinstance(value, Variable) for value in options.intervals.values()))

    def test_explicit_proxy_cookie_ua_are_in_memory_only(self):
        app = settings_app()
        app.house_buy.set(False)
        app.v2_proxy_host.set("127.0.0.1")
        app.v2_proxy_port.set("1080")
        app.v2_proxy_username.set("PRIVATE-USER")
        app.v2_proxy_password.set("PRIVATE-PASSWORD@")
        app.v2_clearance["28hse"].set("PRIVATE-COOKIE")
        app.v2_user_agent["28hse"].set("PRIVATE-UA")
        options = app._runtime_options()
        self.assertEqual(options.proxy, "socks5h://PRIVATE-USER:PRIVATE-PASSWORD%40@127.0.0.1:1080")
        self.assertEqual(options.clearance, {"28hse": "PRIVATE-COOKIE"})
        self.assertNotIn("house730-buy", options.selected_lanes)
        with tempfile.TemporaryDirectory(prefix="pandamonitor-v2-settings-") as directory, \
             patch.object(gui, "data_root", return_value=Path(directory)):
            gui.PandaMonitorV2App._save_v2_settings(app)
            text = (Path(directory) / "v2_settings.json").read_text()
        self.assertNotIn("PRIVATE", text)
        self.assertNotIn("proxy", text)
        self.assertNotIn("clearance", text)
        self.assertNotIn("user_agent", text)
        self.assertNotIn("cdp", text)
        self.assertEqual(json.loads(text)["intervals"]["28hse-rent"], .5)

    def test_random_ua_is_explicit_and_conflicting_manual_settings_reject(self):
        app = settings_app()
        app.v2_random_ua.set(True)
        self.assertEqual(app._runtime_options().user_agents, {site: "random" for site in gui.SITE_LABELS})
        app.v2_clearance["28hse"].set("PRIVATE-COOKIE")
        with self.assertRaises(ValueError) as caught:
            app._runtime_options()
        self.assertNotIn("PRIVATE", str(caught.exception))

    def test_bad_numbers_and_empty_selection_do_not_start_networking(self):
        app = settings_app()
        for value in ("0", "nan", "inf", "-1"):
            app.v2_intervals["28hse-rent"].set(value)
            with self.assertRaises(ValueError):
                app._runtime_options()
        app.v2_intervals["28hse-rent"].set(".5")
        for variable in app._flags().values():
            variable.set(False)
        with self.assertRaises(ValueError):
            app._runtime_options()


class LifecycleTests(unittest.TestCase):
    def test_start_constructs_only_new_controller_and_never_legacy_workers(self):
        options = RuntimeOptions(cdp="http://127.0.0.1:56941", intervals={lane: .5 for lane in gui.LANE_LABELS},
                                 selected_lanes=("28hse-rent", "house730-rent"))
        cards = {lane: Variable() for lane in gui.LANE_LABELS}
        app = SimpleNamespace(
            _v2_controller=None, _runtime_options=lambda: options, _save_v2_settings=Mock(),
            _v2_lane_stats={}, _v2_tests={}, run_id=0, lock=threading.Lock(),
            http_stats={trade: {"last_ok": 100} for trade in ("rent", "buy")},
            http_latest={"rent": ["old"], "buy": ["old"]}, api_paused={"rent": "old", "buy": "old"},
            api_pause_banner=Variable(), _cards=lambda: cards, extra_sites=[],
            write=Mock(), set_monitor_controls=Mock(), bg=Mock(), bootstrap=Mock(),
        )
        controller = Mock()
        controller.is_alive.return_value = True
        with patch.object(gui, "MonitorController", return_value=controller) as factory, \
             patch.object(gui.UnifiedApp, "start", side_effect=AssertionError("legacy start forbidden")):
            gui.PandaMonitorV2App.start(app)
        factory.assert_called_once_with(options)
        controller.start.assert_called_once_with()
        app.bg.assert_not_called()
        app.bootstrap.assert_not_called()
        self.assertTrue(app.running)
        self.assertEqual(app.run_id, 1)
        self.assertEqual(app.http_stats["rent"]["last_ok"], 0)
        self.assertEqual(app.api_source_enabled, {"rent": True, "buy": False})
        self.assertEqual(cards["28hse-buy"].get(), "未啟用")

    def test_stop_and_close_do_not_invoke_old_browser_workers(self):
        app = SimpleNamespace(
            _v2_controller=Mock(), running=True, run_id=1, _allow_system_sleep=Mock(),
            api_pause_banner=Variable(), _cards=lambda: {"one": Variable()},
            house_status=Variable(), set_monitor_controls=Mock(),
        )
        with patch.object(gui.UnifiedApp, "stop", side_effect=AssertionError("legacy stop forbidden")):
            gui.PandaMonitorV2App.stop(app)
        app._v2_controller.stop.assert_called_once()
        self.assertFalse(app.running)
        app._v2_closed = False
        app.site_manager = None
        app._v2_controller.is_alive.return_value = False
        app.stop = Mock()
        app._save_v2_settings = Mock()
        app.destroy = Mock()
        app._finish_close = MethodType(gui.PandaMonitorV2App._finish_close, app)
        gui.PandaMonitorV2App.on_close(app)
        app.stop.assert_called_once()
        app.destroy.assert_called_once()
        self.assertTrue(app._v2_closed)

    def test_close_waits_nonblocking_for_controller_cleanup(self):
        controller = SimpleNamespace(is_alive=Mock(side_effect=[True, False, False]))
        app = SimpleNamespace(_v2_closed=False, _v2_controller=controller,
            stop=Mock(), site_manager=None, _save_v2_settings=Mock(), destroy=Mock(),
            after=Mock(), write=Mock())
        app._finish_close = MethodType(gui.PandaMonitorV2App._finish_close, app)
        gui.PandaMonitorV2App.on_close(app)
        app.destroy.assert_not_called()
        self.assertEqual(app.after.call_args.args[0], 50)
        app.after.call_args.args[1]()
        app.destroy.assert_called_once_with()
        app.stop.assert_called_once_with()

    def test_old_api_button_routes_to_controller_on_main_thread(self):
        app = SimpleNamespace(_request_test=Mock(), after=Mock())
        gui.PandaMonitorV2App.api_test_28(app, "rent")
        app._request_test.assert_called_once_with("28hse-rent")
        app._request_test.reset_mock()
        with patch.object(gui.threading, "current_thread", return_value=object()):
            gui.PandaMonitorV2App.api_test_28(app, "buy")
        app._request_test.assert_not_called()
        app.after.call_args.args[1]()
        app._request_test.assert_called_once_with("28hse-buy")

    def test_event_poll_drains_controller_queue_without_legacy_tick(self):
        events = queue.Queue()
        events.put({"type": "phase", "phase": "capture"})
        app = SimpleNamespace(_v2_closed=False,
            _v2_controller=SimpleNamespace(events=events), running=True,
            _apply_event=Mock(), write=Mock(), set_monitor_controls=Mock(),
            winfo_exists=lambda: True, after=Mock())
        app._house_tick = MethodType(gui.PandaMonitorV2App._house_tick, app)
        with patch.object(gui.UnifiedApp, "_house_tick", side_effect=AssertionError("legacy tick forbidden")):
            gui.PandaMonitorV2App._house_tick(app)
        app._apply_event.assert_called_once_with({"type": "phase", "phase": "capture"})
        self.assertEqual(app.after.call_args.args[0], 150)


class EventTests(unittest.TestCase):
    def test_successful_hse_contacts_use_existing_result_then_ack(self):
        app = event_app()
        event = {"type": "contacts", "lane": "28hse-rent", "listing_id": "1000001",
                 "url": "https://www.28hse.com/rent/apartment/property-1000001",
                 "contacts": [{"name": "Fixture", "phone": "81234567"},
                              {"name": "Other", "phone": "91234567"}], "job_id": 12}
        order = []
        app.result.side_effect = lambda *args, **kw: order.append("saved")
        app._v2_controller.ack_contacts.side_effect = lambda job: order.append(("ack", job))
        app._apply_contacts(event)
        self.assertEqual(order, ["saved", ("ack", 12)])
        self.assertEqual(app.result.call_args.kwargs["extra_phones"], event["contacts"][1:])
        self.assertFalse(app.result.call_args.kwargs["test_mode"])
        app.publish_secondary_phone.assert_called_once_with("rent", event["url"], "Other", "91234567")
        self.assertEqual(app.hse28_history.save.call_count, 2)

    def test_duplicate_primary_does_not_hide_a_new_hse_secondary(self):
        app = event_app()
        app.seen_phones.add("81234567")
        event = {"lane": "28hse-rent", "job_id": 13,
                 "url": "https://www.28hse.com/rent/apartment/property-1000001",
                 "contacts": [{"name": "Existing", "phone": "81234567"},
                              {"name": "Fresh", "phone": "91234567"}]}
        app._apply_contacts(event)
        self.assertEqual(app.result.call_args.args[:3], ("rent", "Fresh", "91234567"))
        app.publish_secondary_phone.assert_not_called()
        app.hse28_history.save.assert_called_once_with("rent", event["url"], "91234567", "Fresh", is_extra=False)
        app._v2_controller.ack_contacts.assert_called_once_with(13)

    def test_all_house_contacts_are_committed_before_job_ack(self):
        app = event_app()
        order = []
        app.house_store.save_phone.side_effect = lambda *args: order.append(("commit", args[2])) or True
        app._new_house_result.side_effect = lambda data: order.append(("primary", data["phone"]))
        app._show_house_extra_contact.side_effect = lambda data: order.append(("extra", data["phone"]))
        app._v2_controller.ack_contacts.side_effect = lambda job: order.append(("ack", job))
        app._apply_contacts({"lane": "house730-buy", "listing_id": "1000001", "job_id": 14,
            "url": "https://www.house730.com/buy-property-1000001/",
            "contacts": [{"name": "First", "phone": "81234567"},
                         {"name": "Second", "phone": "91234567"},
                         {"name": "Duplicate", "phone": "91234567"}]})
        self.assertEqual(order, [("commit", "81234567"), ("primary", "81234567"),
                                 ("commit", "91234567"), ("extra", "91234567"), ("ack", 14)])
        app.extend_auto_clipboard_group.assert_called_once_with(("730", "售", "1000001"), "4567\n4567")

    def test_secondary_history_failure_leaves_hse_job_unacknowledged(self):
        app = event_app()
        app.hse28_history.save.side_effect = OSError("fixture history failure")
        with self.assertRaises(OSError):
            app._apply_contacts({"lane": "28hse-rent", "job_id": 15,
                "url": "https://www.28hse.com/rent/apartment/property-1000001",
                "contacts": [{"name": "Fixture", "phone": "81234567"}]})
        app._v2_controller.ack_contacts.assert_not_called()
        app.result.assert_not_called()

    def test_house_contacts_are_committed_before_showing_and_ack(self):
        app = event_app()
        order = []
        app.house_store.save_phone.side_effect = lambda *args: order.append("commit") or True
        app._new_house_result.side_effect = lambda event: order.append("show")
        app._v2_controller.ack_contacts.side_effect = lambda job: order.append("ack")
        app._apply_contacts({"lane": "house730-buy", "listing_id": "1000001", "job_id": 9,
            "url": "https://www.house730.com/buy-property-1000001/",
            "contacts": [{"name": "Fixture", "phone": "81234567"}],
            "first_seen_at": "2026-10-20T10:00:00+07:00"})
        self.assertEqual(order, ["commit", "show", "ack"])
        self.assertEqual(app._new_house_result.call_args.args[0]["deal"], "售")

    def test_failed_contact_processing_does_not_ack_durable_job(self):
        app = event_app()
        app.result.side_effect = OSError("fixture persistence failure")
        with self.assertRaises(OSError):
            app._apply_contacts({"lane": "28hse-rent", "job_id": 4, "url": "https://www.28hse.com/rent/apartment/property-1000001",
                                 "contacts": [{"phone": "81234567"}]})
        app._v2_controller.ack_contacts.assert_not_called()

    def test_test_phone_does_not_commit_or_ack_production_job(self):
        app = event_app()
        app._apply_contacts({"lane": "house730-rent", "test_mode": True, "job_id": 5,
                             "url": "https://www.house730.com/rent-property-1000001/",
                             "contacts": [{"name": "Fixture", "phone": "81234567"}]})
        app.house_store.save_phone.assert_not_called()
        app._new_house_result.assert_not_called()
        app._v2_controller.ack_contacts.assert_not_called()
        app.copy_auto_tail_with_defer.assert_called_once_with("81234567")

    def test_lane_event_shows_current_valid_response_counts(self):
        app = event_app()
        gui.PandaMonitorV2App._apply_event(app, {"type": "lane", "lane": "28hse-rent",
            "status": "監控中", "valid": 4, "started": 6, "failed": 1, "last_ok": 123.0})
        self.assertIn("有效 4", app._cards()["28hse-rent"].get())
        self.assertEqual(app.http_stats["rent"]["last_ok"], 123)
        gui.PandaMonitorV2App._apply_event(app, {"type": "alert", "site": "28hse", "kind": "403",
            "text": "HTTP 403：Cookie 可能失效；同站已停止，請人工確認。"})
        self.assertIn("403", app.api_pause_banner.get())
        app.toast.assert_called_once()


@unittest.skipUnless(os.environ.get("DISPLAY"), "Real Tk smoke requires an available display")
class RealTkSmokeTests(unittest.TestCase):
    def test_dashboard_opens_with_masked_secrets_and_new_version(self):
        with tempfile.TemporaryDirectory(prefix="pandamonitor-v2-tk-") as directory, \
             patch.object(gui, "data_root", return_value=Path(directory)):
            app = gui.PandaMonitorV2App()
            try:
                app.update_idletasks()
                self.assertIn("PandaMonitorV2", app.title())
                self.assertEqual(app.VERSION, "2.0.0")
                self.assertFalse(app.wa_enable.get())
                self.assertFalse(app.wa_730_enable.get())
                self.assertEqual(app.v2_intervals["28hse-rent"].get(), "0.5")
                self.assertEqual(app.tabs.tab(app.sites_tab, "state"), "hidden")
                self.assertTrue(any("通知與原版設定" in app.tabs.tab(tab, "text")
                                    for tab in app.tabs.tabs()))
                all_widgets = []
                def visit(widget):
                    all_widgets.append(widget)
                    for child in widget.winfo_children():
                        visit(child)
                visit(app)
                masked = [widget for widget in all_widgets if isinstance(widget, gui.ttk.Entry)
                          and str(widget.cget("show")) == "*"]
                self.assertGreaterEqual(len(masked), 4)
            finally:
                app.on_close()


if __name__ == "__main__":
    unittest.main()
