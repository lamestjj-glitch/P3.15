"""Parse House730's verified primary listing array without traversing adverts."""
from __future__ import annotations

import math
import re
from typing import Any
from urllib.parse import unquote, urljoin, urlsplit, urlunsplit

from listing_types import Listing, ListingPage, ListingParseError


LANES = {"house730-rent": "rent", "house730-buy": "buy"}
PLACEHOLDERS = {
    "[string]", "[strings]", "[redacted]", "[text]", "[value]", "[structure limit]",
}


def _listing_id(value: Any) -> str:
    if isinstance(value, bool):
        raise ListingParseError("House730 房源 ID 無效，未接受本次列表。")
    if isinstance(value, int) and 0 < value < 10 ** 20:
        return str(value)
    if isinstance(value, str) and re.fullmatch(r"[0-9]{1,20}", value):
        normalized = value.lstrip("0")
        if normalized:
            return normalized
    raise ListingParseError("House730 房源 ID 無效，未接受本次列表。")


def _public_url(value: Any, trade: str, listing_id: str) -> str | None:
    if not isinstance(value, str) or not value.strip() or any(ord(char) < 32 or ord(char) == 127 for char in value):
        return None
    try:
        parsed = urlsplit(urljoin("https://www.house730.com/", value.strip()))
        if (parsed.scheme != "https" or parsed.hostname not in {"house730.com", "www.house730.com"}
                or parsed.username is not None or parsed.password is not None
                or parsed.port not in (None, 443)):
            return None
        if any(unquote(part) in {".", ".."} or "\\" in unquote(part) for part in parsed.path.split("/")):
            return None
        match = re.match(r"^/(rent|buy)-property-([0-9]+)(?=$|/|\.html?(?:/|$))", parsed.path)
        if not match or match[1] != trade or match[2].lstrip("0") != listing_id:
            return None
        return urlunsplit(("https", parsed.netloc.lower(), parsed.path, "", ""))
    except (ValueError, TypeError):
        return None


def _title(value: Any) -> str | None:
    if not isinstance(value, str):
        return None
    title = " ".join(value.split())
    title = "".join(character for character in title if character.isprintable())
    if not title or title.lower() in PLACEHOLDERS:
        return None
    return title[:300]


def _price(value: Any) -> int | float | None:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return None
    if isinstance(value, float) and not math.isfinite(value):
        return None
    return value if value >= 0 else None


def parse_listings(lane: str, payload: Any) -> ListingPage:
    """Accept one primary page; reject malformed batches before establishing IDs."""
    trade = LANES.get(lane)
    if trade is None:
        raise ListingParseError("House730 路線無效。")
    if not isinstance(payload, dict) or type(payload.get("code")) is not int or payload["code"] != 0:
        raise ListingParseError("House730 未回傳成功列表，未更新監控狀態。")
    result = payload.get("result")
    if not isinstance(result, dict) or not isinstance(result.get("data"), list):
        raise ListingParseError("House730 列表結構無效，未更新監控狀態。")
    total = result.get("count")
    if type(total) is not int or total < 0:
        raise ListingParseError("House730 列表總數無效，未更新監控狀態。")
    rows = result["data"]
    if total > 0 and not rows:
        raise ListingParseError("House730 第一頁總數與空列表不一致，未更新監控狀態。")
    listings = []
    seen = set()
    for row in rows:
        if not isinstance(row, dict):
            raise ListingParseError("House730 房源記錄無效，未接受本次列表。")
        listing_id = _listing_id(row.get("propertyID"))
        if listing_id in seen:
            continue
        seen.add(listing_id)
        listings.append(Listing(
            listing_id=listing_id,
            url=_public_url(row.get("url"), trade, listing_id),
            title=_title(row.get("titleWithCulture")),
            price=_price(row.get("rentPrice" if trade == "rent" else "salePrice")),
        ))
    if total < len(listings):
        raise ListingParseError("House730 列表總數與房源筆數不一致，未更新監控狀態。")
    # currentIndex was not retained by the anonymizer and its indexing contract
    # has not been established. The captured request is checked by the monitor.
    return ListingPage(tuple(listings), page=None, total=total)
