"""Fixed-cadence asyncio polling with curl_cffi; Python 3.12+."""
from __future__ import annotations

import argparse
import asyncio
from contextlib import AsyncExitStack
from dataclasses import dataclass, field
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
import logging
import math
import os
from pathlib import Path
import random
import re
import json
from typing import Any, Awaitable, Callable
from urllib.parse import urlsplit

from curl_cffi import CurlOpt
from curl_cffi.requests import AsyncSession
from curl_cffi.requests.exceptions import RequestException

LOG = logging.getLogger("crawler")
DNS_BACKOFF_SECONDS = 30.0
SKIP_LOG_SECONDS = 30.0

# 隨機 UA 的配置位置：每個 Session 選一次，並非每個請求切換。
# 有 cf_clearance 時，請用 CRAWLER_USER_AGENT 指定取得 Cookie 的原瀏覽器 UA。
USER_AGENTS = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36",
)

TARGETS = {
    "28hse-list": ("https://www.28hse.com/property/dosearch", "POST"),
    "28hse-contact": ("https://www.28hse.com/property/detail/doaction", "POST"),
    "house730-list": ("https://api.house730.com/Property/QueryProperty", "POST"),
    "house730-contact": ("https://api.house730.com/Property/GetPropertyUserInfoById", "GET"),
}


def proxy_options(prefix: str | None = None, *, value: str | None = None) -> dict[str, Any]:
    """Use an explicitly supplied proxy without logging its address or secrets."""
    if value is None:
        value = (os.environ.get(f"{prefix}_PROXY") if prefix else None) or os.environ.get("CRAWLER_PROXY")
    if not value:
        return {}
    try:
        proxy = urlsplit(value)
        if (any(ord(char) <= 32 or ord(char) == 127 for char in value)
                or proxy.scheme not in {"http", "https", "socks4", "socks4a", "socks5", "socks5h"}
                or not proxy.hostname or proxy.port is None or not 1 <= proxy.port <= 65535
                or proxy.path not in ("", "/") or proxy.query or proxy.fragment):
            raise ValueError
    except ValueError:
        raise ValueError("代理設定無效；請核對協定、主機與埠，帳密中的特殊字元需編碼。") from None
    # An explicitly selected browser proxy must not be silently bypassed by
    # a NO_PROXY/no_proxy inherited from the terminal. Other sessions keep
    # their normal environment behavior when no proxy is explicitly supplied.
    return {"proxy": value, "curl_options": {CurlOpt.NOPROXY: ""}}


@dataclass(frozen=True)
class Config:
    url: str = field(repr=False)
    method: str = "GET"
    headers: dict[str, str] = field(default_factory=dict, repr=False)
    params: dict[str, Any] = field(default_factory=dict, repr=False)
    form: dict[str, Any] | None = field(default=None, repr=False)
    json_body: Any = field(default=None, repr=False)
    raw_body: str | None = field(default=None, repr=False)
    expect_json: bool = False
    interval: float = 0.5
    concurrency: int = 8
    timeout: float = 10.0
    impersonate: str = "chrome136"
    user_agent: str | None = None
    cf_clearance: str = field(default="", repr=False)

    def __post_init__(self) -> None:
        target = urlsplit(self.url)
        if target.scheme not in ("http", "https") or not target.hostname:
            raise ValueError("請提供完整的 http/https 網址")
        if target.username is not None or target.password is not None:
            raise ValueError("網址不得包含使用者名稱或密碼")
        if self.method not in ("GET", "POST"):
            raise ValueError("method 僅支援 GET 或 POST")
        if sum(value is not None for value in (self.form, self.json_body, self.raw_body)) > 1:
            raise ValueError("form、json 與 body 不可同時設定")
        if self.method == "GET" and any(value is not None for value in (self.form, self.json_body, self.raw_body)):
            raise ValueError("GET 請把參數放在 params，而非 form/json/body")
        if not isinstance(self.headers, dict) or not all(
            isinstance(k, str) and isinstance(v, str) for k, v in self.headers.items()
        ):
            raise ValueError("headers 必須是字串名稱與字串值的物件")
        if any(k.lower() in ("cookie", "user-agent") for k in self.headers):
            raise ValueError("Cookie 與 User-Agent 請透過 CF_CLEARANCE／CRAWLER_USER_AGENT 設定")
        if self.raw_body is not None:
            if not isinstance(self.raw_body, str):
                raise ValueError("body 必須是原始 UTF-8 字串")
            if not any(k.lower() == "content-type" for k in self.headers):
                raise ValueError("原始 body 請同時指定實際 Content-Type")
        if not isinstance(self.params, dict) or (self.form is not None and not isinstance(self.form, dict)):
            raise ValueError("params/form 必須是物件")
        for name in ("interval", "timeout"):
            value = getattr(self, name)
            if not math.isfinite(value) or value <= 0:
                raise ValueError(f"{name} 必須是有限的正數")
        if self.concurrency < 1:
            raise ValueError("concurrency 必須至少為 1")
        if self.cf_clearance and not self.user_agent:
            raise ValueError("使用 cf_clearance 時，請設定 CRAWLER_USER_AGENT 為原瀏覽器 UA")


@dataclass
class Stats:
    started: int = 0
    succeeded: int = 0
    failed: int = 0
    skipped: int = 0
    forbidden: int = 0
    blocked: int = 0


class SiteState:
    """Shared by lanes on one site; all access is on the same asyncio loop."""

    def __init__(self, concurrency: int = 8) -> None:
        if concurrency < 1:
            raise ValueError("同站並發上限必須至少為 1")
        self.concurrency = concurrency
        self.stop = asyncio.Event()
        self.cooldown_until = 0.0
        self.dns_retry_until = 0.0
        self.dns_generation = 0
        self.in_flight = 0
        # Only one reservation per lane; no accumulated queue of requests.
        self._waiting: list[object] = []

    def defer_dns(self, now: float, generation: int) -> bool:
        # One failure in a batch opens a pause. Older in-flight completions
        # must not renew that pause or emit duplicate warnings.
        if generation != self.dns_generation:
            return False
        self.dns_generation += 1
        self.dns_retry_until = max(self.dns_retry_until, now + DNS_BACKOFF_SECONDS)
        return True

    def try_acquire(self, owner: object) -> bool:
        if owner not in self._waiting:
            self._waiting.append(owner)
        free = self.concurrency - self.in_flight
        # A lane skipped on the previous tick gets priority over a repeat winner.
        if free <= 0 or self._waiting.index(owner) >= free:
            return False
        self._waiting.remove(owner)
        self.in_flight += 1
        return True

    def release(self) -> None:
        self.in_flight -= 1

    def discard_waiter(self, owner: object) -> None:
        if owner in self._waiting:
            self._waiting.remove(owner)


async def handle_data(data: Any, request_id: int) -> None:
    """資料解析／存檔的擴充位置；data 是 JSON 物件或 HTML 字串。"""
    LOG.info("請求 #%d：已取得 %s 資料", request_id, type(data).__name__)
    # 例如：JSON API 的房源清單可能是 data['items']。
    # 請依目標網站補上欄位解析；耗時同步工作請交給 asyncio.to_thread。


def retry_delay(value: str | None) -> float:
    """Respect both Retry-After seconds and HTTP dates; default to 60 seconds."""
    if value:
        try:
            seconds = float(value)
        except ValueError:
            try:
                when = parsedate_to_datetime(value)
                if when.tzinfo is None:
                    when = when.replace(tzinfo=timezone.utc)
                seconds = (when - datetime.now(timezone.utc)).total_seconds()
            except (TypeError, ValueError, OverflowError):
                seconds = 60.0
        if math.isfinite(seconds):
            return max(1.0, seconds)
    return 60.0


class Crawler:
    def __init__(
        self, config: Config,
        on_data: Callable[[Any, int], Awaitable[None]] = handle_data,
        *, state: SiteState | None = None, name: str = "single",
    ) -> None:
        self.config = config
        self.on_data = on_data
        self.stats = Stats()
        self.state = state if state is not None else SiteState(config.concurrency)
        self.stop = self.state.stop
        self.log = logging.getLogger(f"crawler.{name}")
        self._used = False
        self._dns_generations: dict[int, int] = {}
        self._skip_pending = 0
        self._last_skip_log: float | None = None

    def _skip_tick(self, now: float) -> None:
        self.stats.skipped += 1
        self._skip_pending += 1
        if self._last_skip_log is None or now - self._last_skip_log >= SKIP_LOG_SECONDS:
            self.log.warning("並發額度不足：自上次摘要略過 %d 次排程；同站在途=%d/%d。"
                             "不累積請求，後續每 %.0f 秒最多摘要一次。",
                             self._skip_pending, self.state.in_flight,
                             self.state.concurrency, SKIP_LOG_SECONDS)
            self._skip_pending = 0
            self._last_skip_log = now

    async def _fetch(self, session: AsyncSession, request_id: int) -> None:
        dns_generation = self._dns_generations.pop(request_id, self.state.dns_generation)
        try:
            # 不跟隨重新導向，避免把 clearance 帶到其他目標。
            response = await session.request(
                self.config.method, self.config.url,
                headers=self.config.headers, params=self.config.params,
                data=(self.config.raw_body.encode("utf-8")
                      if self.config.raw_body is not None else self.config.form),
                json=self.config.json_body,
                timeout=self.config.timeout,
                allow_redirects=False,
            )
        except RequestException as exc:
            self.stats.failed += 1
            code = getattr(exc, "code", None)
            if code in (5, 6):
                if self.state.defer_dns(asyncio.get_running_loop().time(), dns_generation):
                    self.log.warning("請求 #%d：%s DNS 解析失敗（curl 代碼 %d）；"
                                     "同站暫停新增請求 %.0f 秒。請核對本機 DNS 與代理設定；"
                                     "Python 不會自動沿用 BitBrowser 代理。",
                                     request_id, "代理網域" if code == 5 else "目標網域",
                                     code, DNS_BACKOFF_SECONDS)
                return
            # 不輸出例外全文，因其可能含有網址中的敏感 query 參數。
            self.log.warning("請求 #%d：網路異常 %s，代碼 %s；後續排程繼續",
                        request_id, type(exc).__name__, getattr(exc, "code", "unknown"))
            return

        if response.headers.get("cf-mitigated", "").lower() == "challenge":
            self.stats.failed += 1
            self.stats.blocked += 1
            self.log.error("Cloudflare 挑戰回應：已停止同站新增請求，請在原瀏覽器確認驗證後重新擷取。")
            self.stop.set()
            return
        if response.status_code == 403:
            self.stats.failed += 1
            self.stats.forbidden += 1
            self.log.error("HTTP 403：cf_clearance 可能失效，或網站拒絕存取。"
                      "已停止新增請求；請在瀏覽器確認驗證，更新 Cookie 與相符 UA 後重啟。"
                      "403 本身無法證明 Cookie 已失效。")
            self.stop.set()
            return
        if response.status_code == 429:
            self.stats.failed += 1
            delay = retry_delay(response.headers.get("Retry-After"))
            loop = asyncio.get_running_loop()
            self.state.cooldown_until = max(self.state.cooldown_until, loop.time() + delay)
            self.log.warning("HTTP 429：暫停新增請求 %.1f 秒", delay)
            return
        if not 200 <= response.status_code < 300:
            self.stats.failed += 1
            self.log.warning("請求 #%d：HTTP %d；請檢查網址或回應狀態",
                        request_id, response.status_code)
            return

        try:
            data = response.json()
        except ValueError:
            if self.config.expect_json:
                self.stats.failed += 1
                self.stats.blocked += 1
                self.log.error("API 預期 JSON 卻收到非 JSON：可能是驗證頁或端點已變更；已停止同站新增請求。")
                self.stop.set()
                return
            data = response.text
        try:
            await self.on_data(data, request_id)
        except Exception as exc:
            self.stats.failed += 1
            self.log.error("請求 #%d：資料處理失敗（%s）", request_id, type(exc).__name__)
        else:
            self.stats.succeeded += 1

    async def run(
        self, max_requests: int | None = None, *, session: AsyncSession | None = None,
    ) -> Stats:
        """Single-use; drain sent requests; an injected session remains caller-owned."""
        if max_requests is not None and max_requests < 1:
            raise ValueError("max_requests 必須至少為 1")
        if self._used:
            raise ValueError("請建立新的 Crawler 執行下一輪")
        self._used = True
        if self.stop.is_set():
            return self.stats
        config = self.config
        ua = config.user_agent or random.choice(USER_AGENTS)
        active: set[asyncio.Task[None]] = set()
        loop = asyncio.get_running_loop()

        async with AsyncExitStack() as stack:
            if session is None:
                connection = proxy_options()
                if connection:
                    self.log.info("已套用指定代理；不顯示位址或帳密。")
                session = await stack.enter_async_context(AsyncSession(
                    max_clients=config.concurrency,
                    impersonate=config.impersonate,
                    headers={"User-Agent": ua}, timeout=config.timeout,
                    **connection,
                ))
            # Cookie 的配置位置：由環境變數讀入，不寫入程式碼或日誌。
            if config.cf_clearance:
                session.cookies.set("cf_clearance", config.cf_clearance,
                                    domain=urlsplit(config.url).hostname, path="/")
            next_tick = loop.time()
            try:
                while not self.stop.is_set():
                    if max_requests is not None and self.stats.started >= max_requests:
                        break
                    delay = max(next_tick, self.state.cooldown_until, self.state.dns_retry_until) - loop.time()
                    if delay > 0:
                        try:
                            await asyncio.wait_for(self.stop.wait(), timeout=delay)
                        except TimeoutError:
                            pass
                        if self.stop.is_set():
                            break
                        # Other in-flight requests can open a 429 or DNS pause
                        # while this lane is sleeping; neither pause replaces the other.
                        if loop.time() < max(self.state.cooldown_until, self.state.dns_retry_until):
                            continue
                    now = loop.time()
                    # 使用單調時鐘固定節拍；延遲的 tick 直接略過，不補發突發請求。
                    missed = max(0, int((now - next_tick) // config.interval))
                    next_tick = now + config.interval if missed else next_tick + config.interval
                    completed = {task for task in active if task.done()}
                    for task in completed:
                        task.result()  # 非預期程式錯誤須向上傳遞，不可默默遺失。
                    active.difference_update(completed)
                    if len(active) >= config.concurrency:
                        self.state.discard_waiter(self)
                        self._skip_tick(now)
                        continue
                    if not self.state.try_acquire(self):
                        self._skip_tick(now)
                        continue
                    self.stats.started += 1
                    self._dns_generations[self.stats.started] = self.state.dns_generation
                    task = asyncio.create_task(self._fetch(session, self.stats.started))
                    # Callback also runs if cancellation occurs before the coroutine starts.
                    def release(_task: asyncio.Task[None], request_id: int = self.stats.started) -> None:
                        self._dns_generations.pop(request_id, None)
                        self.state.release()
                    task.add_done_callback(release)
                    active.add(task)
                if active:
                    await asyncio.gather(*active)
            finally:
                self.state.discard_waiter(self)
                for task in active:
                    if not task.done():
                        task.cancel()
                await asyncio.gather(*active, return_exceptions=True)
        return self.stats


def config_from_args(args: argparse.Namespace) -> Config:
    request: dict[str, Any] = {}
    if args.request_file:
        try:
            request = json.loads(Path(args.request_file).read_text(encoding="utf-8"))
        except (OSError, ValueError):
            raise ValueError("無法讀取請求設定；請確認檔案存在且是有效 JSON") from None
        if not isinstance(request, dict) or set(request) - {"method", "headers", "params", "form", "json", "body"}:
            raise ValueError("請求設定僅接受 method、headers、params、form、json、body 欄位")
    if args.target:
        if args.url:
            raise ValueError("url 與 --target 請擇一設定")
        url, default_method = TARGETS[args.target]
    else:
        if not args.url:
            raise ValueError("請提供 url 或 --target")
        url, default_method = args.url, "GET"
    method = args.method or request.get("method", default_method)
    if not isinstance(method, str):
        raise ValueError("method 必須是 GET 或 POST")
    params = request.get("params", {})
    form = request.get("form")
    headers = request.get("headers", {})
    if not isinstance(headers, dict) or not isinstance(params, dict):
        raise ValueError("headers 與 params 必須是物件")
    # 機密 API 標頭可經安全的環境變數注入，不需存進請求設定檔。
    try:
        secret_headers = json.loads(os.environ.get("CRAWLER_HEADERS_JSON", "{}"))
    except ValueError:
        raise ValueError("CRAWLER_HEADERS_JSON 必須是有效 JSON 物件") from None
    if not isinstance(secret_headers, dict):
        raise ValueError("CRAWLER_HEADERS_JSON 必須是 JSON 物件")
    headers = {**headers, **secret_headers}
    if args.target in ("28hse-contact", "house730-contact"):
        pattern = r"[0-9]{6,10}" if args.target == "28hse-contact" else r"[0-9]{1,15}"
        if not args.property_id or not re.fullmatch(pattern, args.property_id):
            raise ValueError("電話端點需要有效的 --property-id")
        if args.target == "house730-contact":
            params = {**params, "propertyId": args.property_id}
        else:
            if form is not None and not isinstance(form, dict):
                raise ValueError("form 必須是物件")
            # 來自現有封裝 hse28_direct_phone.py 的請求格式；未聲稱線上有效。
            form = {"action": "statistic_inc", "user_action": "phone",
                    "event_name": "property_contact_phone", **(form or {}),
                    "ad_id": args.property_id}
    elif args.property_id:
        raise ValueError("--property-id 僅供電話端點使用")
    if args.target in ("28hse-list", "house730-list"):
        if method.upper() == "POST" and all(value is None for value in (form, request.get("json"), request.get("body"))):
            raise ValueError("列表 POST 需要 --request-file 提供實際 form、json 或 body；不猜測搜尋／簽章欄位")
        if method.upper() == "GET" and not params:
            raise ValueError("列表 GET 需要 --request-file 提供實際 params")
    return Config(
        url=url, method=method.upper(), headers=headers, params=params,
        form=form, json_body=request.get("json"),
        raw_body=request.get("body"),
        interval=args.interval, concurrency=args.concurrency,
        timeout=args.timeout, impersonate=args.impersonate,
        user_agent=os.environ.get("CRAWLER_USER_AGENT") or None,
        cf_clearance=os.environ.get("CF_CLEARANCE", ""),
    )


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("url", nargs="?", help="目標頁面或 JSON API")
    parser.add_argument("--target", choices=TARGETS, help="使用已配置的網站端點")
    parser.add_argument("--method", choices=("GET", "POST"))
    parser.add_argument("--request-file", help="本機 JSON 請求設定檔")
    parser.add_argument("--property-id", help="電話端點的單一房源 ID")
    parser.add_argument("--interval", type=float, default=0.5, help="發起請求的間隔秒數（預設 0.5）")
    parser.add_argument("--concurrency", type=int, default=8)
    parser.add_argument("--timeout", type=float, default=10.0)
    parser.add_argument("--count", type=int, help="最多發起幾次；省略則持續執行")
    parser.add_argument("--impersonate", default="chrome136", help="與原瀏覽器相符的 curl_cffi profile")
    args = parser.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s")
    try:
        config = config_from_args(args)
        stats = asyncio.run(Crawler(config).run(max_requests=args.count))
    except ValueError as exc:
        parser.error(str(exc))
    except KeyboardInterrupt:
        LOG.info("已停止並清理連線")
        return 130
    LOG.info("執行結束：發起=%d 成功=%d 失敗=%d 跳過=%d",
             stats.started, stats.succeeded, stats.failed, stats.skipped)
    return 2 if stats.forbidden or stats.blocked else (1 if stats.failed and not stats.succeeded else 0)


if __name__ == "__main__":
    raise SystemExit(main())
