"""Parse the verified 28Hse search-result HTML, without scanning sidebars."""
from __future__ import annotations

from html.parser import HTMLParser
import re
from typing import Any
from urllib.parse import urlsplit

from listing_types import Listing, ListingPage, ListingParseError


_LANES = {"28hse-rent": "rent", "28hse-buy": "buy"}
_HOSTS = {"28hse.com", "www.28hse.com"}
_MAX_HTML_CHARS = 3_000_000


def _public_listing(href: str, trade: str) -> Listing | None:
    try:
        parsed = urlsplit(href.strip())
        if parsed.scheme not in ("", "https") or parsed.username is not None or parsed.password is not None:
            return None
        if parsed.netloc and ((parsed.hostname or "").lower() not in _HOSTS or parsed.port not in (None, 443)):
            return None
        # Explicit schemes must have a trusted host. Network-path references
        # inherit HTTPS from the verified browser page and are canonicalized.
        if parsed.scheme and not parsed.netloc:
            return None
        match = re.fullmatch(
            rf"/{trade}/(?:[A-Za-z0-9_-]+/)*property-(\d{{1,15}})/?", parsed.path,
        )
        if match is None or int(match[1]) == 0:
            return None
    except (TypeError, ValueError):
        return None
    return Listing(match[1], "https://www.28hse.com" + parsed.path.rstrip("/"))


class _ListingLinks(HTMLParser):
    _BLOCKED = {"script", "style", "iframe", "object", "template", "noscript", "svg", "math"}

    def __init__(self, trade: str) -> None:
        super().__init__(convert_charrefs=True)
        self.trade = trade
        self.blocked: list[str] = []
        self.listings: dict[str, Listing] = {}

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag in self._BLOCKED:
            self.blocked.append(tag)
            return
        if self.blocked or tag != "a":
            return
        hrefs = [value for key, value in attrs if key == "href"]
        if len(hrefs) != 1 or not isinstance(hrefs[0], str):
            return
        listing = _public_listing(hrefs[0], self.trade)
        if listing is not None:
            self.listings.setdefault(listing.listing_id, listing)

    def handle_startendtag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        self.handle_starttag(tag, attrs)
        self.handle_endtag(tag)

    def handle_endtag(self, tag: str) -> None:
        if self.blocked and self.blocked[-1] == tag:
            self.blocked.pop()


def parse_listings(lane: str, payload: Any) -> ListingPage:
    """Return first-page IDs from known HTML, or fail without changing a baseline."""
    trade = _LANES.get(lane)
    if trade is None:
        raise ListingParseError("28Hse 路線無效")
    if not isinstance(payload, dict) or type(payload.get("status")) is not int or payload["status"] != 1:
        raise ListingParseError("28Hse 回應未表示成功，未更新基線")
    data = payload.get("data")
    results = data.get("results") if isinstance(data, dict) else None
    result_data = results.get("resultData") if isinstance(results, dict) else None
    paginator = result_data.get("ListingPaginator") if isinstance(result_data, dict) else None
    if not isinstance(paginator, dict):
        raise ListingParseError("28Hse 回應缺少已知的列表及分頁結構，未更新基線")
    page, total = paginator.get("page"), paginator.get("count")
    if type(page) is not int or page != 1:
        raise ListingParseError("28Hse 必須監控第 1 頁，未更新基線")
    if type(total) is not int or total < 0:
        raise ListingParseError("28Hse 列表總數無效，未更新基線")
    # A present but invalid/empty primary field must not be concealed by a
    # different branch. The fallback is only for a missing primary field.
    html = results["resultContentHtml"] if "resultContentHtml" in results else result_data.get("showHtml")
    if not isinstance(html, str) or len(html) > _MAX_HTML_CHARS:
        raise ListingParseError("28Hse 主列表 HTML 無效，未更新基線")
    parser = _ListingLinks(trade)
    try:
        parser.feed(html)
        parser.close()
    except (AssertionError, ValueError):
        raise ListingParseError("28Hse 主列表 HTML 無法解析，未更新基線") from None
    listings = tuple(parser.listings.values())
    if (total > 0 and not listings) or total < len(listings):
        raise ListingParseError("28Hse 列表總數與可辨識樓盤不一致，未更新基線")
    return ListingPage(listings, page=page, total=total)
