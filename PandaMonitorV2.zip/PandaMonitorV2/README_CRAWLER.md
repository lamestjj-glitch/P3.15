# curl_cffi 非同步爬蟲

Python 3.12+；不依賴原 ZIP 內的 Windows GUI。

Windows 建議先把完整 ZIP 解壓到一般可寫入的資料夾，再雙擊 **`START_CAPTURE.cmd`**。它會逐一實際測試 PATH 中的 Python，再嘗試 `py` 的 3.15／3.14／3.13／3.12，建立此資料夾專用的 `.crawler-venv` 並在需要時安裝依賴，接著詢問實際 CDP 調試埠、抓取間隔與四頁篩選確認。首次安裝需要網路。程式結束後視窗會停留，避免錯誤訊息閃退；啟動階段與退出碼寫入 `logs/startup.log`，不記錄 Cookie、標頭、CDP 或命令列值。

若 Python 更新或移除後留下失效的 `.crawler-venv`，啟動器會實際檢查其直譯器，將無法執行或版本不同的環境改名備份為 `.crawler-venv.backup-*`，再以目前選定的 Python 建立替代環境。也可在程式資料夾直接執行 `py -3.15 start_capture.py` 明確選擇已安裝的 Python 3.15。若需指定完整路徑，先在 CMD 設定 `set "CRAWLER_PYTHON=C:\完整路徑\python.exe"` 再執行 `START_CAPTURE.cmd`。

直接開啟 `capture_four_lanes.py` 且未提供參數時，也會進入互動輸入；若尚未安裝依賴，會提示改用上述啟動器。從終端執行 `python capture_four_lanes.py --check-setup` 可單獨檢查 Python／依賴，不連線瀏覽器。

```bash
python -m pip install -r requirements-crawler.txt
python async_crawler.py 'https://example.com/api/items' --interval 0.5 --concurrency 8
```

目前雲端已在 `/workspace/crawler-env/.venv` 安裝依賴，可先執行 `source /workspace/crawler-env/.venv/bin/activate`。

- `--interval` 調整發起請求的間隔（秒）。`--count 10` 可限制最多發起 10 次。
- `USER_AGENTS` 是隨機 UA 的配置位置；每個 Session 選定一次。`CRAWLER_USER_AGENT` 環境變數可指定固定 UA。
- `CF_CLEARANCE` 環境變數提供 Cookie，請透過安全的環境設定填入，不要貼到聊天或提交 Git。有 Cookie 時必須設定原瀏覽器的完整 `CRAWLER_USER_AGENT`，並讓 `--impersonate` 與該瀏覽器相符；預設 profile 是 `chrome136`。Cookie 亦可能受原 IP／其他瀏覽器狀態限制，不能保證複用成功。
- `handle_data(data, request_id)` 是資料處理位置：JSON 會轉成 Python 物件，其他回應為文字；依實際 API 補上欄位解析或存檔。多個請求可能按不同順序完成。

排程使用單調時鐘，不會等回應完成再睡 500ms。慢請求可以重疊；達到並發上限時跳過 tick，避免無限累積。500ms 是預定發起頻率，並非保證每 500ms 完成一次回應；實際頻率受網路、事件迴圈與並發上限影響。請依網站允許的頻率設定。

HTTP 403 會提示 clearance **可能**失效或存取被拒絕，停止新增請求，並回傳退出碼 2；已送出的請求會完成。403 並不一定代表 Cookie 失效。HTTP 429 會依 `Retry-After` 冷卻（缺少或無效則 60 秒）；網路錯誤與逾時會記錄後繼續。重新導向不會自動跟隨，請使用實際資料端點。

已提供以下端點預設值：

| `--target` | 預設方法 | 端點 |
| --- | --- | --- |
| `28hse-list` | POST | `https://www.28hse.com/property/dosearch` |
| `28hse-contact` | POST | `https://www.28hse.com/property/detail/doaction` |
| `house730-list` | POST，可用 `--method GET` 調整 | `https://api.house730.com/Property/QueryProperty` |
| `house730-contact` | GET | `https://api.house730.com/Property/GetPropertyUserInfoById` |

列表端點需要瀏覽器實際產生的搜尋參數；端點網址不足以判斷租／售、業主篩選或最新排序。House730 的舊版列表端點亦可能需要有效應用程式標頭、時間戳或簽章，這些不會自動產生，也未確認端點目前仍可使用。

將非機密參數寫入 `request.local.json`（已加入 `.gitignore`）。以下只展示結構，`form` 必須換成 Network 中完整的實際 Form Data；若原請求是 JSON，將 `form` 換成 `json`：

```json
{
  "method": "POST",
  "headers": {"X-Requested-With": "XMLHttpRequest"},
  "form": {}
}
```

```bash
python async_crawler.py --target 28hse-list --request-file request.local.json --interval 0.5
python async_crawler.py --target house730-list --request-file house730.local.json --interval 0.5
python async_crawler.py --target house730-contact --property-id 1234567 --count 1
python async_crawler.py --target 28hse-contact --property-id 1234567 --count 1
```

範例 ID 請換成你要查詢的實際房源 ID。28Hse 電話表單格式來自現有 ZIP 的 `hse28_direct_phone.py`，尚未對線上 API 驗證；該動作也可能累加聯絡瀏覽統計。額外非機密標頭放在 `headers`，機密標頭以 `CRAWLER_HEADERS_JSON` 環境變數注入；時間戳或簽章若會過期，仍須由網站支援的認證流程更新。單一路線使用上述 `async_crawler.py`；四路同時執行使用下方入口。預設只將資料交給 `handle_data`，尚未串接「列表 → 新房源去重 → 電話查詢」管線。

四路列表監控使用 `four_lane_crawler.py` 與 `four_lanes.example.json`：

| 路線 | 列表頁 |
| --- | --- |
| `28hse-rent` | `https://www.28hse.com/rent` |
| `28hse-buy` | `https://www.28hse.com/buy` |
| `house730-rent` | `https://www.house730.com/rent/s1u14/` |
| `house730-buy` | `https://www.house730.com/buy/s1u14/` |

將範本另存為 `four_lanes.local.json`，逐路填入真實 Network 請求的 `request`，確認租／售、業主與最新排序後，將該路 `verified` 設為 `true`。此旗標代表操作者已核對請求，不代表本程式已驗證線上 API。範本全部維持待確認，既有檔案不會被自動覆寫。

```bash
python four_lane_crawler.py --config four_lanes.example.json --check
python four_lane_crawler.py --config four_lanes.local.json --check
python four_lane_crawler.py --config four_lanes.local.json --interval 0.5 --count 10
```

第一個指令會列出四路待補項目並以狀態碼 2 結束，完全不建立 HTTP 連線。只要任一路未確認或配置無效，四路都不會開始發送請求。通過 `--check` 僅證明配置結構有效；登入狀態、網站回應及篩選結果仍須實際驗證。

每路預設各 500ms，即名義上每秒共 8 次列表請求、每站 4 次。各路可在自己的配置加入 `interval`，`--interval` 則覆寫全部四路。`--count` 是每路的最多發起次數。每站租售共用一個 Session、固定 UA、並發上限與錯誤狀態：403 停止該站兩路新增請求，429 讓該站兩路共用冷卻時間；另一站繼續執行。既有請求會完成，取消程式時清理本次建立的任務與連線。

四路模式的機密設定分站讀取：

| 網站 | Cookie | 原瀏覽器 UA | 額外機密標頭 JSON |
| --- | --- | --- | --- |
| 28Hse | `HSE28_CF_CLEARANCE` | `HSE28_USER_AGENT` | `HSE28_HEADERS_JSON` |
| House730 | `HOUSE730_CF_CLEARANCE` | `HOUSE730_USER_AGENT` | `HOUSE730_HEADERS_JSON` |

這些環境變數只在記憶體中使用，不寫入範本或日誌。有 Cookie 時須同時設定相符的 UA。`sites` 中各站的 `impersonate` 也須符合該瀏覽器；預設為 `chrome136`。每路 API 網址必須屬於該站 HTTPS 網域，避免把網站憑證送到其他網站。

`request` 需要實際的 `url`、`method`，以及可選的 `headers`、`params`。POST 本文只選一種表示：`form` 物件、`json` 值，或 `body` 原始字串。若真實網站把條件包在 `form_data` 欄位，請保留這個結構；若需要保留完整編碼，使用 `body` 並填入真實 `Content-Type`，程式以原始 UTF-8 位元組傳送，不先解析或重編碼。不要把同一份內容同時放進多種本文欄位。

`endpoint_hint` 只供辨識，不會自動代填 `request.url`，也不會在失敗時切回舊端點。House730 範本的 `QueryProperty` 明確標為歷史線索，需以目前 Network 實際端點取代。28Hse 的 `landlordAgency=LANDLORD`、`sortBy=latest` 可作核對依據；完整本文、`buyRent`、`page` 與外層編碼仍未經本次線上驗證，未直接填入正式範本。

四路資料處理位置是 `handle_lane_data(lane_name, data, request_id)`，依實際回應格式補上解析或存檔；目前不會自動讀取電話或傳送訊息。

`capture_four_lanes.py` 的一般執行模式現已接上第一頁 ID 監控：28Hse 只解析主列表 HTML 的公開樓盤連結，House730 只解析 `result.data[].propertyID`，不將廣告／貸款旁欄當成房源。四個分頁須設好業主、最新排序並停在第 1 頁；House730 請求必須包含 `pageIndex=1`，28Hse 也會核對回應分頁。未知回應格式、業務錯誤或不一致的空頁不會建立或清除基線。

每一路的首個有效回應只建立基線，之後只列出「首次發現」的公開 ID 與可驗證的連結；相同 ID、消失後再出現的 ID、較舊請求編號的延遲回應不會重複通知。預設每 60 秒印一次有效回應及已見 ID 統計。這表示本程式第一次看見該 ID，不能據此斷言網站剛發布該盤；監控只看第一頁，不自動翻頁補抓期間漏過的盤。

公開 ID 與搜尋範圍指紋保存在程式資料夾的 `monitor_data/seen.sqlite3`；首次基線之後發現的結果保存在 `monitor_data/new_listings.jsonl`。相同範圍重啟會接續去重，搜尋條件變更則建立獨立基線。狀態與結果不保存 Cookie、UA、原始請求本文或完整回應；資料庫是結果的權威來源，JSONL 以原子替換產生，檔案寫入失敗後可在後續回應或下次啟動後重建。尚未串接電話查詢、訊息通知及價格變動追蹤；429 與抓取頻率的原有設定未變更。

也可以在原 Windows／BitBrowser 機器上使用記憶體擷取入口，省去手動整理完整 Payload。先在同一個已開啟的 BitBrowser 環境中開啟上述四個列表分頁，確認各頁的租／售、業主與最新排序，再執行：

```powershell
py -m pip install -r requirements-capture.txt
py capture_four_lanes.py --cdp http://127.0.0.1:9222 --confirm-filters --interval 0.5 --count 10
```

`9222` 只是示例，須換成 BitBrowser 173 **目前實際的 CDP 調試埠**，不是 Local API 的 `54345`。此入口只連接已開啟的瀏覽器，不安裝另一個瀏覽器；請在出現提示後，於四個分頁各按一次搜尋。它不導覽頁面、不點擊驗證、不關閉原瀏覽器或分頁，也不將 Cookie、標頭值、原始 Body 或回應內容寫入檔案／日誌。CLI 只接受本機 CDP 位址。

28Hse 擷取會檢查 Body 中的 `landlordAgency=LANDLORD`、`sortBy=latest`，支援包在 `form_data` 的 JSON 字串。House730 依實際非空列表 JSON 的連結或房源記錄形狀辨識候選，不依賴歷史 `QueryProperty` 路徑；這個辨識不能代替操作者核對未知的業主／排序欄位，因此需要 `--confirm-filters`。若候選不唯一會停止，請在 Network 核對實際路徑後用 `--house730-path /實際路徑` 限定；空列表或未能辨識的回應也不會被當成已學習成功。

四路學習完成後，直接以同一程序的 `curl_cffi` 執行列表請求。UA 取自原請求；桌面 Chrome 優先選同主版本的 profile，若套件沒有收錄該版本，改選最近的較舊桌面 Chrome profile 並顯示近似配對警告。日誌只列站名、解析出的主版本與選定 profile，不列完整 UA。無法識別為桌面 Chrome（例如 Edge、Android、iOS、Firefox、Safari），或版本低於最舊支援 profile 時，須用 `--hse28-impersonate`／`--house730-impersonate` 明確指定設定；有效的顯式設定會優先使用。Cookie 保留網域、路徑、Secure 與有效期，只留在記憶體。近似 profile 及瀏覽器會話複用均不保證網站接受，403 或已辨識的驗證頁仍會停止該站。若簽章或 Cookie 過期，須在原瀏覽器確認後重新擷取；此模式不會自動完成 Turnstile。

四路 API 模式預期 JSON：若收到非 JSON，或回應標頭明示 `cf-mitigated: challenge`，即使 HTTP 是 200 也停止同站兩路；這只能攔截這些已知異常，JSON 內的業務錯誤仍需依實際回應格式解析。

`curl_cffi` 不執行網頁 JavaScript，也不會自動完成 Cloudflare／Turnstile 驗證。HTTP 200 仍可能是挑戰頁；成功狀態還需依實際 API 回應結構驗證。

要提供回應結構以開發樓盤解析，可執行一次性樣本匯出：

```cmd
py -3.15 start_capture.py --export-samples
```

輸入實際 CDP 埠並確認四頁篩選後，在四個分頁各手動按一次搜尋。程式只監聽這些瀏覽器回應，產生同資料夾的 `samples_for_review.zip` 後結束，不進入 `curl_cffi` 輪詢，也不變更 429 冷卻機制。需等網站列表本身可正常載入時擷取；原本只顯示 `dict` 的日誌沒有保存可供匯出的歷史回應。

此模式使用 `sample_export.py` 匿名化結構樣本，保留欄位層級與辨識樓盤所需的公開 ID，遮罩其他非必要值，並限制每個陣列的樣本筆數。輸出不包含原始 Cookie、標頭、UA 或完整請求網址。樣本用來辨識解析結構，不能作為可重播的請求配置。先在本機檢查 ZIP，再將 ZIP 拖進聊天上傳。若輸出已存在，會停止而不覆寫；也可用 `--export-samples another-samples.zip` 指定另一個檔名。

驗證指令：

```bash
python -m unittest discover -s tests_crawler -v
```

測試只使用本機 HTTP 伺服器，不連線目標網站。
另外，安裝選用的 `requirements-capture.txt` 且系統具有 Chromium 時，會執行真實本機 CDP 擷取測試；四個網站的頁面與 API 回應全部攔截為測試資料，不送到實際網站。
