"""PandaMonitorV2: one asyncio loop, shared curl sessions, no Tk calls."""
from __future__ import annotations

import asyncio
from contextlib import AsyncExitStack
from dataclasses import dataclass, field, replace
import logging
import math
from pathlib import Path
import queue
import random
import threading
import time
from typing import Any
from urllib.parse import urlsplit

from curl_cffi.requests import AsyncSession
from async_crawler import Crawler, SiteState, USER_AGENTS, proxy_options, retry_delay
from capture_four_lanes import CaptureError, capture, impersonation, prepare
from four_lane_crawler import BrowserCookie, LANES, SITE_PREFIXES
from listing_monitor import ListingMonitor, MonitorConfigurationError
from v2_contacts import fetch_contacts
from v2_paths import data_root

LOG = logging.getLogger("crawler.v2")


def normalize_cdp(value: str) -> str:
    value = str(value).strip()
    if value.isdecimal() and 1 <= int(value) <= 65535:
        value = "http://127.0.0.1:" + value
    try:
        target = urlsplit(value)
        if (target.scheme not in ("http", "https", "ws", "wss")
                or target.hostname not in ("127.0.0.1", "localhost", "::1")
                or target.username is not None or target.password is not None
                or target.port is None or not 1 <= target.port <= 65535):
            raise ValueError
    except ValueError:
        raise ValueError("請輸入實際的本機 CDP 埠或完整位址，不能使用 BitBrowser Local API 埠代替。") from None
    return value


@dataclass(frozen=True)
class RuntimeOptions:
    cdp: str = field(repr=False)
    intervals: dict[str, float] = field(default_factory=lambda: {name: .5 for name in LANES})
    selected_lanes: tuple[str, ...] = tuple(LANES)
    timeout: float = 20.0
    concurrency: int = 8
    capture_seconds: float = 120.0
    proxy: str = field(default="", repr=False)
    # Configuration slots: original browser UA/cookies are the safe default.
    # "random" selects ONCE per session, and is refused with cf_clearance.
    user_agents: dict[str, str] = field(default_factory=dict, repr=False)
    clearance: dict[str, str] = field(default_factory=dict, repr=False)
    impersonate_overrides: dict[str, str] = field(default_factory=dict)
    phone_enabled: bool = True
    phone_concurrency: int = 2
    data_dir: Path | None = None

    def __post_init__(self) -> None:
        normalize_cdp(self.cdp)
        if (not self.selected_lanes or len(set(self.selected_lanes)) != len(self.selected_lanes)
                or set(self.selected_lanes) - set(LANES)):
            raise ValueError("請至少選擇一個有效的租售監控來源。")
        if (isinstance(self.concurrency, bool) or not isinstance(self.concurrency, int)
                or not 1 <= self.concurrency <= 64
                or isinstance(self.phone_concurrency, bool) or not isinstance(self.phone_concurrency, int)
                or not 1 <= self.phone_concurrency <= 8):
            raise ValueError("列表並發上限為 1–64，電話工作數為 1–8。")
        try:
            values = [self.timeout, self.capture_seconds, *(self.intervals[name] for name in self.selected_lanes)]
            if any(isinstance(value, bool) or not math.isfinite(value) or value <= 0 for value in values):
                raise ValueError
        except (TypeError, KeyError, ValueError):
            raise ValueError("間隔與逾時必須是有限正數，每個已選來源都要設定間隔。") from None
        if set(self.clearance) - set(SITE_PREFIXES) or set(self.user_agents) - set(SITE_PREFIXES):
            raise ValueError("UA／Cookie 僅支援 28hse 與 house730。")
        for site, cookie in self.clearance.items():
            if cookie and (not isinstance(cookie, str) or any(ord(c) <= 32 or c == ";" for c in cookie)):
                raise ValueError("cf_clearance 請只填 Cookie 值，不包含名稱、空白或其他 Cookie。")
            if cookie and self.user_agents.get(site, "").lower() in ("", "auto", "random"):
                raise ValueError("手動設定 cf_clearance 時，請同時填入取得該 Cookie 的原始 User-Agent。")
        if self.proxy:
            proxy_options(value=self.proxy)


def apply_session_settings(prepared: Any, options: RuntimeOptions) -> Any:
    """Apply runtime-only secrets without modifying captured request bytes."""
    sites = {}
    for name, site in prepared.sites.items():
        cookies = list(site.cookies)
        if options.clearance.get(name):
            cookies = [cookie for cookie in cookies if cookie.name != "cf_clearance"]
            domain = ".28hse.com" if name == "28hse" else ".house730.com"
            cookies.append(BrowserCookie("cf_clearance", options.clearance[name], domain))
        requested = options.user_agents.get(name, "auto") or "auto"
        if requested == "random":
            if any(cookie.name == "cf_clearance" and cookie.value for cookie in cookies):
                raise ValueError("有 cf_clearance 時不能隨機更換 UA；請使用原瀏覽器 User-Agent。")
            ua = random.choice(USER_AGENTS)
        else:
            ua = site.user_agent if requested == "auto" else requested
        if not isinstance(ua, str) or not ua or any(ord(char) < 32 for char in ua):
            raise ValueError("User-Agent 格式無效。")
        profile = site.impersonate
        if ua != site.user_agent:
            profile = impersonation(ua, options.impersonate_overrides.get(name), site=name)
        sites[name] = replace(site, cookies=tuple(cookies), user_agent=ua, impersonate=profile)
    lanes = [replace(lane, config=replace(lane.config, interval=options.intervals[lane.name],
                                        user_agent=sites[lane.site].user_agent,
                                        impersonate=sites[lane.site].impersonate)) for lane in prepared.lanes]
    return replace(prepared, sites=sites, lanes=lanes)


def install_browser_cookies(session: Any, cookies: tuple[BrowserCookie, ...], site: str) -> None:
    from http.cookiejar import Cookie
    domain = "28hse.com" if site == "28hse" else "house730.com"
    for item in cookies:
        host = item.domain.lstrip(".").lower()
        if host != domain and not host.endswith("." + domain):
            raise ValueError("Cookie 網域與網站不符。")
        session.cookies.jar.set_cookie(Cookie(
            version=0, name=item.name, value=item.value, port=None, port_specified=False,
            domain=item.domain, domain_specified=item.domain.startswith("."),
            domain_initial_dot=item.domain.startswith("."), path=item.path, path_specified=True,
            secure=item.secure, expires=item.expires, discard=item.expires is None,
            comment=None, comment_url=None, rest={}, rfc2109=False,
        ))


class MonitorController:
    """Thread facade; GUI exchanges plain events, never touches HTTP sessions."""

    def __init__(self, options: RuntimeOptions) -> None:
        self.options = options
        self.events: queue.Queue[dict[str, Any]] = queue.Queue()
        self._thread: threading.Thread | None = None
        self._loop: asyncio.AbstractEventLoop | None = None
        self._halt: asyncio.Event | None = None
        self._stop_requested = threading.Event()
        self._monitor: ListingMonitor | None = None
        self._sessions: dict[str, Any] = {}
        self._states: dict[str, SiteState] = {}
        self._crawlers: dict[str, Crawler] = {}
        self._latest: dict[str, tuple[str, str | None]] = {}
        self._headers: dict[str, dict[str, str]] = {}
        self._in_phone: set[int] = set()
        self._awaiting_ack: dict[int, float] = {}
        self._alerted: set[str] = set()
        self._last_ok: dict[str, float] = {}
        self._test_tasks: set[asyncio.Task[Any]] = set()

    def emit(self, event_type: str, **values: Any) -> None:
        self.events.put({"type": event_type, **values})

    def is_alive(self) -> bool:
        return bool(self._thread and self._thread.is_alive())

    def start(self) -> None:
        if self._thread is not None:
            raise ValueError("每個監控控制器只能啟動一次。")
        self._thread = threading.Thread(target=self._entry, name="PandaMonitorV2-asyncio", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop_requested.set()
        if self._loop and not self._loop.is_closed() and self._halt:
            self._loop.call_soon_threadsafe(self._halt.set)

    def ack_contacts(self, job_id: int) -> None:
        def acknowledge() -> None:
            try:
                if self._monitor:
                    self._monitor.ack_contact(job_id)
                self._in_phone.discard(job_id)
                self._awaiting_ack.pop(job_id, None)
            except Exception:
                self.emit("error", text="電話保存確認未完成，工作仍保留，停止後可重試。")
        if self._loop and not self._loop.is_closed():
            self._loop.call_soon_threadsafe(acknowledge)

    def test_phone(self, lane: str) -> None:
        def enqueue() -> None:
            if lane not in self._latest or lane not in self._crawlers:
                self.emit("error", text="該路尚未收到有效列表，無法執行電話測試。")
                return
            task = asyncio.create_task(self._lookup({"lane": lane, "listing_id": self._latest[lane][0],
                                                     "url": self._latest[lane][1]}, test_mode=True))
            self._test_tasks.add(task)
            task.add_done_callback(self._test_tasks.discard)
        if self._loop and not self._loop.is_closed() and self._sessions:
            self._loop.call_soon_threadsafe(enqueue)
        else:
            self.emit("error", text="請先啟動 V2 並完成列表擷取，再測試電話 API。")

    def _entry(self) -> None:
        owner_thread = threading.get_ident()
        controller = self
        class EventLogHandler(logging.Handler):
            def emit(self, record: logging.LogRecord) -> None:
                if record.thread == owner_thread:
                    controller.emit("log", text=self.format(record))
        logger = logging.getLogger("crawler")
        old_level = logger.level
        handler = EventLogHandler()
        handler.setFormatter(logging.Formatter("%(levelname)s %(message)s"))
        logger.addHandler(handler)
        logger.setLevel(logging.INFO)
        try:
            asyncio.run(self._run())
        except (CaptureError, MonitorConfigurationError) as exc:
            self.emit("error", text=str(exc))  # Fixed descriptions from our own validators.
        except Exception as exc:
            self.emit("error", text=f"V2 未完成（{type(exc).__name__}）；請核對本機環境與代理設定。")
        finally:
            logger.removeHandler(handler)
            logger.setLevel(old_level)
            self._loop = None
            self.emit("done")

    async def _run(self) -> None:
        from playwright.async_api import async_playwright
        self._loop = asyncio.get_running_loop()
        self._halt = asyncio.Event()
        if self._stop_requested.is_set():
            return
        self.emit("phase", phase="capture", text="請在已勾選的列表分頁各搜尋一次（業主、最新、第 1 頁）。")
        async def learn() -> Any:
            async with async_playwright() as playwright:
                browser = await playwright.chromium.connect_over_cdp(normalize_cdp(self.options.cdp), timeout=15_000)
                return await capture(browser, self.options.capture_seconds, selected_lanes=self.options.selected_lanes)
        capture_task = asyncio.create_task(learn())
        stop_task = asyncio.create_task(self._halt.wait())
        try:
            done, _ = await asyncio.wait({capture_task, stop_task}, return_when=asyncio.FIRST_COMPLETED)
            if stop_task in done:
                return
            observations = await capture_task
        finally:
            for task in (capture_task, stop_task):
                if not task.done():
                    task.cancel()
            await asyncio.gather(capture_task, stop_task, return_exceptions=True)
        prepared = prepare(observations, interval=.5, concurrency=self.options.concurrency,
                           timeout=self.options.timeout, overrides=self.options.impersonate_overrides,
                           selected_lanes=self.options.selected_lanes)
        prepared = apply_session_settings(prepared, self.options)
        if self._halt.is_set():
            return
        await self.run_prepared(prepared)

    async def run_prepared(self, prepared: Any, *, max_requests: int | None = None) -> None:
        """Also supports offline end-to-end tests using genuine local HTTP."""
        self._loop = asyncio.get_running_loop()
        if self._halt is None:
            self._halt = asyncio.Event()
        if self._halt.is_set() or self._stop_requested.is_set():
            return
        folder = self.options.data_dir or data_root() / "monitor"
        self._monitor = ListingMonitor(prepared, state_path=Path(folder) / "seen.sqlite3",
                                       queue_contacts=self.options.phone_enabled, summary_interval=30)
        tasks: list[asyncio.Task[Any]] = []
        try:
            async with AsyncExitStack() as stack:
                for name, site in prepared.sites.items():
                    connection = proxy_options(SITE_PREFIXES[name], value=self.options.proxy or None)
                    session = await stack.enter_async_context(AsyncSession(
                        max_clients=site.concurrency + self.options.phone_concurrency,
                        impersonate=site.impersonate, headers={"User-Agent": site.user_agent}, **connection,
                    ))
                    install_browser_cookies(session, site.cookies, name)
                    self._sessions[name] = session
                    self._states[name] = SiteState(site.concurrency)
                    self.emit("log", text=f"{name}：curl_cffi 異步通道已建立；代理={'已指定' if connection else '依環境設定'}。")
                self._phone_gate = asyncio.Semaphore(self.options.phone_concurrency)
                for lane in prepared.lanes:
                    async def on_data(payload: Any, request_id: int, name: str = lane.name) -> None:
                        assert self._monitor is not None
                        discovered = await self._monitor(name, payload, request_id)
                        self._last_ok[name] = time.time()
                        first = self._monitor.latest_listing(name)
                        if first:
                            self._latest[name] = (first["listing_id"], first["url"])
                        for event in discovered:
                            self.emit("listing", **{key: event[key] for key in ("lane", "listing_id", "url", "first_seen_at")})
                    crawler = Crawler(lane.config, on_data, state=self._states[lane.site], name=lane.name)
                    self._crawlers[lane.name] = crawler
                    self._headers[lane.name] = lane.config.headers
                    tasks.append(asyncio.create_task(crawler.run(max_requests, session=self._sessions[lane.site])))
                self.emit("phase", phase="running", text="V2 監控中；首次有效回應建立基線，之後只處理首次發現的樓盤。")
                auxiliary = [asyncio.create_task(self._telemetry()), asyncio.create_task(self._dispatch_contacts())]
                stop_task = asyncio.create_task(self._halt.wait())
                all_lists = asyncio.gather(*tasks)
                try:
                    done, _ = await asyncio.wait({all_lists, stop_task, *auxiliary}, return_when=asyncio.FIRST_COMPLETED)
                    for task in auxiliary:
                        if task in done:
                            task.result()
                    if all_lists.done():
                        await all_lists
                    # Give any final received events a telemetry update.
                    self._report_lanes()
                finally:
                    self._halt.set()
                    for state in self._states.values():
                        state.stop.set()
                    for task in [*tasks, *auxiliary, stop_task, *self._test_tasks]:
                        if not task.done():
                            task.cancel()
                    await asyncio.gather(*tasks, *auxiliary, stop_task, *self._test_tasks, return_exceptions=True)
                    if not all_lists.done():
                        all_lists.cancel()
                    await asyncio.gather(all_lists, return_exceptions=True)
        finally:
            self._sessions.clear()
            if self._monitor:
                self._monitor.close()
                self._monitor = None

    def _report_lanes(self) -> None:
        if not self._monitor:
            return
        now = asyncio.get_running_loop().time()
        for name, crawler in self._crawlers.items():
            state, stats = crawler.state, crawler.stats
            counts = self._monitor.lane_snapshot(name)
            if state.stop.is_set():
                status = "驗證／存取已停止" if stats.forbidden or stats.blocked or LANES[name][0] in self._alerted else "已停止"
            elif now < state.dns_retry_until:
                status = "DNS 退避中"
            elif now < state.cooldown_until:
                status = "429 退避中"
            else:
                status = "監控中" if self._last_ok.get(name) else "等待有效回應"
            self.emit("lane", lane=name, status=status, started=stats.started, succeeded=stats.succeeded,
                      failed=stats.failed, skipped=stats.skipped, in_flight=state.in_flight,
                      capacity=state.concurrency, valid=counts.get("valid", counts.get("accepted", 0)),
                      seen=counts.get("seen", 0), discoveries=counts.get("discoveries", 0),
                      last_ok=self._last_ok.get(name, 0))
            site = LANES[name][0]
            if (stats.forbidden or stats.blocked) and site not in self._alerted:
                self._alerted.add(site)
                self.emit("alert", site=site, kind="403" if stats.forbidden else "challenge",
                          text=f"{site}：已停止同站新增請求。cf_clearance 可能失效或網站要求驗證；"
                               "請在原瀏覽器確認，再停止並重新啟動 V2。403 本身不能證明 Cookie 已失效。")

    async def _telemetry(self) -> None:
        while self._halt and not self._halt.is_set():
            self._report_lanes()
            await asyncio.sleep(1)

    async def _dispatch_contacts(self) -> None:
        while self._halt and not self._halt.is_set():
            if self.options.phone_enabled and self._monitor:
                now = asyncio.get_running_loop().time()
                for job_id, delivered_at in list(self._awaiting_ack.items()):
                    if now - delivered_at >= 60:
                        self._monitor.release_contact(job_id, retry_seconds=30)
                        self._awaiting_ack.pop(job_id, None)
                        self._in_phone.discard(job_id)
                        self.emit("error", text="介面尚未確認電話保存，已保留工作稍後重試。")
                capacity = self.options.phone_concurrency - len(self._in_phone)
                if capacity > 0:
                    for job in self._monitor.claim_contacts(limit=capacity):
                        self._in_phone.add(job["job_id"])
                        task = asyncio.create_task(self._lookup(job))
                        self._test_tasks.add(task)
                        task.add_done_callback(self._test_tasks.discard)
            await asyncio.sleep(.2)

    async def _lookup(self, job: dict[str, Any], *, test_mode: bool = False) -> None:
        lane = job["lane"]
        site = LANES[lane][0]
        state = self._states[site]
        job_id = job.get("job_id")
        delivered = False
        try:
            now = asyncio.get_running_loop().time()
            wait = max(state.cooldown_until, state.dns_retry_until) - now
            if state.stop.is_set() or wait > 0:
                if job_id and self._monitor:
                    self._monitor.release_contact(job_id, retry_seconds=max(30, wait))
                if test_mode:
                    self.emit("error", text="該站處於停止或退避狀態，目前不執行電話測試。")
                return
            url = job.get("url")
            if not url and site == "house730":
                # This canonical route is present in the legacy app's listing_key.
                trade = lane.rsplit("-", 1)[1]
                url = f"https://www.house730.com/{trade}-property-{job['listing_id']}/"
            generation = state.dns_generation
            async with self._phone_gate:
                wait = max(state.cooldown_until, state.dns_retry_until) - asyncio.get_running_loop().time()
                if state.stop.is_set() or wait > 0:
                    if job_id and self._monitor:
                        self._monitor.release_contact(job_id, retry_seconds=max(30, wait))
                    return
                result = await fetch_contacts(lane, job["listing_id"], url, self._sessions[site],
                                              self._headers.get(lane, {}), timeout=self.options.timeout)
            if result.kind in ("forbidden", "challenge"):
                state.stop.set()
                if site not in self._alerted:
                    self._alerted.add(site)
                    self.emit("alert", site=site, kind="403" if result.status == 403 else "challenge",
                              text=f"{site} 電話 API 要求驗證或拒絕存取；cf_clearance 可能失效，已停止同站新增請求。")
                if job_id and self._monitor:
                    self._monitor.release_contact(job_id, retry_seconds=30)
            elif result.kind == "rate":
                delay = retry_delay(result.retry_after)
                state.cooldown_until = max(state.cooldown_until, asyncio.get_running_loop().time() + delay)
                if job_id and self._monitor:
                    self._monitor.release_contact(job_id, retry_seconds=delay)
                self.emit("log", text=f"{site} 電話 API HTTP 429；同站依 Retry-After 退避。")
            elif result.kind == "network":
                if result.error_code in (5, 6):
                    state.defer_dns(asyncio.get_running_loop().time(), generation)
                if job_id and self._monitor:
                    self._monitor.release_contact(job_id, retry_seconds=30)
                self.emit("log", text=f"{site} 電話 API 網路未完成，稍後重試；未輸出原始例外。")
            elif result.contacts:
                self.emit("contacts", lane=lane, listing_id=job["listing_id"], url=url,
                          contacts=[{"name": item.name, "phone": item.phone} for item in result.contacts],
                          first_seen_at=job.get("first_seen_at", ""), job_id=job_id, test_mode=test_mode)
                delivered = bool(job_id)
                if job_id:
                    self._awaiting_ack[job_id] = asyncio.get_running_loop().time()
            elif result.kind in ("invalid", "http"):
                if job_id and self._monitor:
                    self._monitor.release_contact(job_id, retry_seconds=60)
                self.emit("log", text=f"{lane}：電話 API 格式或 HTTP 狀態未通過，保留工作稍後重試。")
            else:
                if job_id and self._monitor:
                    self._monitor.release_contact(job_id, outcome="no-public-phone")
                self.emit("log", text=f"{lane}：電話 API 未提供可解析的公開完整手機號碼。")
        except asyncio.CancelledError:
            if job_id and self._monitor:
                self._monitor.release_contact(job_id, retry_seconds=1)
            raise
        except Exception:
            if job_id and self._monitor:
                self._monitor.release_contact(job_id, retry_seconds=30)
            self.emit("error", text="電話處理未完成，已保留工作稍後重試；未輸出請求內容。")
        finally:
            if job_id and not delivered:
                self._in_phone.discard(job_id)
