"""Bounded public contact API requests through the caller's curl_cffi session.

Credentials stay in the supplied per-site session and are never written here.
Only already discovered listing IDs are queried; there is no CAPTCHA solver,
detail-page navigation, hidden-field guessing or request-signature synthesis.
"""
from __future__ import annotations

import asyncio
from dataclasses import dataclass, field
import json
import math
import re
from typing import Any
from urllib.parse import urlsplit

from bs4 import BeautifulSoup, NavigableString, Tag
from curl_cffi.requests.exceptions import RequestException

MAX_CONTACT_BYTES = 500_000
KNOWN_LANES = {"28hse-rent", "28hse-buy", "house730-rent", "house730-buy"}
HOUSE_STABLE_HEADERS = {
    "accept", "authorization", "language", "lang", "platform", "cityen",
    "appkey", "app-key", "appversion", "version", "channel", "region", "locale",
}
PHONE_LABEL = re.compile(
    r"(?:\bTel\.?|電話|电话)\s*[:：]\s*"
    r"((?:(?:\+?852|00852)[\s().-]*)?[2-9][0-9]{3}[\s.-]?[0-9]{4})"
    r"(?![0-9*xX])", re.I,
)
TITLE_NAME = re.compile(
    r"([\u3400-\u9fff]{1,5}(?:小姐|女士|太太|先生|姐|生)|"
    r"\b(?:Ms|Mrs|Miss|Mr)\.?\s+[A-Za-z][A-Za-z .]{0,35})", re.I,
)


@dataclass(frozen=True)
class Contact:
    name: str = field(repr=False)
    phone: str = field(repr=False)


@dataclass(frozen=True)
class ContactResult:
    contacts: tuple[Contact, ...] = field(default=(), repr=False)
    status: int = 0
    kind: str = "empty"
    retry_after: str | None = field(default=None, repr=False)
    error_code: int | None = None


def _name(value: Any) -> str:
    if not isinstance(value, str):
        return "未提供"
    value = " ".join(value.split())
    return value[:80] if value else "未提供"


def _phone(value: Any) -> str | None:
    """Accept a complete HK mobile field, never digits inside arbitrary text."""
    if isinstance(value, bool) or not isinstance(value, (str, int)):
        return None
    text = str(value).strip()
    if len(text) > 50 or not re.fullmatch(r"(?:\+?852|00852)?[0-9\s().-]{8,35}", text):
        return None
    digits = re.sub(r"\D", "", text)
    if digits.startswith("00852") and len(digits) == 13:
        digits = digits[5:]
    elif digits.startswith("852") and len(digits) == 11:
        digits = digits[3:]
    return digits if re.fullmatch(r"[4-9][0-9]{7}", digits) else None


def _valid_listing(lane: str, listing_id: Any, url: str | None) -> tuple[str, str] | None:
    if lane not in KNOWN_LANES or isinstance(listing_id, bool):
        return None
    pid = str(listing_id)
    pattern = r"[1-9][0-9]{5,9}" if lane.startswith("28hse-") else r"[1-9][0-9]{0,19}"
    if not re.fullmatch(pattern, pid):
        return None
    trade = "rent" if lane.endswith("-rent") else "buy"
    # House730's contact endpoint needs only its genuine public property ID.
    # Its listing response does not always contain a detail URL.
    if url is None and lane.startswith("house730-"):
        return pid, f"https://www.house730.com/{trade}/s1u14/"
    if not isinstance(url, str) or len(url) > 3000 or any(ord(char) <= 32 for char in url):
        return None
    try:
        parsed = urlsplit(url)
        site = "28hse.com" if lane.startswith("28hse-") else "house730.com"
        if (parsed.scheme != "https" or parsed.hostname not in {site, "www." + site}
                or parsed.username is not None or parsed.password is not None
                or parsed.port not in (None, 443) or parsed.query or parsed.fragment):
            return None
        expected = (rf"/{trade}/(?:[^/?#]+/)*property-{re.escape(pid)}/?"
                    if lane.startswith("28hse-") else
                    rf"/{trade}-property-{re.escape(pid)}(?:\.html?)?(?:/[^?#]*)?/?")
        if not re.fullmatch(expected, parsed.path):
            return None
    except ValueError:
        return None
    return pid, url


def _identity_conflict(payload: dict[str, Any], pid: str, site: str) -> bool:
    checks = [payload]
    if site == "28hse":
        data = payload.get("data")
        if isinstance(data, dict):
            checks.append(data)
            if isinstance(data.get("results"), dict):
                checks.append(data["results"])
    else:
        result = payload.get("result")
        if isinstance(result, dict):
            checks.append(result)
            for key in ("contacts", "list", "items", "data", "results"):
                if isinstance(result.get(key), list):
                    checks.extend(part for part in result[key][:40] if isinstance(part, dict))
        elif isinstance(result, list):
            checks.extend(part for part in result[:40] if isinstance(part, dict))
    for part in checks:
        for key in ("propertyId", "PropertyId", "propertyID", "listingId", "ListingId", "ad_id"):
            if key in part and part[key] not in (None, "") and str(part[key]) != pid:
                return True
    return False


def _house_contacts(payload: dict[str, Any]) -> tuple[Contact, ...] | None:
    result = payload.get("result")
    if isinstance(result, dict):
        if "telphone" in result or "customerTel" in result:
            result = [result]
        else:
            result = next((result[key] for key in ("contacts", "list", "items", "data", "results")
                           if isinstance(result.get(key), list)), None)
    if not isinstance(result, list):
        return None
    contacts: list[Contact] = []
    seen: set[str] = set()
    for part in result[:40]:
        if not isinstance(part, dict):
            continue
        visible = part.get("isShowTel")
        if visible is False or visible == 0 or (isinstance(visible, str) and visible.lower() in {"false", "0", "no"}):
            continue
        phone = _phone(part.get("telphone")) or _phone(part.get("customerTel"))
        if phone is None or phone in seen:
            continue
        seen.add(phone)
        names = [_name(part.get(key)) for key in ("contactNameCN", "contactNameEN")]
        name = " ".join(dict.fromkeys(name for name in names if name != "未提供"))
        contacts.append(Contact(_name(name), phone))
    return tuple(contacts)


def _hse_contacts(parts: list[Any]) -> tuple[Contact, ...]:
    found: dict[str, Contact] = {}
    for fragment in parts[:24]:
        if not isinstance(fragment, str):
            continue
        soup = BeautifulSoup(fragment, "html.parser")
        for node in list(soup.select("script,style,noscript,template,[hidden],[aria-hidden='true']")):
            if node.attrs is not None:
                node.decompose()
        for node in list(soup.select("[style]")):
            if node.attrs is not None and re.search(
                r"(?:display\s*:\s*none|visibility\s*:\s*hidden)", node.get("style", ""), re.I,
            ):
                node.decompose()
        blocks = soup.select(".content_phone_information") or [soup]
        for block in blocks:
            chunks: list[str] = []
            names: list[tuple[int, str]] = []
            phone_events: list[tuple[int, int, str]] = []
            offset = 0

            def walk(node: Any, depth: int = 0) -> None:
                nonlocal offset
                if depth > 40:
                    return
                if isinstance(node, NavigableString):
                    text = str(node) + " "
                    chunks.append(text)
                    offset += len(text)
                    return
                if not isinstance(node, Tag):
                    return
                start = offset
                classes = {re.sub(r"[^a-z]", "", str(value).lower()) for value in node.get("class", [])}
                if node is not block and "contentphoneinformation" in classes:
                    return  # A nested contact block must establish its own name.
                if any("contactname" in value or "personname" in value for value in classes):
                    names.append((start, _name(node.get_text(" ", strip=True))))
                href = node.get("href", "")
                value = None
                if isinstance(href, str) and href.lower().startswith("tel:"):
                    value = href[4:].split("?", 1)[0]
                elif "fullphone" in classes:
                    value = node.get_text(" ", strip=True)
                for child in node.children:
                    walk(child, depth + 1)
                if isinstance(value, str):
                    phone_events.append((start, offset, value))

            walk(block)
            text = "".join(chunks)
            phone_events.extend((match.start(), match.end(), match[1]) for match in PHONE_LABEL.finditer(text))
            previous_end = 0
            for start, end, raw in sorted(phone_events, key=lambda item: item[0]):
                phone = _phone(raw)
                if phone is None:
                    continue
                explicit = [name for position, name in names if position <= start]
                titled = list(TITLE_NAME.finditer(text[max(0, previous_end):start]))
                name = _name(titled[-1][1]) if titled else explicit[-1] if explicit else "未提供"
                previous_end = max(previous_end, end)
                if phone not in found or (found[phone].name == "未提供" and name != "未提供"):
                    found[phone] = Contact(name, phone)
    return tuple(found.values())


def _request_headers(site: str, referer: str, source: dict[str, str]) -> dict[str, str]:
    if site == "28hse":
        # The original verified same-origin action has no list signatures.
        return {
            "Accept": "application/json, text/javascript, */*; q=0.01",
            "X-Requested-With": "XMLHttpRequest",
            "Referer": referer,
            "Origin": "https://www.28hse.com",
            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
        }
    headers = {key: value for key, value in source.items()
               if key.lower() in HOUSE_STABLE_HEADERS and isinstance(value, str)}
    headers["Accept"] = "application/json"
    headers["Referer"] = referer
    headers["Origin"] = "https://www.house730.com"
    return headers


def _json_object(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key")
        result[key] = value
    return result


def _invalid_constant(value: str) -> None:
    raise ValueError("Non-finite JSON value")


async def fetch_contacts(
    lane: str, listing_id: str, url: str | None, session: Any,
    headers: dict[str, str], timeout: float = 10,
) -> ContactResult:
    """Fetch one known listing's public contacts; never log response values."""
    valid = _valid_listing(lane, listing_id, url)
    if (valid is None or isinstance(timeout, bool) or not isinstance(timeout, (int, float))
            or not math.isfinite(timeout) or timeout <= 0 or not isinstance(headers, dict)
            or not all(isinstance(key, str) and isinstance(value, str) for key, value in headers.items())):
        return ContactResult(kind="invalid-input")
    pid, referer = valid
    site = "28hse" if lane.startswith("28hse-") else "house730"
    request_headers = _request_headers(site, referer, headers)
    if site == "28hse":
        target = "https://www.28hse.com/property/detail/doaction"
        method = "POST"
        options = {"data": {"action": "statistic_inc", "user_action": "phone", "ad_id": pid,
                            "event_name": "property_contact_phone"}}
    else:
        target = "https://api.house730.com/Property/GetPropertyUserInfoById"
        method = "GET"
        options = {"params": {"propertyId": pid}}
    try:
        response = await session.request(method, target, headers=request_headers,
                                         timeout=timeout, allow_redirects=False, **options)
    except RequestException as exc:
        code = getattr(exc, "code", None)
        return ContactResult(kind="network", error_code=int(code) if isinstance(code, int) else None)
    except (asyncio.TimeoutError, OSError):
        return ContactResult(kind="network")
    status = response.status_code
    if not isinstance(status, int) or isinstance(status, bool):
        return ContactResult(kind="invalid")
    incoming = {str(key).lower(): value for key, value in response.headers.items()}
    if str(incoming.get("cf-mitigated", "")).lower() == "challenge":
        return ContactResult(status=status, kind="challenge")
    if status in (401, 403):
        return ContactResult(status=status, kind="forbidden")
    if status == 429:
        retry = incoming.get("retry-after")
        return ContactResult(status=status, kind="rate", retry_after=retry if isinstance(retry, str) else None)
    if status != 200:
        return ContactResult(status=status, kind="http")
    body = response.content
    if not isinstance(body, bytes) or len(body) > MAX_CONTACT_BYTES:
        return ContactResult(status=status, kind="invalid")
    try:
        text = body.decode("utf-8")
        payload = json.loads(text, parse_constant=_invalid_constant, object_pairs_hook=_json_object)
    except (UnicodeDecodeError, ValueError, RecursionError):
        challenge = any(marker in body[:20_000].lower() for marker in (
            b"cf-turnstile", b"challenges.cloudflare.com", b"verify you are human", b"checking your browser",
        ))
        return ContactResult(status=status, kind="challenge" if challenge else "invalid")
    content_type = str(incoming.get("content-type", "")).lower()
    if content_type and "json" not in content_type and "javascript" not in content_type:
        return ContactResult(status=status, kind="invalid")
    if not isinstance(payload, dict) or _identity_conflict(payload, pid, site):
        return ContactResult(status=status, kind="invalid")
    if site == "28hse":
        if "status" in payload and (type(payload["status"]) is not int or payload["status"] != 1):
            return ContactResult(status=status, kind="invalid")
        data = payload.get("data")
        result = data.get("results") if isinstance(data, dict) else None
        if not isinstance(result, dict):
            return ContactResult(status=status, kind="invalid")
        if result.get("need_verify"):
            return ContactResult(status=status, kind="challenge")
        parts = result.get("contacts")
        if not isinstance(parts, list):
            return ContactResult(status=status, kind="invalid")
        contacts = _hse_contacts(parts)
    else:
        if "code" in payload and (type(payload["code"]) is not int or payload["code"] != 0):
            return ContactResult(status=status, kind="invalid")
        contacts = _house_contacts(payload)
        if contacts is None:
            return ContactResult(status=status, kind="invalid")
    return ContactResult(contacts=contacts, status=status, kind="ok" if contacts else "empty")
