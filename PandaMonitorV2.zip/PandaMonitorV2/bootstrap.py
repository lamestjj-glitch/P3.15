"""Compatibility entry: launch PandaMonitorV2, never the old list engines."""
from __future__ import annotations

if __name__ == "__main__":
    from start_v2 import main
    raise SystemExit(main())
