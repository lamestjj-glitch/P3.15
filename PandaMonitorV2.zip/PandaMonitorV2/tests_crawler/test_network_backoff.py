"""DNS retry and explicit proxy checks using only local asynchronous fakes."""
from __future__ import annotations

import asyncio
import os
from types import SimpleNamespace
import unittest
from unittest.mock import patch

from curl_cffi import CurlOpt
from curl_cffi.requests.exceptions import RequestException

import async_crawler as crawler_module
from async_crawler import Config, Crawler, SiteState


class Response:
    status_code = 200
    headers = {}

    def json(self):
        return {"ok": True}


class Session:
    def __init__(self, action=None):
        self.action = action
        self.cookies = SimpleNamespace(set=lambda *args, **kwargs: None)
        self.closed = False
        self.calls = []

    async def __aenter__(self):
        return self

    async def __aexit__(self, *args):
        self.closed = True

    async def request(self, method, url, **kwargs):
        self.calls.append((method, url, kwargs))
        if self.action:
            return await self.action(url)
        return Response()


async def ignore(data, request_id):
    pass


class DNSStateTests(unittest.TestCase):
    def test_old_batch_failures_do_not_extend_retry_or_change_429_deadline(self):
        state = SiteState()
        state.cooldown_until = 200.0
        with patch.object(crawler_module, "DNS_BACKOFF_SECONDS", 30.0):
            self.assertTrue(state.defer_dns(100.0, 0))
            self.assertEqual(state.dns_retry_until, 130.0)
            self.assertFalse(state.defer_dns(115.0, 0))
            self.assertEqual(state.dns_retry_until, 130.0)
            self.assertEqual(state.dns_generation, 1)
            self.assertEqual(state.cooldown_until, 200.0)
            self.assertTrue(state.defer_dns(140.0, 1))
            self.assertEqual(state.dns_retry_until, 170.0)


class DNSRuntimeTests(unittest.IsolatedAsyncioTestCase):
    async def test_concurrent_dns_failures_share_one_pause_and_do_not_log_private_message(self):
        gate = asyncio.Event()
        entered = 0

        async def fail(url):
            nonlocal entered
            entered += 1
            await gate.wait()
            raise RequestException("PRIVATE-TOKEN PRIVATE-PROXY-PASSWORD", code=6)

        state = SiteState(concurrency=2)
        crawlers = [Crawler(Config("https://example.invalid/?secret=PRIVATE-QUERY"), ignore,
                            state=state, name=f"batch-{index}") for index in range(2)]
        with self.assertLogs("crawler", level="WARNING") as logs:
            tasks = [asyncio.create_task(crawler._fetch(Session(fail), 1)) for crawler in crawlers]
            while entered < 2:
                await asyncio.sleep(0)
            gate.set()
            await asyncio.gather(*tasks)
        self.assertEqual([crawler.stats.failed for crawler in crawlers], [1, 1])
        self.assertEqual(state.dns_generation, 1)
        self.assertGreater(state.dns_retry_until, asyncio.get_running_loop().time())
        self.assertEqual(len(logs.output), 1)
        output = "\n".join(logs.output)
        for secret in ("PRIVATE-TOKEN", "PRIVATE-PROXY-PASSWORD", "PRIVATE-QUERY"):
            self.assertNotIn(secret, output)

    async def test_proxy_dns_code_five_is_also_deferred(self):
        async def fail(url):
            raise RequestException("PRIVATE-PROXY-ADDRESS", code=5)

        crawler = Crawler(Config("https://example.invalid"), ignore)
        with self.assertLogs("crawler", level="WARNING") as logs:
            await crawler._fetch(Session(fail), 1)
        self.assertEqual(crawler.stats.failed, 1)
        self.assertGreater(crawler.state.dns_retry_until, asyncio.get_running_loop().time())
        self.assertNotIn("PRIVATE-PROXY-ADDRESS", "\n".join(logs.output))

    async def test_shared_site_retries_after_pause_while_another_site_keeps_polling(self):
        failed = False
        first = SiteState(concurrency=2)
        other = SiteState(concurrency=2)
        launches = []
        failure_at = None
        initial_a_entered = 0
        initial_a_ready = asyncio.Event()

        async def action(url):
            nonlocal failed, failure_at, initial_a_entered
            now = asyncio.get_running_loop().time()
            launches.append((url, now, first.dns_retry_until))
            if "/a-" in url and initial_a_entered < 2:
                # Both initial requests are already sent before DNS fails.
                # Only later launches must respect the newly opened pause.
                initial_a_entered += 1
                if initial_a_entered == 2:
                    initial_a_ready.set()
                await initial_a_ready.wait()
            if url.endswith("/a-rent") and not failed:
                failed = True
                failure_at = asyncio.get_running_loop().time()
                raise RequestException("PRIVATE-DNS-FAILURE", code=6)
            await asyncio.sleep(.001)
            return Response()

        crawlers = [Crawler(Config(f"https://example.invalid/{lane}", interval=.01, concurrency=2),
                            ignore, state=first if index < 2 else other, name=lane)
                    for index, lane in enumerate(("a-rent", "a-buy", "b-rent", "b-buy"))]
        with patch.object(crawler_module, "DNS_BACKOFF_SECONDS", .10), \
             self.assertLogs("crawler", level="WARNING"):
            results = await asyncio.wait_for(asyncio.gather(*(
                crawler.run(max_requests=3 if index < 2 else 8, session=Session(action))
                for index, crawler in enumerate(crawlers)
            )), 2)
        self.assertIsNotNone(failure_at)
        delayed = [(started, until) for url, started, until in launches
                   if "/a-" in url and until]
        self.assertTrue(delayed)
        self.assertTrue(all(started >= until - .002 for started, until in delayed))
        self.assertTrue(any("/b-" in url and failure_at + .025 < started < failure_at + .08
                            for url, started, _ in launches))
        self.assertEqual([result.succeeded for result in results[2:]], [8, 8])
        self.assertEqual((first.in_flight, other.in_flight), (0, 0))

    async def test_successful_older_request_does_not_clear_a_dns_pause_or_429(self):
        gate = asyncio.Event()
        entered = asyncio.Event()

        async def slow_success(url):
            entered.set()
            await gate.wait()
            return Response()

        state = SiteState()
        state.cooldown_until = asyncio.get_running_loop().time() + 60
        crawler = Crawler(Config("https://example.invalid"), ignore, state=state)
        task = asyncio.create_task(crawler._fetch(Session(slow_success), 1))
        await entered.wait()
        self.assertTrue(state.defer_dns(asyncio.get_running_loop().time(), 0))
        expected_dns, expected_429 = state.dns_retry_until, state.cooldown_until
        gate.set()
        await task
        self.assertEqual(crawler.stats.succeeded, 1)
        self.assertEqual(state.dns_retry_until, expected_dns)
        self.assertEqual(state.cooldown_until, expected_429)

    async def test_cancellation_during_dns_wait_returns_without_starting_requests(self):
        state = SiteState()
        state.defer_dns(asyncio.get_running_loop().time(), 0)
        crawler = Crawler(Config("https://example.invalid", interval=.01), ignore, state=state)
        session = Session()
        task = asyncio.create_task(crawler.run(session=session))
        await asyncio.sleep(.01)
        task.cancel()
        with self.assertRaises(asyncio.CancelledError):
            await asyncio.wait_for(task, .5)
        self.assertEqual(session.calls, [])
        self.assertEqual(state.in_flight, 0)
        self.assertEqual(state._waiting, [])
        self.assertFalse(session.closed)

    async def test_non_dns_request_error_retains_existing_retry_behavior(self):
        async def timeout(url):
            raise RequestException("PRIVATE-TIMEOUT", code=28)

        crawler = Crawler(Config("https://example.invalid", interval=.01), ignore)
        with self.assertLogs("crawler", level="WARNING"):
            stats = await crawler.run(max_requests=2, session=Session(timeout))
        self.assertEqual((stats.started, stats.failed), (2, 2))
        self.assertEqual(crawler.state.dns_retry_until, 0)

    async def test_concurrency_skip_warnings_are_summarized_without_losing_counts(self):
        async def slow(url):
            await asyncio.sleep(.08)
            return Response()

        crawler = Crawler(Config("https://example.invalid", interval=.002, concurrency=1), ignore)
        with self.assertLogs("crawler", level="WARNING") as logs:
            stats = await crawler.run(max_requests=3, session=Session(slow))
        self.assertEqual((stats.started, stats.succeeded), (3, 3))
        self.assertGreater(stats.skipped, 20)
        self.assertLessEqual(len(logs.output), 2)
        self.assertEqual(crawler.state.in_flight, 0)


class ProxyOptionsTests(unittest.TestCase):
    @staticmethod
    def expected_proxy(value):
        return {"proxy": value, "curl_options": {CurlOpt.NOPROXY: ""}}

    def test_common_proxy_and_per_site_override_are_kept_separate(self):
        common = "socks5h://user:PRIVATE-COMMON@127.0.0.1:1080"
        override = "http://user:PRIVATE-HSE@127.0.0.1:8080"
        with patch.dict(os.environ, {"CRAWLER_PROXY": common, "HSE28_PROXY": override}, clear=True):
            self.assertEqual(crawler_module.proxy_options(), self.expected_proxy(common))
            self.assertEqual(crawler_module.proxy_options("HSE28"), self.expected_proxy(override))
            self.assertEqual(crawler_module.proxy_options("HOUSE730"), self.expected_proxy(common))
        with patch.dict(os.environ, {}, clear=True):
            self.assertEqual(crawler_module.proxy_options(), {})

    def test_supported_proxy_protocols_pass_without_rewriting(self):
        for scheme in ("http", "https", "socks4", "socks4a", "socks5", "socks5h"):
            value = f"{scheme}://private-user:PRIVATE-PASSWORD@127.0.0.1:1080"
            with self.subTest(scheme=scheme), patch.dict(os.environ, {"CRAWLER_PROXY": value}, clear=True):
                self.assertEqual(crawler_module.proxy_options(), self.expected_proxy(value))

    def test_bad_proxy_settings_raise_fixed_errors_without_private_values(self):
        values = ("ftp://PRIVATE-PASSWORD@127.0.0.1:1080", "http://PRIVATE-PASSWORD@:1080",
                  "http://PRIVATE-PASSWORD@127.0.0.1:99999", "http://PRIVATE-PASSWORD@127.0.0.1:8080/private",
                  "http://PRIVATE-PASSWORD@127.0.0.1:8080?token=PRIVATE-TOKEN", "PRIVATE-PASSWORD")
        for value in values:
            with self.subTest(kind=value.split(":", 1)[0]), \
                 patch.dict(os.environ, {"CRAWLER_PROXY": value}, clear=True):
                with self.assertRaises(ValueError) as caught:
                    crawler_module.proxy_options()
                self.assertNotIn("PRIVATE-PASSWORD", str(caught.exception))
                self.assertNotIn("PRIVATE-TOKEN", str(caught.exception))


class ProxySessionTests(unittest.IsolatedAsyncioTestCase):
    async def test_owned_session_receives_proxy_but_injected_session_remains_owned_by_caller(self):
        value = "socks5h://user:PRIVATE-PASSWORD@127.0.0.1:1080"
        owned, injected = Session(), Session()
        with patch.dict(os.environ, {"CRAWLER_PROXY": value}, clear=True), \
             patch.object(crawler_module, "AsyncSession", return_value=owned) as factory:
            await Crawler(Config("https://example.invalid"), ignore).run(max_requests=1)
            self.assertEqual(factory.call_args.kwargs["proxy"], value)
            self.assertEqual(factory.call_args.kwargs["curl_options"], {CurlOpt.NOPROXY: ""})
            factory.reset_mock()
            await Crawler(Config("https://example.invalid"), ignore).run(max_requests=1, session=injected)
            factory.assert_not_called()
        self.assertTrue(owned.closed)
        self.assertFalse(injected.closed)

    async def test_four_lanes_apply_their_own_site_proxy_to_separate_sessions(self):
        import four_lane_crawler as four_module
        from four_lane_crawler import LaneConfig, PreparedRun, SiteConfig

        first_proxy = "http://user:PRIVATE-HSE@127.0.0.1:8080"
        common_proxy = "socks5h://user:PRIVATE-COMMON@127.0.0.1:1080"
        sites = {name: SiteConfig(name) for name in ("28hse", "house730")}
        lanes = [LaneConfig(f"{site}-{trade}", site, "https://example.invalid/",
                            Config(f"https://example.invalid/{site}/{trade}", interval=.01))
                 for site in sites for trade in ("rent", "buy")]
        sessions = [Session(), Session()]

        async def consume(lane, data, request_id):
            pass

        with patch.dict(os.environ, {"CRAWLER_PROXY": common_proxy, "HSE28_PROXY": first_proxy}, clear=True), \
             patch.object(four_module, "AsyncSession", side_effect=sessions) as factory:
            results = await four_module.run_four_lanes(PreparedRun(sites, lanes), max_requests=1,
                                                       on_data=consume)
        self.assertEqual([call.kwargs["proxy"] for call in factory.call_args_list],
                         [first_proxy, common_proxy])
        self.assertTrue(all(call.kwargs["curl_options"] == {CurlOpt.NOPROXY: ""}
                            for call in factory.call_args_list))
        self.assertEqual([result.succeeded for result in results.values()], [1, 1, 1, 1])
        self.assertTrue(all(session.closed for session in sessions))
