"""Synthetic copies of the verified response shape; no uploaded IDs or data."""
from __future__ import annotations

import unittest

from hse28_parser import parse_listings
from listing_types import ListingParseError


def response(html: str = '<a href="/rent/apartment/property-1000001">Fixture</a>', *,
             page=1, count=1, status=1):
    return {"status": status, "data": {"results": {
        "resultContentHtml": html,
        "resultData": {"ListingPaginator": {"page": page, "count": count}},
    }}}


class Hse28ParserTests(unittest.TestCase):
    def test_main_html_links_are_deduplicated_in_response_order(self):
        payload = response('''<div class="unrelated-selector">
            <a href="/rent/apartment/property-1000001"><img></a>
            <a href="/rent/apartment/property-1000001">Fixture</a>
            <a href="/rent/office/property-1000002">Another fixture</a></div>''', count=20)
        payload["data"]["results"]["resultData"]["items"] = []
        result = parse_listings("28hse-rent", payload)
        self.assertEqual([item.listing_id for item in result.listings], ["1000001", "1000002"])
        self.assertEqual(result.listings[0].url, "https://www.28hse.com/rent/apartment/property-1000001")
        self.assertEqual((result.page, result.total), (1, 20))
        self.assertIsNone(result.listings[0].title)

    def test_trusted_absolute_and_multisegment_links_have_no_query_or_fragment(self):
        payload = response('''<a href="https://28hse.com:443/buy/hk/area/apartment/property-1000001/?token=PRIVATE#secret">Fixture</a>
            <a href="//www.28hse.com/buy/office/property-1000002">Fixture</a>''', count=2)
        items = parse_listings("28hse-buy", payload).listings
        self.assertEqual(items[0].url, "https://www.28hse.com/buy/hk/area/apartment/property-1000001")
        self.assertEqual(len(items), 2)
        self.assertNotIn("PRIVATE", repr(items))

    def test_external_insecure_wrong_trade_or_malformed_links_are_excluded(self):
        links = [
            "https://example.com/rent/apartment/property-1000002",
            "https://www.28hse.com.example.com/rent/apartment/property-1000002",
            "http://www.28hse.com/rent/apartment/property-1000002",
            "https://private@www.28hse.com/rent/apartment/property-1000002",
            "https://www.28hse.com:8443/rent/apartment/property-1000002",
            "/buy/apartment/property-1000002", "/rent/../property-1000002",
            "/rent/apartment/property-1000002/extra", "javascript:alert(1)",
            "https:/rent/apartment/property-1000002",
        ]
        html = '<a href="/rent/apartment/property-1000001">Fixture</a>'
        html += "".join(f'<a href="{url}">Ignored</a>' for url in links)
        self.assertEqual([item.listing_id for item in parse_listings("28hse-rent", response(html)).listings], ["1000001"])

    def test_sidebars_do_not_supply_or_add_listing_ids(self):
        payload = response("<div>No matching listing links</div>", count=4)
        payload["data"]["results"]["resultData"]["MortgageBankRateAside"] = {
            "showHtml": '<a href="/rent/apartment/property-1000002">Sidebar</a>',
            "Items": [{"adId": 1000003}],
        }
        with self.assertRaises(ListingParseError):
            parse_listings("28hse-rent", payload)

    def test_fallback_is_used_only_when_primary_key_is_missing(self):
        payload = response()
        results = payload["data"]["results"]
        results["resultData"]["showHtml"] = results.pop("resultContentHtml")
        self.assertEqual(len(parse_listings("28hse-rent", payload).listings), 1)
        for invalid in (None, "", 42):
            with self.subTest(primary=invalid):
                results["resultContentHtml"] = invalid
                with self.assertRaises(ListingParseError):
                    parse_listings("28hse-rent", payload)

    def test_explicit_empty_page_is_valid_but_false_empty_or_count_conflict_is_not(self):
        for html in ("", "<div>No results</div>"):
            with self.subTest(html=html):
                result = parse_listings("28hse-rent", response(html, count=0))
                self.assertEqual((result.listings, result.page, result.total), ((), 1, 0))
        for payload in (response("<div>No ID</div>", count=1), response(count=0)):
            with self.assertRaises(ListingParseError):
                parse_listings("28hse-rent", payload)

    def test_unknown_or_failed_payload_never_exposes_original_content(self):
        bad_values = [None, [], {"PRIVATE-PAYLOAD": "PRIVATE-CREDENTIAL"},
                      response(status=0), response(status=True), response(status="1")]
        for payload in bad_values:
            with self.subTest(kind=type(payload).__name__), self.assertRaises(ListingParseError) as caught:
                parse_listings("28hse-rent", payload)
            self.assertNotIn("PRIVATE", str(caught.exception))
        with self.assertRaises(ListingParseError):
            parse_listings("house730-rent", response())

    def test_only_integer_first_page_and_nonnegative_integer_count_are_accepted(self):
        for page in (None, 0, 2, True, "1", 1.0):
            with self.subTest(page=page), self.assertRaises(ListingParseError):
                parse_listings("28hse-rent", response(page=page))
        for count in (None, -1, True, "1", 1.0):
            with self.subTest(count=count), self.assertRaises(ListingParseError):
                parse_listings("28hse-rent", response(count=count))

    def test_missing_verified_structure_is_rejected(self):
        for payload in ({"status": 1}, {"status": 1, "data": {"results": []}},
                        {"status": 1, "data": {"results": {"resultContentHtml": ""}}}):
            with self.assertRaises(ListingParseError):
                parse_listings("28hse-rent", payload)

    def test_active_content_and_ambiguous_attributes_do_not_supply_ids(self):
        html = '''<template><a href="/rent/apartment/property-1000002">Ignored</a></template>
            <script><a href="/rent/apartment/property-1000003">Ignored</a></script>
            <a href="/rent/apartment/property-1000004" href="/rent/apartment/property-1000005">Ignored</a>
            <a href="/rent/apartment/property-1000001">Fixture</a>'''
        result = parse_listings("28hse-rent", response(html))
        self.assertEqual([item.listing_id for item in result.listings], ["1000001"])

    def test_zero_ids_are_ignored_and_cannot_establish_a_false_baseline(self):
        zero_links = ('<a href="/rent/apartment/property-0">Invalid</a>'
                      '<a href="/rent/apartment/property-000">Invalid</a>')
        valid = '<a href="/rent/apartment/property-1000001">Fixture</a>'
        result = parse_listings("28hse-rent", response(zero_links + valid))
        self.assertEqual([item.listing_id for item in result.listings], ["1000001"])
        with self.assertRaises(ListingParseError):
            parse_listings("28hse-rent", response(zero_links, count=2))


if __name__ == "__main__":
    unittest.main()
