"""Persistent first-page discovery tests using synthetic public listing IDs."""
from __future__ import annotations

import asyncio
import json
from contextlib import closing
from pathlib import Path
import sqlite3
import tempfile
import threading
from types import SimpleNamespace
import unittest
from unittest.mock import patch
from urllib.parse import urlencode

from async_crawler import Config
from listing_monitor import ListingMonitor, MonitorConfigurationError, scope_fingerprint
from listing_types import Listing, ListingPage, ListingParseError


def config(lane="house730-rent", *, filters=None, **changes):
    if lane.startswith("house730"):
        body = {"pageIndex": 1, "pageCount": 20, "propertySourceList": ["OWNER"]}
        body.update(filters or {})
        values = {"url": "https://api.house730.com/Property/Search", "method": "POST", "json_body": body}
    else:
        body = {"page": 1, "landlordAgency": "LANDLORD", "sortBy": "latest"}
        body.update(filters or {})
        values = {"url": "https://www.28hse.com/property/dosearch", "method": "POST",
                  "form": {"form_data": json.dumps(body)}}
    values.update(changes)
    return Config(**values)


def prepared(*definitions):
    return SimpleNamespace(lanes=[SimpleNamespace(name=lane,
        site="28hse" if lane.startswith("28hse") else "house730", config=setting)
        for lane, setting in definitions])


def page(*identifiers, lane="house730-rent", page_number=None):
    trade = "rent" if lane.endswith("rent") else "buy"
    records = tuple(Listing(str(identifier),
        f"https://www.house730.com/{trade}-property-{identifier}/?token=PRIVATE-LINK",
        title="PRIVATE-TITLE", price="PRIVATE-PRICE") for identifier in identifiers)
    return ListingPage(records, page=page_number, total=len(records))


class ListingMonitorTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory(prefix="monitor-tests-")
        self.addCleanup(self.directory.cleanup)
        self.folder = Path(self.directory.name)
        self.state_path = self.folder / "seen.sqlite3"
        self.output_path = self.folder / "new_listings.jsonl"

    def monitor(self, definitions=None, **kwargs):
        definitions = definitions or prepared(("house730-rent", config()))
        monitor = ListingMonitor(definitions, state_path=self.state_path,
                                 output_path=self.output_path, **kwargs)
        self.addCleanup(monitor.close)
        return monitor

    async def deliver(self, monitor, request_id, *identifiers, lane="house730-rent", page_number=None):
        with patch("listing_monitor.parse_page", return_value=page(*identifiers, lane=lane, page_number=page_number)):
            await monitor(lane, {"fixture": True}, request_id)

    def events(self):
        if not self.output_path.exists():
            return []
        return [json.loads(line) for line in self.output_path.read_text(encoding="utf-8").splitlines()]

    async def test_first_valid_page_is_only_a_silent_baseline(self):
        monitor = self.monitor()
        with self.assertLogs("crawler.monitor", level="INFO") as logs:
            await self.deliver(monitor, 1, 1000001, 1000002)
        self.assertEqual(self.events(), [])
        self.assertTrue(self.output_path.exists())
        self.assertIn("2 個 ID", "\n".join(logs.output))
        self.assertNotIn("首次發現 ID=", "\n".join(logs.output))
        with closing(sqlite3.connect(self.state_path)) as database:
            self.assertEqual(database.execute("SELECT COUNT(*) FROM monitor_seen").fetchone()[0], 2)

    async def test_new_ids_are_reported_once_and_disappearing_ids_remain_seen(self):
        monitor = self.monitor()
        await self.deliver(monitor, 1, 1000001, 1000002)
        await self.deliver(monitor, 2, 1000001, 1000003)
        await self.deliver(monitor, 3, 1000001)
        await self.deliver(monitor, 4, 1000002, 1000003)
        await self.deliver(monitor, 5, 1000003, 1000004)
        await self.deliver(monitor, 6, 1000003, 1000004)
        self.assertEqual([row["listing_id"] for row in self.events()], ["1000003", "1000004"])

    async def test_restart_loads_seen_ids_but_still_discovers_new_first_response_ids(self):
        first = self.monitor()
        await self.deliver(first, 1, 1000001)
        await self.deliver(first, 2, 1000001, 1000002)
        first.close()
        second = self.monitor()
        await self.deliver(second, 1, 1000001, 1000002, 1000003)
        await self.deliver(second, 2, 1000002, 1000003)
        self.assertEqual([row["listing_id"] for row in self.events()], ["1000002", "1000003"])

    async def test_two_precreated_instances_use_the_database_baseline_not_stale_cache(self):
        first = self.monitor()
        second = self.monitor()
        await self.deliver(first, 1, 1000001)
        await self.deliver(second, 1, 1000001, 1000002)
        await self.deliver(first, 2, 1000001, 1000002, 1000003)
        self.assertEqual([row["listing_id"] for row in self.events()], ["1000002", "1000003"])

    async def test_late_older_response_does_not_turn_old_ids_into_new_discoveries(self):
        monitor = self.monitor()
        await self.deliver(monitor, 2, 1000001)
        with patch("listing_monitor.parse_page", side_effect=AssertionError("Stale response must not be parsed")):
            await monitor("house730-rent", {"old": True}, 1)
        await self.deliver(monitor, 3, 1000001, 1000002)
        await self.deliver(monitor, 2, 1000009)
        self.assertEqual([row["listing_id"] for row in self.events()], ["1000002"])

    async def test_parse_failures_neither_initialize_nor_replace_the_baseline(self):
        monitor = self.monitor()
        with patch("listing_monitor.parse_page", side_effect=ListingParseError("PRIVATE-PARSER-MESSAGE")), \
             self.assertLogs("crawler.monitor", level="WARNING") as logs, \
             self.assertRaises(ListingParseError):
            await monitor("house730-rent", {"secret": "PRIVATE-RESPONSE"}, 1)
        self.assertNotIn("PRIVATE", "\n".join(logs.output))
        await self.deliver(monitor, 2, 1000001)
        self.assertEqual(self.events(), [])
        with patch("listing_monitor.parse_page", side_effect=ListingParseError("failure")), \
             self.assertRaises(ListingParseError):
            await monitor("house730-rent", {}, 3)
        await self.deliver(monitor, 4, 1000001, 1000002)
        self.assertEqual([row["listing_id"] for row in self.events()], ["1000002"])

    async def test_successful_empty_baseline_is_initialized_and_persists(self):
        monitor = self.monitor()
        await self.deliver(monitor, 1)
        monitor.close()
        restarted = self.monitor()
        await self.deliver(restarted, 1, 1000001)
        self.assertEqual([row["listing_id"] for row in self.events()], ["1000001"])

    async def test_each_lane_has_independent_seen_state(self):
        monitor = self.monitor(prepared(("house730-rent", config()),
                                        ("house730-buy", config("house730-buy"))))
        for lane in ("house730-rent", "house730-buy"):
            await self.deliver(monitor, 1, 1000001, lane=lane)
            await self.deliver(monitor, 2, 1000001, 1000002, lane=lane)
        self.assertEqual([(row["lane"], row["listing_id"]) for row in self.events()],
                         [("house730-rent", "1000002"), ("house730-buy", "1000002")])

    async def test_changed_search_filters_create_a_new_silent_baseline(self):
        first = self.monitor()
        await self.deliver(first, 1, 1000001)
        await self.deliver(first, 2, 1000001, 1000002)
        first.close()
        second = self.monitor(prepared(("house730-rent", config(filters={"propertySourceList": ["OTHER"]}))))
        await self.deliver(second, 1, 1000003)
        await self.deliver(second, 2, 1000003, 1000004)
        events = self.events()
        self.assertEqual([row["listing_id"] for row in events], ["1000002", "1000004"])
        self.assertNotEqual(events[0]["scope"], events[1]["scope"])

    async def test_first_page_preflight_rejects_missing_conflicting_or_later_house_pages(self):
        configs = [config(filters={"pageIndex": value}) for value in (0, 2, True, 1.0, "PRIVATE-PAGE")]
        configs.extend([
            config(json_body={"pageCount": 20}),
            config(url="https://api.house730.com/Property/Search?pageIndex=2"),
            config(json_body=None, raw_body='pageIndex=1&pageIndex=2',
                   headers={"Content-Type": "application/x-www-form-urlencoded"}),
        ])
        for setting in configs:
            with self.subTest(setting=setting), self.assertRaises(MonitorConfigurationError) as caught:
                self.monitor(prepared(("house730-rent", setting)))
            self.assertNotIn("PRIVATE-PAGE", str(caught.exception))
        self.assertFalse(self.state_path.exists())

    async def test_nested_hse_request_and_response_must_both_be_first_page(self):
        bad = config("28hse-rent", filters={"page": 2})
        with self.assertRaises(MonitorConfigurationError):
            self.monitor(prepared(("28hse-rent", bad)))
        encoded = urlencode({"form_data": json.dumps({"page": 1, "landlordAgency": "LANDLORD"})})
        setting = config("28hse-rent", form=None, raw_body=encoded,
                         headers={"Content-Type": "application/x-www-form-urlencoded"})
        monitor = self.monitor(prepared(("28hse-rent", setting)))
        with self.assertRaises(ListingParseError):
            await self.deliver(monitor, 1, 1000001, lane="28hse-rent", page_number=2)
        await self.deliver(monitor, 2, 1000001, lane="28hse-rent", page_number=1)
        await self.deliver(monitor, 3, 1000001, 1000002, lane="28hse-rent", page_number=1)
        self.assertEqual([row["listing_id"] for row in self.events()], ["1000002"])

    async def test_scope_ignores_transient_credentials_but_keeps_search_filters(self):
        first = config(filters={"token": "PRIVATE-TOKEN-ONE", "nonce": "ONE", "timestamp": 1},
                       headers={"Authorization": "PRIVATE-HEADER-ONE"},
                       url="https://api.house730.com/Property/Search?signature=PRIVATE-QUERY-ONE")
        second = config(filters={"timestamp": 2, "nonce": "TWO", "token": "PRIVATE-TOKEN-TWO"},
                        headers={"Authorization": "PRIVATE-HEADER-TWO"},
                        url="https://api.house730.com/Property/Search?signature=PRIVATE-QUERY-TWO")
        options = {"lane": "house730-rent", "site": "house730"}
        self.assertEqual(scope_fingerprint(first, **options), scope_fingerprint(second, **options))
        changed = config(filters={"propertySourceList": ["OTHER"]})
        self.assertNotEqual(scope_fingerprint(first, **options), scope_fingerprint(changed, **options))
        self.assertNotEqual(scope_fingerprint(first, **options), scope_fingerprint(first, lane="house730-buy", site="house730"))

    async def test_persistent_output_contains_only_public_ids_urls_and_metadata(self):
        secret = "PRIVATE-CREDENTIAL-MARKER"
        setting = config(filters={"token": secret}, headers={"Authorization": secret},
                         user_agent=secret, cf_clearance=secret,
                         url=f"https://api.house730.com/Property/Search?token={secret}")
        monitor = self.monitor(prepared(("house730-rent", setting)))
        with self.assertLogs("crawler.monitor", level="INFO") as logs:
            await self.deliver(monitor, 1, 1000001)
            await self.deliver(monitor, 2, 1000001, 1000002)
        self.assertNotIn("PRIVATE", "\n".join(logs.output))
        event, = self.events()
        self.assertEqual(event["url"], "https://www.house730.com/rent-property-1000002/")
        self.assertTrue(event["first_seen_at"].endswith("+07:00"))
        monitor.close()
        for path in self.folder.iterdir():
            if path.is_file():
                self.assertNotIn(b"PRIVATE", path.read_bytes(), path.name)

    async def test_failed_atomic_output_preserves_previous_file_and_recovers_from_database(self):
        first = self.monitor()
        await self.deliver(first, 1, 1000001)
        await self.deliver(first, 2, 1000001, 1000002)
        original = self.output_path.read_bytes()
        with patch("listing_monitor.os.replace", side_effect=OSError("PRIVATE-OUTPUT-ERROR")), \
             self.assertRaises(OSError):
            await self.deliver(first, 3, 1000001, 1000002, 1000003)
        self.assertEqual(self.output_path.read_bytes(), original)
        self.assertFalse(list(self.folder.glob(".new-listings-*.tmp")))
        first.close()
        restarted = self.monitor()
        await self.deliver(restarted, 1, 1000001, 1000002, 1000003)
        self.assertEqual([row["listing_id"] for row in self.events()], ["1000002", "1000003"])

    async def test_safe_parser_url_forms_are_retained_without_query_values(self):
        monitor = self.monitor(prepared(("28hse-rent", config("28hse-rent")),
                                        ("house730-buy", config("house730-buy"))))
        for lane in ("28hse-rent", "house730-buy"):
            await self.deliver(monitor, 1, lane=lane,
                               page_number=1 if lane.startswith("28hse") else None)
        examples = (
            ("28hse-rent", "https://www.28hse.com/rent/property-1000001?token=PRIVATE-QUERY", 1),
            ("house730-buy", "https://www.house730.com/buy-property-1000001.html?token=PRIVATE-QUERY", None),
        )
        for lane, url, page_number in examples:
            value = ListingPage((Listing("1000001", url),), page=page_number, total=1)
            with patch("listing_monitor.parse_page", return_value=value):
                await monitor(lane, {}, 2)
        self.assertEqual([event["url"] for event in self.events()], [
            "https://www.28hse.com/rent/property-1000001",
            "https://www.house730.com/buy-property-1000001.html",
        ])

    async def test_real_http_polling_parses_and_saves_only_the_added_listing(self):
        from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
        from four_lane_crawler import LaneConfig, PreparedRun, SiteConfig, run_four_lanes

        requests = []

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *args):
                pass

            def do_GET(self):
                requests.append(self.path)
                identifiers = [1000001, 1000002]
                if len(requests) > 1:
                    identifiers.append(1000003)
                body = json.dumps({"code": 0, "result": {"count": len(identifiers), "data": [
                    {"propertyID": identifier, "url": f"/rent-property-{identifier}/"}
                    for identifier in identifiers
                ]}}).encode()
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

        server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        worker = threading.Thread(target=lambda: server.serve_forever(poll_interval=.02), daemon=True)
        worker.start()
        try:
            settings = Config(f"http://127.0.0.1:{server.server_port}/list", params={"pageIndex": 1},
                              interval=.03, concurrency=1, expect_json=True)
            definitions = PreparedRun({"house730": SiteConfig("house730", concurrency=1)}, [
                LaneConfig("house730-rent", "house730", "https://www.house730.com/rent/s1u14/", settings),
            ])
            monitor = self.monitor(definitions)
            statistics = await run_four_lanes(definitions, max_requests=3, on_data=monitor)
            self.assertEqual(statistics["house730-rent"].succeeded, 3)
            self.assertEqual(len(requests), 3)
            self.assertEqual([event["listing_id"] for event in self.events()], ["1000003"])
        finally:
            await asyncio.to_thread(server.shutdown)
            server.server_close()
            await asyncio.to_thread(worker.join, 1)


if __name__ == "__main__":
    unittest.main()
