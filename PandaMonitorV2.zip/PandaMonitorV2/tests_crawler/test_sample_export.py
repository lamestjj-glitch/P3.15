from __future__ import annotations

import json
from pathlib import Path
from types import SimpleNamespace
import tempfile
import unittest
from unittest.mock import patch
from zipfile import ZipFile

from sample_export import Anonymizer, LANES, StructuralHTML, export_samples


class AnonymizerTests(unittest.TestCase):
    def test_unknown_values_private_context_and_public_listing_ids(self):
        original = {"rows": [{"propertyId": 1234567, "id": 7654321, "price": 12300,
                              "title": "PRIVATE-TITLE", "arbitrary": "PRIVATE-UNKNOWN-TOKEN",
                              "numericPhone": 91234567, "phone": "PRIVATE-PHONE",
                              "owner": {"propertyId": 99887766, "id": 22334455,
                                        "name": "PRIVATE-NAME", "token": "PRIVATE-OWNER-TOKEN"}}],
                    "total": 42, "session": {"id": 66778899}, "active": True, "nothing": None}
        cleaner = Anonymizer()
        result = cleaner.clean(original)
        row = result["rows"][0]
        self.assertEqual(row["propertyId"], 1234567)
        self.assertEqual(row["id"], 7654321)
        self.assertEqual(result["total"], 42)
        self.assertEqual(row["numericPhone"], 0)
        self.assertEqual(row["owner"]["propertyId"], 0)
        self.assertEqual(result["session"]["id"], 0)
        self.assertIs(result["active"], True)
        self.assertIsNone(result["nothing"])
        encoded = json.dumps(result)
        for secret in ("PRIVATE-", "91234567", "99887766", "22334455", "66778899"):
            self.assertNotIn(secret, encoded)

    def test_array_lengths_nested_json_and_depth_are_bounded(self):
        cleaner = Anonymizer()
        value = cleaner.clean({"rows": list(range(10)), "form_data": '{"token":"PRIVATE-NESTED"}',
                               "private@example.com": "PRIVATE-KEY", "Bearer PRIVATE-KEY": ["PRIVATE-VALUE"]})
        self.assertEqual(len(value["rows"]), 3)
        self.assertEqual(cleaner.array_lengths["/rows"], 10)
        self.assertNotIn("PRIVATE-NESTED", value["form_data"])
        self.assertNotIn("PRIVATE-", json.dumps(value))
        self.assertNotIn("private@example.com", json.dumps(value))
        cyclic = {}
        cyclic["next"] = cyclic
        encoded = json.dumps(Anonymizer().clean(cyclic))
        self.assertIn("structure limit", encoded)
        self.assertLess(len(encoded), 1000)

    def test_html_keeps_safe_listing_structure_without_text_or_credentials(self):
        html = ('<div id="property-list" class="listing-card PRIVATE-CLASS"><script>PRIVATE-SCRIPT</script>'
                '<style>.x{background:url(PRIVATE-STYLE)}</style><iframe>PRIVATE-IFRAME</iframe>'
                '<a href="https://www.28hse.com/rent/shop/property-1234567?token=PRIVATE-QUERY#PRIVATE-FRAGMENT" '
                'onclick="PRIVATE-EVENT" data-token="PRIVATE-DATA" title="PRIVATE-NAME">PRIVATE-TEXT 91234567</a>'
                '<a href="tel:91234567">PRIVATE-PHONE</a><a href="mailto:private@example.com">PRIVATE-EMAIL</a>'
                '<img src="PRIVATE-IMAGE" alt="PRIVATE-ALT"></div>')
        result = Anonymizer().clean({"html": html})["html"]
        self.assertIn('class="listing-card sample-class-1"', result)
        self.assertIn('href="/rent/shop/property-1234567"', result)
        for secret in ("PRIVATE-", "91234567", "private@example.com", "onclick", "data-token", "<script", "<iframe"):
            self.assertNotIn(secret, result)
        self.assertIn("[text]", result)

    def test_opaque_fields_and_html_classes_are_replaced_but_schema_names_remain(self):
        opaque = "q7B8n2D4k6M9p3R5"
        value = {opaque: "PRIVATE-OPAQUE-VALUE", "propertyId": 1234567,
                 "transactionTypeDescription": "PRIVATE-DESCRIPTION",
                 "0123456789abcdef0123456789abcdef": 123,
                 "c03c8997-f9f4-4438-bcab-8a04a23d10b4": 456,
                 "QmFzZTY0ZW5jb2RlZFNlY3JldA": 789,
                 "html": f'<div class="listing-card {opaque}"><span class="{opaque}">PRIVATE-TEXT</span></div>'}
        result = Anonymizer().clean(value)
        encoded = json.dumps(result)
        for secret in (opaque, "PRIVATE-", "0123456789abcdef0123456789abcdef",
                       "c03c8997-f9f4-4438-bcab-8a04a23d10b4", "QmFzZTY0ZW5jb2RlZFNlY3JldA"):
            self.assertNotIn(secret, encoded)
        self.assertEqual(result["propertyId"], 1234567)
        self.assertIn("transactionTypeDescription", result)
        self.assertEqual(result["html"].count("sample-class-1"), 2)


class SampleExportTests(unittest.TestCase):
    def fixtures(self):
        return {lane: SimpleNamespace(
            method="POST", url="https://api.house730.com/list?token=PRIVATE-QUERY&page=1",
            body='{"session":"PRIVATE-BODY","page":1}', user_agent="PRIVATE-UA",
            headers={"Authorization": "PRIVATE-HEADER"}, cookies=("PRIVATE-COOKIE",),
            sample={"data": [{"propertyId": 1234567, "title": "PRIVATE-LISTING"}],
                    "unusual": "PRIVATE-ARBITRARY", "tel": 91234567,
                    "q7B8n2D4k6M9p3R5": "PRIVATE-DYNAMIC-KEY",
                    "html": '<div class="q7B8n2D4k6M9p3R5">PRIVATE-TEXT</div>'},
        ) for lane in LANES}

    def test_four_fixed_samples_and_readme_are_valid_and_do_not_export_credentials(self):
        with tempfile.TemporaryDirectory() as folder:
            output = Path(folder) / "samples.zip"
            export_samples(self.fixtures(), output)
            with ZipFile(output) as archive:
                self.assertIsNone(archive.testzip())
                self.assertEqual(set(archive.namelist()), {lane + ".json" for lane in LANES} | {"README_UPLOAD.txt"})
                all_text = "\n".join(archive.read(name).decode() for name in archive.namelist())
                self.assertNotIn("PRIVATE-", all_text)
                self.assertNotIn("q7B8n2D4k6M9p3R5", all_text)
                self.assertNotIn("91234567", all_text)
                self.assertNotIn("https://api.house730.com", all_text)
                for lane in LANES:
                    document = json.loads(archive.read(lane + ".json"))
                    self.assertEqual(document["lane"], lane)
                    self.assertTrue(document["anonymized"])
                    self.assertEqual(document["response"]["data"][0]["propertyId"], 1234567)

    def test_existing_target_is_not_modified(self):
        with tempfile.TemporaryDirectory() as folder:
            output = Path(folder) / "samples.zip"
            output.write_bytes(b"KEEP EXISTING")
            with self.assertRaises(FileExistsError):
                export_samples(self.fixtures(), output)
            self.assertEqual(output.read_bytes(), b"KEEP EXISTING")

    def test_failed_new_zip_is_removed(self):
        with tempfile.TemporaryDirectory() as folder:
            output = Path(folder) / "samples.zip"
            with patch("sample_export.ZipFile.writestr", side_effect=OSError("fixture failure")):
                with self.assertRaises(OSError):
                    export_samples(self.fixtures(), output)
            self.assertFalse(output.exists())

    def test_missing_lane_or_sample_does_not_create_target(self):
        with tempfile.TemporaryDirectory() as folder:
            output = Path(folder) / "samples.zip"
            fixtures = self.fixtures()
            fixtures[LANES[0]].sample = None
            with self.assertRaises(ValueError):
                export_samples(fixtures, output)
            self.assertFalse(output.exists())


if __name__ == "__main__":
    unittest.main()
