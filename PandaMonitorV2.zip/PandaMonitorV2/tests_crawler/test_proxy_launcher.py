"""Proxy launcher checks: no real proxy, credentials or network required."""
from __future__ import annotations

from contextlib import redirect_stdout
import getpass
import io
import os
from pathlib import Path
from types import SimpleNamespace
import unittest
from unittest.mock import patch
import warnings

import start_with_proxy as launcher


class ProxyURLTests(unittest.TestCase):
    def test_credentials_are_escaped_and_socks5_uses_remote_dns(self):
        proxy = launcher.proxy_url("socks5", "127.0.0.1", "01080", "u@ser:name", "p@ss:/?#% +")
        self.assertEqual(proxy, "socks5h://u%40ser%3Aname:p%40ss%3A%2F%3F%23%25%20%2B@127.0.0.1:1080")

    def test_http_and_ipv6_are_supported(self):
        self.assertEqual(launcher.proxy_url("http", "proxy.example", "8080", "", ""),
                         "http://proxy.example:8080")
        self.assertEqual(launcher.proxy_url("https", "[2001:db8::1]", "443", "", ""),
                         "https://[2001:db8::1]:443")

    def test_invalid_settings_do_not_echo_values(self):
        for protocol, host, port in (
            ("PRIVATE-SCHEME", "localhost", "1"),
            ("http", "PRIVATE-HOST/path", "1"),
            ("http", "localhost", "PRIVATE-PORT"),
            ("http", "localhost", "0"),
            ("http", "localhost", "65536"),
            ("http", "localhost", "１"),
        ):
            with self.subTest(protocol=protocol, host=host, port=port):
                with self.assertRaises(ValueError) as caught:
                    launcher.proxy_url(protocol, host, port, "PRIVATE-USER", "PRIVATE-PASSWORD")
                self.assertNotIn("PRIVATE", str(caught.exception))


class ProxyLauncherTests(unittest.TestCase):
    def test_child_uses_proxy_without_exposing_or_persisting_it(self):
        output = io.StringIO()
        parent_values = {"HSE28_PROXY": "PRIVATE-OLD-HSE", "HOUSE730_PROXY": "PRIVATE-OLD-HOUSE"}
        with patch.dict(os.environ, parent_values), \
             patch("builtins.input", side_effect=["socks5", "127.0.0.1", "1080"]), \
             patch.object(launcher.getpass, "getpass", side_effect=["PRIVATE-USER", "PRIVATE-PASSWORD"]), \
             patch.object(launcher.subprocess, "run", return_value=SimpleNamespace(returncode=7)) as run, \
             patch.object(Path, "write_text", side_effect=AssertionError("must not persist settings")), \
             patch.object(Path, "write_bytes", side_effect=AssertionError("must not persist settings")), \
             redirect_stdout(output):
            result = launcher.main(["--count", "1"])
            self.assertEqual(os.environ["HSE28_PROXY"], "PRIVATE-OLD-HSE")
            self.assertEqual(os.environ["HOUSE730_PROXY"], "PRIVATE-OLD-HOUSE")
        self.assertEqual(result, 7)
        args, kwargs = run.call_args
        self.assertEqual(args[0], [launcher.sys.executable, str(launcher.ROOT / "start_capture.py"), "--count", "1"])
        self.assertEqual(kwargs["cwd"], launcher.ROOT)
        self.assertEqual(kwargs["env"]["CRAWLER_PROXY"],
                         "socks5h://PRIVATE-USER:PRIVATE-PASSWORD@127.0.0.1:1080")
        self.assertNotIn("HSE28_PROXY", kwargs["env"])
        self.assertNotIn("HOUSE730_PROXY", kwargs["env"])
        self.assertNotIn("PRIVATE", output.getvalue())

    def test_anonymous_proxy_does_not_ask_for_password(self):
        with patch("builtins.input", side_effect=["http", "localhost", "8888"]), \
             patch.object(launcher.getpass, "getpass", return_value="") as hidden, \
             patch.object(launcher.subprocess, "run", return_value=SimpleNamespace(returncode=0)) as run, \
             redirect_stdout(io.StringIO()):
            self.assertEqual(launcher.main([]), 0)
        self.assertEqual(hidden.call_count, 1)
        self.assertEqual(run.call_args.kwargs["env"]["CRAWLER_PROXY"], "http://localhost:8888")

    def test_invalid_port_fails_before_asking_for_credentials_or_launching(self):
        with patch("builtins.input", side_effect=["http", "localhost", "70000"]), \
             patch.object(launcher.getpass, "getpass") as hidden, \
             patch.object(launcher.subprocess, "run") as run, redirect_stdout(io.StringIO()):
            self.assertEqual(launcher.main([]), 2)
        hidden.assert_not_called()
        run.assert_not_called()

    def test_interrupt_returns_130_without_launching(self):
        with patch("builtins.input", side_effect=KeyboardInterrupt), \
             patch.object(launcher.subprocess, "run") as run, redirect_stdout(io.StringIO()):
            self.assertEqual(launcher.main([]), 130)
        run.assert_not_called()

    def test_getpass_echo_fallback_fails_closed(self):
        def insecure(prompt):
            warnings.warn("Password input may be echoed", getpass.GetPassWarning)
            self.fail("fallback must stop before accepting credentials")

        with patch("builtins.input", side_effect=["http", "localhost", "8080"]), \
             patch.object(launcher.getpass, "getpass", side_effect=insecure), \
             patch.object(launcher.subprocess, "run") as run, redirect_stdout(io.StringIO()):
            self.assertEqual(launcher.main([]), 2)
        run.assert_not_called()

    def test_help_needs_no_input_or_child_process(self):
        with patch("builtins.input") as prompt, patch.object(launcher.subprocess, "run") as run, \
             redirect_stdout(io.StringIO()):
            self.assertEqual(launcher.main(["--help"]), 0)
        prompt.assert_not_called()
        run.assert_not_called()


if __name__ == "__main__":
    unittest.main()
