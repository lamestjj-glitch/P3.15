"""Capture decoding regressions; all requests and browser objects are local fakes."""
from __future__ import annotations

import json
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import capture_four_lanes as capture_module


PAGES = {
    "28hse-rent": "https://www.28hse.com/rent",
    "28hse-buy": "https://www.28hse.com/buy",
    "house730-rent": "https://www.house730.com/rent/s1u14/",
    "house730-buy": "https://www.house730.com/buy/s1u14/",
}


def listing_payload(lane):
    if lane.startswith("28hse"):
        trade = "rent" if lane.endswith("rent") else "buy"
        return {"status": 1, "data": {"results": {
            "resultContentHtml": f'<a href="/{trade}/apartment/property-1000001">Fixture</a>',
            "resultData": {"ListingPaginator": {"page": 1, "count": 1}},
        }}}
    return {"code": 0, "result": {"count": 1, "data": [
        {"propertyID": 1000001, "titleWithCulture": "Fixture", "rentPrice": 1},
    ]}}


def request_body(lane):
    values = {"landlordAgency": "LANDLORD", "sortBy": "latest", "page": 1} if lane.startswith("28hse") else {"pageIndex": 1}
    values["searchText"] = "中文測試"
    return json.dumps(values, ensure_ascii=False, separators=(",", ":")).encode("utf-8")


class Request:
    def __init__(self, lane, body, *, forbid_body=False):
        self.url = ("https://www.28hse.com/property/dosearch" if lane.startswith("28hse") else
                    "https://api.house730.com/fixture/current-list")
        self.method, self.resource_type = "POST", "fetch"
        self.raw_body, self.forbid_body = body, forbid_body
        self.body_reads = 0

    @property
    def post_data_buffer(self):
        self.body_reads += 1
        if self.forbid_body:
            raise AssertionError("PRIVATE-BACKGROUND-BODY-MUST-NOT-BE-READ")
        return self.raw_body

    async def all_headers(self):
        return {"user-agent": "Mozilla/5.0 Chrome/148.0.0.0", "content-type": "application/json",
                "cookie": "PRIVATE-COOKIE-HEADER", "x-fixture": "retained"}


class Response:
    def __init__(self, request, payload):
        self.request, self.status = request, 200
        self.raw_response = payload if isinstance(payload, bytes) else json.dumps(payload).encode("utf-8")

    async def body(self):
        return self.raw_response


class Browser:
    def __init__(self, frames):
        context = SimpleNamespace(pages=[])

        async def cookies(urls):
            domain = ".28hse.com" if "28hse.com" in urls[0] else ".house730.com"
            return [{"name": "cf_clearance", "value": "PRIVATE-COOKIE-VALUE", "domain": domain,
                     "path": "/", "secure": True, "expires": -1}]

        context.cookies = cookies

        class Page:
            def __init__(self, lane):
                self.url, self.context, self.lane = PAGES[lane], context, lane
                self.listeners = []

            def on(self, event, handler):
                self.listeners.append(handler)
                for response in frames[self.lane]:
                    handler(response)

            def remove_listener(self, event, handler):
                self.listeners.remove(handler)

        context.pages = [Page(lane) for lane in PAGES]
        self.contexts = [context]


def valid_frames():
    return {lane: [Response(Request(lane, request_body(lane)), listing_payload(lane))] for lane in PAGES}


class CaptureDecodeTests(unittest.IsolatedAsyncioTestCase):
    def assert_detached(self, browser):
        self.assertTrue(all(not page.listeners for context in browser.contexts for page in context.pages))

    async def test_unrelated_binary_posts_are_rejected_before_request_body_is_read(self):
        frames, irrelevant = valid_frames(), []
        for lane in PAGES:
            for payload in ({"ok": True}, b"\xffPRIVATE-NON-JSON-RESPONSE"):
                request = Request(lane, b"\xffPRIVATE-BINARY-BACKGROUND", forbid_body=True)
                irrelevant.append(request)
                frames[lane].insert(0, Response(request, payload))
        browser = Browser(frames)
        with patch.object(capture_module.LOG, "warning") as warning:
            observations = await capture_module.capture(browser, 2.5)
        self.assertEqual(set(observations), set(PAGES))
        self.assertTrue(all(request.body_reads == 0 for request in irrelevant))
        warning.assert_not_called()
        self.assert_detached(browser)

    async def test_non_utf8_listing_body_is_not_repaired_or_allowed_to_replace_template(self):
        frames = valid_frames()
        for lane in PAGES:
            frames[lane].append(Response(Request(lane, b"\xffPRIVATE-LISTING-BODY"), listing_payload(lane)))
        browser = Browser(frames)
        with self.assertLogs("crawler.capture", level="WARNING") as logs:
            observations = await capture_module.capture(browser, 2.5)
        for lane, observation in observations.items():
            self.assertEqual(observation.body.encode("utf-8"), request_body(lane))
        output = "\n".join(logs.output)
        self.assertIn("UTF-8", output)
        self.assertNotIn("PRIVATE-LISTING-BODY", output)
        self.assertNotIn("UnicodeDecodeError", output)
        self.assert_detached(browser)

    async def test_owner_latest_requirement_still_rejects_an_unfiltered_hse_page(self):
        frames = valid_frames()
        frames["28hse-rent"] = [Response(Request("28hse-rent", json.dumps({
            "landlordAgency": "AGENCY", "sortBy": "latest", "page": 1,
        }).encode()), listing_payload("28hse-rent"))]
        browser = Browser(frames)
        with self.assertRaises(capture_module.CaptureError) as caught:
            await capture_module.capture(browser, .3)
        self.assertIn("28hse-rent", str(caught.exception))
        self.assert_detached(browser)

    async def test_unicode_request_bytes_headers_cookies_and_sample_round_trip(self):
        browser = Browser(valid_frames())
        observations = await capture_module.capture(browser, 2.5, include_samples=True)
        for lane, observation in observations.items():
            self.assertEqual(observation.body.encode("utf-8"), request_body(lane))
            self.assertIn("中文測試", observation.body)
            self.assertEqual(observation.headers["x-fixture"], "retained")
            self.assertNotIn("cookie", observation.headers)
            self.assertEqual(observation.cookies[0].value, "PRIVATE-COOKIE-VALUE")
            self.assertEqual(observation.sample, listing_payload(lane))
        self.assert_detached(browser)


if __name__ == "__main__":
    unittest.main()
