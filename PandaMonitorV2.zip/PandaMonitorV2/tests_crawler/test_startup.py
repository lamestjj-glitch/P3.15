"""Startup regressions: no browser requests or package installation in these tests."""
from __future__ import annotations

import contextlib
import importlib.util
import io
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

import capture_four_lanes
import start_capture

ROOT = Path(__file__).resolve().parents[1]
HAS_CAPTURE_DEPS = bool(importlib.util.find_spec("curl_cffi") and importlib.util.find_spec("playwright"))


class CaptureStartupTests(unittest.TestCase):
    def invoke(self, arguments, *, no_packages=False, input_text=None):
        command = [sys.executable]
        if no_packages:
            command.append("-S")
        command.extend([str(ROOT / "capture_four_lanes.py"), *arguments])
        return subprocess.run(command, cwd=ROOT, input=input_text, capture_output=True,
                              encoding="utf-8", timeout=15,
                              env={**os.environ, "PYTHONUTF8": "1", "PYTHONDONTWRITEBYTECODE": "1"})

    def test_help_works_without_third_party_packages(self):
        result = self.invoke(["--help"], no_packages=True)
        self.assertEqual(result.returncode, 0)
        self.assertIn("--cdp", result.stdout)
        self.assertIn("--check-setup", result.stdout)
        self.assertNotIn("Traceback", result.stderr)

    def test_missing_packages_have_friendly_diagnostic_without_traceback(self):
        result = self.invoke(["--check-setup"], no_packages=True)
        self.assertEqual(result.returncode, 1)
        self.assertIn("python -m pip install -r requirements-capture.txt", result.stdout + result.stderr)
        self.assertNotIn("Traceback", result.stdout + result.stderr)
        self.assertNotIn("ModuleNotFoundError", result.stdout + result.stderr)

    @unittest.skipUnless(HAS_CAPTURE_DEPS, "Optional capture dependencies unavailable")
    def test_installed_setup_check_succeeds_without_connecting(self):
        result = self.invoke(["--check-setup"])
        self.assertEqual(result.returncode, 0)
        self.assertIn("[CHECK_OK]", result.stdout)
        self.assertNotIn("Traceback", result.stderr)

    @unittest.skipUnless(HAS_CAPTURE_DEPS, "Optional capture dependencies unavailable")
    def test_no_arguments_can_cancel_through_stdin_without_network(self):
        result = self.invoke([], input_text="\n")
        self.assertEqual(result.returncode, 0)
        self.assertIn("已取消", result.stdout)
        self.assertNotIn("Traceback", result.stdout + result.stderr)

    def test_interactive_port_and_defaults_are_forwarded_to_capture(self):
        received = []

        async def capture(args):
            received.append(args)
            return 0

        with patch.object(capture_four_lanes, "check_dependencies", return_value=True), \
             patch.object(capture_four_lanes, "run", new=capture), \
             patch("builtins.input", side_effect=["9333", "", "y"]), \
             contextlib.redirect_stdout(io.StringIO()):
            code = capture_four_lanes.main([])
        self.assertEqual(code, 0)
        self.assertEqual(len(received), 1)
        self.assertEqual(received[0].cdp, "http://127.0.0.1:9333")
        self.assertEqual(received[0].interval, 0.5)
        self.assertTrue(received[0].confirm_filters)

    def test_bad_interactive_input_never_calls_capture(self):
        async def forbidden(args):
            self.fail("Invalid interactive input attempted to connect")

        for inputs in (["9333", "not-a-number"], ["70000"], ["9333", "nan", "y"]):
            with self.subTest(inputs=inputs), \
                 patch.object(capture_four_lanes, "check_dependencies", return_value=True), \
                 patch.object(capture_four_lanes, "run", new=forbidden), \
                 patch("builtins.input", side_effect=inputs), \
                 contextlib.redirect_stdout(io.StringIO()), \
                 self.assertLogs("crawler.capture", level="ERROR") as logs:
                self.assertEqual(capture_four_lanes.main([]), 2)
            self.assertNotIn("Traceback", " ".join(logs.output))


class BootstrapStartupTests(unittest.TestCase):
    def make_package(self, base):
        root = Path(base) / "中文 folder with spaces"
        root.mkdir()
        for filename in ("capture_four_lanes.py", "async_crawler.py", "four_lane_crawler.py",
                         "requirements-capture.txt", "requirements-crawler.txt"):
            (root / filename).write_text("# local test fixture\n", encoding="utf-8")
        return root

    def make_interpreter_marker(self, root):
        executable = start_capture.venv_python(root)
        executable.parent.mkdir(parents=True)
        executable.touch()
        return executable

    def test_install_failure_is_retained_and_capture_does_not_start(self):
        with tempfile.TemporaryDirectory(prefix="startup-test-") as directory:
            root = self.make_package(directory)
            executable = self.make_interpreter_marker(root)
            with patch.object(start_capture, "ROOT", root), \
                 patch.object(start_capture, "interpreter_ok", return_value=True), \
                 patch.object(start_capture, "dependencies_ok", return_value=False), \
                 patch.object(start_capture, "ensure_pip", return_value=0), \
                 patch.object(start_capture.subprocess, "run", return_value=subprocess.CompletedProcess([], 23)) as execute, \
                 contextlib.redirect_stdout(io.StringIO()):
                code = start_capture.main(["--cdp", "http://127.0.0.1:9333/?token=PRIVATE_STARTUP_TOKEN"])
            self.assertEqual(code, 23)
            self.assertEqual(execute.call_count, 1)
            command = execute.call_args.args[0]
            self.assertEqual(command[:4], [str(executable), "-m", "pip", "install"])
            self.assertEqual(command[-1], str(root / "requirements-capture.txt"))
            self.assertEqual(execute.call_args.kwargs["cwd"], root)
            log = (root / "logs" / "startup.log").read_text()
            self.assertIn("stage=install_dependencies exit=23", log)
            self.assertNotIn("capture_finished", log)
            self.assertNotIn("PRIVATE_STARTUP_TOKEN", log)
            self.assertNotIn("--cdp", log)

    def test_partial_venv_restores_pip_before_install_and_launch(self):
        with tempfile.TemporaryDirectory(prefix="startup-test-") as directory:
            root = self.make_package(directory)
            executable = self.make_interpreter_marker(root)
            outcomes = [subprocess.CompletedProcess([], code) for code in (1, 0, 0, 9)]
            with patch.object(start_capture, "ROOT", root), \
                 patch.object(start_capture, "interpreter_ok", return_value=True), \
                 patch.object(start_capture, "dependencies_ok", side_effect=[False, True]), \
                 patch.object(start_capture.subprocess, "run", side_effect=outcomes) as execute, \
                 contextlib.redirect_stdout(io.StringIO()):
                self.assertEqual(start_capture.main([]), 9)
            commands = [call.args[0] for call in execute.call_args_list]
            self.assertEqual(commands[0], [str(executable), "-m", "pip", "--version"])
            self.assertEqual(commands[1], [str(executable), "-m", "ensurepip", "--upgrade"])
            self.assertEqual(commands[2][:4], [str(executable), "-m", "pip", "install"])
            self.assertEqual(commands[3], [str(executable), "-u", str(root / "capture_four_lanes.py")])
            log = (root / "logs" / "startup.log").read_text()
            self.assertIn("stage=restore_pip exit=0", log)
            self.assertIn("stage=install_dependencies exit=0", log)
            self.assertIn("stage=capture_finished exit=9", log)

    def test_child_exit_and_argument_boundaries_survive_spaces_and_chinese_path(self):
        with tempfile.TemporaryDirectory(prefix="startup-test-") as directory:
            root = self.make_package(directory)
            executable = self.make_interpreter_marker(root)
            arguments = ["--cdp", "http://127.0.0.1:9333/?token=PRIVATE_STARTUP_TOKEN",
                         "--house730-path", "/fixture/path with spaces"]
            with patch.object(start_capture, "ROOT", root), \
                 patch.object(start_capture, "interpreter_ok", return_value=True), \
                 patch.object(start_capture, "dependencies_ok", return_value=True), \
                 patch.dict(os.environ, {"TEST_CRAWLER_SECRET": "PRIVATE_ENV_VALUE"}, clear=True), \
                 patch.object(start_capture.subprocess, "run", return_value=subprocess.CompletedProcess([], 17)) as execute, \
                 contextlib.redirect_stdout(io.StringIO()) as output:
                code = start_capture.main(arguments)
            self.assertEqual(code, 17)
            self.assertEqual(execute.call_count, 1)
            self.assertEqual(execute.call_args.args[0],
                             [str(executable), "-u", str(root / "capture_four_lanes.py"), *arguments])
            self.assertEqual(execute.call_args.kwargs["cwd"], root)
            self.assertEqual(execute.call_args.kwargs["env"]["CRAWLER_PARENT_PAUSES"], "1")
            self.assertEqual(execute.call_args.kwargs["env"]["PYTHONUTF8"], "1")
            self.assertFalse(execute.call_args.kwargs.get("shell", False))
            log = (root / "logs" / "startup.log").read_text()
            self.assertIn("stage=dependencies_ready exit=0", log)
            self.assertIn("stage=capture_finished exit=17", log)
            for secret in ("PRIVATE_STARTUP_TOKEN", "PRIVATE_ENV_VALUE", "--cdp", arguments[1]):
                self.assertNotIn(secret, log)
                self.assertNotIn(secret, output.getvalue())

    def test_venv_creation_failure_stops_before_dependency_probe(self):
        with tempfile.TemporaryDirectory(prefix="startup-test-") as directory:
            root = self.make_package(directory)
            with patch.object(start_capture, "ROOT", root), \
                 patch.object(start_capture, "interpreter_ok") as interpreter_probe, \
                 patch.object(start_capture, "dependencies_ok") as probe, \
                 patch.object(start_capture.subprocess, "run", return_value=subprocess.CompletedProcess([], 8)) as execute, \
                 contextlib.redirect_stdout(io.StringIO()):
                self.assertEqual(start_capture.main([]), 8)
            interpreter_probe.assert_not_called()
            probe.assert_not_called()
            self.assertEqual(execute.call_count, 1)
            self.assertEqual(execute.call_args.args[0][-1], str(root / ".crawler-venv"))
            self.assertIn("stage=create_environment exit=8", (root / "logs" / "startup.log").read_text())

    def test_broken_existing_venv_is_preserved_then_rebuilt_with_selected_python(self):
        with tempfile.TemporaryDirectory(prefix="startup-test-") as directory:
            root = self.make_package(directory)
            executable = self.make_interpreter_marker(root)
            environment = root / ".crawler-venv"
            (environment / "pyvenv.cfg").write_text("home = C:\\removed-python313\n")
            (environment / "keep.txt").write_text("existing environment data")

            def execute(command, **kwargs):
                if command[:3] == [sys.executable, "-m", "venv"]:
                    backups = list(root.glob(".crawler-venv.backup-*"))
                    self.assertEqual(len(backups), 1)
                    self.assertEqual((backups[0] / "keep.txt").read_text(), "existing environment data")
                    self.make_interpreter_marker(root)
                else:
                    self.assertEqual(command, [str(executable), "-u", str(root / "capture_four_lanes.py")])
                return subprocess.CompletedProcess(command, 0)

            with patch.object(start_capture, "ROOT", root), \
                 patch.object(start_capture, "interpreter_ok", side_effect=[False, True]) as interpreter_probe, \
                 patch.object(start_capture, "dependencies_ok", return_value=True) as dependencies, \
                 patch.object(start_capture, "ensure_pip") as pip, \
                 patch.object(start_capture.subprocess, "run", side_effect=execute) as run, \
                 contextlib.redirect_stdout(io.StringIO()):
                self.assertEqual(start_capture.main([]), 0)
            self.assertEqual([call.args[0] for call in run.call_args_list], [
                [sys.executable, "-m", "venv", str(environment)],
                [str(executable), "-u", str(root / "capture_four_lanes.py")],
            ])
            self.assertEqual(interpreter_probe.call_count, 2)
            dependencies.assert_called_once_with(executable)
            pip.assert_not_called()
            backup, = root.glob(".crawler-venv.backup-*")
            self.assertEqual((backup / "pyvenv.cfg").read_text(), "home = C:\\removed-python313\n")
            self.assertTrue(executable.is_file())
            log = (root / "logs" / "startup.log").read_text()
            self.assertIn("stage=backup_environment exit=0", log)
            self.assertIn("stage=create_environment exit=0", log)
            self.assertIn("stage=capture_finished exit=0", log)

    def test_incomplete_venv_without_python_is_preserved_before_replacement(self):
        with tempfile.TemporaryDirectory(prefix="startup-test-") as directory:
            root = self.make_package(directory)
            environment = root / ".crawler-venv"
            environment.mkdir()
            (environment / "keep.txt").write_text("partial setup data")
            executable = start_capture.venv_python(root)

            def execute(command, **kwargs):
                if command[:3] == [sys.executable, "-m", "venv"]:
                    self.make_interpreter_marker(root)
                return subprocess.CompletedProcess(command, 0)

            with patch.object(start_capture, "ROOT", root), \
                 patch.object(start_capture, "interpreter_ok", return_value=True) as interpreter_probe, \
                 patch.object(start_capture, "dependencies_ok", return_value=True), \
                 patch.object(start_capture.subprocess, "run", side_effect=execute) as run, \
                 contextlib.redirect_stdout(io.StringIO()):
                self.assertEqual(start_capture.main([]), 0)
            interpreter_probe.assert_called_once_with(executable)
            self.assertEqual(run.call_args_list[0].args[0],
                             [sys.executable, "-m", "venv", str(environment)])
            backup, = root.glob(".crawler-venv.backup-*")
            self.assertEqual((backup / "keep.txt").read_text(), "partial setup data")
            self.assertFalse((environment / "keep.txt").exists())
            self.assertTrue(executable.is_file())

    def test_working_existing_venv_is_reused_without_backup_or_install(self):
        with tempfile.TemporaryDirectory(prefix="startup-test-") as directory:
            root = self.make_package(directory)
            executable = self.make_interpreter_marker(root)
            with patch.object(start_capture, "ROOT", root), \
                 patch.object(start_capture, "interpreter_ok", return_value=True) as interpreter_probe, \
                 patch.object(start_capture, "dependencies_ok", return_value=True), \
                 patch.object(start_capture, "ensure_pip") as pip, \
                 patch.object(start_capture.subprocess, "run", return_value=subprocess.CompletedProcess([], 9)) as run, \
                 contextlib.redirect_stdout(io.StringIO()):
                self.assertEqual(start_capture.main([]), 9)
            interpreter_probe.assert_called_once_with(executable)
            run.assert_called_once()
            self.assertEqual(run.call_args.args[0],
                             [str(executable), "-u", str(root / "capture_four_lanes.py")])
            self.assertFalse(list(root.glob(".crawler-venv.backup-*")))
            pip.assert_not_called()

    def test_backup_failure_stops_without_modifying_old_venv_or_running_commands(self):
        with tempfile.TemporaryDirectory(prefix="startup-test-") as directory:
            root = self.make_package(directory)
            executable = self.make_interpreter_marker(root)
            preserved = executable.parent / "keep.txt"
            preserved.write_text("must survive")
            with patch.object(start_capture, "ROOT", root), \
                 patch.object(start_capture, "interpreter_ok", return_value=False), \
                 patch.object(Path, "rename", side_effect=PermissionError("test fixture locked")), \
                 patch.object(start_capture, "dependencies_ok") as dependencies, \
                 patch.object(start_capture, "ensure_pip") as pip, \
                 patch.object(start_capture.subprocess, "run") as run, \
                 contextlib.redirect_stdout(io.StringIO()) as output:
                self.assertEqual(start_capture.main([]), 1)
            dependencies.assert_not_called()
            pip.assert_not_called()
            run.assert_not_called()
            self.assertEqual(preserved.read_text(), "must survive")
            self.assertTrue(executable.is_file())
            self.assertFalse(list(root.glob(".crawler-venv.backup-*")))
            self.assertIn("PermissionError", output.getvalue())
            self.assertNotIn("Traceback", output.getvalue())
            log = (root / "logs" / "startup.log").read_text()
            self.assertIn("stage=startup_os_error exit=1", log)
            self.assertNotIn("stage=create_environment", log)

    def test_unusable_new_venv_stops_before_dependency_checks_or_pip(self):
        with tempfile.TemporaryDirectory(prefix="startup-test-") as directory:
            root = self.make_package(directory)

            def create_environment(command, **kwargs):
                self.assertEqual(command, [sys.executable, "-m", "venv", str(root / ".crawler-venv")])
                self.make_interpreter_marker(root)
                return subprocess.CompletedProcess(command, 0)

            with patch.object(start_capture, "ROOT", root), \
                 patch.object(start_capture, "interpreter_ok", return_value=False), \
                 patch.object(start_capture, "dependencies_ok") as dependencies, \
                 patch.object(start_capture, "ensure_pip") as pip, \
                 patch.object(start_capture.subprocess, "run", side_effect=create_environment) as run, \
                 contextlib.redirect_stdout(io.StringIO()):
                self.assertEqual(start_capture.main([]), 1)
            run.assert_called_once()
            dependencies.assert_not_called()
            pip.assert_not_called()
            log = (root / "logs" / "startup.log").read_text()
            self.assertIn("stage=environment_python_failed exit=1", log)
            self.assertNotIn("stage=install_dependencies", log)
            self.assertNotIn("stage=capture_finished", log)

    def test_interpreter_probe_requires_matching_supported_version_in_isolated_mode(self):
        executable = Path("fixture python with spaces")
        with patch.object(start_capture.subprocess, "run", return_value=subprocess.CompletedProcess([], 0)) as run:
            self.assertTrue(start_capture.interpreter_ok(executable))
        command = run.call_args.args[0]
        self.assertEqual(command[:3], [str(executable), "-I", "-c"])
        self.assertEqual(run.call_args.kwargs["timeout"], 10)
        self.assertEqual(run.call_args.kwargs["stderr"], subprocess.DEVNULL)
        probe = command[3]
        for version, expected in ((sys.version_info[:2], 0), ((3, 11), 1),
                                  ((sys.version_info.major, sys.version_info.minor + 1), 1)):
            with self.subTest(version=version):
                result = subprocess.run([sys.executable, "-I", "-c",
                                         f"import sys; sys.version_info={version!r}; " + probe],
                                        capture_output=True, timeout=10)
                self.assertEqual(result.returncode, expected, result.stderr)

    def test_interpreter_probe_treats_missing_failed_and_hung_python_as_unusable(self):
        cases = (OSError("missing base Python"), subprocess.TimeoutExpired("fixture", 10),
                 subprocess.CompletedProcess([], 1))
        for outcome in cases:
            with self.subTest(outcome=type(outcome).__name__):
                kwargs = {"side_effect": outcome} if isinstance(outcome, Exception) else {"return_value": outcome}
                with patch.object(start_capture.subprocess, "run", **kwargs):
                    self.assertFalse(start_capture.interpreter_ok(Path("fixture python")))

    def test_cmd_version_probe_accepts_supported_python_and_rejects_old_python(self):
        # Exercise the Python snippets verbatim; native CMD itself is not run on Linux.
        content = (ROOT / "START_CAPTURE.cmd").read_text(encoding="utf-8")
        probes = set(re.findall(r'-c "([^"]*sys\.version_info[^\"]*)"', content))
        self.assertTrue(probes)
        for probe in probes:
            self.assertNotIn("^", probe)
            current = subprocess.run([sys.executable, "-c", probe], capture_output=True, timeout=10)
            self.assertEqual(current.returncode, 0)
            old = subprocess.run([sys.executable, "-c", "import sys; sys.version_info=(3,11); " + probe],
                                 capture_output=True, timeout=10)
            self.assertEqual(old.returncode, 1)


if __name__ == "__main__":
    unittest.main()
