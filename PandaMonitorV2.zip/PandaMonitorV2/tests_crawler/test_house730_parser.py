from __future__ import annotations

import copy
import math
import unittest

from house730_parser import parse_listings
from listing_types import ListingParseError


def payload(rows=None, *, count=2, code=0):
    if rows is None:
        rows = [
            {"propertyID": 1000001, "titleWithCulture": "Fixture first", "rentPrice": 18000.0,
             "salePrice": 4500000.0, "url": "/rent-property-1000001/fixture/?tracking=omit#omit"},
            {"propertyID": "1000002", "titleWithCulture": "Fixture second", "rentPrice": 20000,
             "salePrice": 5000000, "url": "https://www.house730.com/rent-property-1000002/"},
        ]
    return {"code": code, "message": None, "result": {"count": count, "currentIndex": 0, "data": rows}}


class House730ParserTests(unittest.TestCase):
    def test_primary_rows_only_and_order_are_retained(self):
        document = payload()
        document["result"]["ads"] = [{"propertyID": 1999998}]
        document["result"]["newEstateDrainages"] = [{"propertyID": 1999999}]
        before = copy.deepcopy(document)
        page = parse_listings("house730-rent", document)
        self.assertEqual([item.listing_id for item in page.listings], ["1000001", "1000002"])
        self.assertEqual(page.total, 2)
        self.assertIsNone(page.page)
        self.assertEqual(page.listings[0].title, "Fixture first")
        self.assertEqual(page.listings[0].price, 18000.0)
        self.assertEqual(page.listings[0].url, "https://www.house730.com/rent-property-1000001/fixture/")
        self.assertEqual(document, before)

    def test_buy_uses_sale_price_and_matching_public_url(self):
        rows = [{"propertyID": "001000001", "rentPrice": 18000, "salePrice": 4500000,
                 "titleWithCulture": "  Fixture\n\ttitle  ",
                 "url": "https://house730.com/buy-property-1000001/fixture/?token=PRIVATE-QUERY#PRIVATE-FRAGMENT"}]
        item, = parse_listings("house730-buy", payload(rows, count=1)).listings
        self.assertEqual(item.listing_id, "1000001")
        self.assertEqual(item.price, 4500000)
        self.assertEqual(item.title, "Fixture title")
        self.assertEqual(item.url, "https://house730.com/buy-property-1000001/fixture/")

    def test_id_duplicates_collapse_without_reordering(self):
        rows = [{"propertyID": 1000001}, {"propertyID": "001000001"}, {"propertyID": 1000002}]
        page = parse_listings("house730-rent", payload(rows, count=2))
        self.assertEqual([item.listing_id for item in page.listings], ["1000001", "1000002"])

    def test_invalid_ids_or_rows_reject_entire_batch(self):
        for record in ({}, {"propertyId": 1000003}, {"propertyID": True}, {"propertyID": 0},
                       {"propertyID": -1}, {"propertyID": 1.5}, {"propertyID": "000"},
                       {"propertyID": "PRIVATE-CREDENTIAL"}, {"propertyID": "1e7"},
                       {"propertyID": 10 ** 20}, {"propertyID": "1" * 21}, None):
            with self.subTest(record=record), self.assertRaises(ListingParseError) as caught:
                parse_listings("house730-rent", payload([{"propertyID": 1000001}, record]))
            self.assertNotIn("PRIVATE-CREDENTIAL", str(caught.exception))

    def test_success_code_and_shape_are_strict_without_echoing_response(self):
        documents = [None, [], {}, {"code": 0}, {"code": 0, "result": None},
                     {"code": 0, "result": {"data": None, "count": 0}}]
        documents.extend(payload(code=code) for code in (False, True, "0", 0.0, 403, -1))
        for document in documents:
            if isinstance(document, dict):
                document["message"] = "PRIVATE-RESPONSE-SECRET"
            with self.subTest(document=document), self.assertRaises(ListingParseError) as caught:
                parse_listings("house730-rent", document)
            self.assertNotIn("PRIVATE-RESPONSE-SECRET", str(caught.exception))
        with self.assertRaises(ListingParseError):
            parse_listings("PRIVATE-LANE", payload())

    def test_total_and_successful_empty_page(self):
        self.assertEqual(parse_listings("house730-buy", payload([], count=0)).listings, ())
        for count in (True, -1, 1.0, "1", None):
            with self.subTest(count=count), self.assertRaises(ListingParseError):
                parse_listings("house730-buy", payload([], count=count))
        with self.assertRaises(ListingParseError):
            parse_listings("house730-rent", payload([], count=2))

    def test_total_cannot_be_smaller_than_unique_listing_count(self):
        for rows, count in (([{"propertyID": 1000001}], 0),
                            ([{"propertyID": 1000001}, {"propertyID": 1000002}], 1)):
            with self.subTest(count=count), self.assertRaises(ListingParseError):
                parse_listings("house730-rent", payload(rows, count=count))
        page = parse_listings("house730-rent", payload([
            {"propertyID": 1000001}, {"propertyID": "1000001"},
        ], count=1))
        self.assertEqual(len(page.listings), 1)

    def test_untrusted_or_mismatched_urls_are_omitted_without_losing_ids(self):
        bad_urls = (
            "[string]", "http://www.house730.com/rent-property-1000001/", "https://evil.example/rent-property-1000001/",
            "https://www.house730.com.evil.example/rent-property-1000001/", "javascript:PRIVATE-SECRET",
            "https://user:PRIVATE-SECRET@www.house730.com/rent-property-1000001/",
            "/buy-property-1000001/", "/rent-property-1000002/", "/rent-property-10000010/",
            "/rent-property-1000001/../../private", "/rent-property-1000001/%2e%2e/private",
            "/rent-property-1000001/\r\nPRIVATE-SECRET", "https://www.house730.com:9999/rent-property-1000001/",
        )
        for url in bad_urls:
            with self.subTest(url=url):
                item, = parse_listings("house730-rent", payload([{"propertyID": 1000001, "url": url}], count=1)).listings
                self.assertEqual(item.listing_id, "1000001")
                self.assertIsNone(item.url)

    def test_optional_metadata_omits_placeholders_and_invalid_prices(self):
        for title in (None, "", "[string]", "[strings]", "[redacted]", "[text]", 123):
            for price in (None, True, -1, math.nan, math.inf, "PRIVATE-PRICE"):
                with self.subTest(title=title, price=price):
                    item, = parse_listings("house730-rent", payload([
                        {"propertyID": 1000001, "titleWithCulture": title, "rentPrice": price},
                    ], count=1)).listings
                    self.assertIsNone(item.title)
                    self.assertIsNone(item.price)


if __name__ == "__main__":
    unittest.main()
