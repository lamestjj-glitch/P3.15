"""Prove explicit proxies carry traffic using only local fake HTTP proxies."""
from __future__ import annotations

import asyncio
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import os
import threading
import unittest
from unittest.mock import patch

from async_crawler import Config, Crawler
from four_lane_crawler import LANES, LaneConfig, PreparedRun, SiteConfig, run_four_lanes


class ProxyRoutingTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.servers = []
        self.threads = []

    def proxy(self, label):
        requests = []

        class Handler(BaseHTTPRequestHandler):
            def do_GET(self):
                requests.append(self.path)
                body = json.dumps({"proxy": label}).encode()
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

            def log_message(self, *args):
                pass

        server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        thread = threading.Thread(target=lambda: server.serve_forever(poll_interval=.02), daemon=True)
        thread.start()
        self.servers.append(server)
        self.threads.append(thread)
        return f"http://127.0.0.1:{server.server_port}", requests

    async def asyncTearDown(self):
        for server in self.servers:
            await asyncio.to_thread(server.shutdown)
            server.server_close()
        for thread in self.threads:
            await asyncio.to_thread(thread.join, 1)

    async def test_owned_crawler_explicit_proxy_overrides_no_proxy_bypass(self):
        proxy, requests = self.proxy("single")
        received = []

        async def consume(data, request_id):
            received.append(data["proxy"])

        environment = {"CRAWLER_PROXY": proxy, "NO_PROXY": "*", "no_proxy": "*"}
        with patch.dict(os.environ, environment):
            crawler = Crawler(Config("http://unresolvable.invalid/fixture", timeout=1), consume)
            result = await crawler.run(max_requests=1)
        self.assertEqual((result.succeeded, result.failed), (1, 0))
        self.assertEqual(received, ["single"])
        self.assertEqual(requests, ["http://unresolvable.invalid/fixture"])

    async def test_each_site_explicit_proxy_is_used_for_both_lanes(self):
        first_proxy, first_requests = self.proxy("28hse")
        second_proxy, second_requests = self.proxy("house730")
        sites = {site: SiteConfig(site) for site in ("28hse", "house730")}
        lanes = [LaneConfig(name, site, page, Config(
            f"http://unresolvable.invalid/{name}", timeout=1,
        )) for name, (site, page) in LANES.items()]
        received = {}

        async def consume(lane, data, request_id):
            received[lane] = data["proxy"]

        environment = {
            "CRAWLER_PROXY": "http://127.0.0.1:1",
            "HSE28_PROXY": first_proxy,
            "HOUSE730_PROXY": second_proxy,
            "NO_PROXY": "*", "no_proxy": "*",
        }
        with patch.dict(os.environ, environment):
            results = await run_four_lanes(PreparedRun(sites, lanes), max_requests=1, on_data=consume)
        self.assertTrue(all(result.succeeded == 1 and result.failed == 0 for result in results.values()))
        self.assertEqual(received, {name: site for name, (site, _) in LANES.items()})
        self.assertEqual(set(first_requests), {
            "http://unresolvable.invalid/28hse-rent", "http://unresolvable.invalid/28hse-buy",
        })
        self.assertEqual(set(second_requests), {
            "http://unresolvable.invalid/house730-rent", "http://unresolvable.invalid/house730-buy",
        })


if __name__ == "__main__":
    unittest.main()
