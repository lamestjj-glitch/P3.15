"""Profile selection regressions; all browser observations are local fixtures."""
from __future__ import annotations

import unittest

from capture_four_lanes import CaptureError, Observation, impersonation, prepare
from four_lane_crawler import BrowserCookie, LANES


def desktop_ua(major: int, marker: str = "") -> str:
    return ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            f"AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{major}.0.0.0 "
            f"Safari/537.36 {marker}").strip()


class ProfileSelectionTests(unittest.TestCase):
    def test_exact_desktop_version_remains_the_first_choice(self):
        self.assertEqual(impersonation(desktop_ua(136), None), "chrome136")
        self.assertEqual(impersonation(desktop_ua(133), None), "chrome133a")

    def test_missing_versions_choose_nearest_older_desktop_profile_and_warn(self):
        # Includes a variant, a missing release, and a future release. Numerical
        # ordering must select 150 for 999 rather than the lexicographic 99.
        for major, expected in ((134, "chrome133a"), (143, "chrome142"), (999, "chrome150")):
            with self.subTest(major=major), self.assertLogs("crawler.capture", level="WARNING") as logs:
                result = impersonation(desktop_ua(major, "PRIVATE-UA-MARKER"), None, site="28hse")
            self.assertEqual(result, expected)
            output = "\n".join(logs.output)
            self.assertIn("28hse", output)
            self.assertIn(str(major), output)
            self.assertIn(expected, output)
            self.assertIn("403", output)
            self.assertNotIn("PRIVATE-UA-MARKER", output)

    def test_too_old_chrome_does_not_silently_choose_a_newer_fingerprint(self):
        with self.assertRaises(CaptureError) as caught:
            impersonation(desktop_ua(98, "PRIVATE-OLD-UA"), None, site="28hse")
        self.assertNotIn("PRIVATE-OLD-UA", str(caught.exception))

    def test_other_browser_families_are_not_misidentified_as_desktop_chrome(self):
        agents = (
            desktop_ua(143) + " Edg/143.0.0.0",
            desktop_ua(143) + " Edge/143.0.0.0",
            desktop_ua(143) + " OPR/143.0.0.0",
            desktop_ua(143) + " Firefox/143.0",
            desktop_ua(143).replace("Windows NT 10.0; Win64; x64", "Linux; Android 15") + " Mobile",
            desktop_ua(143).replace("Windows NT 10.0; Win64; x64", "iPhone; CPU iPhone OS 18_0") + " Mobile",
            "Mozilla/5.0 Version/18.0 Safari/605.1.15 PRIVATE-SAFARI-UA",
            "PRIVATE-UNRECOGNIZED-UA",
        )
        for user_agent in agents:
            with self.subTest(user_agent=user_agent), self.assertRaises(CaptureError) as caught:
                impersonation(user_agent, None, site="house730")
            self.assertNotIn(user_agent, str(caught.exception))

    def test_explicit_valid_profile_is_preserved_even_for_unknown_ua(self):
        for profile in ("chrome136", "chrome133a", "chrome", "edge", "safari", "firefox"):
            with self.subTest(profile=profile):
                self.assertEqual(impersonation("PRIVATE-CUSTOM-UA", profile, site="28hse"), profile)

    def test_invalid_override_does_not_echo_the_input(self):
        secret = "invalid-profile-PRIVATE-CREDENTIAL"
        with self.assertRaises(CaptureError) as caught:
            impersonation(desktop_ua(143), secret, site="28hse")
        self.assertNotIn(secret, str(caught.exception))


class PreparedProfileTests(unittest.TestCase):
    def observations(self):
        agents = {
            "28hse": desktop_ua(143, "PRIVATE-UA-HSE"),
            "house730": desktop_ua(145, "PRIVATE-UA-HOUSE"),
        }
        observations = {}
        for lane, (site, _) in LANES.items():
            domain = ".28hse.com" if site == "28hse" else ".house730.com"
            observations[lane] = Observation(
                lane=lane,
                url=f"https://www{domain}/fixture/list?token=PRIVATE-QUERY",
                method="POST",
                headers={"Content-Type": "application/json", "X-Fixture": "PRIVATE-HEADER"},
                body='{"fixture":"PRIVATE-BODY"}',
                user_agent=agents[site],
                cookies=(BrowserCookie("cf_clearance", "PRIVATE-COOKIE-" + site, domain),),
            )
        return observations, agents

    def test_preparation_keeps_each_site_profile_and_original_credentials_separate(self):
        observations, agents = self.observations()
        with self.assertLogs("crawler.capture", level="INFO") as logs:
            prepared = prepare(observations)
        self.assertEqual(prepared.sites["28hse"].impersonate, "chrome142")
        self.assertEqual(prepared.sites["house730"].impersonate, "chrome145")
        for site, agent in agents.items():
            self.assertEqual(prepared.sites[site].user_agent, agent)
            self.assertEqual(prepared.sites[site].cookies[0].value, "PRIVATE-COOKIE-" + site)
        for lane in prepared.lanes:
            self.assertEqual(lane.config.user_agent, agents[lane.site])
            self.assertEqual(lane.config.impersonate, prepared.sites[lane.site].impersonate)
            self.assertEqual(lane.config.headers["X-Fixture"], "PRIVATE-HEADER")
            self.assertEqual(lane.config.raw_body, '{"fixture":"PRIVATE-BODY"}')
        output = "\n".join(logs.output)
        for item in ("28hse", "house730", "143", "145", "chrome142", "chrome145"):
            self.assertIn(item, output)
        for secret in ("PRIVATE-UA-HSE", "PRIVATE-UA-HOUSE", "PRIVATE-QUERY", "PRIVATE-HEADER",
                       "PRIVATE-BODY", "PRIVATE-COOKIE-28hse", "PRIVATE-COOKIE-house730"):
            self.assertNotIn(secret, output)

    def test_site_overrides_are_respected_without_rewriting_original_user_agents(self):
        observations, agents = self.observations()
        overrides = {"28hse": "chrome136", "house730": "chrome150"}
        prepared = prepare(observations, overrides=overrides)
        for site, profile in overrides.items():
            self.assertEqual(prepared.sites[site].impersonate, profile)
            self.assertEqual(prepared.sites[site].user_agent, agents[site])


if __name__ == "__main__":
    unittest.main()
