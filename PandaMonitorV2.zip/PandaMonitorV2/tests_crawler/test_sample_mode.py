"""Sample mode uses browser observations once, then exports without polling."""
from __future__ import annotations

import argparse
import asyncio
import contextlib
import io
import json
from types import SimpleNamespace
import unittest
from unittest.mock import AsyncMock, patch
from urllib.parse import urlencode

import capture_four_lanes as capture_module


class ObservationPrivacyTests(unittest.TestCase):
    def test_sample_is_not_in_observation_representation(self):
        observation = capture_module.Observation(
            "28hse-rent", "https://www.28hse.com/property/dosearch", "POST",
            {}, None, "fixture-agent", sample={"private": "PRIVATE-SAMPLE-CONTENT"},
        )
        self.assertNotIn("PRIVATE-SAMPLE-CONTENT", repr(observation))


class SampleRunTests(unittest.IsolatedAsyncioTestCase):
    def arguments(self, export=None):
        return argparse.Namespace(
            cdp="http://127.0.0.1:9333", capture_seconds=5, house730_path=None,
            interval=.5, concurrency=8, timeout=10, count=1,
            hse28_impersonate=None, house730_impersonate=None,
            export_samples=export,
        )

    def browser_client(self, events):
        browser = object()

        async def connect(*args, **kwargs):
            events.append("connect")
            return browser

        class Manager:
            async def __aenter__(self):
                events.append("attach")
                return SimpleNamespace(chromium=SimpleNamespace(connect_over_cdp=connect))

            async def __aexit__(self, *args):
                events.append("detach")

        return browser, Manager()

    async def test_export_detaches_then_writes_without_profile_selection_or_polling(self):
        events = []
        browser, manager = self.browser_client(events)
        # Unknown browser profiles do not matter when only exporting samples.
        observations = {"fixture": SimpleNamespace(user_agent="UNKNOWN-PRIVATE-UA")}

        async def capture(*args, **kwargs):
            self.assertIs(args[0], browser)
            self.assertTrue(kwargs["include_samples"])
            events.append("capture")
            return observations

        def export(received, target):
            self.assertIs(received, observations)
            self.assertEqual(target, "samples_for_review.zip")
            self.assertEqual(events[-1], "detach")
            events.append("export")

        with patch("playwright.async_api.async_playwright", return_value=manager), \
             patch.object(capture_module, "capture", new=capture), \
             patch.object(capture_module, "prepare", side_effect=AssertionError("No profile selection")) as prepare, \
             patch.object(capture_module, "run_four_lanes", new_callable=AsyncMock) as poll, \
             patch.dict("sys.modules", {"sample_export": SimpleNamespace(export_samples=export)}):
            self.assertEqual(await capture_module.run(self.arguments("samples_for_review.zip")), 0)
        self.assertEqual(events, ["attach", "connect", "capture", "detach", "export"])
        prepare.assert_not_called()
        poll.assert_not_awaited()

    async def test_normal_mode_still_prepares_and_polls_after_detaching(self):
        events = []
        browser, manager = self.browser_client(events)
        observations, prepared = object(), object()

        async def capture(*args, **kwargs):
            self.assertIs(args[0], browser)
            self.assertFalse(kwargs.get("include_samples", False))
            return observations

        def prepare(received, **kwargs):
            self.assertIs(received, observations)
            self.assertEqual(events[-1], "detach")
            return prepared

        stats = SimpleNamespace(started=1, succeeded=1, failed=0, skipped=0,
                                forbidden=0, blocked=0)
        with patch("playwright.async_api.async_playwright", return_value=manager), \
             patch.object(capture_module, "capture", new=capture), \
             patch.object(capture_module, "prepare", side_effect=prepare), \
             patch("listing_monitor.ListingMonitor") as monitor, \
             patch.object(capture_module, "run_four_lanes", new_callable=AsyncMock,
                          return_value={"fixture": stats}) as poll:
            self.assertEqual(await capture_module.run(self.arguments()), 0)
        poll.assert_awaited_once_with(prepared, max_requests=1, on_data=monitor.return_value)
        monitor.assert_called_once_with(prepared)
        monitor.return_value.close.assert_called_once()

    async def test_existing_export_file_is_reported_without_echoing_its_exception(self):
        events = []
        _, manager = self.browser_client(events)

        def export(*args):
            self.assertEqual(events[-1], "detach")
            raise FileExistsError("PRIVATE-OUTPUT-PATH")

        with patch("playwright.async_api.async_playwright", return_value=manager), \
             patch.object(capture_module, "capture", new_callable=AsyncMock, return_value={}), \
             patch.object(capture_module, "prepare") as prepare, \
             patch.object(capture_module, "run_four_lanes", new_callable=AsyncMock) as poll, \
             patch.dict("sys.modules", {"sample_export": SimpleNamespace(export_samples=export)}), \
             self.assertRaises(capture_module.CaptureError) as caught:
            await capture_module.run(self.arguments("samples_for_review.zip"))
        self.assertNotIn("PRIVATE-OUTPUT-PATH", str(caught.exception))
        prepare.assert_not_called()
        poll.assert_not_awaited()

    async def test_monitor_is_closed_when_polling_is_cancelled(self):
        events = []
        _, manager = self.browser_client(events)
        with patch("playwright.async_api.async_playwright", return_value=manager), \
             patch.object(capture_module, "capture", new_callable=AsyncMock, return_value={}), \
             patch.object(capture_module, "prepare", return_value=object()), \
             patch("listing_monitor.ListingMonitor") as monitor, \
             patch.object(capture_module, "run_four_lanes", new_callable=AsyncMock,
                          side_effect=asyncio.CancelledError), \
             self.assertRaises(asyncio.CancelledError):
            await capture_module.run(self.arguments())
        monitor.return_value.close.assert_called_once()

    async def test_capture_only_retains_response_payload_when_explicitly_requested(self):
        payload = {"result": [{"propertyId": 1234567, "title": "PRIVATE-SAMPLE-TITLE"}]}
        context = SimpleNamespace(pages=[])

        async def cookies(*args):
            return []

        context.cookies = cookies

        class Page:
            def __init__(self, lane, url):
                self.url, self.context, self.lane = url, context, lane
                self.listeners = []

            def on(self, event, handler):
                self.listeners.append(handler)
                hse = self.lane.startswith("28hse")
                request = SimpleNamespace(
                    url=("https://www.28hse.com/property/dosearch" if hse else
                         "https://api.house730.com/fixture/current-list"),
                    method="POST", resource_type="fetch",
                    post_data_buffer=urlencode({"landlordAgency": "LANDLORD", "sortBy": "latest"}).encode(),
                )

                async def all_headers():
                    return {"user-agent": "Mozilla/5.0 Chrome/143.0.0.0"}

                async def body():
                    return json.dumps(payload).encode()

                request.all_headers = all_headers
                handler(SimpleNamespace(request=request, status=200, body=body))

            def remove_listener(self, event, handler):
                self.listeners.remove(handler)

        routes = {
            "28hse-rent": "https://www.28hse.com/rent",
            "28hse-buy": "https://www.28hse.com/buy",
            "house730-rent": "https://www.house730.com/rent/s1u14/",
            "house730-buy": "https://www.house730.com/buy/s1u14/",
        }
        context.pages = [Page(lane, url) for lane, url in routes.items()]
        browser = SimpleNamespace(contexts=[context])
        for include_samples in (False, True):
            with self.subTest(include_samples=include_samples):
                observations = await capture_module.capture(browser, 3, include_samples=include_samples)
                self.assertEqual(set(observations), set(routes))
                for observation in observations.values():
                    if include_samples:
                        self.assertEqual(observation.sample, payload)
                    else:
                        self.assertIsNone(observation.sample)
                self.assertTrue(all(not page.listeners for page in context.pages))


class SampleCLItests(unittest.TestCase):
    def test_export_flag_prompts_for_cdp_and_confirmation_without_interval(self):
        received = []

        async def run(args):
            received.append(args)
            return 0

        with patch.object(capture_module, "check_dependencies", return_value=True), \
             patch.object(capture_module, "run", new=run), \
             patch("builtins.input", side_effect=["9333", "y"]) as read, \
             contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(capture_module.main(["--export-samples"]), 0)
        self.assertEqual(read.call_count, 2)
        self.assertFalse(any("間隔" in call.args[0] for call in read.call_args_list))
        self.assertEqual(received[0].export_samples, "samples_for_review.zip")
        self.assertEqual(received[0].cdp, "http://127.0.0.1:9333")
        self.assertTrue(received[0].confirm_filters)

    def test_export_accepts_explicit_destination_and_existing_cli_parameters(self):
        received = []

        async def run(args):
            received.append(args)
            return 0

        with patch.object(capture_module, "check_dependencies", return_value=True), \
             patch.object(capture_module, "run", new=run), \
             patch("builtins.input", side_effect=AssertionError("Unexpected interactive input")), \
             contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(capture_module.main([
                "--export-samples", "custom-samples.zip", "--cdp", "http://127.0.0.1:9333",
                "--confirm-filters",
            ]), 0)
        self.assertEqual(received[0].export_samples, "custom-samples.zip")

    def test_blank_cdp_cancels_export_without_starting_capture(self):
        with patch.object(capture_module, "check_dependencies", return_value=True), \
             patch.object(capture_module, "run", new_callable=AsyncMock) as run, \
             patch("builtins.input", return_value=""), \
             contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(capture_module.main(["--export-samples"]), 0)
        run.assert_not_awaited()


if __name__ == "__main__":
    unittest.main()
