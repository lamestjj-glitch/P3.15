"""HSE filter serialization checks using only synthetic local requests."""
from __future__ import annotations

import json
import unittest
from urllib.parse import urlencode

import capture_four_lanes as capture_module
from tests_crawler.test_capture_decode import Browser, Request, Response, listing_payload, valid_frames


EXPECTED = {"landlordAgency": "match", "sortBy": "match"}


class HSEFilterStatusTests(unittest.TestCase):
    def assert_matches(self, body):
        self.assertEqual(capture_module.hse_filter_status(body), EXPECTED)
        self.assertTrue(capture_module.owner_latest(body))

    def test_supported_filter_serializations(self):
        filters = {"landlordAgency": "LANDLORD", "sortBy": "latest"}
        actual = 'sortBy=latest&buyRent=rent&is_return_newmenu=1&propertyDoSearchVersion=2.0&sortBy=latest&landlordAgency=["LANDLORD"]'
        bodies = {
            "json": json.dumps(filters),
            "form": urlencode(filters),
            "nested_json_form": urlencode({"form_data": json.dumps(filters)}),
            "nested_query_form": urlencode({"form_data": urlencode(filters)}),
            "actual_live_shape": actual,
            "nested_actual_live_shape": urlencode({"form_data": actual}),
            "encoded_array": urlencode({"landlordAgency": '["LANDLORD"]', "sortBy": "latest"}),
            "json_array_value": json.dumps({"landlordAgency": ["LANDLORD"], "sortBy": "latest"}),
        }
        for name, body in bodies.items():
            with self.subTest(serialization=name):
                self.assert_matches(body)

    def test_missing_mismatch_and_invalid_are_distinguished(self):
        cases = [
            (None, {"landlordAgency": "missing", "sortBy": "missing"}),
            ("sortBy=latest", {"landlordAgency": "missing", "sortBy": "match"}),
            ("landlordAgency=AGENCY&sortBy=latest", {"landlordAgency": "mismatch", "sortBy": "match"}),
            ("landlordAgency=LANDLORD&sortBy=oldest", {"landlordAgency": "match", "sortBy": "mismatch"}),
            (json.dumps({"landlordAgency": 1, "sortBy": "latest"}), {"landlordAgency": "invalid", "sortBy": "match"}),
            (json.dumps({"landlordAgency": None, "sortBy": "latest"}), {"landlordAgency": "invalid", "sortBy": "match"}),
        ]
        for body, expected in cases:
            with self.subTest(expected=expected):
                self.assertEqual(capture_module.hse_filter_status(body), expected)
                self.assertFalse(capture_module.owner_latest(body))

    def test_value_case_and_numeric_enums_are_not_guessed(self):
        for owner, sort in (("landlord", "latest"), ("LANDLORD", "LATEST"), ("1", "0")):
            with self.subTest(owner=owner, sort=sort):
                self.assertFalse(capture_module.owner_latest(urlencode({"landlordAgency": owner, "sortBy": sort})))

    def test_conflicting_known_fields_cannot_hide_behind_wrappers(self):
        bodies = [
            "landlordAgency=LANDLORD&landlordAgency=AGENCY&sortBy=latest",
            '{"landlordAgency":"LANDLORD","landlordAgency":"AGENCY","sortBy":"latest"}',
            json.dumps({"landlordAgency": "LANDLORD", "sortBy": "latest", "filters": {"sortBy": "oldest"}}),
            urlencode({"landlordAgency": '["LANDLORD","AGENCY"]', "sortBy": "latest"}),
            'landlordAgency=["LANDLORD"]&landlordAgency=AGENCY&sortBy=latest',
        ]
        for body in bodies:
            with self.subTest(body=body):
                self.assertFalse(capture_module.owner_latest(body))
                self.assertIn("conflict", capture_module.hse_filter_status(body).values())

    def test_repeated_identical_values_do_not_create_false_conflicts(self):
        self.assert_matches("landlordAgency=LANDLORD&landlordAgency=LANDLORD&sortBy=latest")

    def test_invalid_extra_value_prevents_acceptance(self):
        bodies = [
            json.dumps({"landlordAgency": ["LANDLORD", None], "sortBy": "latest"}),
            urlencode({"landlordAgency": '["LANDLORD",null]', "sortBy": "latest"}),
            urlencode({"landlordAgency": '["LANDLORD",1]', "sortBy": "latest"}),
            urlencode({"landlordAgency": '[]', "sortBy": "latest"}),
        ]
        for body in bodies:
            with self.subTest(body=body):
                self.assertEqual(capture_module.hse_filter_status(body)["landlordAgency"], "invalid")
                self.assertFalse(capture_module.owner_latest(body))

    def test_malformed_or_overly_nested_input_fails_closed(self):
        nested = {"landlordAgency": "LANDLORD", "sortBy": "latest"}
        for _ in range(50):
            nested = {"form_data": nested}
        for body in ('{"landlordAgency":"LANDLORD","sortBy":"latest"', json.dumps(nested)):
            with self.subTest(size=len(body)):
                self.assertFalse(capture_module.owner_latest(body))


class HSEFilterCaptureTests(unittest.IsolatedAsyncioTestCase):
    async def test_new_serializations_keep_the_original_request_bytes(self):
        frames = valid_frames()
        encoded = urlencode({"form_data": 'sortBy=latest&buyRent=rent&sortBy=latest&landlordAgency=["LANDLORD"]&searchText=中文測試'}).encode("utf-8")
        for lane in ("28hse-rent", "28hse-buy"):
            frames[lane] = [Response(Request(lane, encoded), listing_payload(lane))]
        observations = await capture_module.capture(Browser(frames), 2.5)
        self.assertEqual(observations["28hse-rent"].body.encode("utf-8"), encoded)
        self.assertEqual(observations["28hse-buy"].body.encode("utf-8"), encoded)

    async def test_rejection_warning_explains_both_fields_without_private_values(self):
        frames = valid_frames()
        body = json.dumps({"landlordAgency": "PRIVATE-UNKNOWN-ENUM", "sortBy": "latest",
                           "token": "PRIVATE-TOKEN", "searchText": "PRIVATE-SEARCH"}).encode()
        frames["28hse-rent"] = [Response(Request("28hse-rent", body), listing_payload("28hse-rent"))]
        with self.assertLogs("crawler.capture", level="WARNING") as logs:
            with self.assertRaises(capture_module.CaptureError):
                await capture_module.capture(Browser(frames), .3)
        output = "\n".join(logs.output)
        self.assertIn("landlordAgency", output)
        self.assertIn("sortBy", output)
        for private in ("PRIVATE-UNKNOWN-ENUM", "PRIVATE-TOKEN", "PRIVATE-SEARCH", "PRIVATE-COOKIE"):
            self.assertNotIn(private, output)


if __name__ == "__main__":
    unittest.main()
