"""PandaMonitorV2 GUI entry; importing this module does not start networking."""
from __future__ import annotations

import argparse
import importlib
import importlib.metadata
import os
from pathlib import Path
import sys

VERSION = "2.0.0"


def check_setup() -> bool:
    if sys.version_info < (3, 12):
        print("[ERROR] Python 3.12+ required; use your installed Python 3.15.", flush=True)
        return False
    try:
        for module in ("tkinter", "curl_cffi.requests", "playwright.async_api", "bs4", "websocket", "requests"):
            importlib.import_module(module)
        if importlib.metadata.version("curl_cffi") != "0.16.3":
            raise ImportError
        if importlib.metadata.version("playwright") != "1.64.0":
            raise ImportError
    except (ImportError, OSError, importlib.metadata.PackageNotFoundError):
        print("[ERROR] GUI dependencies are unavailable. Run py -3.15 start_v2.py.", flush=True)
        return False
    return True


def main(arguments: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="PandaMonitorV2: curl_cffi + asyncio GUI")
    parser.add_argument("--version", action="version", version=f"PandaMonitorV2 {VERSION}")
    parser.add_argument("--check-setup", action="store_true", help="Check dependencies without opening the GUI or browser")
    parser.add_argument("--self-test", action="store_true", help="Open and close the GUI without starting monitoring")
    args = parser.parse_args(arguments)
    if not check_setup():
        return 1
    if args.check_setup:
        print("[CHECK_OK] PandaMonitorV2 dependencies available; no browser connection made.", flush=True)
        return 0
    from v2_paths import bootstrap_legacy_data
    bootstrap_legacy_data()
    mutex = None
    kernel = None
    app = None
    try:
        if os.name == "nt":
            import ctypes
            kernel = ctypes.WinDLL("kernel32", use_last_error=True)
            kernel.CreateMutexW.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_wchar_p]
            kernel.CreateMutexW.restype = ctypes.c_void_p
            mutex = kernel.CreateMutexW(None, 1, "Local\\PandaMonitorV2")
            if mutex and ctypes.get_last_error() == 183:
                print("[ALREADY_RUNNING] PandaMonitorV2 is already open.", flush=True)
                return 0
        from v2_gui import PandaMonitorV2App
        app = PandaMonitorV2App()
        if args.self_test:
            app.update_idletasks()
            app.update()
            print("[SELF_TEST_OK] PandaMonitorV2 GUI opened; monitoring was not started.", flush=True)
            return 0
        print("[GUI_READY] PandaMonitorV2", flush=True)
        app.mainloop()
        return 0
    except KeyboardInterrupt:
        return 130
    except Exception as exc:
        # A raw traceback could contain live request/credential values.
        print(f"[ERROR] PandaMonitorV2 could not run ({type(exc).__name__}).", flush=True)
        if os.name == "nt":
            try:
                import ctypes
                ctypes.windll.user32.MessageBoxW(None,
                    "PandaMonitorV2 未能啟動，請從 CMD 執行 py -3.15 start_v2.py 查看狀態。",
                    "PandaMonitorV2", 0x10)
            except Exception:
                pass
        return 1
    finally:
        if app is not None:
            try:
                app.destroy()
            except Exception:
                pass
        if mutex and kernel is not None:
            import ctypes
            kernel.CloseHandle(ctypes.c_void_p(mutex))


if __name__ == "__main__":
    raise SystemExit(main())
