@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
if errorlevel 1 goto folder_error
if not exist "start_v2.py" goto folder_error
if not exist "PandaMonitorV2.py" goto folder_error
set "PYTHONUTF8=1"
set "PYTHONUNBUFFERED=1"
set "PANDAMONITOR_PARENT_PAUSES=1"
if defined PANDAMONITOR_PYTHON (
  "%PANDAMONITOR_PYTHON%" -I -c "import sys; raise SystemExit(not sys.version_info.__ge__((3,12)))" >nul 2>&1
  if errorlevel 1 goto configured_python_error
  "%PANDAMONITOR_PYTHON%" "%~dp0start_v2.py" %*
  goto finished
)
where py >nul 2>&1
if not errorlevel 1 (
  for %%V in (3.15 3) do (
    py -%%V -I -c "import sys; raise SystemExit(not sys.version_info.__ge__((3,12)))" >nul 2>&1
    if not errorlevel 1 (
      py -%%V "%~dp0start_v2.py" %*
      goto finished
    )
  )
)
for /f "delims=" %%P in ('where python.exe 2^>nul') do (
  "%%P" -I -c "import sys; raise SystemExit(not sys.version_info.__ge__((3,12)))" >nul 2>&1
  if not errorlevel 1 (
    "%%P" "%~dp0start_v2.py" %*
    goto finished
  )
)
echo [ERROR] No working Python 3.12+ was found. Run py -0p to locate Python.
set "PANDAMONITOR_EXIT_CODE=1"
goto hold
:configured_python_error
echo [ERROR] PANDAMONITOR_PYTHON is not a working Python 3.12+ executable.
set "PANDAMONITOR_EXIT_CODE=1"
goto hold
:folder_error
echo [ERROR] Extract the complete PandaMonitorV2 ZIP into a writable folder.
set "PANDAMONITOR_EXIT_CODE=1"
goto hold
:finished
set "PANDAMONITOR_EXIT_CODE=%ERRORLEVEL%"
echo [EXIT] Code %PANDAMONITOR_EXIT_CODE%.
:hold
pause
exit /b %PANDAMONITOR_EXIT_CODE%
