"""PandaMonitorV2 dashboard: legacy results UI with one asyncio controller.

The browser is used to learn genuine requests. This module never starts the
legacy CDP list workers or the House730 subprocess.
"""
from __future__ import annotations

from datetime import datetime
import json
import math
import os
from pathlib import Path
import queue
import threading
import time
import tkinter as tk
from tkinter import messagebox, ttk
from urllib.parse import urlsplit, urlunsplit

from start_with_proxy import proxy_url
from unified_gui import UnifiedApp, BG, PANEL, TEXT, MUTED, GOLD, RED
from v2_paths import data_root
from v2_runtime import MonitorController, RuntimeOptions


LANE_LABELS = {
    "28hse-rent": "28Hse 租盤", "28hse-buy": "28Hse 售盤",
    "house730-rent": "House730 租盤", "house730-buy": "House730 售盤",
}
SITE_LABELS = {"28hse": "28Hse", "house730": "House730"}


def cdp_address(value: str) -> str:
    text = value.strip()
    if text.isascii() and text.isdecimal():
        if not 1 <= int(text) <= 65535:
            raise ValueError("CDP 埠必須介於 1 與 65535。")
        return "http://127.0.0.1:" + str(int(text))
    try:
        parsed = urlsplit(text)
        if (parsed.scheme not in {"http", "https", "ws", "wss"}
                or parsed.hostname not in {"127.0.0.1", "localhost", "::1"}
                or parsed.username is not None or parsed.password is not None
                or parsed.port is None or not 1 <= parsed.port <= 65535
                or parsed.query or parsed.fragment):
            raise ValueError
    except ValueError:
        raise ValueError("請填目前瀏覽器的本機 CDP 埠或完整位址；不是 Local API 54345。") from None
    return text


def positive_number(value: str, label: str) -> float:
    try:
        number = float(value)
        if not math.isfinite(number) or number <= 0:
            raise ValueError
    except (ValueError, TypeError):
        raise ValueError(label + "必須是有限的正數。") from None
    return number


def positive_integer(value: str, label: str) -> int:
    text = str(value).strip()
    if not text.isascii() or not text.isdecimal() or not 1 <= int(text) <= 100:
        raise ValueError(label + "必須介於 1 與 100。")
    return int(text)


class PandaMonitorV2App(UnifiedApp):
    VERSION = "2.0.0"

    def __init__(self):
        self._v2_initializing = True
        self._v2_controller = None
        self._v2_closed = False
        self._v2_phase = "已停止"
        self._v2_lane_stats = {}
        self._v2_selected = ()
        self._v2_tests = {}
        super().__init__()
        self._v2_initializing = False
        self.title("PandaMonitorV2｜curl_cffi + asyncio")
        # Imported history and old settings must not silently enable sending.
        # The existing WA controls remain available for this run's selection.
        self.wa_enable.set(False)
        self.wa_730_enable.set(False)
        self.house_engine = None
        self.tabs.hide(self.sites_tab)
        self.tabs.tab(2, text="   通知與原版設定   ")
        self._build_v2_settings()
        self._restore_v2_settings()
        self.api_pause_banner.set("V2：四路獨立節拍；先擷取真實搜尋請求，再用 curl_cffi 監控第一頁。")
        self.house_status.set("V2 尚未啟動")
        self.house_queue.set("V2 電話 API 佇列")
        self._load_house_history()
        self._load_28_history()
        self.write("[V2] PandaMonitorV2 2.0.0：列表與電話 API 由 asyncio 控制器處理；保留歷史、去重與剪貼簿。")
        self.write("[V2] 開啟所選列表、設定業主＋最新並停在第 1 頁；開始擷取後各按一次搜尋。")
        self.set_monitor_controls(False)
        self.protocol("WM_DELETE_WINDOW", self.on_close)

    def write(self, text):
        if getattr(self, "_v2_initializing", False) and str(text).startswith(("[MERGE]", "[WA55]", "[WA56]")):
            return
        return super().write(text)

    def _build_v2_settings(self):
        self.v2_cdp = tk.StringVar(master=self)
        self.v2_intervals = {lane: tk.StringVar(master=self, value="0.5") for lane in LANE_LABELS}
        self.v2_timeout = tk.StringVar(master=self, value="20")
        self.v2_concurrency = tk.StringVar(master=self, value="8")
        self.v2_capture_seconds = tk.StringVar(master=self, value="120")
        self.v2_phone_enabled = tk.BooleanVar(master=self, value=True)
        self.v2_phone_concurrency = tk.StringVar(master=self, value="2")
        self.v2_proxy_protocol = tk.StringVar(master=self, value="socks5")
        self.v2_proxy_host = tk.StringVar(master=self)
        self.v2_proxy_port = tk.StringVar(master=self)
        self.v2_proxy_username = tk.StringVar(master=self)
        self.v2_proxy_password = tk.StringVar(master=self)
        self.v2_clearance = {site: tk.StringVar(master=self) for site in SITE_LABELS}
        self.v2_user_agent = {site: tk.StringVar(master=self, value="auto") for site in SITE_LABELS}
        self.v2_impersonate = {site: tk.StringVar(master=self, value="auto") for site in SITE_LABELS}
        self.v2_random_ua = tk.BooleanVar(master=self, value=False)

        frame = tk.Frame(self.tabs, bg=PANEL)
        self.tabs.insert(0, frame, text="   V2 連線與排程   ")
        self.tabs.select(frame)
        canvas = tk.Canvas(frame, bg=PANEL, highlightthickness=0)
        scroll = ttk.Scrollbar(frame, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=scroll.set)
        scroll.pack(side="right", fill="y")
        canvas.pack(side="left", fill="both", expand=True)
        body = tk.Frame(canvas, bg=PANEL, padx=20, pady=14)
        window = canvas.create_window((0, 0), window=body, anchor="nw")
        body.bind("<Configure>", lambda _e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.bind("<Configure>", lambda e: canvas.itemconfigure(window, width=e.width))
        self._label(body, "PandaMonitorV2｜四路異步 API 監控", TEXT, 16, True).pack(anchor="w")
        self._label(body, "先在原瀏覽器完成驗證，所選分頁設定業主＋最新、第 1 頁；本程式不自動完成驗證。", MUTED).pack(anchor="w", pady=(4, 12))

        def section(title):
            box = tk.LabelFrame(body, text="  " + title + "  ", bg=PANEL, fg=TEXT, padx=10, pady=8)
            box.pack(fill="x", pady=(0, 10))
            return box

        def entry(parent, label, variable, *, width=15, secret=False):
            self._label(parent, label, MUTED).pack(side="left")
            widget = ttk.Entry(parent, textvariable=variable, width=width,
                               show="*" if secret else "", style="Dark.TEntry")
            widget.pack(side="left", padx=(4, 14))
            return widget

        connection = section("既有瀏覽器")
        line = tk.Frame(connection, bg=PANEL); line.pack(fill="x", pady=3)
        entry(line, "本機 CDP 埠／位址：", self.v2_cdp, width=48)
        self._btn(line, "沿用已連線埠", self._use_connected_cdp).pack(side="left")
        self._label(connection, "需要實際 CDP 埠，54345 是 BitBrowser Local API；每次開啟環境時 CDP 埠可能改變。", MUTED).pack(anchor="w")

        timing = section("監控來源與速度")
        line = tk.Frame(timing, bg=PANEL); line.pack(fill="x", pady=3)
        for label, variable in (("28Hse 租盤", self.rent), ("28Hse 售盤", self.buy),
                                ("House730 租盤", self.house_rent), ("House730 售盤", self.house_buy)):
            ttk.Checkbutton(line, text=label, variable=variable, style="Dark.TCheckbutton").pack(side="left", padx=(0, 14))
        for index, (lane, label) in enumerate(LANE_LABELS.items()):
            if index % 2 == 0:
                line = tk.Frame(timing, bg=PANEL); line.pack(fill="x", pady=3)
            entry(line, label + "間隔（秒）：", self.v2_intervals[lane], width=10)
        line = tk.Frame(timing, bg=PANEL); line.pack(fill="x", pady=3)
        entry(line, "請求逾時（秒）：", self.v2_timeout, width=8)
        entry(line, "每站並發上限：", self.v2_concurrency, width=8)
        entry(line, "擷取等候（秒）：", self.v2_capture_seconds, width=8)
        line = tk.Frame(timing, bg=PANEL); line.pack(fill="x", pady=3)
        ttk.Checkbutton(line, text="新 ID 自動查詢電話 API", variable=self.v2_phone_enabled,
                        style="Dark.TCheckbutton").pack(side="left", padx=(0, 15))
        entry(line, "電話並發上限：", self.v2_phone_concurrency, width=8)
        self._label(timing, "預設每路 0.5 秒；請求重疊但不補發積壓。首次有效列表建立基線，之後只處理首次發現 ID。", MUTED).pack(anchor="w")
        self._label(timing, "V2 速度以本頁為準；修改後停止並重新開始即可套用。", GOLD).pack(anchor="w")

        proxy = section("與 BitBrowser 相同的代理（僅本次記憶體）")
        line = tk.Frame(proxy, bg=PANEL); line.pack(fill="x", pady=3)
        self._label(line, "類型：", MUTED).pack(side="left")
        ttk.Combobox(line, textvariable=self.v2_proxy_protocol,
                     values=("http", "https", "socks5"), width=10, state="readonly").pack(side="left", padx=(4, 14))
        entry(line, "主機：", self.v2_proxy_host, width=30)
        entry(line, "埠：", self.v2_proxy_port, width=8)
        line = tk.Frame(proxy, bg=PANEL); line.pack(fill="x", pady=3)
        entry(line, "帳號：", self.v2_proxy_username, width=25, secret=True)
        entry(line, "密碼：", self.v2_proxy_password, width=30, secret=True)
        self._label(proxy, "留空使用安全環境設定或原網路。SOCKS5 使用 socks5h，由代理解析目標網域；代理資料不保存。", MUTED).pack(anchor="w")

        identity = section("Cookie 與 User-Agent（可選；僅本次記憶體）")
        self._label(identity, "預設使用原瀏覽器擷取的 Cookie 與 UA。手動 cf_clearance 必須配對原瀏覽器 UA 及代理。", MUTED).pack(anchor="w")
        for site, label in SITE_LABELS.items():
            line = tk.Frame(identity, bg=PANEL); line.pack(fill="x", pady=3)
            entry(line, label + " cf_clearance：", self.v2_clearance[site], width=56, secret=True)
            line = tk.Frame(identity, bg=PANEL); line.pack(fill="x", pady=3)
            entry(line, label + " UA：", self.v2_user_agent[site], width=72)
            line = tk.Frame(identity, bg=PANEL); line.pack(fill="x", pady=3)
            entry(line, label + " impersonate：", self.v2_impersonate[site], width=18)
        ttk.Checkbutton(identity, text="隨機 UA：每站 Session 選一次，僅在沒有 cf_clearance 時可用",
                        variable=self.v2_random_ua, style="Dark.TCheckbutton").pack(anchor="w", pady=4)
        self._label(identity, "UA 與 impersonate 的 auto 表示依原瀏覽器選擇。403 會停止同站請求並提示人工確認。", MUTED).pack(anchor="w")
        self._btn(body, "儲存 V2 一般設定（不含代理／Cookie／UA）", self._save_settings_clicked).pack(anchor="w", pady=(0, 8))

    def _use_connected_cdp(self):
        if self.cdp_base:
            self.v2_cdp.set(self.cdp_base)
        else:
            messagebox.showinfo("CDP", "請填目前 BitBrowser 的實際 CDP 埠，或先在統一設定連接瀏覽器。", parent=self)

    def _flags(self):
        return {"28hse-rent": self.rent, "28hse-buy": self.buy,
                "house730-rent": self.house_rent, "house730-buy": self.house_buy}

    def _settings_path(self):
        return Path(data_root()) / "v2_settings.json"

    def _plain_settings(self):
        return {"version": self.VERSION,
                "intervals": {key: positive_number(value.get(), LANE_LABELS[key]) for key, value in self.v2_intervals.items()},
                "selected_lanes": [key for key, value in self._flags().items() if value.get()],
                "timeout": positive_number(self.v2_timeout.get(), "請求逾時"),
                "concurrency": positive_integer(self.v2_concurrency.get(), "每站並發上限"),
                "capture_seconds": positive_number(self.v2_capture_seconds.get(), "擷取等候"),
                "phone_enabled": bool(self.v2_phone_enabled.get()),
                "phone_concurrency": positive_integer(self.v2_phone_concurrency.get(), "電話並發上限")}

    def _save_v2_settings(self):
        settings = self._plain_settings()
        path = self._settings_path()
        path.parent.mkdir(parents=True, exist_ok=True)
        temporary = path.with_suffix(".tmp")
        temporary.write_text(json.dumps(settings, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        os.replace(temporary, path)

    def _save_settings_clicked(self):
        try:
            self._save_v2_settings()
        except (ValueError, OSError) as exc:
            messagebox.showerror("V2 設定", str(exc) if isinstance(exc, ValueError) else "無法寫入一般設定。", parent=self)
            return
        self.write("[V2] 已儲存一般設定；代理、Cookie 與 UA 沒有寫入檔案。")

    def _restore_v2_settings(self):
        try:
            settings = json.loads(self._settings_path().read_text(encoding="utf-8"))
            if not isinstance(settings, dict):
                return
            intervals = settings.get("intervals", {})
            if isinstance(intervals, dict):
                for lane, value in intervals.items():
                    if lane in self.v2_intervals:
                        self.v2_intervals[lane].set(str(positive_number(value, LANE_LABELS[lane])))
            for key, variable, validator in (
                ("timeout", self.v2_timeout, positive_number),
                ("concurrency", self.v2_concurrency, positive_integer),
                ("capture_seconds", self.v2_capture_seconds, positive_number),
                ("phone_concurrency", self.v2_phone_concurrency, positive_integer),
            ):
                if key in settings:
                    variable.set(str(validator(str(settings[key]), "設定")))
            if isinstance(settings.get("phone_enabled"), bool):
                self.v2_phone_enabled.set(settings["phone_enabled"])
            selected = settings.get("selected_lanes")
            if isinstance(selected, list) and selected and all(lane in LANE_LABELS for lane in selected):
                for lane, variable in self._flags().items():
                    variable.set(lane in selected)
        except FileNotFoundError:
            return
        except (OSError, ValueError, TypeError):
            self.write("[V2] 未使用無效的一般設定；請在 V2 頁核對數值。")

    def _runtime_options(self):
        settings = self._plain_settings()
        selected = tuple(settings["selected_lanes"])
        if not selected:
            raise ValueError("請至少勾選一路監控來源。")
        cdp = cdp_address(self.v2_cdp.get() or self.cdp_base or "")
        proxy = ""
        if any(variable.get() for variable in (self.v2_proxy_host, self.v2_proxy_port,
                                               self.v2_proxy_username, self.v2_proxy_password)):
            proxy = proxy_url(self.v2_proxy_protocol.get(), self.v2_proxy_host.get(),
                              self.v2_proxy_port.get(), self.v2_proxy_username.get(),
                              self.v2_proxy_password.get())
        clearance = {site: value.get().strip() for site, value in self.v2_clearance.items() if value.get().strip()}
        user_agents = {site: value.get().strip() for site, value in self.v2_user_agent.items()
                       if value.get().strip().lower() not in {"", "auto"}}
        if self.v2_random_ua.get():
            if clearance or user_agents:
                raise ValueError("隨機 UA 不能與手動 Cookie 或固定 UA 同時使用；有 Cookie 時請保留原瀏覽器 UA。")
            user_agents = {site: "random" for site in SITE_LABELS}
        overrides = {site: value.get().strip() for site, value in self.v2_impersonate.items()
                     if value.get().strip().lower() not in {"", "auto"}}
        return RuntimeOptions(cdp=cdp, intervals=settings["intervals"], selected_lanes=selected,
                              timeout=settings["timeout"], concurrency=settings["concurrency"],
                              capture_seconds=settings["capture_seconds"], proxy=proxy,
                              clearance=clearance, user_agents=user_agents,
                              impersonate_overrides=overrides,
                              phone_enabled=settings["phone_enabled"],
                              phone_concurrency=settings["phone_concurrency"], data_dir=Path(data_root()))

    def start(self):
        if self._v2_controller and self._v2_controller.is_alive():
            return
        try:
            options = self._runtime_options()
            self._save_v2_settings()
            controller = MonitorController(options)
        except ValueError as exc:
            messagebox.showerror("V2 設定", str(exc), parent=self)
            return
        except OSError:
            messagebox.showerror("V2 設定", "無法準備 V2 資料目錄。", parent=self)
            return
        self._v2_controller = controller
        self._v2_selected = tuple(options.selected_lanes)
        self._v2_lane_stats.clear()
        self._v2_tests.clear()
        self._v2_phase = "擷取真實請求"
        self.running = True
        self.run_id += 1
        self.api_source_enabled = {trade: "28hse-" + trade in self._v2_selected for trade in ("rent", "buy")}
        with self.lock:
            for trade in ("rent", "buy"):
                self.http_stats[trade]["last_ok"] = 0.0
                self.http_latest[trade] = []
                self.api_paused[trade] = ""
        target = urlsplit(options.cdp)
        self.cdp_base = urlunsplit(("https" if target.scheme in {"https", "wss"} else "http", target.netloc, "", "", ""))
        self.api_pause_banner.set("請在所選業主＋最新、第 1 頁的列表分頁各按一次搜尋；不會自動操作驗證。")
        for lane, card in self._cards().items():
            card.set("等待搜尋擷取" if lane in self._v2_selected else "未啟用")
        if any(site.get("enabled") for site in getattr(self, "extra_sites", ())):
            self.write("[V2] 本次開始只啟動 28Hse／House730 四路；舊擴展網站插件不會同時啟動。")
        try:
            controller.start()
        except Exception:
            self.running = False
            self.write("[V2] 控制器未能啟動；未輸出私密設定。")
            messagebox.showerror("V2 啟動", "控制器未能啟動，請查看日誌。", parent=self)
        self.set_monitor_controls(self.running)

    def stop(self):
        controller = getattr(self, "_v2_controller", None)
        if controller:
            controller.stop()
        self.running = False
        self.run_id += 1
        self._v2_phase = "已停止"
        self._allow_system_sleep()
        if hasattr(self, "api_pause_banner"):
            self.api_pause_banner.set("V2 已要求停止；原瀏覽器分頁保留。")
            for card in self._cards().values():
                card.set("已停止")
            self.house_status.set("V2 已停止")
        self.set_monitor_controls(False)

    def _cards(self):
        return {"28hse-rent": self.card_28r, "28hse-buy": self.card_28b,
                "house730-rent": self.card_730r, "house730-buy": self.card_730b}

    def set_monitor_controls(self, running):
        if not hasattr(self, "start_btn"):
            return
        alive = bool(self._v2_controller and self._v2_controller.is_alive())
        active = bool(self.running or alive)
        self.start_btn.configure(state="disabled" if active else "normal")
        self.stop_btn.configure(state="normal" if active else "disabled")
        state = self._v2_phase if self.running else ("停止中" if alive else "已停止")
        self.monitor_state.set("● V2 " + state)

    def _house_tick(self):
        if getattr(self, "_v2_closed", False):
            return
        try:
            controller = self._v2_controller
            if controller:
                for _ in range(100):
                    try:
                        event = controller.events.get_nowait()
                    except queue.Empty:
                        break
                    try:
                        self._apply_event(event)
                    except Exception:
                        self.write("[V2] 介面處理事件未完成；未輸出事件內容，電話工作保留待確認。")
            self.set_monitor_controls(self.running)
            if self.winfo_exists() and not self._v2_closed:
                self.after(150, self._house_tick)
        except tk.TclError:
            pass

    def _apply_event(self, event):
        kind = event.get("type")
        if kind == "phase":
            self._v2_phase = str(event.get("phase") or "監控中")
            text = str(event.get("text") or "")
            if text:
                self.write("[V2] " + text)
                self.api_pause_banner.set(text)
        elif kind == "lane":
            lane = event.get("lane")
            if lane not in LANE_LABELS:
                return
            self._v2_lane_stats[lane] = dict(event)
            valid = int(event.get("valid") or 0)
            status = str(event.get("status") or ("監控中" if valid else "等待有效列表"))
            self._cards()[lane].set(f"{status}｜有效 {valid}｜失敗 {int(event.get('failed') or 0)}")
            if lane.startswith("28hse-"):
                trade = lane.rsplit("-", 1)[1]
                with self.lock:
                    self.http_stats[trade]["last_ok"] = float(event.get("last_ok") or 0)
                    self.http_stats[trade]["polls"] = int(event.get("started") or 0)
            self.house_queries.set("730 列表請求：%d 次" % sum(int(stats.get("started") or 0)
                                   for name, stats in self._v2_lane_stats.items() if name.startswith("house730-")))
            self.house_status.set("V2：有效列表與失敗次數見各路卡片")
        elif kind == "listing":
            self._listing_row(event)
        elif kind == "contacts":
            self._apply_contacts(event)
        elif kind == "alert":
            text = str(event.get("text") or "網站拒絕請求；請人工確認驗證後重新開始。")
            self.api_pause_banner.set(text)
            self.write("[V2-ALERT] " + text)
            self.toast(SITE_LABELS.get(event.get("site"), "PandaMonitorV2") + " 提示", text, 6500)
        elif kind == "error":
            text = str(event.get("text") or "本次工作未完成。")
            self.write("[V2-ERROR] " + text)
            self.api_pause_banner.set(text)
        elif kind == "done":
            self.running = False
            self._v2_phase = "已停止"
            for lane, card in self._cards().items():
                state = str(self._v2_lane_stats.get(lane, {}).get("status", ""))
                if not any(word in state.lower() for word in ("403", "驗證", "forbidden", "blocked")):
                    card.set("已停止" if lane in self._v2_selected else "未啟用")
            self.house_status.set("V2 已停止")
            self.set_monitor_controls(False)

    def _listing_row(self, event):
        lane, pid = event.get("lane"), str(event.get("listing_id") or "")
        if lane not in LANE_LABELS or not pid:
            return
        trade = lane.rsplit("-", 1)[1]
        deal = "租" if trade == "rent" else "售"
        iid = ("v2:" + lane + ":" + pid if lane.startswith("28hse-") else "house:" + deal + ":" + pid)
        if self.tree.exists(iid):
            return
        stamp = self._display_time(event.get("first_seen_at"))
        url = event.get("url") or ""
        self.tree.insert("", 0, iid=iid, values=(LANE_LABELS[lane], "", "未提供", "等待電話 API",
                         "打開 ↗" if url else "—", stamp, "", pid))
        if url:
            self.row_urls[iid] = url
        if lane.startswith("28hse-"):
            self.listing_rows[(trade, pid)] = iid

    @staticmethod
    def _display_time(value):
        try:
            return datetime.fromisoformat(str(value)).astimezone().strftime("%m-%d %H:%M:%S")
        except ValueError:
            return str(value or "")[:19]

    def _apply_contacts(self, event):
        lane = event.get("lane")
        if lane not in LANE_LABELS:
            return
        contacts = event.get("contacts") or ()
        valid = []
        unique = set()
        for item in contacts:
            if not isinstance(item, dict):
                continue
            phone = self.normalize_phone(item.get("phone"))
            if len(phone) == 8 and phone[:1] in {"4", "5", "6", "7", "8", "9"} and phone not in unique:
                unique.add(phone)
                valid.append({"name": item.get("name") or "未提供", "phone": phone})
        if not valid:
            return
        test = bool(event.get("test_mode"))
        greeting = bool(self._v2_tests.pop(lane, False)) if test else False
        url = event.get("url") or ""
        if lane.startswith("28hse-"):
            trade = lane.rsplit("-", 1)[1]
            for item in valid:
                self.note_wa_phone_contact(url, item["phone"], item.get("name") or "未提供")
            if test:
                fresh = valid
            else:
                with self.phone_lock:
                    fresh = [item for item in valid if item["phone"] not in self.seen_phones
                             and item["phone"] not in self.pending_copy_phones]
            if fresh:
                first = fresh[0]
                if not test:
                    # Commit every fresh API contact before mutating the legacy
                    # in-memory dedup set. If storage fails, a retry must still
                    # see the phone as fresh and be able to finish its history.
                    for item in fresh:
                        self.hse28_history.save(trade, url, item["phone"], item["name"],
                                                is_extra=item is not first)
                self.result(trade, first["name"], first["phone"], url,
                            test_mode=test, wa_test=greeting, extra_phones=fresh[1:])
                if not test:
                    # result() only adds secondary tails to its initial clipboard
                    # batch. The original phone worker separately committed each
                    # extra number; the V2 event consumer must do the same.
                    for item in fresh[1:]:
                        self.publish_secondary_phone(trade, url, item["name"], item["phone"])
        elif test:
            first = valid[0]
            phone = self.normalize_phone(first["phone"])
            self.copy_auto_tail_with_defer(phone)
            if greeting:
                self.bg(self._house_test_wa_job, phone, url, first.get("name") or "未提供")
            else:
                self.test_popup("House730 V2 API 測試", True, "電話已取得，尾四位已複製；測試不寫入去重庫。")
        else:
            deal = "租" if lane.endswith("-rent") else "售"
            saved = []
            for item in valid:
                if self.house_store.save_phone(deal, url, item["phone"], item.get("name") or "未提供"):
                    data = {"deal": deal, "pid": str(event.get("listing_id") or ""),
                        "url": url, "phone": self.normalize_phone(item["phone"]),
                        "contact": item.get("name") or "未提供",
                        "detected_at": event.get("first_seen_at") or datetime.now().astimezone().isoformat(),
                        "wa_status": "未聯絡"}
                    if not saved:
                        self._new_house_result(data)
                    else:
                        self._show_house_extra_contact(data)
                    saved.append(data)
            if len(saved) > 1:
                identity = ("730", deal, str(event.get("listing_id") or ""))
                self.extend_auto_clipboard_group(identity, "\n".join(item["phone"][-4:] for item in saved))
        if not test and event.get("job_id") is not None and self._v2_controller:
            self._v2_controller.ack_contacts(int(event["job_id"]))

    def _show_house_extra_contact(self, data):
        """Show each extra owner without overwriting the primary property's row."""
        phone, deal, pid = data["phone"], data["deal"], data["pid"]
        iid = f"house:{deal}:{pid}:{phone}"
        self.house_rows[iid] = dict(data)
        values = ("730%s盤 · 附加" % deal, phone, data["contact"], data["wa_status"],
                  "打開 ↗", self._display_time(data["detected_at"]), phone[-4:], pid)
        if self.tree.exists(iid):
            self.tree.item(iid, values=values)
        else:
            self.tree.insert("", 0, iid=iid, values=values)
        self.row_urls[iid] = data["url"]
        self.house_session += 1
        if self.wa_730_enable.get():
            self.bg(self._house_wa_job, phone, data["url"], iid, data["contact"], self._house_in_wa_window())
        else:
            self.update_row_field(iid, 3, "未啟用")

    def _request_test(self, lane, greeting=False):
        controller = self._v2_controller
        if not controller or not controller.is_alive() or lane not in self._v2_selected:
            messagebox.showinfo("V2 API 測試", "請先啟動對應來源並完成列表擷取。", parent=self)
            return
        self._v2_tests[lane] = bool(greeting)
        controller.test_phone(lane)
        self.write("[V2] 已要求本路最新有效列表的電話 API 測試；不寫入去重庫。")

    def api_test_28(self, trade):
        # Some old button bindings call this via bg(). Route back to Tk first.
        if threading.current_thread() is not threading.main_thread():
            self.after(0, lambda: self._request_test("28hse-" + trade))
        else:
            self._request_test("28hse-" + trade)

    def test_730(self, deal, greeting=False):
        self._request_test("house730-rent" if deal == "租" else "house730-buy", greeting)

    def test_28_wa(self):
        if messagebox.askyesno("28Hse WA 實際發送測試", "將使用本路最新有效列表查電話，並沿用姓名核對後實際測試 WA。是否繼續？", parent=self):
            lane = "28hse-rent" if self.rent.get() else "28hse-buy"
            self._request_test(lane, True)

    def test_730_wa(self, deal="租"):
        if messagebox.askyesno("House730 WA 實際發送測試", "將使用本路最新有效列表查電話，並沿用姓名核對後實際測試 WA。是否繼續？", parent=self):
            self.test_730(deal, greeting=True)

    def show_730_verification(self, deal):
        messagebox.showinfo("House730 驗證", "請在原 BitBrowser 的對應列表分頁人工確認驗證；V2 不會自動點擊驗證。", parent=self)

    def backfill_contact_name(self, trade, url, phone, iid):
        # The V2 contact response is authoritative. Do not start the old CDP
        # HTML name lookup from result() when the API did not include a name.
        self.update_row_field(iid, 2, "未提供")

    def on_close(self):
        if getattr(self, "_v2_closed", False):
            return
        self._v2_closed = True
        self._user_requested_close = True
        self.stop()
        if self.site_manager:
            self.site_manager.halt()
        try:
            self._save_v2_settings()
        except (ValueError, OSError):
            pass
        self._v2_close_deadline = time.monotonic() + 5.0
        self._finish_close()

    def _finish_close(self):
        controller = getattr(self, "_v2_controller", None)
        if controller and controller.is_alive() and time.monotonic() < self._v2_close_deadline:
            self.after(50, self._finish_close)
            return
        if controller and controller.is_alive():
            self.write("[V2] 網路工作仍在結束；未確認的電話工作保留於資料庫，稍後可恢復。")
        self.destroy()


def main():
    app = PandaMonitorV2App()
    app.mainloop()


if __name__ == "__main__":
    main()
