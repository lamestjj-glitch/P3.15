"""Conservative, local-only structural samples for reviewing listing responses."""
from __future__ import annotations

from html import escape
from html.parser import HTMLParser
import json
import os
from pathlib import Path
import re
from typing import Any
from urllib.parse import parse_qs, urlsplit
from zipfile import ZIP_DEFLATED, ZipFile


LANES = ("28hse-rent", "28hse-buy", "house730-rent", "house730-buy")
MAX_ARRAY_ITEMS = 3
MAX_DEPTH = 18
MAX_NODES = 8_000
MAX_FIELDS = 150
MAX_HTML = 250_000
PUBLIC_IDS = {"propertyid", "adid", "listingid", "houseid", "propid"}
PUBLIC_NUMBERS = {
    "page", "pageno", "pageindex", "pagenumber", "pagesize", "pagecount", "total",
    "totalpage", "totalpages", "totalcount", "count", "limit", "offset", "status",
    "statuscode", "code", "hasmore", "nextpage",
}
LISTING_HINTS = {"propertyid", "adid", "listingid", "propertyname", "propertyurl", "price", "rentprice", "saleprice"}


def normalized(value: str) -> str:
    return re.sub(r"[^a-z0-9]", "", value.lower())


def sensitive(key: str) -> bool:
    key = normalized(key)
    return any(part in key for part in (
        "cookie", "token", "auth", "password", "secret", "private", "signature", "session",
        "csrf", "xsrf", "bearer", "apikey", "appkey", "credential", "phone", "mobile",
        "telephone", "telphone", "email", "whatsapp", "wechat", "contact", "owner",
        "agent", "broker", "account", "member", "customer", "username", "userid",
        "realname", "nickname", "displayname",
    )) or key in {"user", "name", "tel", "client"}


def safe_field(key: Any, index: int) -> str:
    if (isinstance(key, str) and 0 < len(key) <= 64
            and re.fullmatch(r"[\w-]+", key, re.UNICODE)
            and not (key.isdecimal() and len(key) > 6)
            and not opaque_field(key)):
        return key
    return f"field_{index}"


def opaque_field(key: str) -> bool:
    """Reject common encoded/dynamic keys while retaining readable schema names."""
    if re.fullmatch(r"[a-f0-9]{16,}", key, re.I):
        return True
    if re.fullmatch(r"[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}", key, re.I):
        return True
    if len(key) >= 16 and re.fullmatch(r"[A-Za-z0-9_-]+", key):
        upper = sum(character.isupper() for character in key)
        lower = sum(character.islower() for character in key)
        digits = sum(character.isdigit() for character in key)
        if upper >= 3 and lower >= 2 and digits >= 3:
            return True
        # Long encoded mixed-case strings commonly split into many one-letter
        # fragments; readable camelCase names have longer word fragments.
        words = re.findall(r"[A-Z]?[a-z]+|[A-Z]+(?=[A-Z]|$)|\d+", key)
        if upper and lower and len(words) >= 6:
            if sum(len(word) <= 2 for word in words) / len(words) >= 0.7:
                return True
    return False


def listing_href(value: str) -> str | None:
    try:
        parsed = urlsplit(value)
        if parsed.username or parsed.password or parsed.scheme not in ("", "http", "https"):
            return None
        if parsed.netloc:
            host = (parsed.hostname or "").lower()
            if not (host in {"28hse.com", "house730.com", "www.28hse.com", "www.house730.com"}):
                return None
        if not re.fullmatch(r"/(?:rent|buy)(?:-property-\d{1,15}|/[a-z0-9_-]+/property-\d{6,10})/?", parsed.path, re.I):
            return None
        # A relative public listing path retains IDs, but no query, host or fragment.
        return parsed.path
    except (ValueError, TypeError):
        return None


class StructuralHTML(HTMLParser):
    """Keep selector structure; omit active content, arbitrary values and all text."""
    TAGS = set("a article b blockquote br button caption dd div dl dt em fieldset figcaption figure footer form h1 h2 h3 h4 h5 h6 header hr i img input label legend li main nav ol option p section select small span strong table tbody td textarea th thead tr u ul".split())
    BLOCKED = {"script", "style", "iframe", "object", "embed", "noscript", "template", "svg", "math"}
    VOID = {"br", "hr", "img", "input", "embed"}
    IDS = {"property-list", "propertyList", "list", "results", "result-list", "search-results", "main", "content", "listing-list"}
    CLASSES = {
        "property-list", "propertyList", "listing-card", "property-card", "property-item",
        "listing-item", "list-item", "result-item", "result-list", "results", "title",
        "price", "area", "address", "description", "content", "details", "detail", "photo",
        "image", "thumbnail", "row", "col", "container", "rent", "buy", "sale", "status",
        "location", "size", "unit", "room", "rooms", "bedroom", "floor", "date", "time",
        "tags", "tag", "hidden", "active",
    }

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.parts: list[str] = []
        self.blocked: list[str] = []
        self.class_aliases: dict[str, str] = {}

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if self.blocked:
            if tag in self.BLOCKED and tag not in self.VOID:
                self.blocked.append(tag)
            return
        if tag in self.BLOCKED:
            if tag not in self.VOID:
                self.blocked.append(tag)
            return
        if tag not in self.TAGS:
            return
        kept = []
        for key, value in attrs:
            if not value:
                continue
            if key == "class":
                tokens = []
                for part in value.split()[:15]:
                    if part in self.CLASSES:
                        tokens.append(part)
                    else:
                        if part not in self.class_aliases:
                            self.class_aliases[part] = f"sample-class-{len(self.class_aliases) + 1}"
                        tokens.append(self.class_aliases[part])
                if tokens:
                    kept.append((key, " ".join(tokens)))
            elif key == "id" and (value in self.IDS or re.fullmatch(r"(?:property|listing)-\d{1,15}", value)):
                kept.append((key, value))
            elif key == "href" and tag == "a":
                href = listing_href(value)
                if href:
                    kept.append((key, href))
        attributes = "".join(f' {key}="{escape(value, quote=True)}"' for key, value in kept)
        self.parts.append(f"<{tag}{attributes}>")

    def handle_startendtag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        self.handle_starttag(tag, attrs)
        if tag not in self.VOID:
            self.handle_endtag(tag)

    def handle_endtag(self, tag: str) -> None:
        if self.blocked:
            if tag == self.blocked[-1]:
                self.blocked.pop()
            return
        if tag in self.TAGS and tag not in self.VOID:
            self.parts.append(f"</{tag}>")

    def handle_data(self, data: str) -> None:
        if not self.blocked:
            self.parts.append("[text]" if data.strip() else " ")


class Anonymizer:
    def __init__(self) -> None:
        self.nodes = 0
        self.array_lengths: dict[str, int] = {}

    def clean(self, value: Any, *, path: str = "", key: str = "", private: bool = False,
              listing: bool = False, depth: int = 0) -> Any:
        self.nodes += 1
        if depth > MAX_DEPTH or self.nodes > MAX_NODES:
            return "[structure limit]"
        private = private or sensitive(key)
        if isinstance(value, dict):
            hints = {normalized(str(part)) for part in value}
            listing = bool(hints & LISTING_HINTS) and not private
            result = {}
            for index, (original_key, part) in enumerate(value.items()):
                if index >= MAX_FIELDS or self.nodes >= MAX_NODES:
                    result["__sample_truncated__"] = True
                    break
                field = safe_field(original_key, index)
                while field in result:
                    field += "_"
                pointer = path + "/" + field.replace("~", "~0").replace("/", "~1")
                result[field] = self.clean(part, path=pointer, key=str(original_key),
                                           private=private, listing=listing, depth=depth + 1)
            return result
        if isinstance(value, list):
            self.array_lengths[path or "/"] = len(value)
            return [self.clean(part, path=f"{path}/{index}", key=key, private=private,
                               listing=listing, depth=depth + 1)
                    for index, part in enumerate(value[:MAX_ARRAY_ITEMS])]
        if value is None:
            return None
        if isinstance(value, bool):
            return False if private else value
        name = normalized(key)
        public_id = (name in PUBLIC_IDS or (name == "id" and listing)) and not private
        if isinstance(value, (int, float)):
            if public_id and isinstance(value, int) and 0 <= value < 10 ** 20:
                return value
            if not private and name in PUBLIC_NUMBERS and abs(value) < 10 ** 10:
                return value
            return 0.0 if isinstance(value, float) else 0
        if isinstance(value, str):
            if private:
                return "[redacted]"
            if public_id and re.fullmatch(r"\d{1,20}", value):
                return value
            href = listing_href(value)
            if href:
                return href
            if len(value) <= MAX_HTML and re.search(r"</?[A-Za-z][^>]*>", value):
                parser = StructuralHTML()
                parser.feed(value)
                parser.close()
                return "".join(parser.parts)
            if len(value) <= MAX_HTML and value.lstrip().startswith(("{", "[")):
                try:
                    nested = json.loads(value)
                except (ValueError, RecursionError):
                    pass
                else:
                    return json.dumps(self.clean(nested, path=path + "/$json", private=private,
                                                 depth=depth + 1), ensure_ascii=False)
            return "[string]"
        return "[value]"


def request_schema(observation: Any, anonymizer: Anonymizer) -> dict[str, Any]:
    method = observation.method if observation.method in {"GET", "POST"} else "[method]"
    result: dict[str, Any] = {"method": method}
    try:
        query = parse_qs(urlsplit(observation.url).query, keep_blank_values=True, max_num_fields=200)
    except (ValueError, TypeError):
        query = {}
    result["query_schema"] = anonymizer.clean(query, path="/request/query_schema")
    body = observation.body
    if body is not None:
        try:
            parsed = json.loads(body)
        except (ValueError, TypeError, RecursionError):
            if isinstance(body, str) and "=" in body:
                try:
                    parsed = parse_qs(body, keep_blank_values=True, max_num_fields=200)
                except ValueError:
                    parsed = "[unparsed body]"
            else:
                parsed = "[unparsed body]"
        result["body_schema"] = anonymizer.clean(parsed, path="/request/body_schema")
    return result


def export_samples(observations: dict[str, Any], output: str | Path) -> None:
    """Create a review ZIP exclusively; credentials and original response text stay local."""
    if set(observations) != set(LANES) or any(getattr(observations[lane], "sample", None) is None for lane in LANES):
        raise ValueError("Four parsed listing samples are required")
    documents = {}
    for lane in LANES:
        anonymizer = Anonymizer()
        observation = observations[lane]
        response = anonymizer.clean(observation.sample, path="/response")
        request = request_schema(observation, anonymizer)
        documents[lane + ".json"] = json.dumps({
            "lane": lane, "anonymized": True, "response": response,
            "request": request, "array_lengths": anonymizer.array_lengths,
        }, ensure_ascii=False, indent=2, allow_nan=False) + "\n"
    readme = (
        "這是四路列表的匿名結構樣本，每個陣列最多保留三筆。\n"
        "原始 URL、Cookie、標頭與 UA 不會匯出。未知葉值匿名；HTML 保留骨架及部分公開樓盤連結。\n"
        "可讀欄位名及部分公開房源 ID、分頁、狀態數值保留，未知 CSS class 改為穩定占位。\n"
        "不是完整資料，也不是可執行的請求配置；自動處理不能辨識所有可能的動態欄位名。\n"
        "請先解壓檢查內容，確認沒有你不想分享的資訊，再把這個 ZIP 直接上傳聊天。\n"
    )
    target = Path(output)
    created = False
    identity = None
    try:
        with target.open("xb") as stream:
            created = True
            info = os.fstat(stream.fileno())
            identity = (info.st_dev, info.st_ino)
            with ZipFile(stream, "w", ZIP_DEFLATED) as archive:
                for filename, document in documents.items():
                    archive.writestr(filename, document)
                archive.writestr("README_UPLOAD.txt", readme)
    except BaseException:
        if created:
            try:
                info = target.stat()
                if identity == (info.st_dev, info.st_ino):
                    target.unlink()
            except OSError:
                pass
        raise
