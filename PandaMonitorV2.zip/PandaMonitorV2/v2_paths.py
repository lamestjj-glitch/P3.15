"""Separate V2 data, with a conservative first-run history import."""
from __future__ import annotations

import os
from contextlib import closing
from pathlib import Path
import shutil
import sqlite3
import tempfile


def data_root() -> Path:
    override = os.environ.get("PANDAMONITOR_V2_DATA_DIR")
    if override:
        return Path(override).expanduser().resolve()
    return (Path(os.environ.get("LOCALAPPDATA") or Path.home()) / "PandaMonitorV2").resolve()


def _import_one(source: Path, target: Path, *, database: bool) -> str:
    if target.exists():
        return "existing"
    if not source.is_file() or source.resolve() == target.resolve():
        return "missing"
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary: Path | None = None
    try:
        with tempfile.NamedTemporaryFile(prefix=".history-", suffix=".tmp", dir=target.parent,
                                         delete=False) as stream:
            temporary = Path(stream.name)
        if database:
            # The read-only connection and SQLite backup preserve a live WAL
            # snapshot without changing, checkpointing, or copying credentials.
            uri = source.resolve().as_uri() + "?mode=ro"
            with closing(sqlite3.connect(uri, uri=True, timeout=3)) as old:
                with closing(sqlite3.connect(temporary)) as new:
                    old.backup(new, pages=64, sleep=.05)
        else:
            if source.stat().st_size > 8_000_000:
                return "error"
            shutil.copyfile(source, temporary)
        # Publish only if no V2 file exists. Both Windows NTFS and normal
        # local Unix filesystems support this atomic no-clobber operation.
        try:
            os.link(temporary, target)
        except FileExistsError:
            return "existing"
        return "imported"
    except (OSError, sqlite3.Error):
        return "error"
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


def bootstrap_legacy_data(*, root: Path | None = None, legacy_home: Path | None = None,
                          legacy_local: Path | None = None) -> dict[str, str]:
    """Import only known phone/history files; never old settings or tokens.

    Explicit source arguments are useful for offline tests and migrations.
    Existing V2 files and all legacy files remain untouched.
    """
    target = Path(root) if root is not None else data_root()
    home = Path(legacy_home) if legacy_home is not None else Path.home()
    local = Path(legacy_local) if legacy_local is not None else Path(os.environ.get("LOCALAPPDATA") or home)
    jobs = (
        ("28hse-phones", home / "PandaMonitor_28Hse/seen_phones.json",
         target / "28hse/seen_phones.json", False),
        ("28hse-history", home / "PandaMonitor_28Hse/28hse_history.sqlite3",
         target / "28hse/28hse_history.sqlite3", True),
        ("house730-history", local / "House730Standalone173/house730.db",
         target / "house730/house730.db", True),
    )
    target.mkdir(parents=True, exist_ok=True)
    return {name: _import_one(source, destination, database=database)
            for name, source, destination, database in jobs}
