"""First-page baselines and persistent public listing-ID discovery state."""
from __future__ import annotations

import asyncio
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
import hashlib
import importlib
import json
import logging
import math
import os
from pathlib import Path
import re
import sqlite3
import tempfile
import time
from typing import Any
from urllib.parse import parse_qs, urlsplit, urlunsplit

from listing_types import ListingPage, ListingParseError

LOG = logging.getLogger("crawler.monitor")
ROOT = Path(__file__).resolve().parent
LOCAL_TZ = timezone(timedelta(hours=7), "Asia/Phnom_Penh")
KNOWN_LANES = {"28hse-rent", "28hse-buy", "house730-rent", "house730-buy"}
WRAPPERS = {"formdata", "requestdata", "searchparams", "searchinputs", "filters", "body", "params"}


class MonitorConfigurationError(ValueError):
    """A fixed, non-secret explanation of a monitor preflight failure."""


def _name(value: str) -> str:
    return re.sub(r"[^a-z0-9]", "", value.lower())


def _temporary(key: str) -> bool:
    name = _name(key)
    return (name in {"nonce", "timestamp", "ts", "cachebuster", "cachebust", "_"}
            or not name
            or any(part in name for part in (
                "cookie", "authorization", "token", "signature", "appkey", "apikey",
                "session", "csrf", "xsrf", "password", "credential", "secret",
            )))


def _decode(value: Any, *, wrapper: bool = False, depth: int = 0) -> Any:
    if depth > 14:
        raise MonitorConfigurationError("搜尋參數層級過深，請重新擷取列表第一頁。")
    if isinstance(value, dict):
        if len(value) > 1000 or not all(isinstance(key, str) for key in value):
            raise MonitorConfigurationError("搜尋參數結構無效，請重新擷取列表第一頁。")
        return {key: _decode(part, wrapper=_name(key) in WRAPPERS, depth=depth + 1)
                for key, part in value.items()}
    if isinstance(value, list):
        if len(value) > 1000:
            raise MonitorConfigurationError("搜尋參數過多，請重新擷取列表第一頁。")
        return [_decode(part, wrapper=wrapper, depth=depth + 1) for part in value]
    if isinstance(value, str) and wrapper:
        if len(value) > 1_000_000:
            raise MonitorConfigurationError("搜尋參數過大，請重新擷取列表第一頁。")
        text = value.strip()
        if text.startswith(("{", "[")):
            try:
                parsed = json.loads(text)
            except (ValueError, RecursionError):
                raise MonitorConfigurationError("搜尋本文無法解析，請重新擷取列表第一頁。") from None
            return _decode(parsed, depth=depth + 1)
        if "=" in text:
            try:
                parsed = parse_qs(text, keep_blank_values=True, max_num_fields=1000)
            except ValueError:
                raise MonitorConfigurationError("搜尋本文無法解析，請重新擷取列表第一頁。") from None
            return _decode(parsed, depth=depth + 1)
        if text:
            raise MonitorConfigurationError("搜尋本文無法解析，請重新擷取列表第一頁。")
    if isinstance(value, float) and not math.isfinite(value):
        raise MonitorConfigurationError("搜尋參數無效，請重新擷取列表第一頁。")
    if value is not None and not isinstance(value, (str, int, float, bool)):
        raise MonitorConfigurationError("搜尋參數型別無效，請重新擷取列表第一頁。")
    return value


def _request_parts(config: Any) -> dict[str, Any]:
    try:
        query = parse_qs(urlsplit(config.url).query, keep_blank_values=True, max_num_fields=1000)
        raw = getattr(config, "raw_body", None)
        if raw is not None:
            body = _decode(raw, wrapper=True)
        elif getattr(config, "form", None) is not None:
            body = _decode(config.form)
        else:
            body = _decode(getattr(config, "json_body", None))
        return {"query": _decode(query), "params": _decode(getattr(config, "params", {})), "body": body}
    except MonitorConfigurationError:
        raise
    except (ValueError, TypeError, AttributeError, RecursionError):
        raise MonitorConfigurationError("搜尋參數無法核對，請重新擷取列表第一頁。") from None


def _pages(parts: Any, expected: str) -> list[int | None]:
    values: list[int | None] = []

    def scalar(value: Any) -> None:
        if isinstance(value, list):
            for item in value:
                scalar(item)
        elif isinstance(value, int) and not isinstance(value, bool):
            values.append(value)
        elif isinstance(value, str) and re.fullmatch(r"[0-9]{1,9}", value.strip()):
            values.append(int(value.strip()))
        else:
            values.append(None)

    def visit(value: Any) -> None:
        if isinstance(value, dict):
            for key, part in value.items():
                if _name(key) == expected:
                    scalar(part)
                else:
                    visit(part)
        elif isinstance(value, list):
            for part in value:
                visit(part)

    visit(parts)
    return values


def _stable(value: Any) -> Any:
    if isinstance(value, dict):
        return {key: _stable(part) for key, part in value.items() if not _temporary(key)}
    if isinstance(value, list):
        return [_stable(part) for part in value]
    return value


def scope_fingerprint(config: Any, *, lane: str = "", site: str = "") -> str:
    """Only this digest is persisted; headers and browser credentials are excluded."""
    try:
        target = urlsplit(config.url)
        origin = f"{target.scheme.lower()}://{(target.hostname or '').lower()}"
        if target.port is not None and target.port != (443 if target.scheme == "https" else 80):
            origin += f":{target.port}"
        document = {"version": 1, "lane": lane, "site": site, "method": config.method.upper(),
                    "origin": origin, "path": target.path, "search": _stable(_request_parts(config))}
        serialized = json.dumps(document, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)
    except MonitorConfigurationError:
        raise
    except (ValueError, TypeError, AttributeError):
        raise MonitorConfigurationError("搜尋範圍無法核對，請重新擷取列表第一頁。") from None
    return hashlib.sha256(serialized.encode("utf-8")).hexdigest()


def parse_page(lane: str, payload: Any) -> ListingPage:
    module = "hse28_parser" if lane.startswith("28hse-") else "house730_parser"
    return importlib.import_module(module).parse_listings(lane, payload)


def _public_url(lane: str, value: str | None, listing_id: str) -> str | None:
    if not isinstance(value, str) or len(value) > 3000:
        return None
    try:
        parsed = urlsplit(value)
        domain = "28hse.com" if lane.startswith("28hse-") else "house730.com"
        host = (parsed.hostname or "").lower()
        if (parsed.scheme != "https" or parsed.username or parsed.password
                or parsed.port not in (None, 443)
                or host not in {domain, "www." + domain}):
            return None
        trade = "rent" if lane.endswith("-rent") else "buy"
        if lane.startswith("28hse-"):
            pattern = rf"/{trade}/(?:[^/?#]+/)*property-{re.escape(listing_id)}/?"
        else:
            pattern = rf"/{trade}-property-{re.escape(listing_id)}(?:\.html?)?(?:/[^?#]*)?/?"
        if not re.fullmatch(pattern, parsed.path):
            return None
        return urlunsplit(("https", host, parsed.path, "", ""))
    except (ValueError, TypeError):
        return None


@dataclass
class _LaneState:
    scope: str
    initialized: bool
    seen: set[str]
    lock: asyncio.Lock = field(default_factory=asyncio.Lock)
    watermark: int = 0
    accepted: int = 0
    discoveries: int = 0
    stale: int = 0
    errors: int = 0
    last_summary: float = field(default_factory=time.monotonic)


class ListingMonitor:
    def __init__(self, prepared: Any, *, state_path: str | Path | None = None,
                 output_path: str | Path | None = None, summary_interval: float = 60.0) -> None:
        if not isinstance(summary_interval, (int, float)) or not math.isfinite(summary_interval) or summary_interval <= 0:
            raise MonitorConfigurationError("監控統計間隔必須是有限正數。")
        self.summary_interval = float(summary_interval)
        definitions = {}
        for lane in prepared.lanes:
            if lane.name not in KNOWN_LANES or lane.name in definitions:
                raise MonitorConfigurationError("監控路線配置無效。")
            try:
                parts = _request_parts(lane.config)
                expected = "page" if lane.name.startswith("28hse-") else "pageindex"
                pages = _pages(parts, expected)
                if (pages and any(page != 1 for page in pages)) or (expected == "pageindex" and not pages):
                    raise MonitorConfigurationError("first page required")
                definitions[lane.name] = scope_fingerprint(lane.config, lane=lane.name, site=lane.site)
            except MonitorConfigurationError:
                raise MonitorConfigurationError(f"{lane.name}：無法確認列表第一頁，請回到第一頁重新搜尋擷取。") from None
        if not definitions:
            raise MonitorConfigurationError("缺少監控路線配置。")
        self.state_path = Path(state_path) if state_path is not None else ROOT / "monitor_data" / "seen.sqlite3"
        self.output_path = Path(output_path) if output_path is not None else self.state_path.parent / "new_listings.jsonl"
        if self.state_path.absolute() == self.output_path.absolute():
            raise MonitorConfigurationError("監控狀態與輸出必須使用不同檔案。")
        self.state_path.parent.mkdir(parents=True, exist_ok=True)
        self._db = sqlite3.connect(self.state_path)
        try:
            with self._db:
                self._db.execute("CREATE TABLE IF NOT EXISTS monitor_scopes (lane TEXT NOT NULL, scope TEXT NOT NULL, initialized INTEGER NOT NULL, PRIMARY KEY(lane, scope))")
                self._db.execute("CREATE TABLE IF NOT EXISTS monitor_seen (lane TEXT NOT NULL, scope TEXT NOT NULL, listing_id TEXT NOT NULL, url TEXT, first_seen_at TEXT NOT NULL, PRIMARY KEY(lane, scope, listing_id))")
                self._db.execute("CREATE TABLE IF NOT EXISTS monitor_events (event_id INTEGER PRIMARY KEY AUTOINCREMENT, lane TEXT NOT NULL, scope TEXT NOT NULL, listing_id TEXT NOT NULL, url TEXT, first_seen_at TEXT NOT NULL, UNIQUE(lane, scope, listing_id))")
            self._states: dict[str, _LaneState] = {}
            for lane, scope in definitions.items():
                row = self._db.execute("SELECT initialized FROM monitor_scopes WHERE lane=? AND scope=?", (lane, scope)).fetchone()
                seen = {row[0] for row in self._db.execute("SELECT listing_id FROM monitor_seen WHERE lane=? AND scope=?", (lane, scope))}
                self._states[lane] = _LaneState(scope, bool(row and row[0]), seen)
                if row and row[0]:
                    LOG.info("%s：已載入 %d 個已見 ID，持續比對首次發現。", lane, len(seen))
        except BaseException:
            self._db.close()
            raise
        self._closed = False
        self._output_dirty = True

    async def __call__(self, lane_name: str, payload: Any, request_id: int) -> None:
        if self._closed or lane_name not in self._states:
            raise MonitorConfigurationError("監控狀態未開啟或路線無效。")
        if isinstance(request_id, bool) or not isinstance(request_id, int) or request_id < 1:
            raise MonitorConfigurationError("監控請求編號無效。")
        state = self._states[lane_name]
        async with state.lock:
            if request_id <= state.watermark:
                state.stale += 1
                return
            try:
                page = parse_page(lane_name, payload)
                if page.page is not None and page.page != 1:
                    raise ListingParseError("只接受第一頁回應。")
                if lane_name.startswith("28hse-") and page.page != 1:
                    raise ListingParseError("28Hse 回應缺少第一頁確認。")
                records = {}
                for record in page.listings:
                    identifier = record.listing_id
                    if (not isinstance(identifier, str) or not re.fullmatch(r"[0-9]{1,20}", identifier)
                            or int(identifier) <= 0):
                        raise ListingParseError("房源 ID 無效。")
                    records.setdefault(identifier, _public_url(lane_name, record.url, identifier))
            except ListingParseError:
                state.errors += 1
                if state.errors == 1:
                    LOG.warning("%s：列表解析未通過，未建立或更動基線；請核對回應結構。", lane_name)
                raise
            timestamp = datetime.now(LOCAL_TZ).isoformat(timespec="seconds")
            discovered = []
            with self._db:
                # Another process may have initialized this scope since our
                # constructor ran. Serialize that check with the ID updates.
                self._db.execute("BEGIN IMMEDIATE")
                current = self._db.execute(
                    "SELECT initialized FROM monitor_scopes WHERE lane=? AND scope=?",
                    (lane_name, state.scope),
                ).fetchone()
                baseline = not bool(current and current[0])
                self._db.execute("INSERT OR IGNORE INTO monitor_scopes VALUES (?, ?, 0)", (lane_name, state.scope))
                for identifier, url in records.items():
                    inserted = self._db.execute("INSERT OR IGNORE INTO monitor_seen VALUES (?, ?, ?, ?, ?)",
                                                (lane_name, state.scope, identifier, url, timestamp)).rowcount
                    if inserted and not baseline:
                        self._db.execute("INSERT OR IGNORE INTO monitor_events (lane, scope, listing_id, url, first_seen_at) VALUES (?, ?, ?, ?, ?)",
                                         (lane_name, state.scope, identifier, url, timestamp))
                        discovered.append((identifier, url))
                self._db.execute("UPDATE monitor_scopes SET initialized=1 WHERE lane=? AND scope=?", (lane_name, state.scope))
            state.initialized = True
            state.seen.update(records)
            state.watermark = request_id
            state.accepted += 1
            state.discoveries += len(discovered)
            if baseline:
                LOG.info("%s：首次基線已建立，本頁 %d 個 ID；不逐個列出既有樓盤。", lane_name, len(records))
            for identifier, url in discovered:
                LOG.info("%s：首次發現 ID=%s%s", lane_name, identifier, f" {url}" if url else "")
            if discovered:
                self._output_dirty = True
            if self._output_dirty:
                self._write_output()
            now = time.monotonic()
            if now - state.last_summary >= self.summary_interval:
                seen_count = self._db.execute(
                    "SELECT COUNT(*) FROM monitor_seen WHERE lane=? AND scope=?",
                    (lane_name, state.scope),
                ).fetchone()[0]
                LOG.info("%s：有效回應=%d，本頁=%d，累計已見=%d，本次首次發現=%d，忽略舊回應=%d。",
                         lane_name, state.accepted, len(records), seen_count, state.discoveries, state.stale)
                state.last_summary = now

    def _write_output(self) -> None:
        self.output_path.parent.mkdir(parents=True, exist_ok=True)
        temporary = None
        try:
            # Keep a second exporter from replacing a newer snapshot with an
            # older one while sharing this state database.
            with self._db:
                self._db.execute("BEGIN IMMEDIATE")
                with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=self.output_path.parent,
                                                 prefix=".new-listings-", suffix=".tmp", delete=False) as stream:
                    temporary = Path(stream.name)
                    for lane, scope, identifier, url, timestamp in self._db.execute(
                        "SELECT lane, scope, listing_id, url, first_seen_at FROM monitor_events ORDER BY event_id"
                    ):
                        stream.write(json.dumps({"lane": lane, "scope": scope, "listing_id": identifier,
                                                 "url": url, "first_seen_at": timestamp}, ensure_ascii=False) + "\n")
                    stream.flush()
                    os.fsync(stream.fileno())
                os.replace(temporary, self.output_path)
            self._output_dirty = False
        finally:
            if temporary is not None:
                try:
                    temporary.unlink(missing_ok=True)
                except OSError:
                    pass

    def close(self) -> None:
        if not self._closed:
            self._db.close()
            self._closed = True
