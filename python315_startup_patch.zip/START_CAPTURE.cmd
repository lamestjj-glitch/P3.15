@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
if errorlevel 1 goto folder_error
if not exist "start_capture.py" goto folder_error
if not exist "capture_four_lanes.py" goto folder_error
set "PYTHONUTF8=1"
set "PYTHONUNBUFFERED=1"
if defined CRAWLER_PYTHON (
  "%CRAWLER_PYTHON%" -I -c "import sys; raise SystemExit(not sys.version_info.__ge__((3,12)))" >nul 2>&1
  if errorlevel 1 goto configured_python_error
  "%CRAWLER_PYTHON%" "%~dp0start_capture.py" %*
  goto finished
)
for /f "delims=" %%P in ('where python.exe 2^>nul') do (
  "%%P" -I -c "import sys; raise SystemExit(not sys.version_info.__ge__((3,12)))" >nul 2>&1
  if not errorlevel 1 (
    "%%P" "%~dp0start_capture.py" %*
    goto finished
  )
)
where py >nul 2>&1
if not errorlevel 1 (
  for %%V in (3.15 3.14 3.13 3.12 3) do (
    py -%%V -I -c "import sys; raise SystemExit(not sys.version_info.__ge__((3,12)))" >nul 2>&1
    if not errorlevel 1 (
      py -%%V "%~dp0start_capture.py" %*
      goto finished
    )
  )
)
echo [ERROR] No working Python 3.12+ was found.
echo Run "where python" and "py -0p" to find your installed Python.
echo Or set CRAWLER_PYTHON to its full python.exe path before starting.
set "CRAWLER_EXIT_CODE=1"
goto hold
:configured_python_error
echo [ERROR] CRAWLER_PYTHON does not point to a working Python 3.12+.
echo Set it to the full path of an installed python.exe, without extra quotes or arguments.
set "CRAWLER_EXIT_CODE=1"
goto hold
:folder_error
echo [ERROR] Extract the complete ZIP to a normal writable folder first.
set "CRAWLER_EXIT_CODE=1"
goto hold
:finished
set "CRAWLER_EXIT_CODE=%ERRORLEVEL%"
echo.
echo [EXIT] Code %CRAWLER_EXIT_CODE%. Review the messages above.
:hold
echo.
pause
exit /b %CRAWLER_EXIT_CODE%
