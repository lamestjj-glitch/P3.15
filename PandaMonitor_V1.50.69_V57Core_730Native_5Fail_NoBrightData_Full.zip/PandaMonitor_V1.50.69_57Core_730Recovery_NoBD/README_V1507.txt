PandaMonitor V1.50.7 — BusinessForSale.sg Premium Seller Contact 修復
=================================================================
完整原程式包，包含 28Hse、House730、852.house、BusinessForSale.sg。

解決：
1. 新增聯絡面板識別：Seller Contact And Listing Statistics、Contact Number。
2. 原有 Seller Contact & Listing Information、Mobile Number 仍支援。
3. 檢測 Premium Only：未取得已授權電話時，明確顯示是會員鎖定回應，不再一律說頁面未渲染。
4. 從成功讀取的 source=2 業主列表取出樓盤 ID；詳情頁沒顯示 Direct Seller 時，只有列表認證過的 ID 才被接受。
5. Direct seller phone and email 的升級宣傳文案不再被誤當業主身份標籤。
6. 「測試首帖取號」顯示取得詳情來源（已開頁面／已登入 HTTP／背景渲染）。
7. 新增「測試已開帖取號」，只檢查當前 BitBrowser 中已開的相關網站詳情分頁，不導航／不發 WA／不修改去重。

安裝：
  (1) 退出 PandaMonitor，解壓整個 ZIP 至新資料夾。
  (2) 雙擊 UPGRADE_BFS.cmd，將新插件安裝到 C 盤用戶配置（保留舊插件備份）。
  (3) 執行 START.bat；BitBrowser 173 請先開啟，並保持正常登入。

建議測試：
  A. 在 BitBrowser 173 手動打開會員帳號已可看到電話的詳情頁（例如以前測過的 42769）。
  B. 在「網站管理」按「測試已開帖取號」，核對抓到的 URL 及電話。
  C. 再按「測試首帖取號」，確認來源、URL 及具體未取號原因。
  D. 28398 公開頁面顯示 Premium Only：此帳號必須有該帖的可見聯絡資料才可提取；程式不會繞過會員授權或猜測號碼。

限制：
  離線解析與相關回歸測試通過，但沒有接入用戶的 BitBrowser 173 帳號進行實站驗證。
  若登入網頁仍返回 Premium Only，請先在該帖實際確認聯絡資料是否可見。
