# -*- coding: utf-8 -*-
"""Single entrypoint for environment validation, dependencies and the original GUI.

Run with: python bootstrap.py  (normal launcher is START.bat)
Run with: python bootstrap.py --check-only  (environment checks only)
"""
from __future__ import annotations

import importlib
import os
from pathlib import Path
import subprocess
import sys
import traceback
from datetime import datetime

ROOT = Path(__file__).resolve().parent
LOGS = Path(os.environ.get("LOCALAPPDATA") or os.environ.get("TEMP") or str(ROOT)) / "PandaMonitor_28Hse_House730" / "logs"
try:
    LOGS.mkdir(parents=True, exist_ok=True)
except OSError:
    LOGS = ROOT
LOGFILE = LOGS / "start_console.log"


def say(message: str):
    print(message, flush=True)
    try:
        with LOGFILE.open("a", encoding="utf-8") as stream:
            stream.write(message + "\n")
    except OSError:
        pass


def run_logged(argv):
    say("[RUN] " + " ".join(map(str, argv[:4])) + (" ..." if len(argv) > 4 else ""))
    try:
        proc = subprocess.Popen(argv, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                text=True, encoding="utf-8", errors="replace", bufsize=1)
        assert proc.stdout is not None
        for line in proc.stdout:
            say(line.rstrip("\r\n"))
        return proc.wait()
    except Exception as exc:
        say("[EXCEPTION] " + repr(exc))
        say(traceback.format_exc())
        return 99


def check_imports():
    try:
        import tkinter  # noqa: F401
    except Exception as exc:
        say("[ERROR] tkinter is unavailable: " + repr(exc))
        say("Install standard Python 3.13 for Windows with Tcl/Tk included.")
        return False
    missing = []
    for mod in ("websocket", "playwright", "bs4"):
        try:
            importlib.import_module(mod)
        except Exception as exc:
            missing.append((mod, repr(exc)))
    if missing:
        say("[SETUP] Missing package(s): " + ", ".join(m for m, _ in missing))
        if "--check-only" in sys.argv:
            for m, detail in missing:
                say(f"[MISSING] {m}: {detail}")
            return False
        code = run_logged([sys.executable, "-m", "pip", "install", "--disable-pip-version-check", "-r", str(ROOT / "requirements.txt")])
        if code:
            say(f"[ERROR] Dependency install failed with code {code}")
            return False
        for mod in ("websocket", "playwright", "bs4"):
            try:
                importlib.import_module(mod)
            except Exception as exc:
                say(f"[ERROR] Could not import {mod} after pip: {exc!r}")
                return False
    return True


def main():
    say("[BOOT] " + datetime.now().isoformat(timespec="seconds"))
    say("[PYTHON] " + sys.executable + " / " + sys.version.split()[0])
    say("[PROGRAM] " + str(ROOT))
    if sys.version_info < (3, 12):
        say("[ERROR] Python 3.12+ required")
        return 10
    for item in ("launch.py", "unified_gui.py", "panda28_core.py", "house730_engine.py"):
        if not (ROOT / item).is_file():
            say(f"[ERROR] Missing {item}. Extract the whole ZIP first.")
            return 11
    if not check_imports():
        return 12
    if "--check-only" in sys.argv:
        say("[CHECK_OK] Python and packages are available.")
        return 0
    code = run_logged([sys.executable, "-u", str(ROOT / "launch.py")] + (["--self-test"] if "--self-test" in sys.argv else []))
    if code:
        say(f"[ERROR] Main UI exited with code {code}")
    return code


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except BaseException as exc:
        if isinstance(exc, SystemExit):
            raise
        say("[FATAL] " + traceback.format_exc())
        raise SystemExit(99)
