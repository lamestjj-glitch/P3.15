PandaMonitor V1.50.13 — House730 新帖 ID → Direct Phone API（實驗啟用）
基於 V1.50.12 完整版，其他功能保留。

2026-10-14 參數診斷證實：Property/GetPropertyUserInfoById 的 GET propertyId 參數
與公開樓盤 ID 一致；揭號前 telphone 已有完整 8 位香港電話。

730 新帖處理順序：
1. 從原有業主+最新列表 JSON 偵測新帖子 ID。
2. 優先在「已開的 730 列表頁」使用當前瀏覽器會話 fetch API。
   不需要建立詳情 Target、開新帖、點藍色遮罩。
3. 如果 API 缺少必要會話欄位或沒有號碼，保留背景詳情 PhoneFirst 備援。
   在真實詳情頁捕捉到的 API 查詢模板只保存在 RAM，供後續帖子使用。
4. 若 API 返回 401/403/429，停止該次取號並遵守驗證/退避機制。
5. 嚴格拒絕返回資料 PropertyId 明確與目標 ID 不符的情形。
6. 每路列表同一時間最多一條 API 查詢；保留去重、租/售、WA 和剪貼板規則。
   自動複製尾四位；手動複製完整電話。

日誌：
[730-DIRECT] ... 直接 API 成功 ... 0詳情分頁／0揭號點擊
[730-DIRECT-FALLBACK] ... 回退原背景詳情備援
[730-PERF] ... 取號處理 ... ms

注意：離線測試不等於 BitBrowser 173 實站驗證。雖已確認 API 的 propertyId 映射，
網站額外的 language/platform/cityen 及兩個匿名安全欄位的實際規則尚未確認；
首次直接查詢可能失敗，成功率和速度需要用真實日誌評估。
28Hse 延用 V1.50.12 原有的 HTTP doaction 優先、CDP 回退，不假稱純 ID 取號。
