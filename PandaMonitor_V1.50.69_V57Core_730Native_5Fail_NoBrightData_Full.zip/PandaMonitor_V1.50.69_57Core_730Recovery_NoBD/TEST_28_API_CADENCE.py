# -*- coding: utf-8 -*-
"""Offline-only poll cadence regression; no network or user profile access."""
from panda28_core import App

def main():
    class Dummy:
        api_poll_interval = App.api_poll_interval
    obj=Dummy()
    assert obj.api_poll_interval('rent')==1.0
    assert obj.api_poll_interval('buy')==1.0
    obj.api_poll_seconds={'rent':0.5,'buy':1.0}
    assert obj.api_poll_interval('rent')==0.5
    assert obj.api_poll_interval('buy')==1.0
    obj.api_poll_seconds['buy']=0.5
    assert obj.api_poll_interval('buy')==0.5
    obj.api_poll_seconds['rent']=0.7
    assert obj.api_poll_interval('rent')==0.7  # arbitrary decimal seconds are supported
    obj.api_poll_seconds['buy']=7.25
    assert obj.api_poll_interval('buy')==7.25
    obj.api_poll_seconds['buy']=3601
    assert obj.api_poll_interval('buy')==3601.0 # no fixed maximum
    obj.api_poll_seconds['buy']=0.1
    assert obj.api_poll_interval('buy')==0.1 # no fixed 500ms minimum
    obj.api_poll_seconds['rent']='garbled'
    assert obj.api_poll_interval('rent')==1.0
    print('PASS: independent custom seconds, live updates, safe defaults')

if __name__=='__main__':main()
