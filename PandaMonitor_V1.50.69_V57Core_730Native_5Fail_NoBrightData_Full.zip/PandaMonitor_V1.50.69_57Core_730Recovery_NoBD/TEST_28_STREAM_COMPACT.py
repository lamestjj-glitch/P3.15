# -*- coding: utf-8 -*-
"""Test fast compact parsing and early detection safety, without browser or network."""
from panda28_api import api_snapshot, ApiError
from panda28_core import App, CDP
import inspect

TPL={'url':'https://www.28hse.com/property/dosearch', 'body':'landlordAgency=LANDLORD&sortBy=latest'}
URL='https://www.28hse.com/rent/apartment/property-4051679'
class FakeCDP:
    def __init__(self, value): self.value=value;self.calls=[]
    def call(self,cmd,args,timeout=None):
        self.calls.append((cmd,args))
        return {'result':{'value':self.value}}

def main():
    o=FakeCDP({'ok':True,'urls':[URL],'newUrls':[URL],'firstIdMs':321,'headMs':240,'firstNewMs':331,'totalMs':350,'early':True})
    urls,_,_,times=api_snapshot(o,'rent',TPL,['4051471'])
    assert urls==[URL] and times['early'] and times['first_new_ms']==331
    expression=o.calls[0][1]['expression']
    assert 'TextDecoder' in expression and 'reader.cancel(' in expression
    assert 'data' not in o.value and not ('Page.navigate' in expression)
    assert not o.calls[0][1]['userGesture']
    for val,kind in [({'ok':False,'kind':'challenge'},'challenge'),({'ok':False,'kind':'rate','status':429},'rate'),({'ok':True,'urls':['https://example.com/rent/office/property-4051679']},'filter')]:
        try:api_snapshot(FakeCDP(val),'rent',TPL,[])
        except ApiError as e: assert e.kind==kind, (e.kind,kind)
        else:assert False,kind
    assert 'timing.get("early")' in inspect.getsource(App.worker)
    assert 'CDP_TRANSPORT_LOST' in inspect.getsource(CDP.call)
    print('PASS: small CDP payload, API-only early NEW, owner lock, fail closed, CDP socket health')
if __name__=='__main__':main()
