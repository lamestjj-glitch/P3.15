PandaMonitor V1.47.7 — House730 Cloudflare verification protection
==================================================================
This is the integrated 28Hse + House730 build. Windows 10 / BitBrowser environment 173.
Use START.bat from an extracted folder. Stop the previous version first.

Why this release exists
-----------------------
House730 sometimes stays in a Cloudflare verification loop. Replaying the
QueryProperty API at one request per second, or refreshing the challenge page,
can make the cycle worse. A crawler cannot force Cloudflare to accept a browser.

What changes in House730
------------------------
* One site-wide pause shared by House730 RENT + BUY + detail jobs.
* Checks each list cycle for a challenge; pauses instead of reloading it.
* Also pauses if the initial page itself encounters a challenge.
* Waits for the already-open, correctly filtered House730 rent/buy lists to
  become valid and remain valid for at least 20 continuous seconds.
* Waits at least 120 seconds on the first episode. Repeat episodes get a
  longer hold (240, 480, 960, up to 1800 seconds).
* Cloudflare protection is ON by default. It enforces >=60 seconds per source
  for both JSON and HTML checks. The old one-second target DOES NOT apply while
  this protection switch is on. This is intentional; no 120 req/min claims.
* While verification is active: no automatic refresh, new JSON replay or
  House730 phone-page navigation. Work already queued is kept for later.
* Does not block images/fonts/media on House730 verification pages.
* Buttons in Unified Settings bring the existing House730 rent/buy tab to the
  foreground ONLY after you click the button. They do not solve verification.
* Separate WA switches, test buttons, phone/ID de-duplication, Windows alerts
  and original-post links are retained.
* The separate 28Hse core file is byte-for-byte unchanged from V1.47.6.

If Cloudflare never returns to a valid filtered list
----------------------------------------------------
House730 remains paused; the program cannot complete that challenge for you.
Keep the browser open, visit the genuine House730 page manually, and check if
it works WITHOUT the crawler running. If it still loops, check browser
JavaScript/cookies, extensions, proxy/network stability and request access
from the site rather than trying repeated reloads.

Status labels
-------------
'Cloudflare 驗證中｜730 已暫停' : no new House730 requests are issued.
'JSON 保護低頻' / 'HTML 保護低頻' : protection-mode monitoring resumed.

Logs
----
%LOCALAPPDATA%\House730Standalone173\house730.log
%LOCALAPPDATA%\PandaMonitor_28Hse_House730\logs\startup.log

Tests run in a non-Windows container, not with live BitBrowser 173:
  python TEST_730_OFFLINE.py
  python TEST_730_RECOVERY.py
  python TEST_730_API_HEADERS.py
  python TEST_730_CLOUDFLARE_GUARD.py
  python launch.py --self-test   (requires a graphical desktop)
