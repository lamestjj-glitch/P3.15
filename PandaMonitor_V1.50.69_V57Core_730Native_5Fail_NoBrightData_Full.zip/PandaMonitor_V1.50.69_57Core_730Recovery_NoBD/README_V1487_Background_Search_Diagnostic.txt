PandaMonitor V1.48.7｜28Hse 背景 API 學習修復
====================================================

針對 V1.48.6 出現的 no-visible-search-control / waiting-for-background-DOM：
1. 在私有背景 CDP Target 內辨識主搜尋控制，包括子元素文字及主搜尋表單的語義按鈕。
2. 先觀察頁面自行發送的 POST /property/dosearch；只有觀察不到且能唯一辨識控制時，才在背景 Target 中使用 JS DOM .click() 一次。
3. 若仍找不到，輸出不包含敏感內容的狀態診斷（載入狀態、按鈕及表單數量、CDP 錯誤次數）。
4. 同一程式啟動期間，如租／售各自已學習並通過 API 與 DOM 房源 ID 比對，停止後再開始可暫時重用已驗證的 POST 請求格式；重新核對 API 和畫面後才正式監控。
5. 此快取只在記憶體，不儲存 Token、Cookie、POST 資料到磁碟，整個程式完全退出後不保留。
6. 保留：28Hse API-only、PhoneFirst、租售獨立 0.5/1/5/10/30/60 秒、429 同步暫停、730 獨立子程序、統一 UI、跨站去重及 WA。
7. 不使用實體滑鼠/鍵盤、不操作前台分頁、不使用 Input.dispatch* 或 Page.bringToFront。

robots.txt：28Hse 公開的 robots.txt 曾顯示 Allow: / 和 sitemap 入口，
但它只提供爬取規則參考，不能作為房源 API，亦不代表可無限制查詢。
若遇 HTTP 429 / Cloudflare，會保持暫停，不會自動高頻重試。

測試說明：所有 Python/CDP 模擬測試在隔離環境執行。
未在使用者的 Windows 10、BitBrowser 173 上做端對端實測。

啟動：完全停止舊版 → 解壓新資料夾 → 啟動 START.bat。
請先用 10 秒或更慢的查詢間隔測試站點限流狀態。
觀察 [API-LEARN]、[API-VERIFY]、[API-LIST-OK]、[API-CACHE] 或新 diag=... 訊息。
不要刪除 C 槽的設定及永久去重文件。
