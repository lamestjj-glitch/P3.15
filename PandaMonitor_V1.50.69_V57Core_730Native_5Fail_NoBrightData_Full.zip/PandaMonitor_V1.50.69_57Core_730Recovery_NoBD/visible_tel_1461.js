(()=>{
              const clean=s=>String(s||'').replace(/\s+/g,' ').trim();
              const bad=e=>!!e.closest('.recommend,.recommendation,.related,.advertisement,.ads,aside,[class*="similar-property"],[class*="related-property"]');
              const telRx=/(?:Tel\.?|電話|电话)\s*[:：]\s*(?:\+?852[\s-]*)?([2-9]\d{3}[\s-]?\d{4})(?!\d)/ig;
              const norm=v=>{const m=String(v||'').match(/(?:^|\D)(?:\+?852[\s-]*)?([2-9]\d{3}[\s-]?\d{4})(?!\d)/);return m?m[1].replace(/\D/g,''):''};
              const panels=[];
              const add=p=>{if(p&&!bad(p)&&!panels.includes(p)&&p!==document.body&&p.textContent.length<12000)panels.push(p)};
              document.querySelectorAll('.content_phone_information,[class*="contact_information"],[class*="contact-info"],[class*="contactInformation"]').forEach(add);
              // This heading may be a div/span, not an h2; it may contain an
              // already-visible Tel line even if there is no Call button.
              const hs=[...document.querySelectorAll('h2,h3,h4,h5,strong,b,span,div')];
              for(const e of hs){
                if(e.childElementCount>2||bad(e))continue;
                if(!/^(放盤聯絡人|放盘联络人)$/.test(clean(e.textContent)))continue;
                for(let p=e.parentElement,d=0;p&&p!==document.body&&d<7;p=p.parentElement,d++){
                  const txt=(p.textContent||'').slice(0,9500);
                  if(/Tel\.?\s*[:：]|電話\s*[:：]|电话\s*[:：]/i.test(txt)||p.querySelector('a[attr="phone"],a[href^="tel:"]')){add(p);break}
                }
                break;
              }
              const results=[],seen=new Set();
              for(const panel of panels.slice(0,5)){
                const text=(panel.textContent||'').slice(0,8500);
                const names=[...panel.querySelectorAll('[class*="name"],[class*="contactName"],[class*="contact_name"]')]
                  .map(e=>clean(e.textContent)).filter(x=>x.length>1&&x.length<90);
                let name=names[0]||'未知';
                if(name==='未知'){
                  const prefix=clean(text.split(/Tel\.?\s*[:：]/i)[0]||'');
                  const n=prefix.match(/([\u3400-\u9fff]{1,5}(?:小姐|先生)|[\u3400-\u9fff]{1,5}\s*[A-Za-z][\w .]{1,45})/);
                  if(n) name=clean(n[1]);
                }
                const addPhone=p=>{if(p&&!seen.has(p)){seen.add(p);results.push({name,phone:p})}};
                for(const a of panel.querySelectorAll('a[href^="tel:"]'))addPhone(norm(a.getAttribute('href')));
                for(const m of text.matchAll(telRx))addPhone(norm(m[0]));
              }
              return results.slice(0,8);
            })();
