PandaMonitor V1.50.69（以你提供的 V1.50.57 完整包為核心）

1) 28Hse：完全沿用 V1.50.57 panda28_core.py、panda28_api.py 及原有業主/最新抓取，不加入 V1.50.67/68 嚴格 API 學習器。
2) House730：沿用 V1.50.57 原生 HTTP 獨立列表通道（同時監控 28Hse 時優先啟用）、直接電話 GET、租售並行、去重、WA。
3) House730 修復：每個來源連續 5 次初始列表失敗，或連續 5 次正常列表傳輸失敗，會在 CDP 健康、非驗證頁、Windows 未鎖定時，僅重建該來源已綁定的監控列表頁。單路 90 秒內最多重建 1 次；瀏覽器整體 CDP 故障直接重連，HTTP 429/403 不計入分頁故障。
4) 完全不包括 Bright Data、其 SDK、API Key 設定、付費後備通道或安裝腳本。
5) 不改你的設定檔、電話/房源去重資料庫。沒有 Signal 功能。

使用：關閉目前執行的 PandaMonitor；解壓整個目錄到新路徑；確保 BitBrowser 環境與業主＋最新租/售分頁正常開啟；雙擊 START.bat。請勿與舊版本同時運行。

日誌：
[730-NATIVE-API-OK] 表示已驗證原生 HTTP 列表。
[730-STARTUP-RECOVER] 表示連續5次初始列表失敗已單路修復。
[730-TAB-RECOVER-OK] 表示受控重建成功。
若一直沒有 [730-NATIVE-API-OK]，請檢查原有 BitBrowser 分頁、網址及驗證狀態。

已跑離線單元與源碼測試，未在實際 Windows BitBrowser/28Hse/730 網站進行在線驗證。
