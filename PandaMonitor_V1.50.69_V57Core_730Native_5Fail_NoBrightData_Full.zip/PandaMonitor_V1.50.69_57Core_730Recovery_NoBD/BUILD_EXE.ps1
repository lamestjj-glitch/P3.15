﻿$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location -LiteralPath $root
$candidates = @(
  @{ exe='py'; prefix=@('-3.13') },
  @{ exe='py'; prefix=@('-3.12') },
  @{ exe='py'; prefix=@('-3.14') },
  @{ exe='py'; prefix=@('-3.15') },
  @{ exe='py'; prefix=@('-3') },
  @{ exe='python'; prefix=@() },
  @{ exe='python3'; prefix=@() }
)
$python = $null
foreach ($item in $candidates) {
  $cmd = Get-Command $item.exe -CommandType Application -ErrorAction SilentlyContinue | Select-Object -First 1
  if ($null -eq $cmd) { continue }
  $args = [string[]]@($item.prefix)
  $exe = $cmd.Source
  & $exe @args -c 'import sys;sys.exit(0 if sys.version_info >= (3,12) else 2)' 1>$null 2>$null
  if ($LASTEXITCODE -eq 0) { $python = $cmd.Source; $prefix = $args; break }
}
if (-not $python) { Write-Host 'Python 3.12+ required.'; exit 1 }
& $python @prefix -m pip install -r requirements.txt 'pyinstaller>=6.0'
if ($LASTEXITCODE -ne 0) { exit 2 }
& $python @prefix -m PyInstaller --noconfirm --clean --onedir --windowed --collect-all playwright --hidden-import websocket --add-data 'http_phone_1461.js;.' --add-data 'visible_tel_1461.js;.' --add-data 'site_plugins;site_plugins' --hidden-import bs4 --name PandaMonitor_28Hse_House730 launch.py
exit $LASTEXITCODE
