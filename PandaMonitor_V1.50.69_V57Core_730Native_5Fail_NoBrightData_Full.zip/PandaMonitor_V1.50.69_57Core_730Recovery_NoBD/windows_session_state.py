"""Windows 10+ interactive-session lock state for safe browser automation.

Do not mistake Win+L for a closed browser. This module never unlocks the
session, changes Windows security, or switches desktops. Unsupported/unknown
WTS results return None, so callers do not treat guesses as definitive.
"""
from __future__ import annotations
import ctypes
import os


def locked_state():
    """Return True=locked, False=unlocked, None=unavailable/unknown.

    WTSSessionInfoEx (25): WTSINFOEXW Level DWORD, followed by the
    WTSINFOEX_LEVEL1_W fields SessionId, SessionState and SessionFlags.
    Windows 10+ exposes LOCK=0, UNLOCK=1. Never infer from idle time.
    """
    if os.name != 'nt':
        return None
    try:
        from ctypes import wintypes
        kernel32 = ctypes.WinDLL('kernel32', use_last_error=True)
        wts = ctypes.WinDLL('wtsapi32', use_last_error=True)
        pid = kernel32.GetCurrentProcessId()
        sid = wintypes.DWORD()
        kernel32.ProcessIdToSessionId.argtypes = [wintypes.DWORD, ctypes.POINTER(wintypes.DWORD)]
        kernel32.ProcessIdToSessionId.restype = wintypes.BOOL
        if not kernel32.ProcessIdToSessionId(pid, ctypes.byref(sid)):
            return None
        buf = ctypes.c_void_p()
        count = wintypes.DWORD()
        wts.WTSQuerySessionInformationW.argtypes = [
            ctypes.c_void_p, wintypes.DWORD, ctypes.c_int,
            ctypes.POINTER(ctypes.c_void_p), ctypes.POINTER(wintypes.DWORD),
        ]
        wts.WTSQuerySessionInformationW.restype = wintypes.BOOL
        wts.WTSFreeMemory.argtypes = [ctypes.c_void_p]
        if not wts.WTSQuerySessionInformationW(None, sid.value, 25,
                                               ctypes.byref(buf), ctypes.byref(count)):
            return None
        try:
            if count.value < 16:
                return None
            raw = ctypes.string_at(buf, min(count.value, 20))
            level = int.from_bytes(raw[0:4], 'little')
            if level != 1:
                return None
            flag = int.from_bytes(raw[12:16], 'little', signed=True)
            return True if flag == 0 else (False if flag == 1 else None)
        finally:
            wts.WTSFreeMemory(buf)
    except Exception:
        return None


def input_desktop_state():
    """Independent, read-only check of the Windows INPUT desktop.

    Returns False if the real interactive Default desktop is active; True if
    Winlogon (lock) desktop is the input desktop; None if unavailable.
    Unlike idle-time heuristics, this never infers a lock from inactivity.
    No switching desktops, unlocking, bringing windows forward, or elevation.
    """
    if os.name != 'nt':
        return None
    try:
        from ctypes import wintypes
        u = ctypes.WinDLL('user32', use_last_error=True)
        u.OpenInputDesktop.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
        u.OpenInputDesktop.restype = wintypes.HANDLE
        u.GetUserObjectInformationW.argtypes = [wintypes.HANDLE, ctypes.c_int,
            ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(wintypes.DWORD)]
        u.GetUserObjectInformationW.restype = wintypes.BOOL
        u.CloseDesktop.argtypes = [wintypes.HANDLE]
        u.CloseDesktop.restype = wintypes.BOOL
        # DESKTOP_READOBJECTS=0x0001 and UOI_NAME=2.  No switch rights.
        desktop = u.OpenInputDesktop(0, False, 0x0001)
        if not desktop:
            return None
        try:
            name = ctypes.create_unicode_buffer(128)
            needed = wintypes.DWORD()
            if not u.GetUserObjectInformationW(desktop, 2, name,
                    ctypes.sizeof(name), ctypes.byref(needed)):
                return None
            current = name.value.casefold()
            if current == 'default':
                return False
            if current == 'winlogon':
                return True
            return None  # Custom secure desktop, no assumptions.
        finally:
            u.CloseDesktop(desktop)
    except Exception:
        return None


def is_locked():
    """Avoid keeping 730 in `lock-wait` because of a stale WTS flag.

    WTSSessionInfoEx occasionally reports an outdated session flag after
    reconnect / unlock.  The INPUT desktop is direct evidence of the current
    active desktop, and takes precedence if readable; otherwise WTS remains
    the conservative fallback. Unknown must never be interpreted as locked.
    """
    direct = input_desktop_state()
    if direct is not None:
        return direct
    return locked_state() is True
