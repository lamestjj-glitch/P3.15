# -*- coding: utf-8 -*-
"""Bounded, non-navigating browser-session WA name recovery.

Never creates/open/focuses a property page; never sends a message. Only a
phone-associated public contact block, or an exact already-open property page
with a single explicit contact, may establish a name. Uncertain -> no send.
"""
import json
import re
from urllib import request, parse
from panda28_core import CDP

_OPENER = request.build_opener(request.ProxyHandler({}))


def _identity(url):
    try:
        p = parse.urlsplit(str(url or ''))
        host = (p.hostname or '').lower()
        if host not in ('www.28hse.com','28hse.com','www.house730.com','house730.com'):
            return None
        if host.endswith('28hse.com'):
            if not re.search(r'/property-\d+(?:/|$)',p.path): return None
            return '28', re.search(r'property-(\d+)',p.path).group(1)
        m = re.search(r'/(?:rent|buy)-property-(\d+)(?:/|$)',p.path,re.I)
        if m: return '730',m.group(1)
    except (ValueError,AttributeError): pass
    return None


def recover_public_contact(cdp_base, listing_url, phone, *, max_tabs=20):
    """Return (name, evidence) or ('', reason). Needs user-authorized browser CDP.

    The contact must be associated with the SAME phone, or it must be the only
    unambiguous contact on the exact property page currently open in browser.
    """
    listing_id = _identity(listing_url)
    digits = re.sub(r'\D','',str(phone or ''))
    if not cdp_base or not listing_id or len(digits) < 8:
        return '', '無有效房源／電話／CDP'
    try:
        with _OPENER.open(cdp_base.rstrip('/')+'/json',timeout=1.2) as f:
            tabs=json.load(f)
    except Exception:
        return '', '無法讀取現有瀏覽器分頁'
    if not isinstance(tabs,list): return '', '瀏覽器分頁回應無效'
    exact=[]; origin=[]
    for tab in tabs[:max_tabs]:
        if not isinstance(tab,dict) or not tab.get('webSocketDebuggerUrl') or tab.get('type')!='page': continue
        kind_id=_identity(tab.get('url'))
        if kind_id == listing_id: exact.append(tab)
        elif listing_id[0]=='28' and parse.urlsplit(str(tab.get('url'))).hostname in ('www.28hse.com','28hse.com'): origin.append(tab)
        elif listing_id[0]=='730' and parse.urlsplit(str(tab.get('url'))).hostname in ('www.house730.com','house730.com'): origin.append(tab)
    expression = r"""(async ({url,phone,exact})=>{
      const clean=x=>String(x||'').replace(/\D/g,'').replace(/^852(?=\d{8}$)/,'');
      const expected=clean(phone);
      const honor=x=>{
        let s=String(x||'').replace(/\s+/g,' ').trim().slice(0,100);
        const matches=[...s.matchAll(/([\u3400-\u9fff]{1,5}(?:小姐|女士|太太|先生)(?:\s+[A-Za-z][A-Za-z .'-]{1,35})?|(?:Mrs|Ms|Miss|Mr)\.?\s+[A-Za-z][A-Za-z .'-]{1,35})/gi)];
        return matches.map(x=>x[1].trim());
      };
      let doc=document;
      if(!exact){
        const ctl=new AbortController();const timer=setTimeout(()=>ctl.abort(),1800);
        try{
          const r=await fetch(url,{credentials:'include',cache:'no-store',signal:ctl.signal});
          const dest=new URL(r.url);
          if(!r.ok||dest.hostname!==location.hostname||!dest.pathname.includes('property-')&& !/-(?:property)-/i.test(dest.pathname))return {reason:'房源HTTP無效'};
          const html=await r.text();if(html.length>900000)return {reason:'房源HTML過大'};
          doc=new DOMParser().parseFromString(html,'text/html');
        }catch(_){return {reason:'HTTP無法補讀姓名'}}finally{clearTimeout(timer)}
      }
      const blocks=[...doc.querySelectorAll('.content_phone_information,[class*="contact-info"],[class*="contactInfo"],[class*="contact-name"],[class*="contactName"],[class*="contact_name"],[class*="agentInfo"],[class*="ownerInfo"]')].slice(0,45);
      // Look only for phone-associated contact blocks; never take a random name
      // from other agency adverts, recommendations or unrelated listings.
      let matches=[];
      for(const b of blocks){
        let text=(b.textContent||'').slice(0,1700);
        let nums=[...text.matchAll(/(?:\+?852[ -]?)?[2-9]\d{3}[ -]?\d{4}/g)].map(x=>clean(x[0]));
        for(const a of b.querySelectorAll('a[href^="tel:"]'))nums.push(clean(a.getAttribute('href')));
        if(nums.includes(expected)){
          const ns=honor(text);if(ns.length===1)matches.push(ns[0]);
          else if(ns.length>1)return {reason:'同一電話區有多個聯絡人'};
        }
      }
      // If the site's markup uses a different contact container, start from
      // an explicitly associated tel/data-phone element and inspect only its
      // small nearest ancestor, never a whole page or unrelated listing card.
      for(const e of [...doc.querySelectorAll('a[href^="tel:"],[data-phone],[data-tel],[data-mobile]')].slice(0,70)){
        const raw=e.getAttribute('href')||e.getAttribute('data-phone')||
          e.getAttribute('data-tel')||e.getAttribute('data-mobile')||'';
        if(clean(raw)!==expected)continue;
        let node=e;
        for(let depth=0;depth<4 && node;depth++,node=node.parentElement){
          const text=(node.textContent||'').trim();
          if(text.length<4||text.length>360)continue;
          const names=[...new Set(honor(text))];
          if(names.length===1){matches.push(names[0]);break;}
          if(names.length>1)return {reason:'電話鄰近多名聯絡人'};
        }
      }
      matches=[...new Set(matches)];
      if(matches.length===1)return {name:matches[0],reason:'公開電話對應聯絡人'};
      if(matches.length>1)return {reason:'同一電話多個姓名'};
      if(exact){
        // Exact, already opened listing only. Require an explicit single contact
        // immediately after the site's contact heading, not an arbitrary name.
        const body=(doc.body?.innerText||doc.body?.textContent||'').slice(0,50000);
        let heads=[...body.matchAll(/(?:放盤聯絡人|放盘联络人|聯絡人|联系人)[\s:：]{0,12}([\u3400-\u9fff]{1,5}(?:小姐|女士|太太|先生)(?:\s+[A-Za-z][A-Za-z .'-]{1,35})?)/g)]
          .map(x=>x[1].trim());
        heads=[...new Set(heads)];
        if(heads.length===1 && blocks.length<=3)return {name:heads[0],reason:'已開原帖唯一公開聯絡人'};
      }
      return {reason:'沒有可與電話核對的女性姓名'};
    })""" 
    last_reason = '沒有已開的站內監控分頁可用'
    for tab in exact[:1]+origin[:2]:
        c=None
        try:
            c=CDP(tab['webSocketDebuggerUrl']);c.connect()
            result=c.call('Runtime.evaluate',{'expression':expression+'('+json.dumps({'url':listing_url,'phone':digits,'exact':tab in exact},ensure_ascii=False)+')','awaitPromise':True,'returnByValue':True},timeout=3.0) or {}
            val=(result.get('result') or {}).get('value')
            if isinstance(val,dict):
                if val.get('name'):
                    return str(val['name'])[:65],str(val.get('reason') or '公開姓名')
                if val.get('reason'):
                    last_reason = str(val['reason'])[:110]
        except Exception:
            continue
        finally:
            if c:
                try:c.close()
                except Exception:pass
    return '', last_reason
