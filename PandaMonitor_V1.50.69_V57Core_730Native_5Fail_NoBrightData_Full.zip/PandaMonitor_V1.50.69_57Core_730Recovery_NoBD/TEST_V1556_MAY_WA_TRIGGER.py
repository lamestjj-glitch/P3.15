# -*- coding: utf-8 -*-
"""No-network tests: matching an explicit May alias and detection-time WA eligibility."""
import threading
from unittest.mock import patch
from wa_female_filter import parse_female_names, female_name_eligible
from unified_gui import UnifiedApp
from panda28_core import App as BaseApp


def test_may_name_and_male_protection():
    user_txt = parse_female_names('Nora, Alice')
    for name in ('張小姐 May', '张小姐 May', '張小姐', 'May', 'May Cheung', 'Ms May'):
        assert female_name_eligible(name, user_txt)[0], name
    for name in ('Mr May', '張先生 May', '陳生 May', 'May先生', 'Unknown', 'Maybe', 'Mayflower'):
        assert not female_name_eligible(name, user_txt)[0], name
    assert not female_name_eligible('Mandy', user_txt)[0]


class Var:
    def __init__(self, v): self.v = v
    def get(self): return self.v


class Fake730:
    wa_730_enable = Var(True)
    wa_730_text = Var('您好 {url}')
    cdp_base = 'http://localhost:9222'
    lock = threading.RLock()
    _wa_730_lock = threading.RLock()
    def __init__(self):
        self.wa_sent=set()
        self.events=[];self.sent=[]
    def _house_in_wa_window(self): return False # Time window ended during name recovery.
    def _wa_verified_name(self, name, url, phone, row_id=None):return name
    def _wa_female_gate(self, name, url='', row_id=None):
        ok,_=female_name_eligible(name,parse_female_names('Alice'))
        return ok
    def whatsapp_send(self, phone, url, message=None):
        self.sent.append((phone,url,message));return True,'已確認發送'
    def write(self,msg):self.events.append(msg)
    def update_row_field(self,iid,index,value):self.events.append((iid,index,value))


def test_house_window_captured_before_recovery():
    for name in ('張小姐 May', 'May'):
        fake=Fake730()
        UnifiedApp._house_wa_job(fake,'59871234','https://www.house730.com/rent-property-900001/', 'house:rent:900001',name,True)
        assert len(fake.sent)==1, (name,fake.events)
        assert any(isinstance(e,tuple) and e[-1]=='已發送' for e in fake.events),fake.events
    fake=Fake730()
    UnifiedApp._house_wa_job(fake,'59871234','https://www.house730.com/rent-property-900001/','house:rent:900001','May',False)
    assert not fake.sent
    fake=Fake730()
    UnifiedApp._house_wa_job(fake,'59871234','https://www.house730.com/rent-property-900001/','house:rent:900001','張先生 May',True)
    assert not fake.sent


class Fake28:
    wa_enable=Var(True)
    wa_female_name_set=parse_female_names('Nora')
    cdp_base=None
    def __init__(self): self.events=[]
    def in_wa_window(self):return True
    def _wait_28_wa_phone_name(self,url,phone,seconds=8):return 'May'
    def _wa_verified_name(self,name,url,phone,row_id=None):return name
    def _wa_female_gate(self,name,url,row_id=None):return female_name_eligible(name,self.wa_female_name_set)[0]
    def write(self,msg):self.events.append(msg)
    def update_row_field(self,*args):self.events.append(args)


def test_28_does_not_recheck_window_after_name_recovery():
    from unittest.mock import Mock
    d=UnifiedApp.__new__(UnifiedApp)
    d.wa_enable=Var(True)
    d.wa_female_name_set=parse_female_names('Nora')
    d.in_wa_window=Mock(return_value=True)
    d._wait_28_wa_phone_name=Mock(return_value='May')
    d._wa_verified_name=Mock(side_effect=lambda name,*args,**kw:name)
    d._wa_female_gate=Mock(return_value=True)
    d.write=Mock()
    d.update_row_field=Mock()
    with patch.object(BaseApp,'maybe_whatsapp',return_value='queued') as send:
        assert UnifiedApp.maybe_whatsapp(d,'59871234','https://www.28hse.com/rent/apartment/property-9999999','28租盘')=='queued'
        assert send.call_args.kwargs.get('window_approved') is True


def test_base_bypass_only_for_explicit_approval():
    # The unmodified base call must still reject out-of-window messages.
    class Fake:
        wa_enable=Var(True)
        wa_sent=set()
        lock=threading.RLock()
        def in_wa_window(self):return False
        def update_row_field(self,*args):pass
        def write(self,*args):pass
        def whatsapp_send(self,*args):raise AssertionError('should not send')
    f=Fake()
    assert BaseApp.maybe_whatsapp(f,'59871234','https://www.28hse.com/property-9999999','28租盘') is None


if __name__ == '__main__':
    test_may_name_and_male_protection()
    test_house_window_captured_before_recovery()
    test_28_does_not_recheck_window_after_name_recovery()
    test_base_bypass_only_for_explicit_approval()
    print('PASS V1.50.56: May alias regardless TXT, male skip, both site WA time-window handoff, default restriction')
