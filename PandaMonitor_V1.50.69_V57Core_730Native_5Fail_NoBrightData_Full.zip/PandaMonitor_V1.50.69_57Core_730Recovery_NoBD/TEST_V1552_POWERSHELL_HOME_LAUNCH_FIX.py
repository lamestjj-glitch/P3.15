# -*- coding: utf-8 -*-
"""Regression checks for the Windows PowerShell reserved variable crash."""
from pathlib import Path
import re

root = Path(__file__).resolve().parent
ps = (root / "WINDOWS_LAUNCH.ps1").read_text(encoding="utf-8-sig")
assert not re.search(r"\$home\b", ps, flags=re.I), "PowerShell $HOME is a built-in read-only variable"
assert "foreach ($searchRoot in @($env:LOCALAPPDATA, $env:ProgramFiles, ${env:ProgramFiles(x86)}))" in ps
for path in (r"Programs\Python\Python$digits\python.exe", r"Python$digits\python.exe", r"Python\Python$digits\python.exe"):
    assert path in ps, path
assert "Add-Candidate 'py' @('-3') 'Python launcher default 3.x'" in ps
assert "TK_OK=" in ps
assert "Join-Path $root 'bootstrap.py'" in ps
assert (root / 'START.bat').is_file()
assert (root / 'python_runtime_probe.py').is_file()
assert "V1.50.52" in (root / "unified_gui.py").read_text(encoding="utf-8-sig")
print("PASS: PowerShell reserved HOME is untouched; Python candidate probing and GUI entry preserved")
