# -*- coding: utf-8 -*-
"""Per-source HOT-list delta cache; never a replacement for site/SQLite de-dup.

No HTTP request, extra CDP command, guessed API query parameter or new tab.
Rent and buy share one coordinator but NEVER share their last IDs: they are
separate result sets. All returned rows are inspected in memory, so a new
listing below the first six is still seen in the SAME poll.
"""
from collections import OrderedDict
from threading import RLock


class ListingDeltaCache:
    def __init__(self, head_size=6, max_ids=4096):
        self.head_size = max(1, int(head_size))
        self.max_ids = max(100, int(max_ids))
        self._ids = {}
        self._heads = {}
        self._lock = RLock()
        self.stats = {}

    @staticmethod
    def _normal(rows):
        seen = set()
        result = []
        for url, pid in rows:
            pid = str(pid or '')
            if not pid.isdigit() or pid in seen:
                continue
            seen.add(pid)
            result.append((url, pid))
        return result

    def seed(self, source, rows):
        """Only after the caller has registered the original startup baseline."""
        entries = self._normal(rows)
        with self._lock:
            bucket = self._ids.setdefault(source, OrderedDict())
            for _url, pid in entries:
                bucket[pid] = None
                bucket.move_to_end(pid)
            self._trim(bucket)
            self._heads[source] = tuple(pid for _, pid in entries[:self.head_size])
            self.stats.setdefault(source, {'polls': 0, 'head_unchanged': 0,
                                           'cache_skips': 0, 'db_candidates': 0,
                                           'deep_new': 0})

    def candidates(self, source, rows):
        """Latest few are considered first; deep remainder ALWAYS audited.

        Does not mark previously unseen candidates until caller has handled
        them in the durable DB / normal in-flight registry.
        """
        entries = self._normal(rows)
        with self._lock:
            bucket = self._ids.setdefault(source, OrderedDict())
            head = tuple(pid for _, pid in entries[:self.head_size])
            st = self.stats.setdefault(source, {'polls': 0, 'head_unchanged': 0,
                                                'cache_skips': 0, 'db_candidates': 0,
                                                'deep_new': 0})
            st['polls'] += 1
            if head == self._heads.get(source):
                st['head_unchanged'] += 1
            self._heads[source] = head
            new = [(url, pid) for url, pid in entries if pid not in bucket]
            st['cache_skips'] += len(entries) - len(new)
            st['db_candidates'] += len(new)
            st['deep_new'] += sum(1 for _,pid in entries[self.head_size:] if pid not in bucket)
            return new

    def confirm(self, source, rows):
        """Confirm IDs AFTER site/persistent duplicate checks have run."""
        entries = self._normal(rows)
        with self._lock:
            bucket = self._ids.setdefault(source, OrderedDict())
            for _url, pid in entries:
                bucket[pid] = None
                bucket.move_to_end(pid)
            self._trim(bucket)

    def summary(self, source):
        with self._lock:
            return dict(self.stats.get(source) or {})

    def _trim(self, bucket):
        while len(bucket) > self.max_ids:
            bucket.popitem(last=False)
