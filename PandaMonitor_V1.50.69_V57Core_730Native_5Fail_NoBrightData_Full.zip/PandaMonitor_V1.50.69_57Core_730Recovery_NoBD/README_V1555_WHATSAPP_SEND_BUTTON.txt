PandaMonitor V1.50.55：修復 WhatsApp 訊息停留於草稿，沒有真正發送

症狀：WhatsApp Web 可看到 House730 / 28Hse 房源鏈接、消息預覽、右下角發送箭頭，但對話內沒有新消息。

原因候選：WhatsApp Web 新 UI 的箭頭可能包在 span/div 中，舊版主要使用 footer 中的 button 位置推斷，遇上鏈接預覽時容易找錯；或背景 CDP 點擊被忽略。此版尚未在真實 BitBrowser/WhatsApp Web 驗證。

修復：
1. 先在當前聊天的 footer 查找明確 send 圖示，優先 DOM .click()，然後有節制地嘗試 CDP 滑鼠，最後才嘗試對已驗證編輯框 Enter。
2. 只允許唯一無歧義的右下控制作座標回退；不點附件／語音／emoji 鍵。
3. 每次點擊後先核對當前聊天紀錄是否新增匹配的發出消息；草稿清空但無法核實時停止，絕不自動重發。
4. 新增 [WA55-SEND] 及 [WA-VERIFY] 診斷，不記錄發送正文。
5. 保留原有：28Hse、House730 同時監控、WA 女性姓名/稱謂過濾與時段、去重、顯示電話、原帖連結、429 恢復、剪貼簿尾四位；Signal 永久不在 PandaMonitor 中。

使用：
1. 先不要重複點擊目前 WhatsApp 中未發出的同一草稿。請自行確認它仍未出現在聊天紀錄；如確定未發送，可手動點一次發出。若不確定，寧可不發，避免重複。
2. 關閉舊版 PandaMonitor 後，解壓本版到新資料夾，執行原本 START.bat（BitBrowser 設定仍在本機原位置）。
3. 在設定介面使用「730 WA 發送測試」或適當的 28 WA 測試；該操作會真的傳訊，請先選擇你有權傳送的測試對象。
4. 若仍停留在草稿，查看 watcher/GUI 中的 [WA55-SEND]、[WA-VERIFY]、[730-WA]、[WA] 日誌；請勿提供含個人聯絡資訊的原始日誌。

注意：離線測試僅驗證送出邏輯，不代表真實 WhatsApp Web DOM/BitBrowser 已成功，並且不保證網站一直不改 DOM。
