# -*- coding: utf-8 -*-
"""Offline GUI / config verification; needs a graphical display (xvfb-run on Linux)."""
from __future__ import annotations
import json
import os
import tempfile
from pathlib import Path

with tempfile.TemporaryDirectory() as home:
    os.environ['HOME'] = home
    from unified_gui import UnifiedApp
    app = UnifiedApp()
    assert 'V1.50.57' in app.title()
    assert not hasattr(app, 'signal_sender')
    labels = []
    def collect(widget):
        try:
            labels.append(str(widget.cget('text')))
        except Exception:
            pass
        for child in widget.winfo_children():
            collect(child)
    collect(app)
    assert not any('Signal' in label for label in labels)
    assert any('WhatsApp' in label for label in labels)
    assert app.save_config()
    original = json.loads(Path(app.config_path).read_text(encoding='utf-8'))
    original.update(signal_enabled=True, signal_cli='old_test_path', signal_account='old_test_account')
    Path(app.config_path).write_text(json.dumps(original),encoding='utf-8')
    assert app.save_config()
    current = json.loads(Path(app.config_path).read_text(encoding='utf-8'))
    assert not any(k.startswith('signal_') for k in current)
    assert 'wa_730_enable' in current
    assert 'api_rent_interval' in current and 'api_buy_interval' in current
    app.destroy()
print('PASS V1.50.43: no Signal GUI/sender; legacy keys retired; 28/730/WA settings preserved')
