# -*- coding: utf-8 -*-
"""V1.50.54: independent House730 lanes, bounded repeated-429 backoff.

Remove the old site-wide exponential 180-1800s cooldown and the long
Retry-After wait. Repeated 429 adds 3/6/12/24/30s per lane (no hour-long wait).
An HTTP429 still fails the current request: there is no
alternate transport on 429; only that deal pauses briefly before its next
normal attempt. Challenge/403 handling is owned by house730_engine.py.
"""
from __future__ import annotations

import asyncio
import random
import time
from contextlib import asynccontextmanager


class SharedHouse730Rate:
    # User-selected behavior: do not park BOTH monitors for 600/3600 seconds.
    # A short bounded pause avoids an immediate tight-loop on persistent 429.
    SHORT_429_RETRY_SECONDS = 3.0
    MAX_429_RETRY_SECONDS = 30.0

    def __init__(self, requested_seconds, stop, log, *, clock=None, sleeper=None, jitter=None):
        self.requested_seconds = requested_seconds
        self.stop = stop
        self.log = log
        self.clock = clock or time.monotonic
        self.sleep = sleeper or asyncio.sleep
        self.jitter = jitter or (lambda: random.uniform(0.100, 0.300))
        self._lane_locks = {"租": asyncio.Lock(), "售": asyncio.Lock()}
        self._last_start = {"租": -1e9, "售": -1e9}
        self._last_jitter = {"租": 0.0, "售": 0.0}
        self._lane_429_until = {"租": 0.0, "售": 0.0}
        self._last_429_log_at = {"租": -1e9, "售": -1e9}
        self._lane_429_streak = {"租": 0, "售": 0}
        self.last_start = -1e9  # legacy UI diagnostics
        self.spacing = self._requested()
        self.last_jitter = 0.0
        self.good = 0
        self.log(f'[730-CADENCE] 租售獨立並行各1個請求；輸入 {self.spacing:g}s + 每路每輪隨機100–300ms；429本路3–30秒漸進恢復，不設共用長冷卻')

    def _requested(self):
        try:
            return max(0.001, float(self.requested_seconds()))
        except (TypeError, ValueError):
            return 1.0

    @property
    def floor(self):
        return self._requested()

    def in_cooldown(self, deal=None):
        if deal is None:
            return any(self.clock() < x for x in self._lane_429_until.values())
        return self.clock() < self._lane_429_until[deal]

    async def _wait(self, until):
        while not self.stop.is_set():
            left = until - self.clock()
            if left <= 0:
                return True
            await self.sleep(min(0.5, left))
        return False

    @asynccontextmanager
    async def slot(self, deal):
        """One request per deal; another deal is never blocked by its HTTP429."""
        if deal not in self._lane_locks:
            raise ValueError('730 slot requires deal 租 or 售')
        async with self._lane_locks[deal]:
            while True:
                if self.stop.is_set():
                    raise asyncio.CancelledError('House730 stopped')
                due = max(self._lane_429_until[deal],
                          self._last_start[deal] + self._requested() + self._last_jitter[deal])
                if not await self._wait(due):
                    raise asyncio.CancelledError('House730 stopped')
                if self.clock() >= due:
                    break
            now = self.clock()
            self._last_start[deal] = now
            self.last_start = now
            self.spacing = self._requested()
            self._last_jitter[deal] = max(.100, min(.300, float(self.jitter())))
            self.last_jitter = self._last_jitter[deal]
            yield

    def success(self, deal=None):
        self.good += 1
        if deal in self._lane_429_streak:
            if self._lane_429_streak[deal]:
                self.log(f'[730-429-RECOVERED] {deal}盤接口已成功；立即恢復用戶設定的列表間隔')
            self._lane_429_streak[deal] = 0
            self._lane_429_until[deal] = 0.0

    def limit(self, retry_after=0, *, deal):
        """A real 429 is never counted as success; throttle only the affected lane.

        Keep user-selected NO hours-long shared delay. Repeated genuine 429s
        progressively space requests (3,6,12,24,30s) to avoid a 3s 429 storm.
        A successful list query resets the streak. No new IP/session or bypass.
        """
        if deal not in self._lane_locks:
            raise ValueError('730 limit requires deal 租 or 售')
        now = self.clock()
        streak = min(self._lane_429_streak[deal] + 1, 1000)
        self._lane_429_streak[deal] = streak
        pause = min(self.MAX_429_RETRY_SECONDS,
                    self.SHORT_429_RETRY_SECONDS * (2 ** min(streak - 1, 5)))
        self._lane_429_until[deal] = max(self._lane_429_until[deal], now + pause)
        self.good = 0
        if streak <= 2 or now - self._last_429_log_at[deal] >= 20.0:
            self._last_429_log_at[deal] = now
            self.log(f'[730-429-ADAPT] {deal}盤真實HTTP429（連續{streak}次）；本路暫停{pause:g}s，最高30s；其他路獨立；非數千秒共用冷卻')

    async def wait_cooldown(self, deal):
        """Retains the old call-site API but waits only this source's short pause."""
        if deal not in self._lane_locks:
            raise ValueError('730 wait_cooldown requires deal 租 or 售')
        if not self.in_cooldown(deal):
            return not self.stop.is_set()
        return await self._wait(self._lane_429_until[deal])
