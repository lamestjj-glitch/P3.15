# -*- coding: utf-8 -*-
"""Regression tests: phone GET priority, site-observed public query extras, zero detail."""
import asyncio
import inspect
from urllib.parse import parse_qs, urlsplit
from house730_direct_api import DirectPhoneLookup, observed_public_params
from house730_engine import Engine

class Context:
    def __init__(self): self.events={}
    def on(self,key,cb): self.events[key]=cb
    def remove_listener(self,key,cb): self.events.pop(key,None)

class ListAPI:
    ready=True
    def __init__(self):
        self.inflight=asyncio.Lock()
        self.template={'url':'https://api.house730.com/Property/QueryProperty?language=tc&not_a_phone_field=PRIVATE',
                       'headers':{'Platform':'web','cityen':'hk','AppSignature':'DONT_COPY','AppKey':'site-app'}}

class Page:
    def __init__(self,mode='full'):
        self.calls=[]
        self.mode=mode
    def is_closed(self):return False
    async def evaluate(self,code,args):
        assert 'new_page' not in code and 'page.goto' not in code and 'click' not in code
        self.calls.append(args)
        if self.mode=='full':
            return {'status':200,'payload':{'result':[{'telphone':'61234567','isShowTel':True}]}}
        if self.mode=='empty-then-full':
            if len(self.calls)==1:
                return {'status':200,'payload':{'result':[]}}
            return {'status':200,'payload':{'result':[{'telphone':'71234567','isShowTel':True}]}}
        if self.mode=='masked':
            return {'status':200,'payload':{'result':[{'telphone':'712345xx','isShowTel':True}]}}
        if self.mode=='denied':
            return {'status':403,'reason':'http'}
        raise AssertionError(self.mode)

async def main():
    c=Context(); d=DirectPhoneLookup(c); la=ListAPI()
    # Simulate concurrent list API that holds its lock for longer than old .8s.
    await la.inflight.acquire()
    try:
        page=Page()
        res=await asyncio.wait_for(d.query(page,'9293649',la),timeout=.2)
        assert res.contacts==[('未提供','61234567')]
        assert len(page.calls)==1 and 'propertyId=9293649' in page.calls[0]['url']
    finally: la.inflight.release()
    # If bare propertyId returned empty, reuse ONLY actual public params from list.
    page2=Page('empty-then-full')
    res=await d.query(page2,'9293101',la)
    assert res.contacts and res.attempts==2
    fields=parse_qs(urlsplit(page2.calls[1]['url']).query)
    assert fields['language']==['tc'] and fields['platform']==['web'] and fields['cityen']==['hk']
    assert 'not_a_phone_field' not in fields and 'AppSignature' not in fields
    assert 'appsignature' not in ''.join(page2.calls[1]['headers'].keys()).lower()
    assert observed_public_params(la)=={'language':'tc','platform':'web','cityen':'hk'}
    # Legitimately masked phone remains a miss: never guess/reveal it.
    masked=Page('masked'); r=await d.query(masked,'9293101',la)
    assert not r.contacts and r.reason=='no-full-phone' and r.diagnostic=='masked-phone' and len(masked.calls)==1
    denied=Page('denied');r=await d.query(denied,'9293101',la)
    assert not r.contacts and r.status==403 and len(denied.calls)==1
    d.close()
    assert not c.events
    src=inspect.getsource(Engine._run)
    worker=src.split('async def detail_worker(index):',1)[1].split('async def supervise_list(deal):',1)[0]
    testing=src.split("elif cmd in ('test', 'test_wa')",1)[1].split('await asyncio.sleep(.25)',1)[0]
    for x in [worker,testing]:
        for forbidden in ('context.new_page(', 'lane.acquire(', 'reveal_phone(', 'goto('):
            assert forbidden not in x, forbidden
    assert '[:3]' in testing
    assert 'if outcome.status == 429' in worker
    assert 'if outcome.status in (401,403)' in worker
    assert 'if direct.status in (401,403,429)' in testing
    print('PASS V1.50.18: API priority over busy list; observed-only aux params; no token leak; bounded 3-post test; 403/429 stop; no auto detail')

asyncio.run(main())
