# -*- coding: utf-8 -*-
"""Shared BitBrowser profile: child must not reopen the 28Hse browser."""
import asyncio
from bitbrowser_adapter import connect_bitbrowser_context

class FakeChromium:
    def __init__(self): self.connections=[]
    async def connect_over_cdp(self,endpoint,timeout):
        self.connections.append(endpoint)
        raise ConnectionRefusedError('shared port closed')
class FakePlaywright:
    def __init__(self):self.chromium=FakeChromium()

def main():
    p=FakePlaywright()
    try:
        asyncio.run(connect_bitbrowser_context(p,{'bitbrowser_seq':173,'shared_cdp_endpoint':'http://127.0.0.1:54399'}))
    except RuntimeError as e:
        assert '不自動開環境' in str(e) or '不調用/browser/open' in str(e)
    else:raise AssertionError('old shared port was allowed to fall back to browser/open')
    assert p.chromium.connections==['http://127.0.0.1:54399']
    print('PASS: shared stale CDP prevents /browser/open; 28 browser is never restarted by 730')
if __name__=='__main__':main()
