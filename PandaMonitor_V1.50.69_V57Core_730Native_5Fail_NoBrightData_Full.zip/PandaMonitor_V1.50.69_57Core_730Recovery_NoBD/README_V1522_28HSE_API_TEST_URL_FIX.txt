PandaMonitor V1.50.22 — 28Hse API 測試 + 無參數列表附加修復
==========================================================

這一版修正：28Hse 主畫面顯示「運行中」，但按租/售 API 測試卻報
「尚無租盤列表快取」的問題。

根因：
  1. Start 表示已啟動背景線程，並不等於 API 已驗證／取得首輪列表。
  2. 舊版只認帶有 landlordAgency=LANDLORD&sortBy=latest 的列表 URL。
     但 28Hse 有時畫面選了「業主盤」與「最新放盤」，地址仍然只有 /rent 或 /buy。
     舊版因此把已開列表誤認為不存在，永遠不會建立列表快取。

新版：
  - 先接管使用者已開的 /rent 或 /buy 列表（不新建、不切前台分頁）。
  - 無參數 URL 僅作「未驗證候選」，不能直接當作業主盤。
    必須從網頁真實 POST /property/dosearch 取得 landlordAgency=LANDLORD
    + sortBy=latest，並確認 API 房源與現有 DOM 至少八個（或不足八個全部）重合，
    才開始取號監控。若未通過，不處理、不報新帖、不取電話。
  - 當 URL 沒有查詢參數時，不再 Reload 清掉畫面上已選的篩選條件；
    僅操作現有頁面的「搜尋」按鈕來學習網站真正使用的 API 請求。
  - 租盤 / 售盤 API 取號測試若按得太快，會在背景等待本路首次驗證
    與快取（最多 25 秒），不會立即誤報無快取，也不額外發列表請求。
  - 顯示「等待列表 API 驗證」直到取得本輪有效 JSON，之後才顯示「API 監控中」。
  - Stop / Start 清除上一輪列表快取，避免測試使用過期房源；
    已知 ID、電話去重庫、WA 設定和網站插件維持不變。

使用：
  1. 完全退出舊 PandaMonitor，解壓本 ZIP 至新的資料夾。
  2. 在 BitBrowser 173 打開 28Hse 租/售列表，選「業主盤」與「最新放盤」。
  3. 啟動 START.bat。待看到 [API-LEARN]、[API-VERIFY]、[API-LIST-OK]。
     無參數 URL 成功驗證後還會看到 [28-OWNER-DOM-VERIFIED]。
  4. 分別按「28Hse 租盤 API 測試」／「售盤 API 測試」。
     API 取號仍使用 ad_id，無詳情頁、無致電點擊；模擬測試不寫電話去重庫。
  5. 如果仍失敗，請提供 [28-TAB-WAIT] / [API-LEARN] / [API-VERIFY]
     / [28-API-TEST-ERROR] 附近的運行日誌。

注意：
  - 裸 /rent 或 /buy 頁面的「業主＋最新」不會被猜測；必須真正驗證。
  - 當網站人機驗證、HTTP 429、或沒有公開電話時，仍遵從原有保護策略。
  - 730 JSON Direct API、嚴格零開帖、Windows 鎖屏恢復等功能均保留。
  - 新版已通過離線／GUI 回歸測試，但未在使用者 Win10/BitBrowser 上實測。
