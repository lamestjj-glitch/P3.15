# -*- coding: utf-8 -*-
"""Offline integration checks: no browser, no API, no Tk display required."""
import ast
from pathlib import Path
from api_cadence import parse_api_cadence, display_api_cadence
from panda28_core import App

for value in ('0.5', '0.75', '1', '2.5', '7.25', '10', '30', '60', '120.125', '3600', '0.1', '0.01', '0.001', '3600.001', '7200', '999999'):
    assert parse_api_cadence(value) == float(value)
    assert parse_api_cadence(display_api_cadence(value)) == float(value)
for value in ('', '0', '-1', 'nan', 'inf', '1.1234', 'abc', None, True):
    try:
        parse_api_cadence(value)
    except ValueError:
        pass
    else:
        raise AssertionError('invalid interval accepted: %r' % (value,))
class Worker:
    api_poll_interval = App.api_poll_interval
    api_poll_seconds = {'rent':2.5, 'buy':7.25}
obj=Worker()
assert obj.api_poll_interval('rent')==2.5
assert obj.api_poll_interval('buy')==7.25
obj.api_poll_seconds['rent']=0.75
assert obj.api_poll_interval('rent')==0.75
# UI is an Entry (not readonly Combobox), and changes persist after Return/FocusOut.
gui = (Path(__file__).parent / 'unified_gui.py').read_text(encoding='utf-8')
assert gui.count('ttk.Entry(speeds, textvariable=self.api_') == 2
assert "rent_poll.bind('<Return>'" in gui and "buy_poll.bind('<FocusOut>'" in gui
assert "if not self._commit_28_api_intervals(show_error=True):" in gui
assert "data['api_rent_interval'] = display_api_cadence(self.api_poll_seconds['rent'])" in gui
assert "data['api_buy_interval'] = display_api_cadence(self.api_poll_seconds['buy'])" in gui
print('PASS: positive user intervals without 0.5~3600 hard bounds, precision, GUI save')
