# -*- coding: utf-8 -*-
"""Offline regression: a page response 429 must be shared across both lanes."""
import asyncio, threading
from house730_engine import record_page_429
from house730_adaptive_rate import SharedHouse730Rate

class Clock:
    def __init__(self): self.t = 1000.0
    def __call__(self): return self.t
    async def sleep(self, secs):
        self.t += secs
        await asyncio.sleep(0)

class Response:
    def __init__(self, status, headers=None):
        self.status=status; self.headers=headers or {}

async def run():
    t=Clock(); logs=[]; stop=threading.Event()
    g=SharedHouse730Rate(lambda:.15, stop, logs.append, clock=t, sleeper=t.sleep)
    assert record_page_429(Response(200),g,"租") is False
    assert not g.in_cooldown()
    async with g.slot("租"):
        assert record_page_429(Response(429,{'retry-after':'3600'}),g,"租")
        assert g.in_cooldown("租") and not g.in_cooldown("售")
        remaining=g._lane_429_until["租"]-t()
        assert 2.99 <= remaining <= 3.01
    before=t()
    async with g.slot("售"):
        assert t()-before < 1, 'unaffected deal may proceed immediately'
    async with g.slot("租"):
        assert t()-before >= 3, '429 deal should wait only 3 seconds'
    assert record_page_429(Response(403), g, "租") is False
    assert abs(g._requested() - .15) < .0001

    from pathlib import Path
    engine=Path('house730_engine.py').read_text(encoding='utf-8')
    assert 'if record_page_429(res, rate, deal):' in engine
    assert 'if record_page_429(reply, rate, deal):' in engine
    assert '[730-429-RELEARN]' in engine
    gui=Path('unified_gui.py').read_text(encoding='utf-8')
    assert 'V1.50.52' in gui and '本路短等3秒' in gui
    print('PASS 1.50.51: HTML/relearn 429 only source cooldown; no hours-long block')

if __name__=='__main__': asyncio.run(run())
