# -*- coding: utf-8 -*-
"""V1.50.57 offline checks: latest result immediately copies, no Ctrl+V dependency."""
import re
import threading
from types import SimpleNamespace
from paste_clipboard_queue import PasteClipboardQueue
from panda28_core import App
from unified_gui import UnifiedApp

class Clock:
    def __init__(self): self.t = 100.0
    def __call__(self): return self.t
    def go(self, dt): self.t += dt

clock = Clock()
state = {'text': '', 'seq': 10, 'busy': False}
log = []

def writer(value):
    if state['busy']:
        return False
    state['text'] = value
    state['seq'] += 1
    return True

q = PasteClipboardQueue(writer, lambda: state['seq'], log.append, clock=clock)
assert q.submit('5182', ('28','A')) == 'copied'
assert state['text'] == '5182'
# No Ctrl+V: new numbers immediately replace the previous tail.
assert q.submit('7228', ('730','B')) == 'copied'
assert state['text'] == '7228' and q.pending_count() == 0
assert q.submit('4109', ('28','C')) == 'copied'
assert state['text'] == '4109'
# Extra number for the OLD listing cannot overwrite the latest.
assert not q.extend(('28','A'), '5182\n2222')
assert state['text'] == '4109'
# Latest listing's supplement can be merged into a single multi-line text.
assert q.extend(('28','C'), '4109\n6773')
assert state['text'] == '4109\n6773'
# External clipboard edits are not overwritten by a delayed retry.
state['busy'] = True
assert q.submit('3869', ('28','D')) == 'queued'
assert state['text'] == '4109\n6773'
assert q.pending_count() == 1
state['seq'] += 1
state['text'] = 'PERSONAL NOTE'
clock.go(.2); q.poll()
assert state['text'] == 'PERSONAL NOTE'
assert q.paused_external
# The next genuinely NEW number can take clipboard ownership immediately.
state['busy'] = False
assert q.submit('9001', ('730','E')) == 'copied'
assert state['text'] == '9001'
# If clipboard is temporarily busy, the latest failed entry is retried.
state['busy'] = True
assert q.submit('1999', ('28','F')) == 'queued'
assert q.submit('2000', ('28','G')) == 'queued'
assert q.pending_count() == 1
state['busy'] = False
clock.go(.16); q.poll()
assert state['text'] == '2000' and q.pending_count() == 0
# Manual GUI copy always cancels queued work.
state['busy'] = True
assert q.submit('3000', ('28','H')) == 'queued'
q.manual_override(); state['busy'] = False
state['text'] = 'MANUALLY COPIED'; state['seq'] += 1
clock.go(.5); q.poll()
assert state['text'] == 'MANUALLY COPIED'

# Real 28Hse result path: a failed Windows clipboard write still saves full
# number dedup and reports pending, rather than falsely logging "已複製".
class Fake28:
    result = App.result
    _28_clipboard_key = App._28_clipboard_key
    _28_eligible_extra_phones = App._28_eligible_extra_phones
    def __init__(self):
        self.seen_phones=set(); self.pending_copy_phones=set()
        self.phone_lock=threading.Lock()
        self.clipboard_deferred_lock=threading.RLock()
        self.clipboard_copy_generation=0
        self.clipboard_error_local=SimpleNamespace(error='busy', queued=False)
        self._auto_clipboard=object()
        self.run_id=1; self.running=True
        self.logs=[]; self.jobs=[]
        self.latest_28_clipboard_group=None
    def normalize_phone(self, v): return re.sub(r'\D','',str(v or ''))
    def pid_of(self, v): return str(v).split('-')[-1]
    def copy_auto_text(self, text, *, listing_key):
        self.clipboard_copy_generation+=1
        self.clipboard_error_local.queued=True
        self.clipboard_error_local.error='OpenClipboard busy'
        return False
    def copy_text(self, text): raise AssertionError('unexpected manual copy')
    def clean_contact_name(self, x): return x
    def initial_wa_status(self, **kw): return '未聯絡'
    def bg(self, fn, *args): self.jobs.append((fn,args))
    def save_seen_phones_deferred(self): pass
    def after(self, delay, fn): pass
    def write(self, line): self.logs.append(line)
    def set_listing_status(self,*args): pass
    def remove_duplicate_listing_row(self,*args): pass

f=Fake28(); url='https://www.28hse.com/rent/shop/property-3705702'
ok,msg=f.result('rent','未知','91395182',url)
assert ok and '背景補複製' in msg, (ok,msg)
assert '91395182' in f.seen_phones and '91395182' not in f.pending_copy_phones
assert any('[CLIPBOARD-PENDING]' in x for x in f.logs)
assert not any('已立即複製' in x for x in f.logs)
assert f.result('rent','未知','91395182',url)[0] is False

# GUI callback for 730: clipboard MUST be updated before any row/UI work.
class Holder:
    def __init__(self,value): self.value=value
    def set(self,val): self.value=val
    def get(self): return self.value
class Fake730:
    def __init__(self):
        self.events=[];self.latest_phone=Holder('');self.house_session=0
        self.house_popup=Holder(False);self.wa_730_enable=Holder(False)
        self.clipboard_error_local=SimpleNamespace(queued=False)
    def copy_auto_text(self, text, *, listing_key):
        self.events.append(('copy',text)); return True
    def _show_house_row(self, data): self.events.append(('row',data['pid']))
    def write(self,msg): pass
    def update_row_field(self,*args): pass

h=Fake730()
UnifiedApp._new_house_result(h, {'phone':'98887228','deal':'租','pid':'123','url':'test'})
assert h.events == [('copy','7228'),('row','123')],h.events
print('PASS V1.50.57: latest-copy-now, busy retry, external/manual guard, 28 durable dedup, 730 clipboard-first')
