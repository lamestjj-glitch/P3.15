@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
if errorlevel 1 goto launch_failed
if not exist "WINDOWS_LAUNCH.ps1" goto launch_failed
if not exist "bootstrap.py" goto launch_failed
powershell.exe -NoProfile -NoLogo -ExecutionPolicy Bypass -File "%~dp0WINDOWS_LAUNCH.ps1"
set "EXIT_CODE=%ERRORLEVEL%"
if "%EXIT_CODE%"=="0" exit /b 0
echo.
echo [ERROR] PandaMonitor did not start. Exit code: %EXIT_CODE%
echo Run DIAG_PYTHON.bat to check every installed Python and Tkinter.
echo If Python or Tkinter is missing, run INSTALL_PYTHON_313.bat.
echo Please send python_diag.log or the latest startup.log and start_console.log files.
echo Log folder: %LOCALAPPDATA%\PandaMonitor_28Hse_House730\logs
echo.
pause
exit /b %EXIT_CODE%
:launch_failed
echo [ERROR] Program files missing or folder could not be opened.
echo Extract the complete ZIP to a normal folder and run START.bat again.
pause
exit /b 1
