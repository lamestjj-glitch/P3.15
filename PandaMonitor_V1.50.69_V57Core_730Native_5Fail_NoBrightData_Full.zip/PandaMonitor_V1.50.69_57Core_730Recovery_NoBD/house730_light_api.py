# -*- coding: utf-8 -*-
"""Experimental low-overhead House730 list polling through the browser's own XHR.

A request template is *learned* from each genuine list load. No request signatures,
body parameters, sessions or tokens are guessed or saved to disk. This is not an
official API integration and may stop working if the website changes.

There is one request at a time per list, a configurable interval, and mandatory
backoff on 429/403/503. Does not work around CAPTCHA or platform rate limits.
"""
from __future__ import annotations
import asyncio
import json
import re
import time
from urllib.parse import urlparse, quote, unquote
from email.utils import parsedate_to_datetime
from datetime import datetime, timezone

API_HOST = 'api.house730.com'
API_PATH = '/Property/QueryProperty'
MAX_BODY = 1_500_000
URL_RE = re.compile(r'(?:(?:https?:)?//(?:www\.)?house730\.com)?/(rent|buy)-property-(\d+)(?:/[^\s"<>?#\\]*)?', re.I)
# These are application-provided request headers, not browser-generated headers.
# The previous build dropped e.g. 'appkey', 'appsignature' and 'language'
# even when the real page explicitly provided them.  Keep them only in RAM.
APP_HEADERS = frozenset(('accept', 'content-type', 'authorization', 'x-requested-with',
  'language', 'lang', 'platform', 'cityen', 'appkey', 'appsignature',
  'app-key', 'app-signature', 'appversion', 'version', 'timestamp',
  'apptimestamp', 'clientid', 'channel', 'region', 'locale', 'apikey'))
# No Host / Cookie / Origin / Referer / UA / browser-owned sec-* headers.



class PollError(RuntimeError):
    def __init__(self, message, status=0, cooldown=0, kind='other', retry_after=0):
        super().__init__(message)
        self.status = status
        self.cooldown = cooldown
        self.kind = kind
        self.retry_after = retry_after


def parse_retry_after(raw, *, now=None):
    """Seconds or HTTP-date, never a fabricated delay; zero if unrecognized."""
    if not raw:
        return 0.0
    value = str(raw).strip()
    if value.isdigit():
        return float(min(int(value), 86400 * 7))
    try:
        date = parsedate_to_datetime(value)
        if date.tzinfo is None:
            date = date.replace(tzinfo=timezone.utc)
        return max(0.0, min(86400.0 * 7,
                    date.timestamp() - (datetime.now(timezone.utc).timestamp() if now is None else now)))
    except (TypeError, ValueError, OverflowError):
        return 0.0


def safe_json_shape(raw: str) -> str:
    """Non-sensitive diagnostic: structure only, NEVER request or response values."""
    try:
        obj = json.loads(raw)
    except (ValueError, TypeError):
        return 'not-json'
    def keys(d):
        return ','.join(str(k) for k in list(d)[:10]
                        if re.fullmatch(r'[A-Za-z_][A-Za-z_0-9]{0,40}', str(k)))
    if isinstance(obj, list):
        return f'list length={len(obj)}'
    if not isinstance(obj, dict):
        return type(obj).__name__
    result = 'root keys=' + keys(obj)
    for label in ('data', 'Data', 'result', 'Result', 'records', 'Rows', 'list', 'List'):
        child = obj.get(label)
        if isinstance(child, list):
            return f'{result}; {label}=list[{len(child)}]'
        if isinstance(child, dict):
            return f'{result}; {label}=object keys=' + keys(child)
    return result


def parse_listing_urls(raw: str, expected: str) -> list[str]:
    """Extract genuine listing URLs only, in response order, never agent/user URLs."""
    try:
        parsed = json.loads(raw)
    except (json.JSONDecodeError, TypeError, ValueError):
        raise PollError('返回內容不是 JSON（API 可能已改版或發生驗證）')
    # JSON validity still checked above. Most genuine replies contain direct
    # URL strings; scan the original bytes once instead of re-serializing a
    # potentially 1.5MB object on each high-frequency poll. For responses with
    # escaped separators, retain the original lossless decoded search path.
    if r'\/' in raw or r'\u002f' in raw.lower():
        text = json.dumps(parsed, ensure_ascii=False, separators=(',', ':'))
    else:
        text = raw
    expect = 'rent' if expected == '租' else 'buy'
    seen = set()
    result = []
    for m in URL_RE.finditer(text):
        if m.group(1).lower() != expect:
            continue
        url = m.group(0)
        if url.startswith('//'):
            url = 'https:' + url
        if url.startswith('/'):
            url = 'https://www.house730.com' + url
        # never change the listed slug; keep the same canonicalization as V53.
        p = urlparse(url)
        if p.hostname not in ('house730.com', 'www.house730.com'):
            continue
        clean = f'https://www.house730.com{quote(unquote(p.path), safe="/-._~")}'
        if clean not in seen:
            seen.add(clean)
            result.append(clean)
        if len(result) >= 200:
            break
    return result


class House730LightAPI:
    def __init__(self, page, deal: str, *, prefer_native: bool = False):
        self.page = page
        self.deal = deal
        self.template = None
        self.last_capture_at = None
        self.calls = 0
        self.inflight = asyncio.Lock()
        self.latest_http_status = None
        self.bad_response_count = 0
        self._closed = False
        self._internal_query = False
        # V1.50.33: In a shared 28Hse/730 browser the page's Runtime.evaluate
        # may become congested. Playwright's BrowserContext.request uses the
        # SAME browser-session cookies but never invokes this page's renderer.
        # This is an alternative transport for the SAME, already-learned URL,
        # headers and body; it is NOT a different API or an auth workaround.
        # If the native transport is incompatible, fall back to browser fetch
        # on the NEXT cycle (never issue two simultaneous list requests).
        self.transport = 'native' if prefer_native else 'browser'
        self.native_failed = False
        self.native_validated = False  # Only a previously successful native list may be retried.
        self.native_shape_rejected = False
        self.next_native_recovery_at = 0.0
        self.last_query_elapsed_ms = 0
        self.last_query_transport = ''
        self.template_header_names = ()
        page.on('request', self._on_request)

    def _on_request(self, request):
        if self._closed or self._internal_query:
            return  # Do not re-learn the template from our own replayed fetch.
        try:
            p = urlparse(request.url)
            if p.hostname != API_HOST or p.path.rstrip('/') != API_PATH:
                return
            if request.resource_type not in ('xhr', 'fetch'):
                return
            method = request.method.upper()
            if method not in ('GET', 'POST'):
                return
            # Headers from the active browsing session are only stored in RAM.
            # The browser itself supplies origin, cookies and UA on fetch.
            headers = {}
            for k, v in request.headers.items():
                kl = k.lower()
                if kl in APP_HEADERS or kl.startswith('x-'):
                    headers[k] = v
            # This is a FIX: unlike 1.47.5, preserve site-defined, non-X- headers
            # which its XHR may require. Never log values and never store to disk.
            self.template_header_names = tuple(sorted(k.lower() for k in headers))
            self.template = {
                'url': request.url,
                'method': method,
                'body': request.post_data if method != 'GET' else None,
                'headers': headers,
            }
            self.last_capture_at = time.monotonic()
        except Exception:
            pass

    @property
    def ready(self):
        return bool(self.template)

    async def _browser_query(self, params):
        return await self.page.evaluate('''async p => {
          const ctl = new AbortController();
          const timer = setTimeout(() => ctl.abort(), p.timeout_ms);
          try {
            const opts = {
              method: p.method, headers: p.headers,
              cache: 'no-store', mode: 'cors', credentials: 'include',
              signal: ctl.signal
            };
            if (p.method !== 'GET' && p.body != null) opts.body = p.body;
            const res = await fetch(p.url, opts);
            const txt = await res.text();
            return { status: res.status, content_type: res.headers.get('content-type') || '',
                     body: txt.slice(0, p.max_body), truncated: txt.length > p.max_body,
                     host: new URL(res.url).hostname, retry_after: res.headers.get('retry-after') || '' };
          } finally { clearTimeout(timer); }
        }''', params)

    async def _native_query(self, params):
        # No new tab, no user-visible navigation and no Runtime.evaluate.
        # BrowserContext.request shares cookies with the existing CDP session.
        # Never persist credentials, request headers, body or response bytes.
        context = getattr(self.page, 'context', None)
        api_request = getattr(context, 'request', None)
        if api_request is None:
            raise RuntimeError('BrowserContext.request unavailable')
        headers = dict(params.get('headers') or {})
        # A page-origin request normally sets Origin/Referer automatically.
        # The native request uses this *known* site origin, not a forged session.
        headers.setdefault('Origin', 'https://www.house730.com')
        existing_page_url = str(getattr(self.page, 'url', '') or '')
        if existing_page_url.startswith('https://www.house730.com/'):
            headers.setdefault('Referer', existing_page_url)
        kwargs = dict(method=params['method'], headers=headers,
                      timeout=params['timeout_ms'], max_redirects=0)
        if params['method'] != 'GET' and params.get('body') is not None:
            kwargs['data'] = params['body']
        response = await api_request.fetch(params['url'], **kwargs)
        # Read body only once. Never follow a redirect to an unverified host.
        body_bytes = await response.body()
        truncated = len(body_bytes) > params['max_body']
        body = body_bytes[:params['max_body']].decode('utf-8', errors='replace')
        return {'status': response.status,
                'content_type': response.headers.get('content-type', ''),
                'body': body, 'truncated': truncated,
                'host': urlparse(response.url).hostname,
                'retry_after': response.headers.get('retry-after', '')}

    async def query(self, *, timeout_ms: int = 15000) -> list[str]:
        if self._closed or not self.ready or self.page.is_closed():
            raise PollError('沒有可用的列表請求模板；需要重新載入列表取得')
        # One source / one inflight HTTP query. No fallback HTTP request is
        # started in the same cycle when a transport fails or times out.
        async with self.inflight:
            params = {**self.template, 'timeout_ms': timeout_ms, 'max_body': MAX_BODY}
            self._internal_query = True
            used = self.transport
            started_at = time.perf_counter()
            try:
                if used == 'native':
                    result = await self._native_query(params)
                else:
                    result = await self._browser_query(params)
            except Exception as exc:
                closed = self.page.is_closed() or type(exc).__name__ in ('TargetClosedError','ConnectionClosedError')
                if used == 'native' and not closed:
                    self.transport = 'browser'
                    self.native_failed = True
                    raise PollError('原生請求通道未能完成，下一輪恢復原瀏覽器 API；沒有立即重發',
                                    cooldown=3, kind='native-transport') from exc
                kind = 'closed' if closed else 'browser-execution'
                # A renderer/CDP failure can last for minutes while the browser's
                # independent request context remains healthy. Only try the native
                # route if it was confirmed to work with this genuine template.
                # Never re-probe a rejected JSON shape or retry in this same cycle.
                if (used == 'browser' and not closed and self.native_validated
                    and not self.native_shape_rejected
                    and time.monotonic() >= self.next_native_recovery_at):
                    self.transport = 'native'
                    self.next_native_recovery_at = time.monotonic() + 45.0
                # The old code merged browser Runtime errors with site network,
                # CORS and 429, then suspended BOTH sources for >=20 seconds.
                # Keep genuine HTTP 403/429 separate (they are handled below).
                raise PollError('730瀏覽器 API 執行失敗（CDP/頁面或網絡，非HTTP限流）: ' + type(exc).__name__,
                                cooldown=3, kind=kind) from exc
            finally:
                self._internal_query = False
            self.calls += 1
            status = int(result.get('status') or 0)
            self.latest_http_status = status
            if status in (401, 403, 429):
                raise PollError(f'列表接口 HTTP {status}，暫停查詢並等待網站限制解除',
                                status=status, cooldown=180,
                                retry_after=parse_retry_after(result.get('retry_after')))
            if status in (500, 502, 503, 504):
                raise PollError(f'列表接口 HTTP {status}，稍後重試', status=status, cooldown=60)
            if not (200 <= status <= 299):
                raise PollError(f'列表接口 HTTP {status}', status=status, cooldown=30)
            if result.get('host') != API_HOST:
                raise PollError('列表接口發生重定向，不採用該輪資料', cooldown=60)
            if 'json' not in str(result.get('content_type') or '').lower():
                raise PollError('列表接口沒有回傳 JSON', cooldown=60)
            if result.get('truncated'):
                raise PollError('JSON 返回量超出安全上限，本輪跳過', cooldown=60)
            urls = parse_listing_urls(result.get('body') or '', self.deal)
            if not urls:
                self.bad_response_count += 1
                body = result.get('body') or ''
                summary = safe_json_shape(body)
                opposite = '售' if self.deal == '租' else '租'
                other_count = len(parse_listing_urls(body, opposite))
                if other_count:
                    summary += f'; 有其他交易類型樓盤={other_count}'
                if used == 'native':
                    # The native transport may not be accepted by this server.
                    # Preserve original request template, use existing browser
                    # transport NEXT round rather than reloading user tabs.
                    self.transport = 'browser'
                    self.native_failed = True
                    self.native_shape_rejected = True
                    raise PollError('原生通道JSON未通過本類型列表驗證（' + summary + '）；退回原瀏覽器API',
                                    cooldown=3, kind='native-shape')
                raise PollError('HTTP 200 但 JSON 沒有本類型樓盤連結（' + summary + '）；改用 HTML 備援',
                                kind='invalid-json-list')
            self.bad_response_count = 0
            self.last_query_elapsed_ms = round((time.perf_counter() - started_at) * 1000)
            self.last_query_transport = used
            if used == 'native':
                self.native_validated = True
                self.native_failed = False
            return urls

    def detach(self):
        self._closed = True
        try:
            self.page.remove_listener('request', self._on_request)
        except Exception:
            pass
