# -*- coding: utf-8 -*-
"""V1.50.1 regression: sub-second config, SG premium panel, open-tab capture."""
import tempfile
import threading
import unittest
from pathlib import Path
from site_engine import SiteConfigStore, SiteManager, DEFAULT_BFS, validate_site
from site_plugins.businessforsale_sg import extract_contacts, accept_detail

PANEL = """<html><body><div>Direct Seller</div><div>Seller Contact &amp; Listing Information</div>
<div><span>Contact Person</span><div>LCS</div></div><div><span>Mobile Number</span>
<span>+6588539898</span></div><div>Email Address</div>
<form><label>Mobile Number</label><input value='91234567'></form>
</body></html>"""

class NewTests(unittest.TestCase):
    def test_decimal_values(self):
        for interval in ['0.1','0.5','0.8','1','1.25','15.75','3600']:
            cfg=validate_site(dict(DEFAULT_BFS,interval=interval))
            self.assertAlmostEqual(cfg['interval'],float(interval))
            with tempfile.TemporaryDirectory() as d:
                store=SiteConfigStore(d)
                store.save([cfg]);self.assertEqual(store.load()[0]['interval'],float(interval))
        for interval in ['nan','inf','-1','0','0.09','', 'abc', '3600.01']:
            with self.assertRaises(ValueError):validate_site(dict(DEFAULT_BFS,interval=interval))

    def test_upgrade_v150_preset(self):
        with tempfile.TemporaryDirectory() as d:
            store=SiteConfigStore(d)
            cfg=dict(DEFAULT_BFS,mode='http',interval=15)
            cfg.pop('bitbrowser_seq',None)
            store.save([cfg])
            import json
            # Actual v1.50.0 configs have no bitbrowser_seq, simulate manually.
            conf=json.loads(store.path.read_text(encoding='utf-8'))
            conf['sites'][0].pop('bitbrowser_seq',None)
            store.path.write_text(json.dumps(conf),encoding='utf-8')
            upgraded=store.load()[0]
            self.assertEqual(upgraded['mode'],'bitbrowser')
            self.assertEqual(upgraded['bitbrowser_seq'],173)
            self.assertEqual(upgraded['interval'],1.0)

    def test_seller_panel_text_not_enquiry_input(self):
        self.assertTrue(accept_detail(PANEL,'https://www.businessforsale.sg/businesses-for-sale/foo-42769',DEFAULT_BFS))
        contacts=extract_contacts(PANEL,'https://www.businessforsale.sg/businesses-for-sale/foo-42769',DEFAULT_BFS)
        self.assertEqual(contacts,[{'phone':'+6588539898','name':'LCS'}])
        only_form='<div>Direct Seller</div><form><label>Mobile Number</label><input value="+6588539898"></form>'
        self.assertEqual(extract_contacts(only_form,'',DEFAULT_BFS),[])

    def test_manually_opened_tab(self):
        with tempfile.TemporaryDirectory() as d:
            mgr=SiteManager(SiteConfigStore(d))
            class FakeFetcher:
                def open_details(self,cfg):
                    return [('https://www.businessforsale.sg/businesses-for-sale/foo-42769',PANEL)]
            from site_plugins import businessforsale_sg
            manual=set()
            mgr._scan_open_detail_tabs(FakeFetcher(),businessforsale_sg,DEFAULT_BFS,manual)
            self.assertEqual(len(manual),1)
            evt=mgr.out.get_nowait()
            self.assertEqual(evt['event'],'new')
            self.assertEqual(evt['data']['phone'],'+6588539898')
            mgr._scan_open_detail_tabs(FakeFetcher(),businessforsale_sg,DEFAULT_BFS,manual)
            # Second time is a log from first pass, not a second new.
            while not mgr.out.empty():
                self.assertNotEqual(mgr.out.get_nowait()['event'],'new')

if __name__=='__main__':unittest.main(verbosity=2)
