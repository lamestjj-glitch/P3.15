# -*- coding: utf-8 -*-
"""V1.50.45: atomic main+extra tails and latest-wins late supplementary phones."""
import re
import threading
from types import SimpleNamespace
from panda28_core import App

URL = 'https://www.28hse.com/buy/apartment/property-3871960'
OTHER = 'https://www.28hse.com/buy/apartment/property-3871961'

class Fake:
    result = App.result
    publish_secondary_phone = App.publish_secondary_phone
    _28_eligible_extra_phones = App._28_eligible_extra_phones
    _28_clipboard_key = App._28_clipboard_key
    _28_add_extra_to_clipboard = App._28_add_extra_to_clipboard
    _28_defer_group_clipboard_locked = App._28_defer_group_clipboard_locked
    _28_retry_group_clipboard_after_lock = App._28_retry_group_clipboard_after_lock

    def __init__(self):
        self.copied=[]
        self.logs=[]
        self.seen_phones=set()
        self.pending_copy_phones=set()
        self.phone_lock=threading.RLock()
        self.clipboard_deferred_lock=threading.RLock()
        self.clipboard_error_local=SimpleNamespace(error='')
        self.clipboard_copy_generation=0
        self.latest_28_clipboard_group=None
        self.run_id=1
        self.running=True
        self.jobs=[]
        self.last_ui=None
        self.fail_copy_once=False

    def normalize_phone(self, v): return re.sub(r'\D', '', str(v or ''))
    def pid_of(self, url):
        match=re.search(r'property-(\d+)',str(url or ''))
        return match.group(1) if match else ''
    def write(self, msg):self.logs.append(msg)
    def clean_contact_name(self, name):return name
    def initial_wa_status(self, **kwargs):return '未聯絡'
    def after(self, ms, action): self.last_ui=action
    def bg(self, fn, *args): self.jobs.append((fn,args))
    def save_seen_phones_deferred(self):pass
    def _copy_text_raw(self, text):
        if self.fail_copy_once:
            self.fail_copy_once=False
            self.clipboard_error_local.error='busy'
            return False
        self.copied.append(text)
        self.clipboard_error_local.error=''
        return True
    def copy_text(self, text):
        with self.clipboard_deferred_lock:
            self.clipboard_copy_generation+=1
            return self._copy_text_raw(text)

# The exact two rows in the screenshot: supplementary 95116993, primary 98261369.
a=Fake()
ok,_=a.result('buy','未知','98261369',URL,
              extra_phones=[{'phone':'95116993'}, {'phone':'98261369'}])
assert ok and a.copied==['1369\n6993'],a.copied
# The supplementary row is persisted later; no redundant second clipboard write.
assert a.publish_secondary_phone('buy',URL,'未知','95116993')
assert a.copied==['1369\n6993'],a.copied
assert {'98261369','95116993'}<=a.seen_phones

# A phone learned later joins the same listing; one line per phone, main first.
b=Fake(); assert b.result('buy','未知','98261369',URL)[0]
assert b.copied==['1369']
assert b.publish_secondary_phone('buy',URL,'未知','95116993')
assert b.copied==['1369','1369\n6993'],b.copied
assert not b.publish_secondary_phone('buy',URL,'未知','95116993')
assert b.copied[-1]=='1369\n6993'

# NEWER listing must not be replaced by a delayed supplementary number.
c=Fake(); assert c.result('buy','未知','98261369',URL)[0]
assert c.result('buy','未知','98450000',OTHER)[0]
assert c.publish_secondary_phone('buy',URL,'未知','95116993')
assert c.copied==['1369','0000'],c.copied

# Manual clipboard copies must not be overwritten by late supplementary numbers.
d=Fake(); assert d.result('buy','未知','98261369',URL)[0]
d.copy_text('98261369')
assert d.publish_secondary_phone('buy',URL,'未知','95116993')
assert d.copied==['1369','98261369'],d.copied

# Invalid / already used / repeated numbers are never included in the composite.
e=Fake(); e.seen_phones.add('94230000')
assert e.result('buy','未知','98261369',URL,
                extra_phones=['29995555','39997777','94230000','95116993','95116993'])[0]
assert e.copied==['1369\n6993'],e.copied

# No supplementary number: original behavior unchanged.
f=Fake(); assert f.result('buy','未知','98261369',URL)[0]
assert f.copied==['1369'],f.copied

# After a failed copy (Windows locked), later extra must be joined in the
# recovery payload, never cause only the stale single tail to be written.
g=Fake()
g.fail_copy_once=True
assert g.result('buy','未知','98261369',URL)[0] is False
# Fake on POSIX does not schedule Windows lock retry; mimic the late merge.
assert g.publish_secondary_phone('buy',URL,'未知','95116993')
assert g.copied==['1369\n6993'],g.copied

print('PASS V1.50.45: atomic main+extra, late-merge, duplicate filter, newer-post/manual latest wins')

# Windows clipboard temporarily busy: the supplementary merge is retried with
# the latest complete group, not an obsolete single-phone payload.
import panda28_core as core
old_os, old_locked = core.os, core.windows_session_locked
try:
    core.os = SimpleNamespace(name='nt')
    core.windows_session_locked = lambda: False
    busy = Fake()
    assert busy.result('buy','未知','98261369',URL)[0]
    busy.fail_copy_once = True
    assert busy.publish_secondary_phone('buy',URL,'未知','95116993')
    assert busy.copied == ['1369']
    retry_jobs=[(fn,args) for fn,args in busy.jobs
                if getattr(fn,'__name__','')=='_28_retry_group_clipboard_after_lock']
    assert len(retry_jobs)==1,retry_jobs
    fn,args=retry_jobs[0]
    fn(*args)
    assert busy.copied == ['1369','1369\n6993'],busy.copied
    # An intervening manual copy cancels this repair without an overwrite.
    stale = Fake(); assert stale.result('buy','未知','98261369',URL)[0]
    stale.fail_copy_once=True
    assert stale.publish_secondary_phone('buy',URL,'未知','95116993')
    job=[(fn,args) for fn,args in stale.jobs
         if getattr(fn,'__name__','')=='_28_retry_group_clipboard_after_lock'][0]
    stale.copy_text('other listing or user copy')
    job[0](*job[1])
    assert stale.copied==['1369','other listing or user copy'],stale.copied
finally:
    core.os, core.windows_session_locked = old_os, old_locked
print('PASS V1.50.45: Win10 busy clipboard retry combines tails and honors latest-wins')
