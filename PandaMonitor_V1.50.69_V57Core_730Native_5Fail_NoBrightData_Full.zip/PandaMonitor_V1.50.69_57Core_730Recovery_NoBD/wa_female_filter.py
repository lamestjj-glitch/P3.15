# -*- coding: utf-8 -*-
"""Conservative, name-based opt-in eligibility for automatic WA greetings.

A name or honorific is not proof of gender. Unknown/ambiguous contacts are
never automatically greeted; this does not filter listings or phones.
"""
import re

MAX_FEMALE_NAMES = 100_000
MAX_NAME_FILE_BYTES = 2_000_000

# An explicitly approved alias must still work when a large imported TXT
# replaces the built-in short list. Other imported names remain opt-in.
EXPLICIT_CONTACT_ALIASES = frozenset({"may"})

DEFAULT_FEMALE_NAMES = "Alice, Mandy, Amy, Emily, Jessica, Sophie, Sarah, Linda, Anna, Mary, Susan, Jenny, Lily, Wendy, Fiona, Angela, Grace, Cindy, Karen, Michelle, Kelly, Nicole, Lucy, Helen, Daisy, Ivy, May"


def parse_female_names(raw):
    tokens = re.split(r"[,，;；\n]+", str(raw or ""))
    if len(tokens) > MAX_FEMALE_NAMES + 1:
        raise ValueError("女性英文名清單過長（最多100,000個名字）")
    result = set()
    for item in tokens:
        name = item.strip()
        if not name:
            continue
        if not re.fullmatch(r"[A-Za-z]{2,24}", name):
            raise ValueError("英文名請以英文、逗號分隔（不包括姓氏）")
        result.add(name.casefold())
        if len(result) > MAX_FEMALE_NAMES:
            raise ValueError("女性英文名清單過長（最多100,000個名字）")
    if not result:
        raise ValueError("女性英文名清單不能為空")
    return frozenset(result)


def female_name_eligible(contact_name, allowed_names=None):
    """Return (eligible, reason), never infer from empty or merely a surname."""
    name = " ".join(str(contact_name or "").strip().split())
    if not name or name.casefold() in {
        "未知", "未提供", "待補充", "补充中…", "補充中…", "unknown",
        "n/a", "none", "null", "—", "-", "業主", "业主", "owner", "landlord",
    }:
        return False, "姓名未知"
    # Explicit male honorific overrides other keywords, preventing mixed texts
    # or malformed contact names from triggering unsolicited WA.
    # Hong Kong shorthand "劉生 / 陳生" means 先生. It must override e.g.
    # "劉生 CHERRY" even if CHERRY is present in the imported female-name TXT.
    if re.search(r"先生|[\u3400-\u9fff]生(?=$|[\s,，、(（]|[A-Za-z])|(?<![A-Za-z])(?:mr|mister)(?![A-Za-z])", name, flags=re.I):
        return False, "有男性稱謂"
    if name == "姐" or re.search(r"小姐|女士|[\u3400-\u9fff]{1,5}太(?:太)?(?=$|[\s，,、（(]|[A-Za-z])|(?<=\S)姐(?=$|[\s，,、（(])", name):
        return True, "女性稱謂"
    if re.search(r"(?<![A-Za-z])(?:mrs|ms|miss)(?![A-Za-z])", name, flags=re.I):
        return True, "女性英文稱謂"
    if allowed_names is None:
        allowed_names = parse_female_names(DEFAULT_FEMALE_NAMES)
    words = {word.casefold() for word in re.findall(r"[A-Za-z]+", name)}
    if words & set(allowed_names):
        return True, "女性英文名清單"
    # '張小姐 May' passes by the honorific even without this branch, but the
    # genuine contact API sometimes supplies only contactNameEN='May'. Preserve
    # that specific user-approved name after importing a replacement TXT list.
    if words & EXPLICIT_CONTACT_ALIASES:
        return True, "指定英文別名 May"
    return False, "非女性名單／無法判定"


def read_female_names_txt(path):
    """Read a bounded user-supplied TXT, UTF-8/UTF-8-BOM or Unicode BOM.

    Each name may be on its own line or separated by comma / semicolon.
    Deduplicate case-insensitively. Never store a huge list in config.json.
    """
    from pathlib import Path
    raw = Path(path).read_bytes()
    if len(raw) > MAX_NAME_FILE_BYTES:
        raise ValueError("TXT 超過 2MB，請只保留英文名字")
    if raw.startswith((b"\xff\xfe", b"\xfe\xff")):
        content = raw.decode("utf-16")
    else:
        try:
            content = raw.decode("utf-8-sig")
        except UnicodeDecodeError as exc:
            raise ValueError("TXT 請存成 UTF-8（可帶 BOM）或 UTF-16") from exc
    return parse_female_names(content)
