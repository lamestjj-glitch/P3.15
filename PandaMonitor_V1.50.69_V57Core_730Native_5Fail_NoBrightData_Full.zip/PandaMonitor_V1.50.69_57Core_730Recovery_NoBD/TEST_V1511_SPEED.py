# -*- coding: utf-8 -*-
"""No live websites / browser required: safe PhoneFirst performance regression."""
import asyncio
import time
from house730_engine import PrivateDetailLane
from house730_phone_first import DetailPhoneCapture, fast_phone_first, is_phone_api


class FakePage:
    def __init__(self):
        self.closed = False
        self.urls = []
        self.handlers = {}
    async def goto(self, url, **opts):
        self.urls.append((url, opts.get('wait_until')))
    def is_closed(self):
        return self.closed
    async def close(self):
        self.closed = True
    def on(self, ev, f):
        self.handlers.setdefault(ev, []).append(f)
    def remove_listener(self, ev, f):
        self.handlers[ev].remove(f)
    def emit(self, ev, arg):
        for fn in list(self.handlers.get(ev, [])):
            fn(arg)


class FakeContext:
    def __init__(self):
        self.pages = []
    async def new_page(self):
        page = FakePage()
        self.pages.append(page)
        return page


class FakeResponse:
    status=200
    url='https://api.house730.com/Property/GetPropertyUserInfoById?PropertyId=123456'
    async def json(self):
        return {'result':[{'isShowTel':True,'telphone':'61822314','customerTel':'',
                           'contactNameCN':'女士','isVirtualNumber':False}]}


class FakeRequest:
    url=FakeResponse.url


class Waiter:
    def __init__(self, requested=0, blocked_http=None):
        self.requested=requested
        self.blocked_http=blocked_http
        self.calls=[]
    async def first(self, timeout):
        self.calls.append(timeout)
        return []


async def run():
    context=FakeContext()
    lane=PrivateDetailLane(context)
    first=await lane.acquire()
    assert len(context.pages)==1
    again=await lane.acquire()
    assert first is again and again.urls==[('about:blank','commit')]
    await lane.discard()
    assert first.closed
    next_page=await lane.acquire()
    assert next_page is not first and len(context.pages)==2
    await lane.discard()

    page=FakePage()
    capture=DetailPhoneCapture(page).start()
    assert is_phone_api(FakeResponse.url)
    page.emit('request',FakeRequest())
    page.emit('response',FakeResponse())
    phones=await capture.first(timeout=.2)
    assert phones == [('女士','61822314')], phones
    t0=time.monotonic()
    await capture.close()
    assert time.monotonic()-t0 < .09, 'listener shutdown must NOT sleep 120ms'
    assert page.handlers['request']==[] and page.handlers['response']==[]

    absent=Waiter()
    await fast_phone_first(absent)
    assert absent.calls == [2.0], absent.calls
    inflight=Waiter(requested=1)
    await fast_phone_first(inflight)
    assert inflight.calls == [2.0,1.5], inflight.calls
    blocked=Waiter(requested=1,blocked_http=429)
    await fast_phone_first(blocked)
    assert blocked.calls == [2.0], blocked.calls
    print('PASS V1.50.11: reuse private tab, blank separation, API capture, safe fallback, zero fixed close delay')

if __name__=='__main__':
    asyncio.run(run())
