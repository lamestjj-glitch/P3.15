# -*- coding: utf-8 -*-
"""Offline V1.50.28 regression: 429, browser transport and response clocks."""
import inspect
from hse28_adaptive import AdaptiveListScheduler
from panda28_core import App
from panda28_api import api_snapshot
from hse28_429_cooldown import RateCooldown

s = AdaptiveListScheduler()
assert s.report()['gap_ms'] == 0
# No progressive slowdown: transient CDP errors keep requested rate unchanged.
for _ in range(12): assert s.transport_timeout()==0
for _ in range(12): s.slow_or_timeout('timeout')
for _ in range(6): s.success()
s.rate_limited(); s.transport_timeout(); s.slow_or_timeout('network')
assert s.report()['gap_ms']==0 and s.report()['rate_hits']==1
assert RateCooldown(jitter=lambda: 0).rate_limited('25')[0] >= 24.9
# The log must no longer call FIFO wait time 'API response latency'.
w = inspect.getsource(App.worker)
assert 'queue_wait_ms=' in w and 'round_ms=' in w and 'api_call_t0' in w
assert 'elapsed_ms=int((poll_done_at-api_call_t0)*1000)' in w
assert '排隊 %dms · 整輪 %dms' in w
assert 'self.api_adaptive_scheduler.transport_timeout()' in w
assert 'next_tab_healthcheck' in w and 'time.monotonic() + 10.0' in w
assert 'last_browser_info.get(\'id\') != tid' in w
assert 'self.phone_jobs[k].put((u,detected_t0))' in w
phone = inspect.getsource(App.phone_worker)
assert 'self.http_phone_direct' in phone and 'api_adaptive_scheduler.lease' not in phone
snap = inspect.getsource(api_snapshot)
assert 'owner_lock' in snap and 'fetch(__URL__' in snap
print('PASS V1.50.28: 429 preserved, CDP isolated, fixed cadence, queue-vs-API timing, reduced debugger probes, direct phone unchanged')
