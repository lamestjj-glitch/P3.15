# -*- coding: utf-8 -*-
"""852.house owner/contact offline regressions; rent+buy, hydrated+partial HTML."""
import unittest
from site_plugins.house852_owner import accept_detail, extract_contacts, extract_listings

U = ('https://852.house/zh/{kind}?price=0%3B90000&grossarea=0%3B90000'
     '&features%5B0%5D=%E6%A5%AD%E4%B8%BB%E7%9B%A4&order=publishtime%7Cdesc')

class Tests(unittest.TestCase):
    def detail(self, n, full=True, agent=False):
        return (f'<html><nav>業主盤 / 找代理</nav><main><div>樓盤資訊</div><b>陳先生</b>'
                f'<a href="tel:94609811">94609811</a><p>編號 B{n}</p>'
                f'<label>樓盤編號</label><span>(由放盤人提供)</span>'
                + ('<section>物業詳細資料</section><p>特色</p><b>%s</b>' %
                   ('代理盤' if agent else '業主盤') if full else '') + '</main>'
                '<footer>查詢熱線 39151638</footer></html>')
    def test_owner_complete_and_partial_for_rent_and_buy(self):
        for kind, n in [('rent','412921'),('buy','412919')]:
            url=f'https://852.house/zh/properties/{n}?pricetype={kind}'
            cfg={'url':U.format(kind=kind)}
            for complete in (True,False):
                h=self.detail(n, complete)
                self.assertTrue(accept_detail(h,url,cfg), (kind,complete))
                self.assertEqual(extract_contacts(h,url,cfg), [{'name':'陳先生','phone':'94609811'}])
            self.assertFalse(accept_detail(self.detail(n,False),url,{'url':'https://852.house/zh/'+kind}))
            self.assertFalse(accept_detail(self.detail(n,True,agent=True),url,cfg))
    def test_list_owner_only(self):
        for kind,n in [('rent','412921'),('buy','412919')]:
            html=(f'<div class="card"><a href="/zh/properties/{n}?pricetype={kind}">Sample</a><span>業主盤</span><span>B{n}</span></div>'
                  f'<div class="card"><a href="/zh/properties/412999?pricetype={kind}">Agent</a><span>代理盤</span><span>B412999</span></div>')
            self.assertEqual([x['id'] for x in extract_listings(html,U.format(kind=kind),{})],[n])

if __name__=='__main__': unittest.main(verbosity=2)
