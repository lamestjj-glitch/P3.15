# -*- coding: utf-8 -*-
"""V1.50.44: independent deterministic tests; no HTTP / Signal calls."""
import asyncio
import threading
from house730_adaptive_rate import SharedHouse730Rate

class FakeClock:
    def __init__(self): self.t=1000.0
    def __call__(self): return self.t
    async def sleep(self, delta):
        self.t+=delta
        await asyncio.sleep(0)

async def main():
    clock=FakeClock(); stop=threading.Event(); logs=[]
    setting=[0.2]
    jitter_values=iter([0.1,0.2,0.3,0.2,0.1,0.1])
    rate=SharedHouse730Rate(lambda: setting[0],stop,logs.append,
                             clock=clock, sleeper=clock.sleep,
                             jitter=lambda: next(jitter_values))
    assert rate.spacing==.2 and rate.floor==.2
    # Within a single lane, requests are serialized; success
    # never changes requested frequency.
    entries=[]; active=[0]
    for index in range(4):
        async with rate.slot("租"):
            assert active[0]==0
            active[0]+=1
            entries.append(clock())
            rate.success()
            active[0]-=1
            if index==1: setting[0]=.5
    assert [round(entries[i+1]-entries[i],3) for i in range(3)]==[.3,.7,.8]
    assert not any('[730-RATE-ADAPT]' in msg for msg in logs)
    assert rate.spacing==.5
    # Retry-After/real 429 behavior remains exactly as before.
    rate.limit(250,deal="租")
    assert rate.in_cooldown("租") and not rate.in_cooldown("售")
    last=clock()
    async with rate.slot("租"):
        assert 3 <= clock()-last < 4
        rate.success()
    assert not rate.in_cooldown() and not stop.is_set()
    assert abs(rate._requested()-.5)<1e-12
    print('PASS V1.50.44: fixed custom interval + jitter, no adaptive ramp, short isolated 429 retry')

if __name__=='__main__': asyncio.run(main())
