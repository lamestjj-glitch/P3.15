# -*- coding: utf-8 -*-
"""Validate House730 JSON polling cadence with at most 3 decimal places.

Validation is independent of Tk, multiprocessing and site requests.  When
Cloudflare protection is enabled, its stricter interval still takes priority.
"""
import re
from decimal import Decimal, InvalidOperation

MIN_SECONDS = Decimal('0.001')
MAX_SECONDS = Decimal('300')
_CADENCE_RE = re.compile(r'(?:[0-9]+(?:\.[0-9]{1,3})?|\.[0-9]{1,3})\Z')
_EDIT_RE = re.compile(r'[0-9]*(?:\.[0-9]{0,3})?\Z')


def valid_edit(text):
    """Permit incomplete values while typing; commit must validate range."""
    return bool(_EDIT_RE.fullmatch(str(text)))


def parse_house730_cadence(value):
    """Return float seconds, rejecting nonfinite/overprecision/out-of-range."""
    if isinstance(value, bool):
        raise ValueError('730 JSON 間隔必須輸入數字（最多3位小數）')
    raw = str(value).strip()
    if not _CADENCE_RE.fullmatch(raw):
        raise ValueError('730 JSON 間隔請輸入秒數，最多3位小數，例如 0.125、0.5、1.25')
    try:
        val = Decimal(raw)
    except (InvalidOperation, ValueError):
        raise ValueError('請輸入有效的秒數') from None
    if not (MIN_SECONDS <= val <= MAX_SECONDS):
        raise ValueError('730 JSON 間隔只接受 0.001 至 300 秒')
    return float(val)


def display_house730_cadence(value):
    """Keep a valid decimal visible; no integer truncation on reload."""
    return format(Decimal(str(parse_house730_cadence(value))).normalize(), 'f')
