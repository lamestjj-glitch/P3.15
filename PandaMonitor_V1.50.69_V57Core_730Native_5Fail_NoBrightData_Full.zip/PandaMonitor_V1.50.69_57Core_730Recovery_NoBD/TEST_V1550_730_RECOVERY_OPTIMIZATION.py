# -*- coding: utf-8 -*-
"""Offline V1.50.50 regression: bounded renderer errors and safe native recovery."""
import asyncio
from unittest.mock import AsyncMock
from pathlib import Path
from house730_light_api import House730LightAPI, PollError


class FakePage:
    def on(self, *args): pass
    def is_closed(self): return False


GOOD = {'status': 200, 'content_type': 'application/json',
        'body': '{"list":[{"url":"https://www.house730.com/rent-property-9296803/a/"}]}',
        'truncated': False, 'host': 'api.house730.com'}
BAD = {'status': 200, 'content_type': 'application/json',
       'body': '{"code":"bad","result":null,"message":""}',
       'truncated': False, 'host': 'api.house730.com'}


async def run():
    page = FakePage()
    api = House730LightAPI(page, '租', prefer_native=True)
    api.template = {'url': 'https://api.house730.com/Property/QueryProperty',
                    'method': 'POST', 'headers': {}, 'body': '{}'}
    api._native_query = AsyncMock(return_value=GOOD)
    assert len(await api.query()) == 1
    assert api.native_validated and api.last_query_transport == 'native'
    assert isinstance(api.last_query_elapsed_ms, int)

    api._native_query = AsyncMock(side_effect=RuntimeError('native dropped'))
    try: await api.query()
    except PollError as e: assert e.kind == 'native-transport'
    else: raise AssertionError('native transport error not surfaced')
    assert api.transport == 'browser'
    assert api._native_query.await_count == 1

    api._browser_query = AsyncMock(side_effect=RuntimeError('renderer gone'))
    try: await api.query()
    except PollError as e: assert e.kind == 'browser-execution'
    else: raise AssertionError('renderer error not surfaced')
    assert api.transport == 'native', 'known-good native transport must be retried NEXT cycle'
    assert api._browser_query.await_count == 1
    assert api._native_query.await_count == 1, 'no two network attempts in same cycle'
    api._native_query = AsyncMock(return_value=GOOD)
    assert len(await api.query()) == 1
    assert api.last_query_transport == 'native'

    # Unverified native shape is NEVER silently retried as an alternate route.
    other = House730LightAPI(page, '租', prefer_native=True)
    other.template = dict(api.template)
    other._native_query = AsyncMock(return_value=BAD)
    try: await other.query()
    except PollError as e: assert e.kind == 'native-shape'
    else: raise AssertionError('missing listing URLs not detected')
    assert other.native_shape_rejected
    other._browser_query = AsyncMock(side_effect=RuntimeError('renderer gone'))
    try: await other.query()
    except PollError as e: assert e.kind == 'browser-execution'
    else: raise AssertionError('renderer error not surfaced')
    assert other.transport == 'browser', 'unverified native transport must not be retried'

    # A true HTTP429 must remain a 429, not an ordinary transport error.
    api._native_query = AsyncMock(return_value={**GOOD, 'status': 429, 'retry_after': '600'})
    try: await api.query()
    except PollError as e:
        assert e.status == 429 and e.retry_after == 600
    else: raise AssertionError('429 lost')

    source = Path(__file__).with_name('house730_engine.py').read_text(encoding='utf-8')
    assert '[730-API-TIMING]' in source
    assert 'transport_error_streak' in source and 'min(30.0' in source
    assert '[730-INIT-DOM-RECOVER]' in source
    assert 'learn_navigation_lock = asyncio.Lock()' in source
    assert 'reconnect_delay = min(30.0' in source
    print('PASS V1.50.50: restored validated native, no same-cycle duplicates, rejected shape, real429, capped retries, startup DOM fallback')


if __name__ == '__main__':
    asyncio.run(run())
