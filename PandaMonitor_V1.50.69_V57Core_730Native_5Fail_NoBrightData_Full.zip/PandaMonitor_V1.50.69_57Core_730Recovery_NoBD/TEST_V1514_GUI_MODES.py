# -*- coding: utf-8 -*-
"""Run with xvfb-run -a python TEST_V1514_GUI_MODES.py on headless Linux."""
import tempfile,os,json
from pathlib import Path

with tempfile.TemporaryDirectory() as home:
    os.environ['HOME']=home
    from unified_gui import UnifiedApp
    a=UnifiedApp()
    assert a.phone_api_direct_var.get() is True
    assert a.phone_api_allow_detail_var.get() is False
    assert a.phone_api_direct_enabled and not a.phone_api_allow_detail
    assert a.save_config()
    saved=json.loads(Path(a.config_path).read_text(encoding='utf8'))
    assert saved['phone_api_direct_enabled'] is True
    assert saved['phone_api_allow_detail'] is False
    assert 'api_rent_interval' in saved and 'wa_730_enable' in saved
    a.phone_api_allow_detail_var.set(True)
    a.update_28_phone_mode()
    assert a.phone_api_allow_detail
    a.destroy()
    b=UnifiedApp()
    # Startup policy intentionally resets optional detail fallback to OFF.
    assert b.phone_api_allow_detail_var.get() is False
    b.phone_api_allow_detail_var.set(False)
    b.update_28_phone_mode()
    b.destroy()
    c=UnifiedApp()
    assert c.phone_api_allow_detail_var.get() is False
    c.destroy()
print('PASS V1.50.14 GUI: defaults, settings toggles and persistence, 730 settings retained')
