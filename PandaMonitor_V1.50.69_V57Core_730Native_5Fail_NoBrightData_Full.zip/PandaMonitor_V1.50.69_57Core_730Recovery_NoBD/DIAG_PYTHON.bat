@echo off
setlocal EnableExtensions
cd /d "%~dp0"
echo ==================================================
echo PandaMonitor V1.50.38a Python / Tkinter diagnosis
echo ==================================================
powershell.exe -NoProfile -NoLogo -ExecutionPolicy Bypass -File "%~dp0WINDOWS_LAUNCH.ps1" -DiagnoseOnly
echo.
echo Python diagnostic log:
echo %LOCALAPPDATA%\PandaMonitor_28Hse_House730\logs\python_diag.log
echo.
echo Python launcher versions (if present):
where py 2>nul
py -0p 2>nul
echo.
echo Python executables on PATH (if present):
where python 2>nul
where python3 2>nul
echo.
pause
