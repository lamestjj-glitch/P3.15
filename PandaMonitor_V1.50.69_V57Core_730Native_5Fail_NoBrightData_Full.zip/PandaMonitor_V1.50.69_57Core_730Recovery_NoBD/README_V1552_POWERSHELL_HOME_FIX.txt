PandaMonitor V1.50.52 — PowerShell 啟動修正（完整包）

原因：PowerShell 變數不分大小寫，$home 和內建唯讀 $HOME 是同一個變數。
V1.50.51 WINDOWS_LAUNCH.ps1 第55–59行迴圈試圖覆寫 $HOME，導致重複報錯。

修復：使用 $searchRoot 遍歷安裝目錄。未變更候選 Python 搜尋位置、優先次序與 Tkinter 探測。

操作：停止舊版；完整解壓；啟動 PandaMonitor_V1.50.52/START.bat。
舊有 config.json、去重庫與歷史紀錄不受影響。

提示：日誌顯示 Python 3.13 launcher 指向已不存在的安裝檔，但 Python 3.15 已通過 TK_OK 並成功啟動 GUI。
本次只修啟動器顯示的 HOME 錯誤，不宣稱修復已損壞的 Python 3.13 安裝。
