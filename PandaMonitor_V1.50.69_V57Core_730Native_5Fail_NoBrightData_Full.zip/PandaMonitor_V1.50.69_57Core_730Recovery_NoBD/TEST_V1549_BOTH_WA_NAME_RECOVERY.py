# -*- coding: utf-8 -*-
"""No-network tests: WA name gate across 28Hse/730; no message in tests."""
import json
from unittest.mock import patch
import wa_contact_recovery as recovery
from wa_female_filter import female_name_eligible, parse_female_names
from unified_gui import UnifiedApp
from house730_phone_first import contacts_from_api


def test_names():
    names=parse_female_names('Alice, Nora, Mandy')
    for name in ('周小姐 Nora Zhou','周小姐','Nora Zhou','Ms Wong','黄女士','Alice'):
        assert female_name_eligible(name,names)[0],name
    for name in ('未知','未提供','Ken Ip','黃先生 Nora','Mr Alice'):
        assert not female_name_eligible(name,names)[0],name


def test_direct_api_name_both_fields():
    payload={'result':[{'isShowTel':True,'telphone':'95116993','contactNameCN':'周小姐','contactNameEN':'Nora Zhou'}]}
    data=contacts_from_api(payload)
    assert data==[('周小姐 Nora Zhou','95116993')],data


def test_both_wa_gate():
    # Exercise GUI method without Tk, CDP, threads, WhatsApp side effects.
    class Dummy:
        wa_female_name_set=parse_female_names('Nora,Alice')
        cdp_base='http://127.0.0.1:62663'
        messages=[]
        fields=[]
        def write(self,msg):self.messages.append(msg)
        def update_row_field(self,*args):self.fields.append(args)
    d=Dummy()
    with patch('unified_gui.recover_public_contact',return_value=('周小姐 Nora Zhou','同號碼')) as fn:
        for site,url in [('28','https://www.28hse.com/rent/apartment/property-4059333'),('730','https://www.house730.com/rent-property-9296803/x/')]:
            result=UnifiedApp._wa_verified_name(d,'未提供',url,'95116993',row_id=site)
            assert result=='周小姐 Nora Zhou'
        assert fn.call_count==2 and len(d.fields)==2
        # Eligible direct contact => no network read.
        assert UnifiedApp._wa_verified_name(d,'Ms Wong','https://www.house730.com/rent-property-9296803/x/','95116993')=='Ms Wong'
        assert fn.call_count==2
        # Male always overrides recovered/public English female name.
        assert UnifiedApp._wa_verified_name(d,'黃先生 Nora','https://www.house730.com/rent-property-9296803/x/','95116993')=='黃先生 Nora'
        assert fn.call_count==2
    with patch('unified_gui.recover_public_contact',return_value=('', '無法確認')):
        assert UnifiedApp._wa_verified_name(d,'未知','https://www.house730.com/rent-property-9296803/x/','95116993')=='未知'
    assert any('UNCONFIRMED' in msg for msg in d.messages)


def test_valid_target_url():
    class Fake:
        pid_of=lambda self,url: '3871960' if 'property-3871960' in url else ''
        wa_test_property_url=type('V',(),{'get':lambda self:'https://www.28hse.com/buy/apartment/property-3871960'})()
    f=Fake()
    assert UnifiedApp._wa_test_url_for(f,'28').endswith('3871960')
    f.wa_test_property_url.get=lambda:'https://www.house730.com/buy-property-9296593/someplace/'
    assert UnifiedApp._wa_test_url_for(f,'730','售').endswith('/someplace/')
    try:
        UnifiedApp._wa_test_url_for(f,'730','租')
    except ValueError: pass
    else: raise AssertionError('wrong deal WA test URL accepted')


def test_browser_recover_safety():
    assert recovery._identity('https://www.28hse.com/buy/apartment/property-3871960')==('28','3871960')
    assert recovery._identity('https://www.house730.com/buy-property-9296593/abc/')==('730','9296593')
    assert recovery._identity('https://evil.example/buy-property-9296593/') is None
    assert recovery.recover_public_contact('http://localhost:1234','https://evil.example/buy-property-9296593/','95116993')[0]==''
    # No network. Browser has 28Hse tab EXACT MATCH and a 730 list tab, only matching tab probed.
    class FakeStream:
        def __enter__(self):return self
        def __exit__(self,*args):pass
        def read(self):return json.dumps([
            {'type':'page','url':'https://www.28hse.com/rent/apartment/property-4059333', 'webSocketDebuggerUrl':'ws://browser/exact'},
            {'type':'page','url':'https://www.house730.com/rent/', 'webSocketDebuggerUrl':'ws://browser/other'}
        ]).encode('utf-8')
    class FakeCDP:
        urls=[]
        def __init__(self,url):self.urls.append(url)
        def connect(self):pass
        def call(self,op,args,timeout=3):
            assert op=='Runtime.evaluate' and args['returnByValue']
            assert '95116993' in args['expression']
            return {'result':{'value':{'name':'周小姐 Nora Zhou','reason':'已開原帖唯一聯絡人'}}}
        def close(self):pass
    with patch.object(recovery._OPENER,'open',return_value=FakeStream()), patch.object(recovery,'CDP',FakeCDP):
        name,source=recovery.recover_public_contact('http://127.0.0.1:62663','https://www.28hse.com/rent/apartment/property-4059333','95116993')
    assert name=='周小姐 Nora Zhou' and FakeCDP.urls==['ws://browser/exact']


if __name__=='__main__':
    test_names();test_direct_api_name_both_fields();test_both_wa_gate();test_valid_target_url();test_browser_recover_safety()
    print('PASS V1.50.49: 28 + 730 WA name source, matched 730 CN+EN, missing/men blocked, URL selection and browser-only recovery')

# Test the exact WA test-target selection WITHOUT network, GUI or sending WA.
def test_exact_28_test_no_first_list_probe():
    from panda28_core import App
    class F:
        cdp_base='http://127.0.0.1:62663'
        wa_test_selected_url='https://www.28hse.com/buy/apartment/property-3871960'
        def pid_of(self,url):return '3871960' if url.endswith('property-3871960') else ''
        def write(self,*args):pass
        def test_popup(self,*args):raise AssertionError('Unexpected error popup')
        def fast_test_detail(self,k,u,**kwargs):
            assert (k,u)==('buy',self.wa_test_selected_url)
            assert kwargs.get('wa_test') and kwargs.get('test_mode')
            self.called=True
            return True,'OK'
        def probe_http_once(self,k):raise AssertionError('Must NOT probe first listing when explicit URL selected')
    f=F();App.whatsapp_test(f);assert f.called


def test_house_process_test_target_ipc():
    from house730_engine import Engine
    e=Engine(cfg={'hello':'world'},store=object())
    e.test_first('租',greeting=True,listing_url='https://www.house730.com/rent-property-9296803/x/')
    cmd,payload=e.commands.get_nowait()
    assert cmd=='test_wa' and payload['deal']=='租' and '9296803' in payload['listing_url']
    e.test_first('售',greeting=False)
    assert e.commands.get_nowait()==('test','售'),'Old no-target test behavior changed'

if __name__ == '__main__':
    test_exact_28_test_no_first_list_probe()
    test_house_process_test_target_ipc()
    print('PASS V1.50.49: exact-site 28/730 WA test selected target and preserved default first-list test')
