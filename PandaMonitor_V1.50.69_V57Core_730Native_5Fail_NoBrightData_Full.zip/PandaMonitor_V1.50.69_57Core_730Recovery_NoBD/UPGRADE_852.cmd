@echo off
chcp 65001 >nul
cd /d "%~dp0852_PLUGIN_UPDATE"
call INSTALL_852_HOUSE.cmd
