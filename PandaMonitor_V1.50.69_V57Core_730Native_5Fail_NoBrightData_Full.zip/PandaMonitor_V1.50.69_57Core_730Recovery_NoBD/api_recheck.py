# -*- coding: utf-8 -*-
"""8-second additional JSON query scheduler (same worker; no parallel fetch).

With deduplicate=True a *successful normal query* resets the eight-second
watchdog, so high-frequency normal polling does not create redundant requests.
Legacy standalone scheduling tests use deduplicate=False for compatibility.
"""
import time

RECHECK_SECONDS = 8.0


class RecheckSchedule:
    def __init__(self, enabled=True, period=RECHECK_SECONDS, now=None, deduplicate=False):
        self.period = float(period)
        self.enabled = bool(enabled)
        self.deduplicate = bool(deduplicate)
        self.next_at = (time.monotonic() if now is None else float(now)) + self.period

    def kind(self, baseline_ready, now=None):
        now = time.monotonic() if now is None else float(now)
        return "extra" if self.enabled and baseline_ready and now >= self.next_at else "normal"

    def completed(self, kind, now=None):
        if kind == "extra" or (self.deduplicate and kind == "normal"):
            now = time.monotonic() if now is None else float(now)
            self.next_at = now + self.period

    def wait(self, normal_wait, baseline_ready, now=None):
        wait = max(0., float(normal_wait))
        if self.enabled and baseline_ready and not self.deduplicate:
            now = time.monotonic() if now is None else float(now)
            wait = min(wait, max(0., self.next_at - now))
        return wait
