PandaMonitor V1.50.0 — 網址新增＋插件擴展版
=========================================
本版在 V1.49.1 的 Python 專案上添加獨立「新增網站」架構，原 28Hse／House730 演算法、JSON 查詢、原有 WA、去重與聯絡人邏輯保留。

開始使用
--------
1. 解壓完整 ZIP，執行 START.bat（Win10／Python 3.12+；第一次啟動會安裝 beautifulsoup4）。
2. 打開「新增網站｜插件管理」分頁。
3. 預設已添加「BusinessForSale.sg｜新加坡業主」，網址是：
   https://www.businessforsale.sg/businesses-for-sale?source=2&sort=2
4. 點選該網站 →「啟用／停用」，然後點上方「開始監控」。
5. 開始前會建立初始基線，舊帖不通知；有新的 Listing ID 才新增統一列表記錄。
6. 如網站因動態載入造成 HTTP 無法取得列表，可以設定監控模式 cdp，並手動輸入對應 AdsPower/BitBrowser 已啟動環境的 localhost DevTools HTTP / WebSocket 地址。

重要限制
--------
• BusinessForSale.sg 的賣家電話、電郵通常屬於 Premium 會員功能；如果頁面沒有公開的 tel:，程式顯示「會員限定／未揭號」，絕不把登記表單的電話、國際區號、假號當成賣家號碼。
• 本版不會自動登入，也不會嘗試繞過會員付費、Captcha、網站真人驗證。
• 通用網址模式需要指定 CSS 選擇器（網站自己生成的 DOM 結構不同）；不是任意 URL 都能在無配置下準確找到帖子。
• 新增網站 WA 尚未開放自動傳送；28/730 舊有的 WA 條件與時段完全保留。
• 新站預設 15 秒間隔，合法設置範圍 5–3600 秒；28/730 原有高頻間隔沒有修改。請按各站可接受的訪問頻率設置。
• CDP 模式使用本機已打開的瀏覽器環境，創建額外獨立分頁供監測；可能產生標籤／瀏覽器佔用，不會控制原有 28/730 Target。
• 新帖被識別後才會抓詳細頁；有公開號碼會自動複製尾四位／共用永久電話去重；沒有就保存新帖記錄而非捏造號碼。

新增一般網站
------------
按「＋新增網址」輸入：網站名稱、已設好篩選的列表 URL、新帖鏈接 CSS（如 a[href*='/listing/']）、URL 路徑包含條件、公開電話 CSS 選擇器、刷新間隔；不需要重新生成主程式。

添加高級插件
------------
請把可信任的 .py 插件交給 PandaMonitor 的「安裝 .py 插件」，插件會拷貝到：
   C:\Users\<用戶>\PandaMonitor_28Hse\site_plugins\
確切路徑以啟動的原 config_dir 為準。
插件需實作：
   extract_listings(html: str, list_url: str, config: dict) -> list[dict]
每個 dict 必須至少包含 {'id': '永久不變ID', 'url': 'https://...', 'title': '標題'}。
可選：
   extract_contacts(html: str, detail_url: str, config: dict) -> list[{'name': '聯絡人', 'phone': '+6588888888'}]
主程式會在每個網站自己的單一工作線程調用插件，並將事件交給 Tk 主畫面。
修改或替換插件後，只需在網站管理頁更改設定／重啟該新網站監控，28/730 不受影響。
插件是 Python 代碼，只安裝自己信任的代碼，不要執行不明下載來源。

保存路徑
---------
會在 PandaMonitor 既有的 config_dir（通常位於 C:\Users\<用戶>\PandaMonitor_28Hse）建立：
 extra_sites.json                 新網站配置
 extra_site_seen.json             新網站 ID 去重／基線
 site_plugins\*.py                使用者自行安裝的網站插件
原本 config.json、seen_phones.json 不覆寫。

測試
----
 python TEST_V150_PLUGINS.py         離線測試；包括基線、不同輪次新帖、會員號碼保護
 python launch.py --self-test       GUI 開機／關閉測試（需桌面環境）

打包 Windows EXE
----------------
 BUILD_EXE.ps1 （PowerShell，使用 PyInstaller onedir）
打包後同樣以「新增網站｜插件管理」管理插件，不必重新編譯 EXE。

本版未在你的 Windows 10 + AdsPower/BitBrowser 帳號進行在線實測。舊站邏輯保持不變，但正式部署前建議先備份配置並測試。
