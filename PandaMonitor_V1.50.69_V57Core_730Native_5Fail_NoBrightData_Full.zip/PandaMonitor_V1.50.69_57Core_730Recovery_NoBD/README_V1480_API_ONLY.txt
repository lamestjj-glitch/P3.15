PandaMonitor V1.48.0 | 28Hse JSON API-only + House730
=========================================================

這版修改（基於 V1.47.9 高效能整合版）：

1. 28Hse 租盤及售盤的「正常日常列表偵測」改用網站真正的
   POST https://www.28hse.com/property/dosearch
   不再重複抓取 /rent 或 /buy 整頁 HTML，也不再按搜尋按鈕做日常局部刷新。

2. 每路在開始時，獨立的 BitBrowser 背景分頁只開啟「業主盤 + 最新」列表一次，
   並按一次正常網站的「搜尋」，透過 CDP Network 記錄真實 form_data。
   這是取得原站請求格式的必要初始化，不是每秒重載頁面。
   form_data 在記憶體使用，不寫入磁碟、設定檔或日誌。

3. 真實 form_data 裡必須同時包含：
   landlordAgency=LANDLORD / sortBy=latest
   並通過首次 API 結果與網站列表房源 ID 核對，否則停止該路。
   不猜測 form_data、不自動降級為高頻 HTML 抓取，避免錯抓代理盤。

4. 日常租盤、售盤各自「目標每 1 秒一次 API」；
   每類 single-flight，上一個請求未完成絕不疊下一個。
   API 只讀 data.results.resultContentHtml，提取房源 ID，再作永久去重。
   注意：此設定每分鐘可產生約 120 次列表請求；並非站方批准的頻率。

5. HTTP 403、429、Cloudflare、無法證實業主盤／最新等問題：
   停止該路 API 查詢及彈出提醒，需要先檢查網站，再由用家重新開始。
   網路短暫超時採退避，不繞過驗證、不反覆導航。

6. 新帖出現時仍沿用原來的 PhoneFirst / CDP 後備揭號。
   28Hse 和 House730 獨立工作程序、高效能優先級、四路統一深色 UI、
   去重、28/730 各自 WA、Windows 彈窗等全部保留。
   28Hse 新號碼彈窗現改成與 House730 一樣的深色置頂樣式，
   可複製尾四位及開原帖。

7. 請觀察日誌：
   [API-LEARN] 取得 /property/dosearch form_data
   [API-VERIFY] API與DOM房源ID一致
   [API-LIST-OK] 正常查詢
   [DETECT-NEW] 新帖發現
   [RACE] NEW→CLIPBOARD 取號到複製耗時
   [API-PAUSE] 驗證/限流/篩選異常，停止該路

安裝：
  停用舊版，在新的資料夾解壓 V1.48.0，開啟 BitBrowser 173，雙擊 START.bat。
  不需要清空或重建原來的電話去重資料庫。

測試狀況：
  已通過 API 模擬測試、730 既有測試、獨立工作程序測試、
  Linux Xvfb GUI 啟動測試。
  尚未在使用者 Windows/BitBrowser 173 上真實測試 API 重播/速度。
  API Finder V2 是「一次受控搜尋」；不保證實際每秒高頻重播不受限制。

安全：
  請勿分享 BitBrowser Local API Token、Cookie、未遮罩的 HAR。
