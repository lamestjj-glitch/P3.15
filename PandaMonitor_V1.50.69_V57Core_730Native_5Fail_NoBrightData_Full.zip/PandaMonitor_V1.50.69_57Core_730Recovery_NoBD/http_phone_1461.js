(async()=>{
          const url="https://www.28hse.com/rent/apartment/property-4049001", pid="4049001", t0=performance.now();
          const totalCtl=new AbortController();
          const totalTimer=setTimeout(()=>totalCtl.abort(),2800);
          const norm=v=>{
            let d=((v||'')+'').replace(/\D/g,'');
            if(d.startsWith('00852'))d=d.slice(5);
            else if(d.length===11&&d.startsWith('852'))d=d.slice(3);
            return /^[235689]\d{7}$/.test(d)?d:'';
          };
          const rowsFromFragments=(contacts)=>{
            const rows=[];
            for(const frag of (Array.isArray(contacts)?contacts:[])){
              if(typeof frag!=='string')continue;
              const fd=new DOMParser().parseFromString(frag,'text/html');
              const blocks=[...fd.querySelectorAll('.content_phone_information')];
              if(!blocks.length)blocks.push(fd.body||fd);
              for(const block of blocks){
                const vals=[];
                for(const a of block.querySelectorAll('a[href]')){
                  const h=a.getAttribute('href')||'';
                  if(/^tel:/i.test(h))vals.push(h.replace(/^tel:/i,'').split('?')[0]);
                  if(/(?:wa\.me|api\.whatsapp\.com|www\.whatsapp\.com)/i.test(h)){
                    try{const u=new URL(h,url);vals.push(u.hostname==='wa.me'?u.pathname.replace(/^\/+|\/+$/g,''):(u.searchParams.get('phone')||''));}catch(e){}
                  }
                }
                for(const x of block.querySelectorAll('.fullPhone'))vals.push(x.textContent||'');
                const lines=(block.textContent||'').split(/\n+/).map(x=>x.trim()).filter(Boolean);
                let name='未知';
                for(const x of lines){
                  if(x.length>100||/致電|致电|WhatsApp|電郵|电邮|發訊|发讯|Tel\s*[:：]/i.test(x)||norm(x))continue;
                  if(!/^\d+$/.test(x)){name=x;break;}
                }
                for(const raw of vals){const p=norm(raw);if(p&&!rows.some(x=>x.phone===p))rows.push({name,phone:p});}
                for(const line of lines){if(!/Tel\s*[:：]/i.test(line))continue;const p=norm(line);if(p&&!rows.some(x=>x.phone===p))rows.push({name,phone:p});}
              }
            }
            return rows;
          };
          const phoneAction=async(uid,stamp)=>{
            const action='https://www.28hse.com/property/detail/doaction';
            const actionStart=performance.now();
            const body=new URLSearchParams({action:'statistic_inc',user_action:'phone',uid_code:uid,ad_id:String(pid),timeStamp:stamp,event_name:'property_contact_phone'});
            const rr=await fetch(action,{
              method:'POST',credentials:'include',cache:'no-store',redirect:'follow',signal:totalCtl.signal,
              referrer:url,referrerPolicy:'strict-origin-when-cross-origin',priority:'high',
              headers:{'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Cache-Control':'no-cache, no-store, max-age=0','Pragma':'no-cache'},
              body:body.toString()
            });
            if(!rr.ok)return {rows:[],reason:'致电接口 HTTP '+rr.status,actionMs:Math.round(performance.now()-actionStart)};
            let data=null; try{data=await rr.json()}catch(e){return {rows:[],reason:'致电接口响应无法解析',actionMs:Math.round(performance.now()-actionStart)}}
            const values=data&&data.data&&data.data.results;
            if(!values||typeof values!=='object')return {rows:[],reason:'致电接口没有 results',actionMs:Math.round(performance.now()-actionStart)};
            if(values.need_verify)return {rows:[],reason:'致电接口要求人工验证',actionMs:Math.round(performance.now()-actionStart)};
            const rows=rowsFromFragments(values.contacts);
            return {rows,reason:rows.length?'':'致电接口未返回公开号码',actionMs:Math.round(performance.now()-actionStart)};
          };
          try{
            const detailStart=performance.now();
            const r=await fetch(url,{
              method:'GET',credentials:'include',cache:'no-store',redirect:'follow',signal:totalCtl.signal,priority:'high',
              headers:{'Cache-Control':'no-cache, no-store, max-age=0','Pragma':'no-cache','Accept':'text/html,application/xhtml+xml'}
            });
            if(!r.ok)return {terminal:false,ok:false,reason:'详情 HTTP '+r.status,totalMs:Math.round(performance.now()-t0)};
            let buf='', uid='', stamp='', bytes=0, actionPromise=null, headMs=0;
            const inspect=()=>{
              if(!uid){const m=buf.match(/var\s+uid_code\s*=\s*'([^']+)'/);if(m)uid=m[1];}
              if(!stamp){const m=buf.match(/timeStamp\s*:\s*'([0-9]+)'/);if(m)stamp=m[1];}
              if(uid&&stamp&&!actionPromise){
                headMs=Math.round(performance.now()-detailStart);
                actionPromise=phoneAction(uid,stamp);
              }
            };
            if(r.body&&r.body.getReader){
              const reader=r.body.getReader(), dec=new TextDecoder();
              while(true){
                const part=await reader.read();
                if(part.done)break;
                bytes += part.value ? part.value.byteLength : 0;
                buf += dec.decode(part.value,{stream:true});
                if(buf.length>240000)buf=buf.slice(-220000);
                inspect();
                if(actionPromise){try{await reader.cancel()}catch(e){};break;}
                if(bytes>260000)break;
              }
            }else{
              buf=await r.text(); inspect();
            }
            if(/verify you are human|checking your browser|attention required|人機驗證|人机验证|請完成驗證|请完成验证/i.test(buf))
              return {terminal:false,ok:false,reason:'网站要求人工验证',totalMs:Math.round(performance.now()-t0)};
            // V1.46.1: the contact often renders as *plain Tel: 852-...*
            // under the 放盤聯絡人 heading, not .content_phone_information.
            // Do not create another hidden Target or click when it is visible.
            if(/content_phone_information|放盤聯絡人|放盘联络人/i.test(buf)){
              const doc=new DOMParser().parseFromString(buf,'text/html');
              const blocks=[...doc.querySelectorAll('.content_phone_information,[class*="contact_information"],[class*="contact-info"],[class*="contactInformation"]')];
              const headings=[...doc.querySelectorAll('h2,h3,h4,h5,strong,b,div,span')].filter(e=>
                e.childElementCount<=2&&/^(放盤聯絡人|放盘联络人)$/.test((e.textContent||'').trim()));
              for(const h of headings.slice(0,2)){
                for(let p=h.parentElement,d=0;p&&p!==doc.body&&d<6;p=p.parentElement,d++){
                  if(/Tel\.?\s*[:：]|電話\s*[:：]|电话\s*[:：]/i.test((p.textContent||'').slice(0,6500))){blocks.push(p);break;}
                }
              }
              const visible=[], seen=new Set();
              const telRx=/(?:Tel\.?|電話|电话)\s*[:：]\s*(?:\+?852[\s-]*)?([2-9]\d{3}[\s-]?\d{4})(?!\d)/ig;
              for(const block of blocks.slice(0,8)){
                if(block.closest('.recommend,.recommendation,.related,.advertisement,.ads,aside'))continue;
                let name='未知';
                const named=block.querySelector('[class*="contact-name"],[class*="contact_name"],[class*="contactName"],[class*="person-name"]');
                if(named){const n=(named.textContent||'').trim();if(n.length<90)name=n;}
                const t=(block.textContent||'').slice(0,6500);
                if(name==='未知'){
                  const n=t.match(/([\u3400-\u9fff]{1,5}(?:小姐|先生)(?:\s*[A-Za-z][A-Za-z .]{1,35})?)/);
                  if(n)name=n[1].trim();
                }
                const add=p=>{if(p&&!seen.has(p)){seen.add(p);visible.push({name,phone:p})}};
                for(const a of block.querySelectorAll('a[href^="tel:"]'))add(norm(a.getAttribute('href')||''));
                for(const m of t.matchAll(telRx))add(norm(m[0]));
              }
              if(visible.length)return {terminal:true,ok:true,rows:visible,source:'detail-stream-visible-tel',headMs,totalMs:Math.round(performance.now()-t0)};
            }
            if(actionPromise){
              const pr=await actionPromise;
              if(pr.rows&&pr.rows.length)return {terminal:true,ok:true,rows:pr.rows,source:'phone-action-stream',headMs,actionMs:pr.actionMs,totalMs:Math.round(performance.now()-t0)};
              return {terminal:false,ok:false,reason:pr.reason||'致电接口未返回公开号码',headMs,actionMs:pr.actionMs,totalMs:Math.round(performance.now()-t0)};
            }
            return {terminal:false,ok:false,reason:'详情前段未及时取得电话动作参数',headMs,totalMs:Math.round(performance.now()-t0)};
          }catch(e){
            return {terminal:false,ok:false,reason:(e&&e.name==='AbortError')?'UltraRace取号超过自适应等待上限':String(e),totalMs:Math.round(performance.now()-t0)};
          }finally{clearTimeout(totalTimer);}
        })();
