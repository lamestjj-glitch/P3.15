"""Fast, bounded fallback extraction of already-visible 28Hse contact numbers.

Only pass the selected listing contact panel or a snippet beginning at its
'放盤聯絡人' heading. This module never searches advertisements/related properties.
"""
import re
from html.parser import HTMLParser

_PHONE = re.compile(r'(?:\+?852[\s\-]*)?([2-9]\d{3}[\s\-]?\d{4})(?!\d)')
_TEL = re.compile(r'(?:Tel\.?|電話|电话)\s*[:：]\s*(?:\+?852[\s\-]*)?([2-9]\d{3}[\s\-]?\d{4})(?!\d)', re.I)

class _Text(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.parts = []
        self.skip = 0

    def handle_starttag(self, tag, attrs):
        if tag in ('script', 'style', 'noscript'):
            self.skip += 1
        if self.skip: return
        if tag in ('br', 'p', 'li', 'div', 'section', 'article', 'tr'):
            self.parts.append('\n')
        for k, v in attrs:
            if k == 'href' and v and v.lower().startswith('tel:'):
                self.parts.append('Tel: ' + v[4:] + '\n')

    def handle_endtag(self, tag):
        if tag in ('script', 'style', 'noscript'):
            self.skip = max(0, self.skip - 1)
        elif not self.skip and tag in ('p', 'li', 'div', 'section', 'tr'):
            self.parts.append('\n')

    def handle_data(self, data):
        if not self.skip and data.strip():
            self.parts.append(data.strip() + ' ')


def extract_visible_phones(html, fallback_name='未知', max_phones=6):
    """Returns [{'name': ..., 'phone': 'xxxxxxxx'}] from a bounded contact fragment."""
    if not html:
        return []
    src = str(html)[:2000000]
    # If this is a whole-page DOM, trim to the *actual listing* contact heading.
    if len(src) > 14000:
        m = re.search(r'放盤聯絡人|放盘联络人', src, flags=re.I)
        if not m:
            return []
        src = src[max(0, m.start()-1500):m.start()+11000]
    parser = _Text()
    try:
        parser.feed(src)
    except Exception:
        return []
    lines = [re.sub(r'\s+', ' ', s).strip() for s in ''.join(parser.parts).split('\n')]
    lines = [s for s in lines if s]
    text = '\n'.join(lines)
    matches = list(_TEL.finditer(text))
    seen = set()
    out = []
    # If there are multiple contacts, use a nearby name rather than a name from
    # the page title, footer or advertisement.
    cursor = 0
    for m in matches:
        phone = re.sub(r'\D', '', m.group(1))
        # Segment is bounded by the previous Tel label, so a second person's
        # number can never inherit the first contact's name.
        preceding = text[cursor:m.start()]
        cursor = m.end()
        if len(phone) != 8 or phone in seen:
            continue
        segment = re.sub(r'放盤聯絡人|放盘联络人|致[電电]|WhatsApp|發訊|发讯|複製|复制', ' ', preceding, flags=re.I).strip()
        name = fallback_name if not out else '未知'
        titles = list(re.finditer(r'([\u3400-\u9fff]{1,5}(?:太太|先生|小姐|女士|太|姐|生)(?:\s*[A-Za-z][A-Za-z .]{0,35})?)', segment))
        if titles:
            name = titles[-1].group(1).strip()
        else:
            eng_title = list(re.finditer(r'\b(?:Mrs|Ms|Miss|Mr)\.?\s*[A-Za-z][A-Za-z .]{0,35}', segment, re.I))
            if eng_title:
                name = eng_title[-1].group(0).strip()
            else:
                last = segment.split('\n')[-1].strip()
                if 2 <= len(last) <= 60 and re.search(r'[A-Za-z]',last):
                    name = last
        out.append({'name':name, 'phone':phone})
        seen.add(phone)
        if len(out) >= max_phones:
            break
    return out
