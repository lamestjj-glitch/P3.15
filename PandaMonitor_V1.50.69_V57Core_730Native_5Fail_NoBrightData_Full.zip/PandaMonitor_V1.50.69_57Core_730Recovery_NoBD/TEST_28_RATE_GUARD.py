# -*- coding: utf-8 -*-
"""Offline tests for 429 8 +/- 8 seconds shared cooldown and low-rate recovery."""
import threading
from datetime import datetime, timezone, timedelta
from hse28_429_cooldown import RateCooldown, retry_after_seconds
from panda28_api import ApiError

class FakeClock:
    now = 1000.0
    def __call__(self): return self.now
    def advance(self, seconds): self.now += seconds

clock=FakeClock()
guard=RateCooldown(clock=clock, jitter=lambda: 0.0)
assert guard.remaining()==0
try:
    with guard.slot(lambda: True) as admitted:
        assert admitted
        raise ApiError('rate','HTTP 429',retry_after='5')
except ApiError:
    pass
else:
    raise AssertionError('expected 429')
assert abs(guard.remaining()-8.0)<0.01
assert guard.recovery()
assert guard._strikes==1
clock.advance(8.0)
# Serialized recovery: four successes 1.5s apart, then normal independent polling.
for i in range(4):
    with guard.slot(lambda: True) as admitted:
        assert admitted
    clock.advance(1.6)
assert not guard.recovery(), guard._recovery_left
with guard.slot(lambda: True) as admitted: assert admitted
# Negative jitter clamps to 2s, never immediate retry.
g2=RateCooldown(clock=clock, jitter=lambda: -8.0)
assert abs(g2.rate_limited()[0]-2.0)<0.01
clock.advance(2.0)
assert g2.rate_limited()[0]>=8.0, 'consecutive 429 raises base to 16 +/- 8'
# Explicit server throttling wins over jitter.
g3=RateCooldown(clock=clock, jitter=lambda: -8.0)
assert g3.rate_limited('55')[0]>=55.0
assert retry_after_seconds('60')==60
stamp=datetime.now(timezone.utc)+timedelta(seconds=90)
assert 85<=retry_after_seconds(stamp.strftime('%a, %d %b %Y %H:%M:%S GMT'))<=95
# User Stop/Restart clears stale cooldown; cancellation cannot deadlock shared lock.
g3.reset()
assert g3.remaining()==0 and not g3.recovery()
with g3.slot(lambda: False) as admitted: assert admitted is False
with g3.slot(lambda: True) as admitted: assert admitted is True
print('PASS V1.50.26: shared 429 jitter / Retry-After / escalating strikes / serial low-rate recovery / cancel / reset')
