# -*- coding: utf-8 -*-
"""Durable 28Hse listing history; separate from the existing cross-site phone set.

This database stores source-identifiable metadata. Never infer source from the
legacy seen_phones.json, which contains only numbers from multiple sites.
"""
import sqlite3
import threading
from datetime import datetime
from pathlib import Path


class Hse28History:
    def __init__(self, config_dir):
        self.path = Path(config_dir) / '28hse_history.sqlite3'
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.guard = threading.RLock()
        with self._open() as cx:
            cx.executescript("""
                CREATE TABLE IF NOT EXISTS history(
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    kind TEXT NOT NULL CHECK (kind IN ('rent','buy')),
                    pid TEXT NOT NULL,
                    phone TEXT NOT NULL,
                    url TEXT NOT NULL,
                    contact TEXT NOT NULL DEFAULT '未知',
                    detected_at TEXT NOT NULL,
                    wa_status TEXT NOT NULL DEFAULT '未聯絡',
                    is_extra INTEGER NOT NULL DEFAULT 0,
                    UNIQUE(kind,pid,phone)
                );
                CREATE INDEX IF NOT EXISTS idx_28hse_history_time
                  ON history(detected_at DESC, id DESC);
            """)

    from contextlib import contextmanager

    @contextmanager
    def _open(self):
        cx = sqlite3.connect(str(self.path), timeout=8)
        cx.execute('PRAGMA busy_timeout=8000')
        try:
            yield cx
            cx.commit()
        except Exception:
            cx.rollback()
            raise
        finally:
            cx.close()

    @staticmethod
    def phone_key(raw):
        import re
        digits = re.sub(r'\D', '', str(raw or ''))
        if digits.startswith('00852') and len(digits) == 13: digits = digits[5:]
        if digits.startswith('852') and len(digits) == 11: digits = digits[3:]
        return digits

    @staticmethod
    def pid_of(url):
        import re
        m = re.search(r'property-(\d+)', str(url or ''))
        return m.group(1) if m else None

    def save(self, kind, url, phone, contact='未知', is_extra=False, wa_status='未聯絡'):
        """Record a confirmed fresh number. Do not mutate dedup ownership.

        Caller invokes after copying and reserving the phone in the original
        28Hse pipeline; SQLite does not change that pipeline's result.
        """
        pid = self.pid_of(url)
        digits = self.phone_key(phone)
        if kind not in ('rent', 'buy') or not pid or len(digits) != 8 or digits[0] in ('2', '3'):
            return False
        contact = str(contact or '未知').strip() or '未知'
        if contact in ('补充中…','待补充'):
            contact = '未知'
        with self.guard, self._open() as cx:
            row = cx.execute("""INSERT OR IGNORE INTO history
                (kind,pid,phone,url,contact,detected_at,wa_status,is_extra)
                VALUES(?,?,?,?,?,?,?,?)""",
                (kind, pid, digits, str(url), contact,
                 datetime.now().astimezone().isoformat(timespec='seconds'),
                 str(wa_status or '未聯絡'), 1 if is_extra else 0))
            if row.rowcount == 0:
                # A late contact-name enrichment does not change first_seen.
                if contact not in ('未知', '未提供'):
                    cx.execute("""UPDATE history SET contact=? WHERE kind=? AND pid=?
                        AND phone=? AND contact IN ('未知','未提供','补充中…')""",
                        (contact, kind, pid, digits))
            return bool(row.rowcount)

    def update_contact(self, kind, url, contact, phone=None):
        pid = self.pid_of(url)
        name = str(contact or '').strip()
        if kind not in ('rent','buy') or not pid or name in ('','未知','未提供','补充中…','待补充'):
            return
        with self.guard, self._open() as cx:
            if phone:
                cx.execute('UPDATE history SET contact=? WHERE kind=? AND pid=? AND phone=?',
                           (name,kind,pid,self.phone_key(phone)))
            else:
                cx.execute('UPDATE history SET contact=? WHERE kind=? AND pid=? AND is_extra=0',
                           (name,kind,pid))

    def update_wa(self, kind, url, phone, status):
        pid=self.pid_of(url)
        if kind not in ('rent','buy') or not pid: return
        with self.guard, self._open() as cx:
            cx.execute('UPDATE history SET wa_status=? WHERE kind=? AND pid=? AND phone=?',
                       (str(status or '未聯絡'),kind,pid,self.phone_key(phone)))

    def rows(self, limit=500):
        with self.guard, self._open() as cx:
            cx.row_factory=sqlite3.Row
            return [dict(r) for r in cx.execute("""
                SELECT id, kind, pid, phone, url, contact, detected_at, wa_status, is_extra
                FROM history ORDER BY detected_at DESC, id DESC LIMIT ?""",
                (int(limit),))]

    def count(self):
        with self.guard, self._open() as cx:
            return cx.execute('SELECT COUNT(*) FROM history').fetchone()[0]
