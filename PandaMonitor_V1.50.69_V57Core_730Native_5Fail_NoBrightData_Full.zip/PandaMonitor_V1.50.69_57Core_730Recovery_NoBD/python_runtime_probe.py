# -*- coding: utf-8 -*-
"""Standalone interpreter / Tcl-Tk probe for Windows launchers.

Executed as a .py file to avoid PowerShell 5.1 `python -c` argument quoting.
This must not import or mutate PandaMonitor runtime state.
"""
import sys

print("VERSION=" + sys.version.split()[0] + " EXE=" + sys.executable, flush=True)
if sys.version_info < (3, 12):
    print("ERROR: Python 3.12+ is required", flush=True)
    raise SystemExit(21)
try:
    import tkinter
    interp = tkinter.Tcl()
    print(
        "TK_OK=" + str(tkinter.TkVersion)
        + " TCL=" + str(interp.eval("info patchlevel")),
        flush=True,
    )
except Exception as exc:
    print("ERROR: Tcl/Tk probe failed: " + repr(exc), flush=True)
    raise SystemExit(22)
