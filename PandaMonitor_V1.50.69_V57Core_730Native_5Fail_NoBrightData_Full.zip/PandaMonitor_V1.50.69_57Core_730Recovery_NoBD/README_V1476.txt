PandaMonitor V1.47.6 - House730 JSON repair (BitBrowser 173)
====================================================
Core 28Hse panda28_core.py is byte-for-byte identical to V1.47.5.

Changes to House730:
* Capture the site's application headers, including appkey/appsignature/language/platform,
  when already sent by its legitimate list page. Memory-only, never written to disk.
* If HTTP200 JSON lacks valid listing URLs, log only structural keys/counts (no values).
* One controlled original-page reload to re-learn a fresh XHR request.
* If re-learned JSON still fails, fall back to 60-second HTML and wait before re-learning again.
* Existing rent/buy owner filter, 1-second JSON target, 429/403 cooldown, SQLite dedupe,
  phone reveal, popup, UI, independent WhatsApp schedules/tests are preserved.

IMPORTANT: Live API replay is UNVERIFIED on your Windows/BitBrowser environment.
This patch addresses a concrete header-loss defect and improves recovery, but a
short-lived/single-use server signature can still prevent JSON replay. The GUI
will display HTML 60 seconds whenever JSON cannot be safely validated.

Start: START.bat (after extracting the ZIP and stopping old monitors).
Test: TEST_730_OFFLINE.py, TEST_730_RECOVERY.py, TEST_730_API_HEADERS.py.
Log: %%LOCALAPPDATA%%\House730Standalone173\house730.log
