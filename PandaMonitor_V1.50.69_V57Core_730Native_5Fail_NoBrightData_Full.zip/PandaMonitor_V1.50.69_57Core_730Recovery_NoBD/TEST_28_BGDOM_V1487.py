# -*- coding: utf-8 -*-
"""No-site regression for V1.48.7 background DOM/cached XHR learning."""
import json
import subprocess
import threading
import time
from urllib.parse import urlencode
from unittest.mock import patch
from panda28_api import capture_template, owner_lock, ApiError, _SEARCH_CONTROL_JS

BODY = urlencode({'form_data':json.dumps({'landlordAgency':'LANDLORD','sortBy':'latest','buyRent':'rent'})})
URL = 'https://www.28hse.com/rent?landlordAgency=LANDLORD&sortBy=latest'

class CDP:
    def __init__(self, emit):
        self.emit=emit;self.event_handler=None;self.calls=[]
    def call(self, name, params=None, timeout=None):
        self.calls.append((name,params or {}))
        if name=='Page.reload' and self.emit and self.event_handler:
            self.event_handler({'method':'Network.requestWillBeSent','params':{'request':{'url':'https://www.28hse.com/property/dosearch','method':'POST','postData':BODY}}})
        if name=='Runtime.evaluate':
            exp=params['expression']
            if exp=='location.href':return {'result':{'value':URL}}
            if exp=="({ready:document.readyState,href:location.href})":return {'result':{'value':{'ready':'complete','href':URL}}}
            if 'const accepted=' in exp:return {'result':{'value':{'ok':False,'reason':'no-visible-search-control','forms':0,'buttons':0,'visible':0,'ready':'complete','count':0}}}
        return {'result':{}}
    def pump_event(self, timeout=.3):return False
    def ev(self,expr,timeout=None):return False
    def close(self):pass

class App:
    def __init__(self,emit):self.lock=threading.Lock();self.http_target_ids=set();self.c=CDP(emit);self.closes=[]
    def target(self,k):return {'id':'user-rent-tab'}
    def create_background_target(self,url):raise AssertionError('never open a new list tab')
    def list_url(self,k):return URL
    def cdp(self,t):return self.c
    def close_target_id(self,tid):self.closes.append(tid)


def main():
    # Normal learning and cached restart must both preserve real OwnerLock.
    initial=App(True)
    _,conn,tpl=capture_template(initial,'rent',lambda:True)
    assert not tpl['reused'] and owner_lock(tpl['body'])
    assert not any(n.startswith('Input.') or n in ('Page.bringToFront','Page.navigate') for n,p in conn.calls)
    # A fresh private page has no search control; reuse only prior validated
    # template from the same application/profile. Use accelerated clock for
    # offline test; never perform real network requests.
    reload=App(False)
    class Clock:
        t=100.0
        def monotonic(self):self.t+=0.8;return self.t
        def sleep(self,seconds):pass
    clock=Clock()
    with patch('panda28_api.time.monotonic',clock.monotonic),patch('panda28_api.time.sleep',clock.sleep):
        _,conn2,tpl2=capture_template(reload,'rent',lambda:True,cached=tpl)
    assert tpl2['reused'] is True and tpl2['body']==BODY
    assert [n for n,_ in conn2.calls].count('Page.navigate')==0 and [n for n,_ in conn2.calls].count('Page.reload')==0
    assert not any('const accepted=' in p.get('expression','') for n,p in conn2.calls if n=='Runtime.evaluate')
    # Wrong owner filter must NOT be reused, even in memory.
    wrong={'url':'https://www.28hse.com/property/dosearch','body':'landlordAgency=AGENT&sortBy=latest'}
    x=App(False);clock=Clock()
    with patch('panda28_api.time.monotonic',clock.monotonic),patch('panda28_api.time.sleep',clock.sleep):
        try:capture_template(x,'rent',lambda:True,cached=wrong)
        except ApiError as err:
            assert err.kind=='learn' and 'diag=' in str(err) and 'no input sent' in str(err)
        else:raise AssertionError('wrong owner template accepted')
    assert not x.closes
    # JS syntax test, without executing in a real site/browser.
    p=subprocess.run(['node','-e','new Function('+json.dumps(_SEARCH_CONTROL_JS+'(false)')+'); console.log("OK")'],capture_output=True,text=True)
    assert p.returncode==0,(p.stdout,p.stderr)
    assert not any(x in _SEARCH_CONTROL_JS for x in ('dispatchMouseEvent','dispatchKeyEvent','bringToFront'))
    print('PASS: background-only search JS syntax, verified template caching, failed learn diagnostics, no OS input, wrong OwnerLock blocked')

if __name__=='__main__':main()
