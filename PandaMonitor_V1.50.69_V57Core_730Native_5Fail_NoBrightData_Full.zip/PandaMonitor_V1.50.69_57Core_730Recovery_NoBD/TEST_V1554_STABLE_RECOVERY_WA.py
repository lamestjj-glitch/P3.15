# -*- coding: utf-8 -*-
"""V1.50.54 regressions without browser, network, clipboard or WA sends."""
import asyncio
import threading
from pathlib import Path
from unittest.mock import patch
from house730_adaptive_rate import SharedHouse730Rate
from unified_gui import UnifiedApp

class Clock:
    def __init__(self): self.t=1000
    def __call__(self): return self.t
    async def sleep(self,delay):
        self.t+=delay
        await asyncio.sleep(0)

async def rate_test():
    clock=Clock();logs=[];rt=SharedHouse730Rate(lambda:.7,threading.Event(),logs.append,clock=clock,sleeper=clock.sleep,jitter=lambda:.1)
    for n,delay in enumerate((3,6,12,24,30,30),1):
        rt.limit(3600,deal='租')
        assert rt._lane_429_streak['租']==n
        assert abs(rt._lane_429_until['租']-clock()-delay)<.001
        before=clock()
        async with rt.slot('售'): pass
        assert clock()-before < 1.0, 'successful sale source should not be blocked'
        async with rt.slot('租'):pass
    rt.success('租')
    assert rt._lane_429_streak['租']==0
    rt.limit(3600,deal='租')
    assert rt._lane_429_until['租']-clock() <= 3.001
    assert any('730-429-RECOVERED' in line for line in logs)

class FakeWA:
    def __init__(self):
        self._wa_name_lock=threading.Lock();self._wa_name_info={};self._wa_phone_info={}
        self.count=0
    def _wait_28_wa_name(self,url,seconds=8):
        self.count+=1
        return '周小姐 Nora Zhou' # Property-wide name from DIFFERENT phone


def wa_test():
    fake=FakeWA();url='https://www.28hse.com/rent/apartment/property-4059798'
    # Main phone associated with a name -> eligible. Another phone must not inherit it.
    UnifiedApp.note_wa_phone_contact(fake,url,'852-95116993','周小姐 Nora Zhou')
    assert UnifiedApp._wait_28_wa_phone_name(fake,url,'95116993')=='周小姐 Nora Zhou'
    assert UnifiedApp._wait_28_wa_phone_name(fake,url,'67771234')=='未知'
    assert fake.count==1
    UnifiedApp.note_wa_phone_contact(fake,url,'67771234','未知')
    assert UnifiedApp._wait_28_wa_phone_name(fake,url,'67771234')=='未知'
    assert fake.count==2


def tab_test():
    s=Path(__file__).with_name('house730_engine.py').read_text(encoding='utf-8')
    assert 'for owner,other in tab_map.items() if owner != deal' in s
    assert '730-TAB-WAIT' in s and 'SOURCES[deal]' in s
    assert '730-INIT-LIVE-REUSE' in s
    assert 'rate.success(deal)' in s
    assert 'context.new_page()' in s  # only in explicit UI open action
    rec=Path(__file__).with_name('wa_contact_recovery.py').read_text(encoding='utf-8')
    assert '[data-phone]' in rec and 'last_reason' in rec

if __name__=='__main__':
    asyncio.run(rate_test());wa_test();tab_test()
    print('PASS V1.50.54: 3-30s 429 cap+reset, separate lanes, correct tab reattach, phone-specific WA, public contact diagnostics')
