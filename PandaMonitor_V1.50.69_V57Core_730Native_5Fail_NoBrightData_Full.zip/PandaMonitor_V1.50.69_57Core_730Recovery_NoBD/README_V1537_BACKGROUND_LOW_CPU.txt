PandaMonitor V1.50.37 -- 後台穩定／降低 CPU
===========================================
本版基於 V1.50.36 完整版，只優化瀏覽器背景活動、GUI 日誌重繪及 28Hse CDP 探測負擔。

1. 28Hse：業主+最新 POST 與當前頁 DOM 比對確認成功後，對該「已開啟」分頁套用一次 CDP FocusEmulation + active lifecycle。不是切換視窗或 window.focus，不開新列表或詳情頁。每路正常 CDP /json 健康探測從每4秒改成每10秒；出現 CDP/socket 問題仍立即恢復。
2. 730：兩站同開時，在原業主盤列表分頁上套用一次 CDP 後台保活提示。成功時記錄 [730-BG-ACTIVE]。優先 native HTTP（不依賴可見分頁 JS）、429 及 Retry-After 保護不變。
3. GUI：寫入日誌改為每150ms合併一次；限制等待顯示的訊息以及Text widget歷史長度；切到其他面板時不強制捲動日誌。提升高頻持續監控下 GUI 及 CPU 響應。
4. Windows：僅 phone_worker 使用 ABOVE_NORMAL 線程優先；租售列表 Worker 維持 normal，避免過度搶佔 BitBrowser 渲染器CPU。
5. 保留：V1.50.36的自由間隔、owner+latest OwnerLock、429/Cloudflare保護、PhoneFirst API、WA、Signal帳號/群組/852.jpg及本機C盤設定（本版不更改/覆寫）。

限制：Chromium/BitBrowser 和 Windows 仍可能自行凍結或省電；FocusEmulation 只能減少「失焦節流」問題，並非 Windows 鎖屏或 Chrome 背景頁無限保活保證。若頻繁 0.1 秒刷新導致電腦卡頓，降低查詢頻率比提高 CPU 優先級更有效。不能取消網站 HTTP429 限制。

建議：先用28租售各0.5秒 + 730智能保護測試；切換到其他視窗或最小化 BitBrowser 後觀察[API-LIST-OK]/[730-NATIVE-API-OK]是否持續，捕獲新號碼時仍能即時複製。測試須在用戶自己的Windows/BitBrowser 173完成。
