# -*- coding: utf-8 -*-
"""Offline direct API test: no browser/page navigation, no phone reveal."""
import asyncio
from house730_direct_api import (phone_url_for_id, mismatched_property,
                                  DirectPhoneLookup, safe_id)
from house730_phone_first import contacts_from_api
from urllib.parse import urlsplit, parse_qs


def test_mapper():
    pid = '9293251'
    assert safe_id(pid) == pid
    assert safe_id('9293251/../no') is None
    assert parse_qs(urlsplit(phone_url_for_id(pid)).query) == {'propertyId':[pid]}
    t = {'url':'https://api.house730.com/Property/GetPropertyUserInfoById?propertyId=9292554&language=zh&platform=wap&cityen=hk&opaque=sessvalue'}
    fields = parse_qs(urlsplit(phone_url_for_id(pid,t)).query)
    assert fields['propertyId'] == [pid]
    assert fields['opaque']==['sessvalue'] and fields['language']==['zh']
    assert mismatched_property({'result':{'propertyId':'999','contacts':[]}},pid)
    assert not mismatched_property({'result':[{'telphone':'61822314'}]},pid)
    assert contacts_from_api({'result':[{'telphone':'61822314','contactNameCN':'Alice','isShowTel':True}]}) == [('Alice','61822314')]


class FakePage:
    def __init__(self, data, status=200): self.data=data;self.status=status;self.closed=False;self.calls=[]
    def is_closed(self): return self.closed
    async def evaluate(self, js, options):
        self.calls.append(options)
        return {'status':self.status, 'payload':self.data} if self.status==200 else {'status':self.status, 'reason':'http'}

class FakeContext:
    def __init__(self):self.cb={}
    def on(self,event,callback):self.cb[event]=callback
    def remove_listener(self,event,callback): self.cb.pop(event,None)

class FakeList:
    def __init__(self):self.ready=True;self.inflight=asyncio.Lock();self.template={'headers':{'AppKey':'publicappkey','AppSignature':'do-not-copy','Language':'zh'}}

class FakeRequest:
    def __init__(self,url):self.url=url;self.method='GET';self.headers={'language':'zh','appsignature':'ephemeral'}

async def test_direct():
    ctx=FakeContext(); direct=DirectPhoneLookup(ctx); light=FakeList()
    page=FakePage({'code':1,'result':[{'telphone':'61234567','customerTel':'','contactNameCN':'Mandy','isShowTel':True}]})
    res=await direct.query(page,'9293251',light)
    assert res.reason=='success' and res.contacts==[('Mandy','61234567')], res
    assert len(page.calls)==1
    opts=page.calls[0]
    assert parse_qs(urlsplit(opts['url']).query)['propertyId']==['9293251']
    assert 'AppSignature' not in opts['headers'] and opts['headers']['AppKey']=='publicappkey'
    # After observing genuine site contact request: preserve full URL extras
    ctx.cb['request'](FakeRequest('https://api.house730.com/Property/GetPropertyUserInfoById?propertyId=9292554&language=zh&platform=wap&opaque=private'))
    page2=FakePage({'result':[{'telphone':'91234567','contactNameCN':'Jenny'}]})
    res2=await direct.query(page2,'9293251',light)
    assert res2.used_template and res2.contacts == [('Jenny','91234567')]
    fields=parse_qs(urlsplit(page2.calls[0]['url']).query)
    assert fields['propertyId']==['9293251'] and fields['opaque']==['private']
    blocked=FakePage({}, status=429)
    r=await direct.query(blocked,'9293251',light)
    assert r.status==429 and not r.contacts
    mismatch=FakePage({'result':{'propertyId':'11223344','contacts':[{'telphone':'91234567'}]}})
    r=await direct.query(mismatch,'9293251',light)
    assert r.reason=='property-mismatch' and not r.contacts
    invalid=FakePage({'result':[{'telphone':'9123****','isShowTel':True}]})
    r=await direct.query(invalid,'9293251',light)
    assert r.reason=='no-full-phone'
    direct.close()
    assert not ctx.cb
    print('PASS 730 V1513 direct API: propertyId param, no page navigation, template, blocked, mismatch, masked and no-click')

if __name__=='__main__':
    test_mapper();asyncio.run(test_direct())
