# -*- coding: utf-8 -*-
"""V1.50.17: CDP socket retirement, event pump and attach-only tests."""
import json
import inspect
import socket
from urllib.parse import urlencode

from panda28_core import CDP, App
from panda28_api import capture_template

class QuietSocket:
    def __init__(self): self.calls=0
    def settimeout(self,v): pass
    def recv(self): self.calls+=1; raise socket.timeout('quiet, not broken')
    def close(self): pass

s=CDP('ws://127.0.0.1/devtools/page/still-open');s.ws=QuietSocket()
assert not s.pump_event(.03) and not s.pump_event(.03)
assert not s.dead and s.ws.calls==2, 'No CDP network events is not a dead socket'

class FailingSocket:
    def __init__(self): self.sent=0
    def settimeout(self,t): pass
    def send(self,m):self.sent+=1
    def recv(self):raise socket.timeout('blocked renderer')
    def close(self):pass

s2=CDP('ws://127.0.0.1/devtools/page/still-open');s2.ws=FailingSocket()
try:s2.call('Runtime.evaluate', {'expression':'true'},timeout=.05)
except TimeoutError:pass
else:raise AssertionError('Command should time out')
assert s2.dead and s2.ws.sent==1
try:s2.call('Runtime.evaluate', {'expression':'true'})
except ConnectionError as e: assert 'socket retired' in str(e)
else:raise AssertionError('Expired socket must not accept a second command')
assert s2.ws.sent==1

class FakeCDP:
    def __init__(self): self.calls=[]; self.event_handler=None;self.closed=False;self.pump_called=0
    def call(self, name, args=None, timeout=None):
        self.calls.append(name)
        if name=='Runtime.evaluate' and args.get('expression')=='location.href':
            return {'result':{'value':'https://www.28hse.com/rent?landlordAgency=LANDLORD&sortBy=latest'}}
        if name=='Page.reload':return {}
        if name=='Runtime.evaluate' and args.get('expression')=='true':
            raise AssertionError('Old Runtime.evaluate-based polling is forbidden')
        return {'result':{}}
    def ev(self, code, timeout=None):return False
    def pump_event(self, timeout=.3):
        self.pump_called+=1
        if self.pump_called==1:
            self.event_handler({'method':'Network.requestWillBeSent','params':{'request':{
                'method':'POST','url':'https://www.28hse.com/property/dosearch',
                'postData':urlencode({'form_data':json.dumps({'landlordAgency':'LANDLORD','sortBy':'latest','buyRent':'rent'})})}}})
            return True
        return False
    def close(self):self.closed=True

class MockApp:
    def __init__(self):self.c=FakeCDP()
    def target(self,k):return {'id':'already-open-rent','url':'https://www.28hse.com/rent?landlordAgency=LANDLORD&sortBy=latest','webSocketDebuggerUrl':'ws://127.0.0.1/current-tab'}
    def cdp(self,t):return self.c
    def create_background_target(self,url):raise AssertionError('Must not create a tab')
    def close_target_id(self,tid):raise AssertionError('Must not close user tab')

ma=MockApp()
t,c,template=capture_template(ma,'rent',lambda:True)
assert t['id']=='already-open-rent'
assert ma.c.pump_called==1
assert 'Page.reload' in ma.c.calls and not ma.c.closed
assert not any(x in ma.c.calls for x in ['Page.navigate','Target.createTarget','Page.bringToFront'])
assert c.event_handler is None
worker=inspect.getsource(App.worker)
assert '[28-CDP-REATTACH]' in worker
assert 'if c is None:' in worker
assert '[28-TAB-WAIT]' in worker
assert 'origin_query_gate' not in worker
print('PASS V1.50.17: socket retired once, quiet event pump stays live, attach existing tab, no new tab, independent rent/buy')
