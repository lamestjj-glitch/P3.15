# -*- coding: utf-8 -*-
"""Regression tests for BitBrowser CDP event-loop, page load, and challenge UI."""
import unittest
from unittest.mock import patch
from types import SimpleNamespace

from site_engine import BitBrowserFetcher, is_verification_page, DEFAULT_BFS
from playwright.sync_api import TimeoutError as PlaywrightTimeoutError

LISTING = """<!doctype html><html><head><title>Businesses for sale</title>
<script>let dummy = 'cf-chl- captcha challenge just a moment...';</script></head>
<body><a href='/businesses-for-sale/an-owner-business-42769'>Direct owner listing</a></body></html>"""
VERIFY = """<html><head><title>Just a moment...</title></head>
<body><div id='challenge-stage'>Verify you are human — checking your browser</div></body></html>"""

class DummyPage:
    url = 'about:blank'
    def __init__(self, html=LISTING):
        self.html = html
        self.calls=[]
        self.closed=False
    def is_closed(self): return self.closed
    def set_default_timeout(self,*args): pass
    def set_default_navigation_timeout(self,*args): pass
    def goto(self, url, **kwargs):
        self.url=url
        self.calls.append(('goto',kwargs))
    def reload(self,**kwargs): self.calls.append(('reload',kwargs))
    def wait_for_load_state(self,*args,**kwargs): pass
    def content(self): return self.html
    def close(self): self.closed=True

class DummyBrowser:
    def __init__(self,page): self.page=page
    @property
    def contexts(self): return [SimpleNamespace(new_page=lambda:self.page, pages=[self.page])]

class Tests(unittest.TestCase):
    def test_verification_not_false_positive(self):
        self.assertFalse(is_verification_page(LISTING))
        self.assertTrue(is_verification_page(VERIFY))
        self.assertFalse(is_verification_page('<html><body>example captcha challenge in script</body></html>'))

    def test_cdp_port_resolved_before_playwright_start(self):
        f=BitBrowserFetcher(dict(DEFAULT_BFS, shared_cdp_endpoint='',
                                 bitbrowser_api_token='test-secret', bitbrowser_seq=173))
        page=DummyPage()
        browser=DummyBrowser(page)
        order=[]
        async def find(api,token,seq):
            order.append('list')
            self.assertEqual(seq,173)
            return {'id':'env-173'}
        async def ports(api,token,idx):
            order.append('ports')
            return ['http://127.0.0.1:56965']
        class FakePlaywright:
            def __init__(self): self.chromium = SimpleNamespace(connect_over_cdp=self.connect)
            def connect(self,*args,**kwargs):
                order.append('cdp')
                return browser
            def stop(self): order.append('stop')
        pw=FakePlaywright()
        class PlaywrightLauncher:
            def start(self):
                order.append('playwright')
                return pw
        import bitbrowser_adapter
        with patch.object(bitbrowser_adapter,'_find_profile_by_seq',new=find), \
             patch.object(bitbrowser_adapter,'_query_port_endpoints',new=ports), \
             patch('playwright.sync_api.sync_playwright',return_value=PlaywrightLauncher()):
            with f:
                self.assertEqual(f.url,'http://127.0.0.1:56965')
                self.assertEqual(order[:4],['list','ports','playwright','cdp'])
        self.assertIn('stop',order)

    def test_missing_list_tab_never_opens_background_page(self):
        f=BitBrowserFetcher(DEFAULT_BFS)
        page=DummyPage();f.page=None;f.browser=DummyBrowser(page)
        with self.assertRaisesRegex(RuntimeError,'SITE-TAB-WAIT'):
            f.fetch(DEFAULT_BFS['url'])
        self.assertEqual(page.calls,[], 'Monitor may not navigate/reopen a closed list')

    def test_existing_browser_tab_fallback_marks_snapshot(self):
        f=BitBrowserFetcher(DEFAULT_BFS)
        hidden=DummyPage('<html><body>Loading...</body></html>')
        live=DummyPage(LISTING); live.url=DEFAULT_BFS['url']
        def timeout(url,**kwargs):
            hidden.url=url
            raise PlaywrightTimeoutError('not committed')
        hidden.goto=timeout
        f.page=hidden
        f.browser=SimpleNamespace(contexts=[SimpleNamespace(pages=[hidden,live])])
        f.last_list_url=''
        self.assertEqual(f.fetch(DEFAULT_BFS['url']), LISTING)
        self.assertEqual(f.last_fetch_mode, 'snapshot')
        # During the cooldown, only read DOM, never reload the user's tab.
        self.assertEqual(f.fetch(DEFAULT_BFS['url']), LISTING)
        self.assertEqual(f.last_fetch_mode, 'snapshot')
        self.assertEqual(hidden.calls,[])
        self.assertEqual(live.calls,[])

    def test_no_silent_acceptance_of_empty_dom_on_timeout(self):
        f=BitBrowserFetcher(DEFAULT_BFS)
        page=DummyPage('<html><body>Loading...</body></html>')
        def timeout(url,**kwargs):
            page.url=url
            raise PlaywrightTimeoutError('navigation did not finish')
        page.goto=timeout
        f.page=page;f.browser=DummyBrowser(page);f.last_list_url=''
        with self.assertRaisesRegex(RuntimeError,'SITE-TAB-WAIT'):f.fetch(DEFAULT_BFS['url'])

    def test_rendered_listing_after_navigation_timeout(self):
        f=BitBrowserFetcher(DEFAULT_BFS)
        page=DummyPage(LISTING)
        def timeout(url,**kwargs):
            page.url=url
            raise PlaywrightTimeoutError('lifecycle event did not finish')
        page.goto=timeout
        page.url=DEFAULT_BFS['url']  # User has opened the source manually.
        f.page=None;f.detail_page=None;f.browser=DummyBrowser(page);f.last_list_url=''
        self.assertEqual(f.fetch(DEFAULT_BFS['url']),LISTING)
        self.assertEqual(page.calls,[], 'Existing user tab is never navigated')

if __name__ == '__main__': unittest.main(verbosity=2)
