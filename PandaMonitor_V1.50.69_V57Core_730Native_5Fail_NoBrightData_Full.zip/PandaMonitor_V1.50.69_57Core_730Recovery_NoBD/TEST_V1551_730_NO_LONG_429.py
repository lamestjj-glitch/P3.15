# -*- coding: utf-8 -*-
"""No-network tests for V1.50.51: 429 must not pause both 730 lanes for hours."""
import asyncio
import threading
from pathlib import Path
from house730_adaptive_rate import SharedHouse730Rate
from house730_engine import record_page_429

class Clock:
    def __init__(self): self.t=1000.0
    def __call__(self): return self.t
    async def sleep(self, delay):
        self.t+=delay
        await asyncio.sleep(0)

class Reply:
    status=429
    headers={'retry-after': '3600'}

async def main():
    clock=Clock(); stop=threading.Event(); lines=[]
    rate=SharedHouse730Rate(lambda:.15, stop, lines.append,
                            clock=clock, sleeper=clock.sleep, jitter=lambda: .1)
    assert record_page_429(Reply(),rate,'租')
    assert rate.in_cooldown('租')
    assert not rate.in_cooldown('售')
    assert 2.99<=rate._lane_429_until['租']-clock()<=3.01
    before=clock()
    async with rate.slot('售'):
        assert clock()-before<1.0, 'buy must not wait for rent Retry-After'
    async with rate.slot('租'):
        assert 3<=clock()-before<4.0, 'rent must retry after short pause'
    assert not rate.in_cooldown('租')
    assert not any('730-429-SHARED' in s for s in lines)
    assert any('730-429-ADAPT' in s for s in lines)
    # Repeated 429 uses a short capped progression, NEVER an hour-long wait.
    for delay in (3,6,12,24,30,30):
        rate.limit(3600,deal='售')
        assert delay - .01 <= rate._lane_429_until['售'] - clock() <= delay + .01
        async with rate.slot('售'): pass
    rate.success('售')
    assert rate._lane_429_streak['售'] == 0
    rate.limit(3600,deal='售')
    assert rate._lane_429_until['售'] - clock() <= 3.01
    # Ensure all call sites were switched to per-source signature.
    engine=Path('house730_engine.py').read_text(encoding='utf-8')
    assert 'rate.wait_cooldown()' not in engine
    assert 'rate.limit()' not in engine
    assert 'rate.limit(e.retry_after)' not in engine
    assert 'rate.limit(list_error.retry_after)' not in engine
    assert 'record_page_429(first_reply, rate)' not in engine
    assert 'rate.wait_cooldown(deal)' in engine
    assert 'rate.limit(deal=deal)' in engine  # phone API HTTP429
    assert 'retry_after' in engine  # parsing still allowed for diagnostics
    gui=Path('unified_gui.py').read_text(encoding='utf-8')
    assert 'V1.50.51' in gui
    assert '730 HTTP429｜租售共用冷卻中' not in gui
    print('PASS V1.50.51: no 3192s/3600s pause, no shared lane, bounded 3-30s per source, phone and GUI wired')

if __name__=='__main__': asyncio.run(main())
