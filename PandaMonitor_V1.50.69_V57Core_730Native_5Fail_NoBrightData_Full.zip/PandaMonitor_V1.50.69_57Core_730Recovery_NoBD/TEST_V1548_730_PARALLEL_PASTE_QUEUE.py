# -*- coding: utf-8 -*-
"""V1.50.48 no-network deterministic tests: 730 lane locks and paste queue."""
import asyncio
import threading
from house730_adaptive_rate import SharedHouse730Rate
from paste_clipboard_queue import PasteClipboardQueue


async def test_730_parallel():
    stop = threading.Event()
    messages = []
    rate = SharedHouse730Rate(lambda: 0.001, stop, messages.append,
                              jitter=lambda: .1)
    inside = []
    entered = {"租": asyncio.Event(), "售": asyncio.Event()}
    release = asyncio.Event()

    async def source(deal):
        async with rate.slot(deal):
            inside.append(deal)
            entered[deal].set()
            await release.wait()
            inside.remove(deal)

    tasks = [asyncio.create_task(source("租")), asyncio.create_task(source("售"))]
    await asyncio.wait_for(asyncio.gather(*(e.wait() for e in entered.values())), 1)
    assert sorted(inside) == ["售", "租"], inside  # true concurrent in-flight requests
    second = asyncio.create_task(source("租"))
    await asyncio.sleep(.025)
    assert len(inside) == 2, 'second rent overlapped first rent'
    release.set()
    await asyncio.gather(*tasks, second)
    assert not inside
    rate.limit(3600, deal="租")
    assert rate.in_cooldown("租") and not rate.in_cooldown("售"), "only affected lane pauses"
    assert any('730-429-ADAPT' in m for m in messages)
    assert not any('730-429-SHARED' in m for m in messages)
    assert rate.floor == .001
    assert not any('730-RATE-ADAPT' in m for m in messages)


class Clock:
    def __init__(self):
        self.time = 100.0
    def __call__(self):
        return self.time
    def advance(self, seconds):
        self.time += seconds


def test_clipboard_queue():
    """V1.50.57 changes the old paste-gated behaviour to latest-first."""
    clock = Clock()
    state = {'seq': 100, 'text': 'initial', 'busy': False}
    logs = []
    def write(value):
        if state['busy']:
            return False
        state['seq'] += 1
        state['text'] = value
        return True
    queue = PasteClipboardQueue(write, lambda: state['seq'], logs.append,
                                clock=clock)
    assert queue.submit('1369\n6993', ('28', 'A')) == 'copied'
    assert queue.submit('1873', ('730', 'B')) == 'copied'
    assert state['text'] == '1873', 'must not wait for Ctrl+V'
    assert queue.submit('9999', ('28', 'C')) == 'copied'
    assert state['text'] == '9999'
    assert not queue.extend(('28','A'), '1369\n9999')
    state['busy'] = True
    assert queue.submit('4567', ('28', 'D')) == 'queued'
    assert queue.submit('8901', ('730', 'E')) == 'queued'
    assert queue.pending_count() == 1
    state['busy'] = False
    clock.advance(.16)
    queue.poll()
    assert state['text'] == '8901', 'only newest busy result should recover'
    state['seq'] += 1
    state['text'] = 'USER TEXT'
    queue.poll()
    assert queue.paused_external
    clock.advance(.4)
    queue.poll()
    assert state['text'] == 'USER TEXT'
    queue.manual_override()
    assert queue.pending_count() == 0


if __name__ == '__main__':
    asyncio.run(test_730_parallel())
    test_clipboard_queue()
    print('PASS V1.50.57: 730 rent/buy concurrent; source-only 429; clipboard latest immediate; busy retry; manual safety')
