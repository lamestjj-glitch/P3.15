# -*- coding: utf-8 -*-
"""Pure offline rate-limit tests. No external HTTP or Signal sends."""
import asyncio
import threading
from house730_adaptive_rate import SharedHouse730Rate
from house730_light_api import parse_retry_after, House730LightAPI, PollError

class Clock:
    def __init__(self):self.t=1000.0
    def __call__(self):return self.t
    async def sleep(self, sec):
        self.t+=sec
        await asyncio.sleep(0)

async def test_rate():
    c=Clock();logs=[];stop=threading.Event()
    governor=SharedHouse730Rate(lambda:.15,stop,logs.append,clock=c,sleeper=c.sleep,
                                jitter=lambda: .1)
    assert governor.spacing==.15 and governor.floor==.15
    starts=[]
    # Same-lane cadence stays fixed; other lane uses independent lock.
    for _ in range(4):
        async with governor.slot("租"):
            starts.append(c())
            governor.success()
    assert all(b-a>=.249 for a,b in zip(starts,starts[1:])), starts
    assert governor.spacing==governor.floor==.15
    before=c()
    governor.limit(3600,deal="租")
    assert governor.in_cooldown("租") and not governor.in_cooldown("售")
    # Other lane is not blocked by a 3600 second Retry-After.
    async with governor.slot("售"):
        assert c() - before < 1, "buy waited for rent 429"
        governor.success()
    assert governor.in_cooldown("租")
    async with governor.slot("租"):
        assert 3 <= c() - before < 4, "rent must pause briefly, not hours"
    assert not governor.in_cooldown("租")
    assert not stop.is_set()
    assert abs(governor._requested()-.15)<1e-9

async def test_transport():
    assert parse_retry_after('180')==180
    assert parse_retry_after('junk')==0
    assert parse_retry_after('Tue, 15 Nov 1994 08:12:31 GMT')==0
    class Response:
        status=429
        url='https://api.house730.com/Property/QueryProperty'
        headers={'retry-after':'260','content-type':'application/json'}
        async def body(self):return b'{}'
    class Req:
        async def fetch(self,*a,**kw):return Response()
    class Ctx:request=Req()
    class Page:
        context=Ctx()
        url='https://www.house730.com/rent/s1u14/'
        def on(self,*a):pass
        def remove_listener(self,*a):pass
        def is_closed(self):return False
    api=House730LightAPI(Page(),'租',prefer_native=True)
    api.template={'url':Response.url,'method':'POST','headers':{},'body':'{}'}
    try:
        await api.query()
    except PollError as e:
        assert e.status==429 and e.retry_after==260 and e.cooldown==180
        assert api.transport=='native'  # do NOT rotate transports after 429
    else:
        raise AssertionError('429 should be raised')
    api.detach()

async def main():
    await test_rate()
    await test_transport()
    print('PASS V1.50.34: 730 per-lane single-flight with concurrent rent/buy, 429 short per-lane wait, no long Retry-After, fixed cadence, native stays native, settings immutable')

if __name__=='__main__':asyncio.run(main())
