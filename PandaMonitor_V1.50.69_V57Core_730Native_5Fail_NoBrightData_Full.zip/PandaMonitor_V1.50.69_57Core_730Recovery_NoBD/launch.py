# -*- coding: utf-8 -*-
"""Crash-resilient, log-first UI entry for PandaMonitor 28Hse+House730.

No monitoring behavior changes. Keep this process in console so startup exceptions
can be read from logs rather than disappearing with a double-clicked script.
"""
from __future__ import annotations
import os
import sys
import traceback
import threading
import multiprocessing
from pathlib import Path
from datetime import datetime

DIR = Path(os.environ.get('LOCALAPPDATA') or Path(__file__).resolve().parent) / 'PandaMonitor_28Hse_House730' / 'logs'
try:
    DIR.mkdir(parents=True, exist_ok=True)
except OSError:
    DIR = Path(os.environ.get('TEMP') or Path.cwd())
LOGFILE = DIR / 'startup.log'

def log(line):
    try:
        with LOGFILE.open('a', encoding='utf-8') as fh:
            fh.write(f'[{datetime.now().isoformat(timespec="seconds")}] {line}\n')
    except OSError:
        pass

def fatal(exc):
    msg = ''.join(traceback.format_exception(type(exc), exc, exc.__traceback__))
    log('FATAL STARTUP ERROR:\n' + msg)
    print(msg, file=sys.stderr, flush=True)
    if os.name == 'nt':
        try:
            import ctypes
            ctypes.windll.user32.MessageBoxW(None,
                f'PandaMonitor 啟動失敗。\n\n{type(exc).__name__}: {str(exc)[:340]}\n\n錯誤日誌：\n{LOGFILE}',
                'PandaMonitor 啟動失敗', 0x10 | 0x0)
        except Exception:
            pass

def thread_exception(args):
    msg = ''.join(traceback.format_exception(args.exc_type, args.exc_value, args.exc_traceback))
    log(f'UNHANDLED THREAD {args.thread.name}:\n{msg}')
    print(msg, file=sys.stderr, flush=True)

threading.excepthook = thread_exception

def main():
    # One GUI per Windows login session; the House730 worker is a separate
    # spawned process and does not call this main(). The OS releases the mutex
    # automatically on crash/exit, so a stale lock file cannot block startup.
    instance_mutex = None
    if os.name == 'nt':
        import ctypes
        kernel = ctypes.WinDLL('kernel32', use_last_error=True)
        create = kernel.CreateMutexW
        create.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_wchar_p]
        create.restype = ctypes.c_void_p
        instance_mutex = create(None, 1, 'Local\\PandaMonitor_28Hse_House730_Unified')
        if instance_mutex and ctypes.get_last_error() == 183:
            print('[ALREADY-RUNNING] PandaMonitor 已開啟；請勿同時啟動兩個版本', flush=True)
            kernel.CloseHandle(ctypes.c_void_p(instance_mutex))
            return 0
    log(f'START executable={sys.executable}, version={sys.version.split()[0]}, cwd={os.getcwd()}')
    try:
        from unified_gui import UnifiedApp
        app = UnifiedApp()
        def tk_exception(exc_type, exc_value, tb):
            msg=''.join(traceback.format_exception(exc_type, exc_value, tb))
            log('TK CALLBACK ERROR:\n' + msg)
            print(msg, file=sys.stderr, flush=True)
        app.report_callback_exception = tk_exception
        try:
            app._load_house_history()
        except Exception as exc:
            # A malformed or locked old database must not prevent the GUI opening.
            log('WARN: could not load House730 history:\n' +
                ''.join(traceback.format_exception(type(exc), exc, exc.__traceback__)))
        log('GUI_READY')
        print(f'[GUI_READY] Startup OK. Log: {LOGFILE}', flush=True)
        if '--self-test' in sys.argv:
            app.update_idletasks()
            app.update()
            app.destroy()
            log('SELF_TEST_OK')
            print('[SELF_TEST_OK]', flush=True)
            return 0
        app.mainloop()
        log('GUI_CLOSED_NORMALLY requested_by_user=%s' % bool(getattr(app, '_user_requested_close', False)))
        return 0
    except BaseException as exc:
        fatal(exc)
        return 1

if __name__ == '__main__':
    multiprocessing.freeze_support()
    sys.exit(main())
