# -*- coding: utf-8 -*-
"""V1.50.21 offline regression: false Win+L lock-wait; existing JSON; unlock."""
import asyncio
import threading
from unittest.mock import patch
from pathlib import Path

import house730_engine as he
import windows_session_state as ws

assert ws.input_desktop_state() is None  # Linux: no active Windows session assumed
with patch.object(ws, 'locked_state', return_value=True), patch.object(ws, 'input_desktop_state', return_value=False):
    assert ws.is_locked() is False, 'Interactive Default desktop should defeat stale WTS locked flag'
with patch.object(ws, 'locked_state', return_value=False), patch.object(ws, 'input_desktop_state', return_value=True):
    assert ws.is_locked() is True, 'Interactive Winlogon input desktop signals lock'
with patch.object(ws, 'locked_state', return_value=True), patch.object(ws, 'input_desktop_state', return_value=None):
    assert ws.is_locked() is True, 'Fallback to WTS when input desktop cannot be opened'
with patch.object(ws, 'locked_state', return_value=None), patch.object(ws, 'input_desktop_state', return_value=None):
    assert ws.is_locked() is False, 'Unknown must not be treated as locked'

class Page:
    url='https://www.house730.com/rent/s1u14/'
    closed=False
    reload_count=0
    def is_closed(self): return self.closed
    async def reload(self, **kwargs):
        self.reload_count+=1
        return None
class Light:
    def __init__(self, ready): self.ready=ready

async def run():
    p=Page()
    notices=[]
    # Genuine Win+L: no reload permitted. But an existing genuine JSON
    # request template is already valid and can continue without navigation.
    with patch.object(he,'windows_session_locked',return_value=True), patch.object(
        he,'dom_urls',return_value=['https://www.house730.com/rent-property-9301234/','https://www.house730.com/rent-property-9301235/']):
        live,links=await asyncio.wait_for(
            he.wait_unlock_or_live_json(p,'租',Light(True),threading.Event(),lambda: notices.append('blocked'),interval=.01),timeout=.5)
        assert live and len(links)==2 and not notices and p.reload_count==0

    # While locked without signed JSON, never navigate. Once Windows reports
    # unlock, leave the lock-wait gate and allow the normal single reload.
    state=[True]
    def read_lock(): return state[0]
    async def unlock():
        await asyncio.sleep(.05)
        state[0]=False
    with patch.object(he,'windows_session_locked',side_effect=read_lock):
        unlocked=asyncio.create_task(unlock())
        live,links=await asyncio.wait_for(
            he.wait_unlock_or_live_json(p,'租',Light(False),threading.Event(),lambda: notices.append('lock-wait'),interval=.01),timeout=1)
        await unlocked
        assert not live and not links and notices==['lock-wait']
        await he.lock_safe_list_reload(p,'租')
        assert p.reload_count==1

    # Never auto-navigate from an incorrect tab or closed tab.
    p.url='https://www.house730.com/buy/s1u14/'
    with patch.object(he,'windows_session_locked',return_value=True):
        try:
            await he.wait_unlock_or_live_json(p,'租',Light(True),threading.Event(),lambda:None,interval=.01)
            raise AssertionError('Wrong list URL should fail')
        except he.PollError as ex:
            assert ex.kind=='list-not-ready'
    assert p.reload_count==1
asyncio.run(run())

src=Path(he.__file__).read_text(encoding='utf8')
assert "[730-LOCK-JSON-CONTINUE]" in src
assert "[730-LOCK-RESUME]" in src
assert "state['mode'] = 'reconnecting'" in src
start=src.split('            async def list_loop(deal):',1)[1].split('            async def detail_worker(index):',1)[0]
assert 'context.new_page()' not in start
assert 'await page.goto(url' not in start
assert 'await wait_unlock_or_live_json(' in start
print('PASS V1.50.21 lock-wait: WTS mismatch, live JSON without reload, unlock immediate resume, zero new list tabs')
