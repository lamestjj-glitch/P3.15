@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
if errorlevel 1 goto failed
powershell.exe -NoProfile -NoLogo -ExecutionPolicy Bypass -File "%~dp0BUILD_EXE.ps1"
if errorlevel 1 goto failed
echo Build finished. Press any key to close.
pause
exit /b 0
:failed
echo Build failed. See output above.
pause
exit /b 1
