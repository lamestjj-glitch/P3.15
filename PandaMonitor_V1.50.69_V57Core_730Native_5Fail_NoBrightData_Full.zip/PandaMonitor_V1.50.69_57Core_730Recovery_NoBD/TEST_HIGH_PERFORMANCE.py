# -*- coding: utf-8 -*-
"""Run: python TEST_HIGH_PERFORMANCE.py (does not contact any website)."""
import os
import queue
import time
import threading
from house730_process import House730Process
from performance import launch_worker, apply_worker_priority

class PhoneLedger:
    def __init__(self):
        self.seen = set()
        self.lock = threading.Lock()
    def save_phone(self, deal, url, raw_phone, contact='未提供'):
        with self.lock:
            if raw_phone in self.seen:
                return False
            self.seen.add(raw_phone)
            return True

def main():
    ledger = PhoneLedger()
    proxy = House730Process({'__perf_smoke_test': True}, ledger)
    proxy.start()
    assert proxy.process.pid != os.getpid(), 'House730 must have its own OS process'
    seen=[]
    deadline=time.monotonic()+9
    while len(seen)<2 and time.monotonic()<deadline:
        try: ev=proxy.out.get(timeout=0.3)
        except queue.Empty: continue
        if ev.get('event')=='ipc_smoke': seen.append(ev)
    assert len(seen)==2, f'IPC events missing: {seen}'
    assert [x['accepted'] for x in seen]==[True,False], seen
    assert all(x['child_pid']!=os.getpid() for x in seen),seen
    proxy.process.join(timeout=3)
    assert proxy.process.exitcode==0,proxy.process.exitcode
    finished=threading.Event()
    def phone_worker(): finished.set()
    t=launch_worker(phone_worker, ())
    t.join(timeout=2)
    assert finished.is_set() and not t.is_alive()
    assert apply_worker_priority('bogus') is False
    print('PASS: independent OS process, phone IPC, atomic duplicate exclusion, clean child exit, 28Hse worker scheduling')

if __name__=='__main__':
    main()
