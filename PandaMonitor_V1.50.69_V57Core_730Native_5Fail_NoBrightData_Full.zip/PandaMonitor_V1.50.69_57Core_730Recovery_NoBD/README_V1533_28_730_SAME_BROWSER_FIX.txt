PandaMonitor V1.50.33 — 28Hse + House730 同時開啟的 CDP/API 資源競爭修復

以 V1.50.32 完整包為基礎修改，沿用原本 PandaMonitor V1.50.28 抓盤核心。
不變更任何已保存的 BitBrowser／Signal／WhatsApp 設定或帳號，亦不複製或覆寫 Windows 上的 config.json。

修正內容：
1. House730 與 28Hse 同時在 BitBrowser 環境 173 監控時，730 的列表優先使用 Playwright BrowserContext.request HTTP 客戶端，沿用現有瀏覽器會話的 Cookie 和從原始 XHR 學到的網址、方法、應用請求頭與 POST 內容，不需要 Runtime.evaluate 讓頁面執行 fetch。
2. 每路列表只有一個進行中的請求。當原生通道因簽名、會話或其他問題不相容時，不會同輪疊加一條瀏覽器 API，下一輪才恢復原有瀏覽器路徑。
3. 普通 CDP/Runtime 或本地 HTTP 通道錯誤不再被當成服務端 429 或無效 JSON 而觸發長達 60 秒的 HTML 備援；保留已驗證的模板／篩選／基線，適度退避並重試。
4. 任何真正 HTTP 401/403/429、Cloudflare 挑戰、非 JSON 或跳轉仍依原版保護和手動驗證處理；不規避限流或驗證。
5. 共用 CDP 的狀況下，730 頁面挑戰健康檢查最多約每 5 秒執行一次，降低無意義的 page.title()/inner_text() 開銷；真正 403/429 不等待此週期才處理。
6. 當只開 House730、不開 28Hse 時維持原來的頁面 API 模式。
7. 舊版 28Hse 500ms 智能模式、ad_id 直接取號、House730 直接電話 API、全站去重、WhatsApp、Signal CLI、852.jpg 路徑不改。

日誌識別：
[730-CDP-ISOLATION] 730列表優先獨立HTTP通道
[730-NATIVE-API-OK] 原生通道獲得有效列表
[730-TRANSPORT-RECOVER] 原生通道無法使用，回退原瀏覽器 API；不中斷

測試建議：
A. 先確定 28Hse 與 730 個別運作正常，再兩站同開；應見到 [730-CDP-ISOLATION]。
B. 如果有 [730-NATIVE-API-OK]，表示共用 CDP 壓力下 730 的列表可不經頁面 Runtime。
C. 如果只見 [730-TRANSPORT-RECOVER]，代表原生通道與當前網站請求格式不相容，已保留原方法；若原方法也持續失敗，可考慮分配第二個 BitBrowser 環境給 730，需另行設定，這個版本沒有替你修改環境。
D. 出現 429 / 網站人機驗證時先停查並手動完成驗證；不能把 500ms 視為網站保證接受的頻率。

本版只經本機離線單元測試，未在使用者 BitBrowser 或網站服務端做實際運行確認。
