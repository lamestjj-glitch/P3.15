# -*- coding: utf-8 -*-
"""No-network V1.50.53 delta cache/House730 serializer regression checks."""
import json
import tempfile
from pathlib import Path
from listing_incremental import ListingDeltaCache
from house730_light_api import parse_listing_urls
from house730_engine import Store


H = 'https://www.house730.com'
def rows(prefix, pids):
    return [(f'{H}/{prefix}-property-{pid}/sample/',str(pid)) for pid in pids]

c = ListingDeltaCache(head_size=6)
rent = rows('rent',list(range(100,120)))
buy = rows('buy',list(range(100,120)))
c.seed('租',rent)
c.seed('售',buy)
assert c.candidates('租',rent) == [], 'Unchanged list should incur zero DB claims'
assert c.candidates('售',buy) == [], 'Buy data are independently cached'
# New listing in top three: handled on same poll.
r1=rows('rent',[777]+list(range(100,119)))
assert [pid for _,pid in c.candidates('租',r1)] == ['777']
# Don't confirm until persistent DB checked; a transient DB error may retry.
assert [pid for _,pid in c.candidates('租',r1)] == ['777']
c.confirm('租',r1)
assert c.candidates('租',r1) == []
# New listing at position >6 must NOT wait for an audit or disappear.
r2=rows('rent',list(range(777,778))+list(range(100,106))+[888]+list(range(107,119)))
assert [pid for _,pid in c.candidates('租',r2)] == ['888'], 'Deep listing silently skipped'
c.confirm('租',[(r2[7])])
assert c.candidates('租',r2) == []
assert c.candidates('售',buy) == []
# Shared coordinator must never merge rent/sale IDs.
b1=rows('buy',[777]+list(range(100,119)))
assert [pid for _,pid in c.candidates('售',b1)] == ['777']
assert c.summary('租')['cache_skips'] >= 60
assert c.summary('租')['deep_new'] >= 1
# Bounded memory still falls back to persistent DB after eviction.
c2=ListingDeltaCache(head_size=6,max_ids=100)
c2.seed('租', rows('rent',range(100,200)))
c2.confirm('租',rows('rent',range(200,350)))
assert [pid for _,pid in c2.candidates('租',rows('rent',[100]))] == ['100']
# DB remains authoritative when cache is cleared or after a process restart.
with tempfile.TemporaryDirectory() as tmp:
    store=Store(db=Path(tmp)/'history.db')
    store.mark_many('租',[u for u,_ in rent])
    assert not store.claim('租',rent[0][0]), 'Old baseline should not be marked new'
    assert store.claim('租',r1[0][0]), 'Genuine new listing should be registered'
    assert not store.claim('租',r1[0][0]), 'Duplicate claim must be rejected'
    assert store.claim('售',b1[0][0]), 'Sale ID must not be hidden by rent ID'
    newcache=ListingDeltaCache()
    assert newcache.candidates('租',r1)
    assert not store.claim('租',r1[0][0]), 'Fresh in-memory cache cannot override persistent dedup'

samples=[
    {'data':{'list':[{'link':f'{H}/rent-property-123456/happy-cottage'},
                     {'link':f'{H}/rent-property-765432/happy-house'},
                     {'link':f'{H}/buy-property-999999/sale'}]}},
    {'result':{'rows':[f'/rent-property-123456/foo',f'/rent-property-123457/bar']}},
    {'items':[f'{H}/rent-property-123456/foo',f'{H}/rent-property-123456/foo']},
]
for obj in samples:
    for encode in (True,False):
        payload=json.dumps(obj,ensure_ascii=encode)
        assert parse_listing_urls(payload,'租') == parse_listing_urls(json.dumps(obj,ensure_ascii=False),'租')
        payload=payload.replace('/','\\/')
        assert parse_listing_urls(payload,'租') == parse_listing_urls(json.dumps(obj,ensure_ascii=False),'租')
# Deliberately encoded slash sequences must enter the fallback.
payload=json.dumps(samples[0],ensure_ascii=True).replace('/',r'\u002F')
assert len(parse_listing_urls(payload,'租'))==2
try:
    parse_listing_urls('{not valid}','租')
except Exception:
    pass
else:
    raise AssertionError('Invalid JSON must never be accepted')
root=Path(__file__).resolve().parent
source=(root/'house730_engine.py').read_text(encoding='utf-8')
assert 'listing_delta.candidates' in source and 'listing_delta.seed' in source
source=(root/'panda28_core.py').read_text(encoding='utf-8')
assert 'listing_delta.candidates' in source and 'listing_delta.seed' in source
assert 'api_snapshot(c,k,template,known_top,timeout_ms=4800)' in source
print('PASS V1.50.53: top-6 prioritization, deep same-poll detection, source isolation, bounded cache, SQLite dedup, JSON escapes')
