PandaMonitor V1.50.17 — 28Hse CDP 連線修正 + House730 嚴格零開帖

28Hse
- CDP Runtime.evaluate 短暫超時／socket retired：丟棄失效 socket，重新附加已開的原租盤／售盤列表，無需手動重啟監控；不新建列表頁。
- API 模板學習以 Network 事件接收取代重複 1 秒 Runtime.evaluate 心跳，減少失效連線重試。
- 不設定重試 3 次即永久停止；穩定退避（最高 15 秒），可在原頁恢復後接回。
- 維持租售獨立查詢秒數、single-flight、429 暫停、OwnerLock、直接ID電話API與尾四位自動複製。

House730
- **正式新帖和「測試首帖取號」一律只在已開的業主+最新列表頁直接請求 GetPropertyUserInfoById。**
- API 成功：完整電話顯示/去重，自動複製尾四位；不開詳情、不點擊揭號。
- API 沒有公開號碼：記錄 [730-DIRECT-NO-DETAIL]，不轉詳情頁；短暫 API 網絡故障最多額外補試 1 次。
- 監控列表關閉後等待手動重開，並保留待取電話隊列。
- 僅使用者明確點「打開原帖」才可手動開帖。

限制：未在使用者 Windows / BitBrowser 173 實站驗證；請查看 [28-CDP-REATTACH]、[API-VERIFY]、[730-DIRECT]、[730-DIRECT-NO-DETAIL] 等日誌。
