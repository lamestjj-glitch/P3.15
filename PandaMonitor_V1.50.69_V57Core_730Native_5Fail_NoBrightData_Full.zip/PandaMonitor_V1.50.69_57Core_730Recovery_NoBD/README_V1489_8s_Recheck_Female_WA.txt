PandaMonitor V1.48.9 — 8-second extra JSON check + Female-name WA eligibility
============================================================================

This is the FULL combined 28Hse + House730 source archive (not a prebuilt EXE).
Windows 10 + Python 3.12+; close older PandaMonitor first; extract and START.bat.
The C: configuration and phone-deduplication database are left untouched.

28Hse LIST CHECKS
- Normal rent and buy JSON-only polling remains independently editable in seconds.
- NEW: each rent/buy worker adds roughly one further JSON check every 8 seconds,
  sharing the original worker / single-flight queue (NEVER overlapping requests).
- Enable/disable using the "每約8秒額外JSON補查" checkbox in Unified Settings.
- [API-RECHECK] in logs indicates a completed extra check.
- A NEW triggers normal existing PhoneFirst; all deduplication still applies.
- Every extra check adds to server traffic, even when base polls are frequent.
  If HTTP 429 occurs, rent/buy *and* rechecks halt; no automatic retry.
- No list Reload, partial HTML Reload, foreground tab activation or OS input.

WHATSAPP GREETING ELIGIBILITY (28Hse AND House730)
- Enabled for a contact name with a clear female-associated honorific:
  小姐, 女士, 姐, Mrs, Ms, Miss.
- Or an exact English first-name token in the editable list, e.g. Alice, Mandy.
- Male honorifics 先生, Mr/Mister are negative even if a female name appears.
- Unknown/ambiguous name, surname only, names not in list: NO automatic greeting.
- 28Hse WA waits (up to 8 seconds) for contact-name backfill AFTER the phone
  was extracted/copied; no delay to PhoneFirst, clipboard, GUI or popup.
- For House730 it checks the contact field already obtained during phone reveal.
- Same check applies to WA send tests. Existing site-specific WA enable,
  time windows, messages, cross-site phone deduplication remain independent.
- User edits female English names (comma-separated) in Unified Settings;
  input is preserved alongside old settings. Matches are case-insensitive.
- Names/titles are not a reliable proof of a person's gender. This is a
  conservative name matching rule, not a demographic classification.
- WA status for skipped contacts says 未發送 with reason; skip never removes
  a property or phone from the normal results list.

VALIDATION
- Offline static/regression tests and GUI creation passed.
- NOT verified against the user's live BitBrowser profile or WhatsApp account.
- Avoid auto messages without the recipient's consent and respect rate limits.
