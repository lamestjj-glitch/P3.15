PandaMonitor V1.47.8 — 28Hse PhoneFirst / House730 Cloudflare Windows Alert

更新內容
1. 28Hse HTTP 揭號：原來等待詳情 HTML 串流下一塊資料才檢查致電 API 是否完成。
   現改為 Promise.race，只要致電 API 已返回有效電話，立即停止等待 HTML 串流。
   維持原本 HTTP 優先、失敗才單路 CDP 備援；不新增多餘的網絡請求。
2. 730：偵測到 Cloudflare/Turnstile 驗證時，兩路監控暫停，Windows 置頂彈窗提示，
   可按「查看730租盤／售盤」切換到現有 BitBrowser 分頁，手動完成驗證。
   每次驗證事件只彈一個視窗；驗證完成且穩定冷卻後自動收起提醒並恢復低頻監控。
3. 其他 28Hse OwnerLock、電話去重、自動複製尾四位、獨立 WA 與四路共用 UI 沒有重新設計。

使用方式：解壓全部，停止舊版後雙擊 START.bat。原有設定 / SQLite 去重紀錄保留。

實測限制：本版經離線、Node.js 模擬串流與 Xvfb GUI 測試；仍未連接用戶的真實 BitBrowser。
500ms 是需要網絡與站方接口配合的目標，並非保證。Cloudflare 驗證需真人手動完成。
House730 保護模式預設最少60秒查詢；不強制每秒發送120次請求。
