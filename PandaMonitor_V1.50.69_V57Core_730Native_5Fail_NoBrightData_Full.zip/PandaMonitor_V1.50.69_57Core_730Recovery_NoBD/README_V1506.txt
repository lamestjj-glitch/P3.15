PandaMonitor V1.50.6 — BusinessForSale.sg 已登入電話提取修復
=======================================================
基於 V1.50.5 完整版，保留 28Hse、House730、852.house 及原來統一 UI。

問題來源：
- 網站會員聯絡表格可能先顯示 Contact Person / Mobile Number / Email Address 三個標題，
  才顯示姓名和 +65 電話；舊版只認標題後立即接數字的格式，造成已登入仍顯示取號失敗。
- 詳情頁 JS 尚未渲染好時，舊版只等 Mobile Number 文字出現，就提前讀取資料。

修正：
1. 新加坡插件支援橫向/直向聯絡表格，僅在賣家聯絡資訊欄位內尋找電話，
   不會拿表單、頁尾客服電話或其他頁面數字冒充賣家電話。
2. 如 BitBrowser 173 已開啟完全相同的詳情 URL，優先只讀其 DOM，
   不跳頁、不搶焦點。否則使用已登入請求，最後才用一個可重用的背景詳情頁。
3. 等待真正的電話出現（最多約 4 秒），不再只等 Mobile Number 標籤。
4. 測試首帖取號失敗時顯示更明確的診斷訊息，仍不影響歷史去重、WA。
5. 修復已有的 C 盤舊 businessforsale_sg.py 插件覆蓋新原碼的問題：
   先關閉舊版，執行 UPGRADE_BFS.cmd，更新外置插件；會備份原插件。

安裝：
- 從 V1.50.5 升級：關閉程式，解壓 V1.50.6 完整 ZIP 至新資料夾；
  先雙擊 UPGRADE_BFS.cmd，再雙擊 START.bat。
- 若只要插件更新：將 site_plugins/businessforsale_sg.py 替換至
  C:\Users\你的用戶名\PandaMonitor_28Hse\site_plugins\ 之下，重啟 PandaMonitor。

診斷：
- 在 BitBrowser 173 使用有權查看賣家資料的帳號登入。
- 測試首帖取號讀的是列表第一個帖子，不一定是你以前手動開過的那個。
  要驗證已開帖子，請打開相同連結（URL 要相同）。
- 如果網站本身沒有把該帖電話提供給此帳號，程式不會猜造電話。
- 不會自動繞過會員驗證、人機驗證或登入限制。

驗證：本地離線測試及 GUI 冒煙測試通過；未在用戶 BitBrowser 帳號實測。
