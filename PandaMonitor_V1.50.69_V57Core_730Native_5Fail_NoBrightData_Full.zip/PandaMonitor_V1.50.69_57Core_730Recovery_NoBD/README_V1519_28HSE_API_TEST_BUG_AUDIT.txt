PandaMonitor V1.50.19 — 28Hse 租／售直接 API 測試 ＋ 隱藏 bug 審查
==============================================================

本版以 V1.50.18 完整程式為基礎；保留 House730 Direct API、嚴格零詳情頁、
28Hse 租／售獨立間隔、BitBrowser 既有分頁重連、429 暫停、女性 WA、跨站去重、
自動複製尾四位／手動複製完整電話、網站插件、Python 3.13 相容性。

主要修正（已做離線測試，實站仍須在 BitBrowser 173 確認）：

1. 原「28Hse 模擬揭號測試」遇 Direct API 無電話後會退回下載詳情 HTML 的
   舊 UltraRace 流程，引發「UltraRace取號超過自適應等待上限」誤導訊息。
   現在替換為「28Hse 租盤 API 測試」「28Hse 售盤 API 測試」，互不混用列表。
   使用各自最後成功的列表快取、最多測 3 個 ID，只走 ad_id 直接電話 API。
   不下載樓盤詳情 HTML、不開樓盤詳情頁、不點「致電」。
   網站同源 HTTP bridge 會短暫開啟 robots.txt 背景 Target，結束後關閉；
   這不是樓盤詳情分頁。
   手動測試會複製尾四位及顯示完整電話，不寫入永久電話去重庫。

2. HTTP bridge 在 Runtime.enable／socket connect 階段出錯時，原碼可能不關閉
   已建立的臨時 Target。已用 finally-equivalent 清理所有失敗路徑。

3. 正式電話 worker 的 JS 評估超時後，舊 CDP 物件可標記 dead 卻仍在
   下一個取號任務被重用。現在於新工作前丟棄已退休 socket／Target、
   重新接上使用者已開啟的環境；不另建監控列表分頁。

4. 28Hse 延後 HTTP 補試遇 CDP 暫停或 Stop 時，原先可留下 inflight 佔用；
   現在會釋放處理中狀態並寫入診斷日誌，以免後續人工／新輪補試被卡住。

5. 28Hse 列表已全局 429 暫停時，電話 worker 也停止增加新的電話 API 請求。
   不嘗試繞過 Cloudflare，不自動破解驗證。

6. 零開帖模式的舊 UltraRace 日誌不再誤稱『轉純 CDP 後台 fallback』。

實際操作：
  * 退出舊程式，完整解壓新 ZIP 到新資料夾，執行 START.bat。
  * 先在 BitBrowser 173 手動開啟 28Hse 租／售業主＋最新列表；啟動監控。
  * 等待本路 [API-LIST-OK] 和基線完成，使用對應的 API 測試按鈕。
  * 日誌： [28-API-TEST]、[28-API-TEST-SKIP]、[28-API-TEST-SUCCESS]。
  * 第一個帖子沒有公開電話時，會最多測當路最近三個，不代表接口必壞。

此次僅做離線回歸及 API 請求格式驗證，未登入用戶 BitBrowser 實機實測。
仍需留意：Cloudflare 429、網站沒有公開電話、CDP 高負載／共享瀏覽器
暫時中斷，均可能造成暫停或漏抓；請保留日誌以便實站針對性修正。
