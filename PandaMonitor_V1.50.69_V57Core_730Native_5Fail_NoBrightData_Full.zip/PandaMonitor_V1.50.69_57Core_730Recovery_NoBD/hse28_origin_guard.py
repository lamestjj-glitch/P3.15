# -*- coding: utf-8 -*-
"""Conservative shared *list-only* 28Hse request gate.

28Hse rent and buy use one profile and one remote origin; independent 500ms
preferences must not become two concurrent high-frequency request streams.
The phone API deliberately does NOT pass through this gate: a newly detected
phone always takes priority over ordinary list monitoring.

No IP rotation, challenge bypass, auto-retry after 429, or hidden background
traffic is implemented here.
"""
import contextlib
import threading
import time


class OriginQueryGate:
    def __init__(self, min_gap_seconds=1.5, clock=None):
        self.min_gap = max(.5, float(min_gap_seconds))
        self.clock = clock or time.monotonic
        self._condition = threading.Condition()
        self._pending = []
        self._ticket = 0
        self._active = False
        self._last_start = None
        self.counts = {'rent': 0, 'buy': 0}
        self.total_wait_ms = {'rent': 0, 'buy': 0}

    @contextlib.contextmanager
    def lease(self, lane, cancelled=None):
        """FIFO admission; callers *must* check the yielded bool.

        Never hold the shared gate while waiting for CDP template learning,
        parsing/GUI/phone work, or any subsequent retry/backoff. Each lease
        covers exactly ONE HTTP JSON list request, released even on exception.
        """
        aborted = cancelled or (lambda: False)
        admitted = False
        ticket = None
        wait_t0 = self.clock()
        with self._condition:
            self._ticket += 1
            ticket = self._ticket
            self._pending.append(ticket)
            try:
                while not aborted():
                    now = self.clock()
                    due = self._last_start is None or now >= self._last_start + self.min_gap
                    if self._pending[0] == ticket and not self._active and due:
                        self._active = True
                        self._last_start = now
                        self._pending.pop(0)
                        self.counts[lane] += 1
                        self.total_wait_ms[lane] += int((now-wait_t0)*1000)
                        admitted = True
                        break
                    rest = max(0.0, self._last_start + self.min_gap - now) if self._last_start is not None else 0.0
                    self._condition.wait(timeout=min(.15, max(.01, rest)))
            finally:
                if not admitted and ticket in self._pending:
                    self._pending.remove(ticket)
                    self._condition.notify_all()
        try:
            yield admitted
        finally:
            if admitted:
                with self._condition:
                    self._active = False
                    self._condition.notify_all()

    def stats(self):
        with self._condition:
            return {'rent': self.counts['rent'], 'buy': self.counts['buy'],
                    'wait_rent_ms': self.total_wait_ms['rent'],
                    'wait_buy_ms': self.total_wait_ms['buy'],
                    'queue': len(self._pending), 'min_gap_ms': int(self.min_gap*1000)}
