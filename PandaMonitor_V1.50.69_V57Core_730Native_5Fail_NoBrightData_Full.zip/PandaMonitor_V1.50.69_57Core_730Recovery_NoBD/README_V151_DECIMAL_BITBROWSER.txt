PandaMonitor V1.50.1 — 2026-10-13

【本版修正】
1. 「新增網站｜插件管理」內「刷新間隔」改成可自訂小數秒：0.1 ～ 3600 秒。
   例如 0.5、0.8、1、1.25、5、60；配置採浮點秒數保存，worker 的等待時間也使用浮點秒數。
   實際輪詢頻率還取決於網絡延遲、網站速度、頁面載入及失敗退避；不保證固定 0.5 秒完成一輪。
2. BusinessForSale.sg 預設刷新 1 秒；舊 V1.50.0 的 SG 預設會自動轉為 1 秒，並改為 BitBrowser 模式。
3. BitBrowser 模式：預設環境序號 173，會先嘗試重用 28Hse 已連線 CDP，否則從 BitBrowser 本地 API
   讀取已開啟環境的 CDP 端口（不調用 /browser/open，以免重設其他監控的連線）。
   在「統一設定」核對 BitBrowser Local API、Token、環境序號；先打開 173 環境並登入該站。
4. 手動在 BitBrowser 173 打開 BusinessForSale.sg 詳情頁：插件讀取當前已渲染 DOM 的
   Seller Contact & Listing Information > Mobile Number；支援沒有 tel: 的文本電話。
   頁面未顯示電話時不會猜測；登錄/會員權限本身不由本程序處理。
5. 28Hse 和 House730 原有抓帖、揭號、WA、去重、聯絡人和設定維持不變。

【使用】
1. 完全退出舊版本，再解壓新版 ZIP，運行 START.bat。
2. 在「統一設定」設定 BitBrowser API URL／Token，並先打開環境 173。
3. 到「新增網站｜插件管理」，選 BusinessForSale.sg →「編輯設定」。
   - 模式：bitbrowser
   - BitBrowser 環境序號：173
   - 刷新間隔（秒）：1 或 0.5 / 1.25 等
   - 勾選「啟用這個網站」，按保存，開始監控。
4. 可於 BitBrowser 173 手動打開詳情頁，程序會讀取頁面已顯示的賣家電話。

【備註】
 - 這是可運行的完整 Python 程序 ZIP，不是已編譯的 Windows EXE。
 - 已做離線單元測試與無頭 GUI 測試；未能連接用戶 Windows/BitBrowser 173 進行實站驗證。
 - 舊版「新增網站」使用 HTTP 的自訂網站會繼續使用 HTTP，只有舊版 SG 預設會遷移。
