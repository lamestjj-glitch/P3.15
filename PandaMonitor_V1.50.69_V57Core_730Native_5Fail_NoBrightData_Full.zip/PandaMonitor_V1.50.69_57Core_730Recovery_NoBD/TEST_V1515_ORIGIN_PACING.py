# -*- coding: utf-8 -*-
"""Offline FIFO origin pacing, adaptive 8s recheck and cancellation."""
import threading
import time
from api_recheck import RecheckSchedule
from hse28_origin_guard import OriginQueryGate

# A normal successful query resets the due date, eliminating extra JSON queries.
s = RecheckSchedule(True, now=100, deduplicate=True)
assert s.kind(True, 108) == 'extra'
s.completed('normal', 108)
assert s.kind(True, 115) == 'normal'
assert s.kind(True, 116) == 'extra'
assert s.wait(9, True, 115) == 9  # no extra wakeup / no duplicate
s.completed('extra', 116)
assert s.kind(True, 123) == 'normal'

# The two independent lanes share one FIFO queue; never overlap requests.
gate = OriginQueryGate(min_gap_seconds=.5)
starts=[]
exits=[]
def poll(lane):
    with gate.lease(lane) as allowed:
        assert allowed
        starts.append((lane, time.monotonic()))
        time.sleep(.04)
        exits.append((lane,time.monotonic()))
threads=[]
for lane in ('rent', 'buy', 'rent'):
    t=threading.Thread(target=poll, args=(lane,));threads.append(t);t.start()
    time.sleep(.02)
for t in threads:t.join(4)
assert all(not t.is_alive() for t in threads)
assert [x[0] for x in starts] == ['rent','buy','rent'], starts
assert all(starts[i+1][1]-starts[i][1] >= .49 for i in range(len(starts)-1)), starts
assert all(exits[i][1] <= starts[i+1][1] for i in range(len(exits)-1)), (exits,starts)
assert gate.stats()['rent'] == 2 and gate.stats()['buy'] == 1

# 429 prevents queued new requests, even while waiting for a turn.
limited = threading.Event()
gate = OriginQueryGate(min_gap_seconds=.5)
waiting = threading.Event()
out=[]

def in_flight():
    with gate.lease('rent') as admitted:
        assert admitted
        waiting.set()
        time.sleep(.3)

def on_hold():
    with gate.lease('buy', cancelled=limited.is_set) as admitted:
        out.append(admitted)

first=threading.Thread(target=in_flight); first.start();assert waiting.wait(2)
second=threading.Thread(target=on_hold);second.start()
time.sleep(.06); limited.set()
first.join(2);second.join(2)
assert out == [False], out
assert gate.stats()['buy'] == 0
print('PASS V1.50.15: shared FIFO no overlapping, min start gap, 429 waiter cancellation, 8s dedup')
