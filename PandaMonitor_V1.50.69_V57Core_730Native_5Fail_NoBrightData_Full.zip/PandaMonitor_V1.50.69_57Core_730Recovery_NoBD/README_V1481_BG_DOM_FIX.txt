PandaMonitor V1.48.1 | 28Hse API learning DOM-only background fix
=============================================================

修復：28Hse 租售啟動時出現「Cannot find exactly one search button」，
引致兩路 API-ONLY 暫停。

1. 只在新開的獨立隱藏 CDP Target 找主搜尋控制。
2. 先等待主搜尋按鈕可見與可識別，略過隱藏／停用按鈕。
3. 選擇唯一可靠的主搜尋控制後，使用 Runtime.evaluate + element.click()
   觸發一次網站原生搜尋，獲取真實 POST /property/dosearch form_data。
4. 不使用 Input.dispatchMouseEvent、Input.dispatchKeyEvent、PyAutoGUI、
   OS 滑鼠或鍵盤，不會調用 Page.bringToFront 或 window.focus。
5. 無法確認正確搜尋按鈕會顯示 no-visible-search-control 或
   ambiguous-visible-search-controls，不亂點、不猜條件、不抓代理。
6. 每次啟動僅做一次背景初始化搜尋。正常監控只使用 API JSON；
   每路最多一個在途請求、1 秒目標，遇到 Cloudflare／限流即暫停。
7. 保留 28 PhoneFirst、730 獨立程序、統一 UI、跨站去重、獨立 WA、
   Windows 置頂彈窗、位元瀏覽器環境 173。無需清空原設定和去重庫。

注意：雖然離線測試通過，尚未在用戶 Windows BitBrowser 173 實測。
如果網站本身要求真人的交互動作，會安全暫停；不會搶佔用戶輸入。

使用：停止舊版，解壓到新的資料夾，雙擊 START.bat。
查看日誌 [API-LEARN] → [API-VERIFY] → [API-LIST-OK]。
