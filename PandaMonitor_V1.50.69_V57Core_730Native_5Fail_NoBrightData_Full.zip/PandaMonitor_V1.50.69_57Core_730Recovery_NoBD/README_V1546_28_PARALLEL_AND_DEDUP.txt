PandaMonitor V1.50.46 — 28Hse 租售獨立單飛並行／API耗時診斷（無Signal）

1. 28Hse 租盤、售盤各維持最多一條列表 API 請求，可同時查詢；同一路第二條必須等待。
2. 28Hse 429 共用冷卻和 Retry-After，恢復期間仍採序列低頻試探；不無限制重試。
3. 既有 BitBrowser 分頁 Chromium fetch 使用同一瀏覽器連線池，維持原 Cookie / OwnerLock。
4. 每約15秒輸出 [28-API-TIMING]：HTTP 頭、資料讀取、JSON 解析、瀏覽器JS、CDP 返回、排隊，
   Browser ResourceTiming 若可用則包括 connection/server wait（若0可能表示連線重用或瀏覽器不提供指標）。
5. 28Hse Phone dedup：完整電話寫入 seen_phones.json，已處理帖按房源ID避免同次重複；
   House730 收到的號碼亦由母程序合併，使用同一電話鎖。
   只抓到 ID 而沒有電話不能標記為「電話已去重」；尾四位只用於複製，不用於去重。
6. House730 V1.50.45、WA、Win+L、多號碼、去重資料庫、Signal 移除狀態均不變。

離線驗證：python TEST_V1546_28_PARALLEL_DIAGNOSTIC.py
注意：租售並行可能增加 API 同時負載／網站429；實際速度需 Windows/BitBrowser 實測。
