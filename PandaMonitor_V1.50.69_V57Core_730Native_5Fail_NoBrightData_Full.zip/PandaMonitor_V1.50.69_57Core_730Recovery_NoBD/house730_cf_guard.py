# -*- coding: utf-8 -*-
"""House730 challenge-aware, non-bypassing pause and manual-recovery guard.

No automatic solving, clearance-cookie manipulation, fingerprint modification,
proxy rotation, challenge-page reload, or extra requests while verification is active.
Only passively inspect the already-open browser pages until the site recovers.
"""
from __future__ import annotations
import asyncio
import time
from urllib.parse import urlparse

CHALLENGE_TOKENS = (
    'just a moment', 'checking your browser', 'verify you are human',
    'verifying you are human', 'checking if the site connection is secure',
    'attention required', 'please wait while we verify',
    '請確認您是真人', '驗證你是真人', '正在確認您的瀏覽器', '正在檢查您的瀏覽器',
    '請稍候，我們正在驗證', '請驗證您是真人',
    '驗證您是人類', '驗證你是人類', '验证您是人类', '请验证您是人类',
)


async def is_challenge(page):
    """Only signs of an actual challenge, not a generic mention of Cloudflare."""
    try:
        if page.is_closed():
            return False
        url = str(page.url or '').lower()
        if '/cdn-cgi/challenge-platform/' in url or 'challenges.cloudflare.com' in url:
            return True
        title = (await page.title()).lower()
        if any(t in title for t in CHALLENGE_TOKENS):
            return True
        # Body text also catches transient challenge pages with a neutral title.
        text = (await page.locator('body').inner_text(timeout=1600))[:1700].lower()
        return any(t in text for t in CHALLENGE_TOKENS)
    except Exception:
        # A transient navigation exception is not proof of a challenge.
        return False


class ChallengeGuard:
    """One global pause shared by House730 rent, buy, and detail workers."""
    def __init__(self, states, send, log, stop, *, clock=time.monotonic,
                 initial_hold=120, stable_seconds=20, check_every=5):
        self.states, self.send, self.log, self.stop = states, send, log, stop
        self.clock = clock
        self.initial_hold = initial_hold
        self.stable_seconds = stable_seconds
        self.check_every = check_every
        self.pages = {}
        self.active = False
        self.slow_mode = False
        self.reason = ''
        self.incidents = 0
        self.last_incident = -1e9
        self.hold_until = 0.0
        self.healthy_since = None
        self._check_lock = asyncio.Lock()

    def register(self, deal, page):
        self.pages[deal] = page

    def notify(self, mode):
        for deal, state in self.states.items():
            state['mode'] = mode
            self.send('source', deal=deal, data=dict(state))

    def trip(self, deal, reason):
        """Pause *all* 730 traffic immediately, and lengthen holds on repeat."""
        now = self.clock()
        if self.active:
            return
        if now - self.last_incident > 3600:
            self.incidents = 0
        self.incidents += 1
        self.last_incident = now
        self.active = True
        self.slow_mode = True
        self.reason = str(reason)[:160]
        self.healthy_since = None
        hold = min(1800, self.initial_hold * (2 ** min(4, self.incidents-1)))
        self.hold_until = now + hold
        self.notify('cloudflare-wait')
        # Exactly one event per incident (rent and buy share this guard).
        # GUI presents a persistent Windows topmost prompt; no solving or
        # automatic challenge-page navigation is attempted.
        self.send('challenge', deal=deal, reason=self.reason,
                  incident=self.incidents, hold_seconds=int(hold))
        self.log(f'730 {deal}盤進入保護暫停：{self.reason}；租售及詳情停止請求。'
                 f'在 BitBrowser 手動確認網站；最少冷卻 {int(hold)} 秒，不會自動刷新驗證頁')

    async def _healthy_pages(self, valid_list):
        """Observe DOM of existing tabs without making HTTP requests or navigating."""
        present = 0
        for deal, page in list(self.pages.items()):
            if page is None or page.is_closed():
                # A monitor tab may have been manually re-opened during CF
                # cooldown. Rebind to that existing tab, never create one.
                finder = getattr(self, 'existing_page_finder', None)
                page = finder(deal) if callable(finder) else None
                if page is None:
                    return False
                self.pages[deal] = page
            present += 1
            if await is_challenge(page):
                return False
            parsed = urlparse(str(page.url or ''))
            target = 'rent' if deal == '租' else 'buy'
            if parsed.hostname not in ('house730.com','www.house730.com') or parsed.path.rstrip('/') != f'/{target}/s1u14':
                return False
            if not await valid_list(page, deal):
                return False
        return present > 0

    async def _observe(self, valid_list):
        async with self._check_lock:
            if not self.active:
                return
            healthy = await self._healthy_pages(valid_list)
            if not healthy:
                self.healthy_since = None
                return
            now = self.clock()
            if self.healthy_since is None:
                self.healthy_since = now
            if now < self.hold_until or now - self.healthy_since < self.stable_seconds:
                return
            self.active = False
            self.healthy_since = None
            self.notify('cf-safe-html')
            self.send('challenge_cleared')
            self.log('730 驗證頁已離開，租售列表連續有效且冷卻完成；以保護低頻模式恢復監控（不會回到每秒查詢）')

    async def wait(self, valid_list):
        while self.active and not self.stop.is_set():
            await self._observe(valid_list)
            if self.active:
                await asyncio.sleep(self.check_every)
        return not self.stop.is_set()

    def effective_interval(self, requested, protected_min=60):
        """Protection mode is intentionally conservative even after clearance."""
        return max(float(requested), float(protected_min)) if self.slow_mode else float(requested)
