PandaMonitor V1.50.38a — Windows Python / Tcl-Tk startup repair

Problem in provided log:
  ERROR: No usable Python >=3.12 with tkinter found.

What's changed (launcher only):
  * Expanded detection: py -3.13/-3.12/-3.14/-3.15, regular PATH,
    standard Python install directories, PEP 514 Windows registry,
    optional PANDA_PYTHON override and project/active virtualenv.
  * Each Python probe is recorded as TRY/FOUND/SKIP, including its
    error, Python version and Tcl/Tk probe result.
  * DIAG_PYTHON.bat runs the same detection independently and writes
    python_diag.log without launching monitoring.
  * INSTALL_PYTHON_313.bat is an OPTIONAL interactive winget install;
    it doesn't remove Python 3.15 or change monitoring settings.

Run:
  1. Extract the whole ZIP (not just START.bat).
  2. Double click START.bat.
  3. If it still fails, run DIAG_PYTHON.bat and send python_diag.log.
  4. If there is truly no Python 3.12+ with working tkinter, run
     INSTALL_PYTHON_313.bat or install official 64-bit Python 3.13
     with Tcl/Tk and IDLE, then START.bat.

Logs in:
  %LOCALAPPDATA%\PandaMonitor_28Hse_House730\logs\

No monitoring engine, API timing, browser, Signal/WA or dedup code changed.
This package was checked offline. Windows-specific behavior requires
verification on the actual PC.
