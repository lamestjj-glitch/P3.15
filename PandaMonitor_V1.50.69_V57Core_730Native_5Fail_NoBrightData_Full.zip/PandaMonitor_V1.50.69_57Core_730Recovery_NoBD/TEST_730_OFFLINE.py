import tempfile
from pathlib import Path
import sqlite3
from unittest.mock import patch

from house730_engine import Store, listing_key,phone_key,valid_phone,read_config, DEFAULTS
from house730_light_api import parse_listing_urls, PollError


def run():
    assert listing_key('https://www.house730.com/rent-property-9288477/a/') == ('租','9288477')
    assert listing_key('https://www.house730.com/rent-property-9288477/改名/') == ('租','9288477')
    assert listing_key('https://www.house730.com/buy-property-9288477/a/', '租') is None
    assert listing_key('https://example.com/rent-property-9288477/') is None
    assert phone_key('+852 6123 4567') == '61234567'
    assert not valid_phone('31234567') and not valid_phone('21234567')
    assert valid_phone('61234567')
    payload='{"result":[{"url":"https://www.house730.com/rent-property-1111111/測試/"},{"url":"https://www.house730.com/rent-property-1111111/改名/"},{"url":"https://www.house730.com/rent-property-2222222/新盤/"}]}'
    assert len(parse_listing_urls(payload,'租'))==3  # backend performs canonical ID de-duplication
    assert parse_listing_urls(payload,'售') == []
    with tempfile.TemporaryDirectory() as p:
        s=Store(Path(p)/'new.db')
        url1='https://www.house730.com/rent-property-1111111/測試/'
        url1_renamed='https://www.house730.com/rent-property-1111111/改名/'
        url2='https://www.house730.com/buy-property-2222222/另一帖/'
        url3='https://www.house730.com/buy-property-3333333/另一帖/'
        assert s.mark_many('租',[url1]) == 1
        assert not s.claim('租',url1_renamed)
        assert s.claim('售',url2)
        assert not s.claim('售',url2)
        assert s.save_phone('售',url2,'+852 6123 4567')
        assert not s.save_phone('售',url2,'61234567')
        assert s.claim('售',url3)
        assert not s.save_phone('售',url3,'61234567')
        assert not s.save_phone('售',url3,'31234567')
        assert s.stats()['listings']==1
        assert s.set_wa('售','2222222','已聯絡')
        assert s.rows()[0]['wa_status']=='已聯絡'
        s2=Store(Path(p)/'new.db')
        assert s2.seen('租','1111111') and s2.seen('售','2222222')
        assert s2.rows()[0]['phone']=='61234567'
        legacy=Path(p)/'old.db'
        with sqlite3.connect(legacy) as con:
            con.execute('CREATE TABLE listings(deal TEXT, url TEXT, phone TEXT, site TEXT)')
            con.execute('CREATE TABLE seen_urls(deal TEXT, url TEXT, site TEXT)')
            con.execute('CREATE TABLE house730_seen_ids(deal TEXT, property_id TEXT, first_url TEXT)')
            con.execute('INSERT INTO listings VALUES (?,?,?,?)',('租','https://www.house730.com/rent-property-4444444/a/','6999 1234','House730'))
            con.execute('INSERT INTO seen_urls VALUES (?,?,?)',('售','https://www.house730.com/buy-property-5555555/b/','House730'))
            con.execute('INSERT INTO house730_seen_ids VALUES (?,?,?)',('租','6666666','https://www.house730.com/rent-property-6666666/c/'))
        st=s.import_legacy(legacy)
        assert s.seen('租','4444444') and s.seen('售','5555555') and s.seen('租','6666666')
        assert st['phones']==2
        assert not s.save_phone('售',url3,'6999 1234')
    print('PASS: URL-ID/canonical, JSON parse, prefix, baseline, atomic phone dedupe, WA state, restart, legacy migration')


if __name__=='__main__':run()
