# -*- coding: utf-8 -*-
"""House730 in a separate Windows process, single UI and single phone ledger.

Uses multiprocessing.spawn and a bidirectional Pipe. House730 never touches Tk
or the 28Hse CDP connection. Phone commits are performed by the parent under
the 28Hse phone lock, so duplicate exclusion remains atomic across sites.
"""
from __future__ import annotations

import itertools
import multiprocessing as mp
import queue
import threading
import time


def _child_main(conn, cfg):
    # Offline-only IPC smoke test: exercises the exact OS-process/pipe handoff
    # without opening BitBrowser or sending any network requests.
    if cfg.pop('__perf_smoke_test', False):
        import os
        for n in range(2):
            conn.send({'kind': 'claim', 'id': n + 1, 'deal': '租',
                       'url': 'https://www.house730.com/rent-property-9224794/',
                       'phone': '93083792', 'contact': '測試'})
            if not conn.poll(4.0):
                break
            ans = conn.recv()
            conn.send({'kind': 'event', 'payload': {
                'event': 'ipc_smoke', 'accepted': bool(ans.get('ok')),
                'child_pid': os.getpid()}})
        conn.close()
        return
    from house730_engine import Engine, Store

    send_lock = threading.Lock()
    pending_lock = threading.Lock()
    pending = {}
    counter = itertools.count(1)
    stopped = threading.Event()

    def send(data):
        with send_lock:
            conn.send(data)

    class ParentCommittedStore(Store):
        def save_phone(self, deal, url, raw_phone, contact='未提供'):
            request_id = next(counter)
            event = threading.Event()
            box = {'result': False}
            with pending_lock:
                pending[request_id] = (event, box)
            try:
                send({'kind': 'claim', 'id': request_id, 'deal': deal,
                      'url': url, 'phone': raw_phone, 'contact': contact})
                # Parent performs the SQLite commit before acknowledging.  Never
                # announce a phone before permanent cross-site dedup completes.
                if not event.wait(8.0):
                    raise TimeoutError('House730 phone claim acknowledgement timeout')
                return bool(box['result'])
            finally:
                with pending_lock:
                    pending.pop(request_id, None)

    engine = Engine(cfg=cfg, store=ParentCommittedStore())
    try:
        engine.start()
        while not stopped.is_set():
            try:
                if conn.poll(0.025):
                    msg = conn.recv()
                    kind = msg.get('kind')
                    if kind == 'command':
                        op = msg.get('op')
                        if op == 'halt':
                            engine.halt()
                            stopped.set()
                        elif op == 'test_first':
                            engine.test_first(msg.get('deal'), bool(msg.get('greeting')), msg.get('listing_url') or '')
                        elif op == 'open_original':
                            engine.open_original(msg.get('url', ''))
                        elif op == 'show_verification':
                            engine.show_verification(msg.get('deal'))
                        elif op == 'set_poll_seconds':
                            from house730_cadence import parse_house730_cadence
                            try:
                                value = parse_house730_cadence(msg.get('seconds'))
                                engine.cfg['poll_seconds'] = value
                                engine.log(f'730 JSON 自訂間隔已更新為 {value:g} 秒＋每輪隨機100–300ms（租售獨立；429僅本路短等3秒，Cloudflare驗證仍受保護）')
                            except ValueError as exc:
                                engine.log('730 JSON 間隔更新被拒絕：' + str(exc))
                    elif kind == 'claim_result':
                        with pending_lock:
                            pair = pending.get(msg.get('id'))
                        if pair:
                            ev, box = pair
                            box['result'] = bool(msg.get('ok'))
                            ev.set()
            except (EOFError, BrokenPipeError, OSError):
                engine.halt()
                stopped.set()
                break
            for _ in range(100):
                try:
                    x = engine.out.get_nowait()
                except queue.Empty:
                    break
                try:
                    send({'kind': 'event', 'payload': x})
                except (EOFError, BrokenPipeError, OSError):
                    engine.halt()
                    stopped.set()
                    break
            if engine.thread and not engine.thread.is_alive():
                break
    except BaseException as exc:
        try:
            send({'kind': 'event', 'payload': {'event': 'fatal', 'text': str(exc)}})
        except (OSError, EOFError, BrokenPipeError):
            pass
    finally:
        engine.halt()
        # Give browser/context normal cleanup time; parent doesn't block UI.
        if engine.thread:
            engine.thread.join(timeout=2.0)
        try:
            conn.close()
        except OSError:
            pass


class House730Process:
    """Drop-in public Engine interface; own full Python interpreter/GIL."""

    def __init__(self, cfg, store):
        self.cfg = dict(cfg)
        self.store = store
        self.out = queue.Queue()
        self.stop = threading.Event()
        self.thread = None
        self.process = None
        self.conn = None
        self._write_lock = threading.Lock()

    def start(self):
        if self.process and self.process.is_alive():
            return
        self.stop.clear()
        ctx = mp.get_context('spawn')
        parent, child = ctx.Pipe(duplex=True)
        self.conn = parent
        self.process = ctx.Process(target=_child_main, args=(child, self.cfg),
                                   daemon=True, name='PandaMonitor-House730')
        try:
            self.process.start()
        except Exception:
            parent.close()
            child.close()
            raise
        child.close()
        self.thread = threading.Thread(target=self._reader, name='House730-IPC', daemon=True)
        self.thread.start()

    def is_alive(self):
        return bool(self.process and self.process.is_alive() and not self.stop.is_set())

    def _send(self, data):
        if not self.conn or not self.process or not self.process.is_alive():
            return False
        try:
            with self._write_lock:
                self.conn.send(data)
            return True
        except (EOFError, OSError, BrokenPipeError):
            return False

    def _reader(self):
        try:
            while not self.stop.is_set() and self.process and self.process.is_alive():
                try:
                    if not self.conn.poll(0.10):
                        continue
                    msg = self.conn.recv()
                except (EOFError, BrokenPipeError, OSError):
                    break
                if msg.get('kind') == 'event':
                    self.out.put(msg.get('payload', {}))
                elif msg.get('kind') == 'claim':
                    try:
                        ok = self.store.save_phone(msg['deal'], msg['url'],
                                                   msg['phone'], msg.get('contact','未提供'))
                    except Exception as exc:
                        ok = False
                        self.out.put({'event': 'log', 'text': '電話去重資料庫寫入失敗: ' + str(exc)[:160]})
                    self._send({'kind': 'claim_result', 'id': msg.get('id'), 'ok': bool(ok)})
        finally:
            # Unexpected subprocess exit should be diagnosed, not mistaken for
            # a normal user-requested Stop (which keeps the 28Hse UI running).
            if not self.stop.is_set() and self.process:
                self.process.join(timeout=0.15)
                code = self.process.exitcode
                if code not in (None, 0):
                    self.out.put({'event': 'fatal', 'text':
                                  f'House730 subprocess exited unexpectedly (code={code})'})
            self.out.put({'event': 'running', 'active': False})
            try:
                self.conn.close()
            except OSError:
                pass

    def test_first(self, deal, greeting=False, listing_url=''):
        self._send({'kind': 'command', 'op': 'test_first', 'deal': deal, 'greeting': greeting, 'listing_url': listing_url or ''})

    def open_original(self, url):
        self._send({'kind': 'command', 'op': 'open_original', 'url': url})

    def show_verification(self, deal):
        self._send({'kind': 'command', 'op': 'show_verification', 'deal': deal})

    def update_poll_seconds(self, seconds):
        from house730_cadence import parse_house730_cadence
        value = parse_house730_cadence(seconds)
        if self._send({'kind': 'command', 'op': 'set_poll_seconds', 'seconds': value}):
            self.cfg['poll_seconds'] = value
            return True
        return False

    def halt(self):
        if self.stop.is_set():
            return
        # Send before setting the flag so the child's browser can close cleanly.
        self._send({'kind': 'command', 'op': 'halt'})
        self.stop.set()

    def alive_process_even_if_stopping(self):
        return bool(self.process and self.process.is_alive())
