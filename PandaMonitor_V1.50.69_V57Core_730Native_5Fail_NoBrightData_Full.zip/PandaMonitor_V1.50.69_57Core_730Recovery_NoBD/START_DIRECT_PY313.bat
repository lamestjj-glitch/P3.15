﻿@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
set "PY=%LOCALAPPDATA%\Programs\Python\Python313\python.exe"
if exist "%PY%" goto found
where py >nul 2>nul
if errorlevel 1 goto missing
set "PY=py"
set "PY_ARGS=-3.13"
:found
echo [DIRECT-START] Prefer Python 3.13 without Windows PowerShell argument probing.
if defined PY_ARGS (
  "%PY%" %PY_ARGS% -u "%~dp0bootstrap.py"
) else (
  "%PY%" -u "%~dp0bootstrap.py"
)
set "RC=%ERRORLEVEL%"
if "%RC%"=="0" exit /b 0
echo [ERROR] Direct Python 3.13 bootstrap exited with code %RC%.
echo Logs: %LOCALAPPDATA%\PandaMonitor_28Hse_House730\logs
pause
exit /b %RC%
:missing
echo [ERROR] Python 3.13 not found at usual location, and py launcher missing.
echo Run START.bat or DIAG_PYTHON.bat to locate it.
pause
exit /b 1
