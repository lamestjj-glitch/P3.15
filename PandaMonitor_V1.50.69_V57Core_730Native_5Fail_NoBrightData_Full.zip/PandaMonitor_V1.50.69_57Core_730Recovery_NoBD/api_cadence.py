# -*- coding: utf-8 -*-
"""28Hse user-entered API polling interval, independent from Tk/CDP."""
from decimal import Decimal, InvalidOperation

# No product-imposed minimum/maximum cadence in seconds.
# 1ms resolution is kept because inputs are stored with millisecond precision.
RESOLUTION = Decimal('0.001')


def parse_api_cadence(value):
    """Validate arbitrary numeric seconds; store at millisecond precision."""
    if isinstance(value, bool):
        raise ValueError('請輸入秒數，例如 2.5、7.25 或 10')
    try:
        number = Decimal(str(value).strip())
    except (ValueError, InvalidOperation, TypeError):
        raise ValueError('請輸入秒數，例如 2.5、7.25 或 10') from None
    if not number.is_finite() or number <= 0:
        raise ValueError('28Hse 間隔必須是大於 0 的有限秒數')
    try:
        millisecond_value = number.quantize(RESOLUTION)
    except InvalidOperation:
        raise ValueError('最多支援三位小數（毫秒精度）') from None
    if number != millisecond_value:
        raise ValueError('最多支援三位小數（毫秒精度）')
    try:
        result = float(number)
    except (OverflowError, ValueError):
        raise ValueError('輸入秒數超出 Python 可以表示的範圍') from None
    if not (0 < result < float('inf')):
        raise ValueError('輸入秒數超出 Python 可以表示的範圍')
    return result


def display_api_cadence(value):
    """Keep decimal settings human-readable and stable across saves."""
    return format(Decimal(str(parse_api_cadence(value))).normalize(), 'f')
