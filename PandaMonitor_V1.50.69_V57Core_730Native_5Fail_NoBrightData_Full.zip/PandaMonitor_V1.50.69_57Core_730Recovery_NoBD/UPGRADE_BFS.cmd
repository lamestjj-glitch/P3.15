@echo off
setlocal EnableExtensions DisableDelayedExpansion
chcp 65001 >nul
set "SOURCE=%~dp0site_plugins\businessforsale_sg.py"
set "CONFIG=%USERPROFILE%\PandaMonitor_28Hse\site_plugins"
if /I not "%HOMEDRIVE%"=="C:" set "CONFIG=C:\Users\%USERNAME%\PandaMonitor_28Hse\site_plugins"
if not exist "%SOURCE%" (
  echo [ERROR] Missing source plugin: %SOURCE%
  pause
  exit /b 1
)
if not exist "%CONFIG%" mkdir "%CONFIG%"
if errorlevel 1 (
  echo [ERROR] Cannot create %CONFIG%
  pause
  exit /b 1
)
if exist "%CONFIG%\businessforsale_sg.py" if not exist "%CONFIG%\businessforsale_sg.py.backup_before_1507" (
  copy /Y "%CONFIG%\businessforsale_sg.py" "%CONFIG%\businessforsale_sg.py.backup_before_1507" >nul
)
copy /Y "%SOURCE%" "%CONFIG%\businessforsale_sg.py" >nul
if errorlevel 1 (
  echo [ERROR] Could not replace external BusinessForSale plugin.
  pause
  exit /b 1
)
echo.
echo [OK] BusinessForSale.sg V1.50.7 plugin installed.
echo [OK] Your other site plugins, settings, and phone history are unchanged.
echo Restart PandaMonitor for changes to take effect.
pause
