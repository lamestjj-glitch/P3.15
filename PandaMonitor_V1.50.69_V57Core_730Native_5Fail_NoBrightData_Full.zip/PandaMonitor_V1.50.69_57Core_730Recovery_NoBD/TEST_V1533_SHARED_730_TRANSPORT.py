# -*- coding: utf-8 -*-
"""Offline tests: 730 list CDP isolation while 28Hse is also active.

No network request, no cookies/tokens saved, no Signal send.
"""
import asyncio
from house730_light_api import House730LightAPI, PollError

class Resp:
    def __init__(self, status=200, body='{"Data":[{"url":"https://www.house730.com/rent-property-9292554/"}]}'):
        self.status=status
        self.url='https://api.house730.com/Property/QueryProperty'
        self.headers={'content-type':'application/json'}
        self.b=body.encode()
    async def body(self): return self.b

class API:
    def __init__(self):
        self.requests=[]
        self.response=Resp()
        self.fail=False
    async def fetch(self, url, **kwargs):
        self.requests.append((url,kwargs))
        if self.fail: raise ConnectionError('local fake transport refused')
        return self.response

class Ctx:
    def __init__(self): self.request=API()

class Page:
    def __init__(self):
        self.context=Ctx()
        self.eval_count=0
        self.eval_fail=False
        self.handlers={}
        self.url='https://www.house730.com/rent/s1u14/'
    def on(self, event, fn): self.handlers[event]=fn
    def remove_listener(self, event, fn): self.handlers.pop(event,None)
    def is_closed(self): return False
    async def evaluate(self, js, params):
        self.eval_count += 1
        if self.eval_fail: raise RuntimeError('CDP busy')
        return {'status':200, 'host':'api.house730.com', 'content_type':'application/json',
                'truncated':False,
                'body':'{"Data":[{"url":"https://www.house730.com/rent-property-9292554/"}]}' }

async def main():
    page=Page()
    api=House730LightAPI(page,'租', prefer_native=True)
    api.template={'url':'https://api.house730.com/Property/QueryProperty','method':'POST',
                  'headers':{'AppKey':'test','AppSignature':'testsig'},'body':'{"sort":"newest"}'}
    links=await api.query(timeout_ms=2500)
    assert len(links)==1 and page.eval_count==0
    req=page.context.request.requests[0]
    assert req[1]['headers']['AppKey']=='test'
    assert req[1]['data']==api.template['body']
    assert req[1]['max_redirects']==0
    page.context.request.response=Resp(status=429)
    try:await api.query()
    except PollError as e: assert e.status==429 and e.cooldown>=180
    else:raise AssertionError('HTTP429 must pause')
    assert api.transport=='native'
    page.context.request.fail=True
    before=len(page.context.request.requests)
    try: await api.query()
    except PollError as e: assert e.kind=='native-transport' and e.cooldown>0
    else:raise AssertionError('Native failure must switch transport')
    assert api.transport=='browser' and len(page.context.request.requests)==before+1
    assert page.eval_count==0  # never reissue a failed native poll immediately
    links=await api.query()
    assert links and page.eval_count==1 and len(page.context.request.requests)==before+1
    api.detach()

    # A generic JS/CDP exception is not a website response or invalid JSON.
    page=Page();page.eval_fail=True
    api=House730LightAPI(page,'租')
    api.template={'url':'https://api.house730.com/Property/QueryProperty','method':'POST',
                  'headers':{},'body':'x'}
    try:await api.query()
    except PollError as e: assert e.kind=='browser-execution' and e.status==0
    else:raise AssertionError('Runtime error must be classified as browser-execution')
    api.detach()
    print('PASS V1.50.33: native path bypasses Runtime, one request/round, 429 honors hold, next-cycle fallback, CDP exceptions classified')

asyncio.run(main())
