PandaMonitor V1.50.11 — PhoneFirst 性能優化 (基於 V1.50.10)

主要改動:
1. 28Hse 偵測 NEW 後，先入揭號隊列，再排 GUI 插入與日誌；降低 GUI 繁忙時延遲。
2. House730 每個獨立抓號 worker 最多重用 1 個自建背景詳情頁；處理下一帖前先重設 about:blank，避免混淆上一帖聯絡 API；任何失敗或驗證即廢棄該分頁。
3. House730 API PhoneFirst：若詳情在 2 秒內完全沒有發出聯絡 API，立即回退原本的頁面揭號；若 API 已發出，維持原 3.5 秒總等待。
4. House730 清理聯絡 API 監聽器時取消固定 120ms 睡眠；保留事件任務安全取消。
5. 新增 730 取號耗時 [730-PERF] 記錄，用於前後對比。

完全保留：
- 28Hse API 業主盤+最新 OwnerLock、8 秒補查、租售獨立 single-flight、429/驗證停機。
- House730 租/售 JSON、API PhoneFirst 先行、DOM 揭號備援、Cloudflare 防護。
- 852.house、BusinessForSale.sg 專用插件、各站刷新、跨站去重、女性 WA。
- 自動入剪貼板：只複製尾四位；手動按複製/雙擊：完整電話。

注意：
- 此版修改的是本地佇列/導航/等待成本，不會改變網站本身的回應速度。
- 部分只靠慢速 JS 才會發出聯絡 API 的 730 網頁，可能更早啟動舊揭號備援；未公開電話、驗證、429 仍不會強制取號。
- 未連接用戶 BitBrowser 173 實測；請觀察 [RACE] NEW→CLIPBOARD 和 [730-PERF]。

安裝：
關閉舊版，解壓完整版至獨立資料夾，執行 START.bat；原有 C 盤設定、插件和電話去重庫不會清空。
