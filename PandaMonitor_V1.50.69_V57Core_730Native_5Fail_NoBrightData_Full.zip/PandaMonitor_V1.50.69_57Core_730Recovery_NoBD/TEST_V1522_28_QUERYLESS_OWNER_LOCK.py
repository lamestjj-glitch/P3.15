"""V1.50.22 regression: attach to queryless user-opened lists without guessing filters."""
from types import SimpleNamespace
from panda28_core import App
from panda28_api import existing_list_url_kind, capture_template, ApiError

class OpenTabs:
    target=App.target
    def __init__(self,items):self.items=items
    def targets(self):return self.items

assert existing_list_url_kind('https://www.28hse.com/rent', 'rent')=='bare'
assert existing_list_url_kind('https://www.28hse.com/buy','buy')=='bare'
assert existing_list_url_kind('https://www.28hse.com/rent?landlordAgency=LANDLORD&sortBy=latest','rent')=='explicit'
assert existing_list_url_kind('https://www.28hse.com/rent?landlordAgency=AGENT&sortBy=latest','rent') is None
assert existing_list_url_kind('https://www.28hse.com/rent?sortBy=latest','rent') is None
assert existing_list_url_kind('https://www.28hse.com/rent/apartment/property-3414271','rent') is None
assert existing_list_url_kind('https://www.28hse.com/rent','buy') is None
assert existing_list_url_kind('https://evil.example/rent','rent') is None

p=OpenTabs([{'id':'bare','url':'https://www.28hse.com/rent'}])
assert p.target('rent')['id']=='bare'
p.items.append({'id':'verified','url':'https://www.28hse.com/rent?landlordAgency=LANDLORD&sortBy=latest'})
assert p.target('rent')['id']=='verified', 'Explicit source must be preferred'

import panda28_api
class FakeCDP:
    def __init__(self,href,trigger_post=True):
        self.href=href
        self.trigger_post=trigger_post
        self.events=[];self.methods=[];self.event_handler=None
    def call(self,method,p=None,timeout=None):
        self.methods.append(method)
        if method=='Runtime.evaluate':
            expr=(p or {}).get('expression','')
            if expr=='location.href': v=self.href
            elif 'document.readyState' in expr: v={'href':self.href,'ready':'complete'}
            else:v=False
            return {'result':{'value':v}}
        return {}
    def pump_event(self,timeout=0.3):return False
    def close(self):pass
    def ev(self,*a,**kw):return False
class FakeApp(OpenTabs):
    def __init__(self,href):
        super().__init__([{'id':'bare','url':href}]);self.c=FakeCDP(href)
    def cdp(self,t):return self.c
app=FakeApp('https://www.28hse.com/rent')
original_search=panda28_api._search_control
original_sleep=panda28_api.time.sleep
original_monotonic=panda28_api.time.monotonic
import time
# Actual click event (no raw tokens in report) is captured and owner-locked.
def fake_search(c,execute=False,timeout=2.0):
    if execute:
        c.event_handler({'method':'Network.requestWillBeSent','params':{'request':{
            'url':'https://www.28hse.com/property/dosearch','method':'POST',
            'postData':'landlordAgency=LANDLORD&sortBy=latest'}}})
    return {'ok':True}
try:
    panda28_api._search_control=fake_search
    # Trigger DOM stable timer using actual sleep(0.7) once, max 1s.
    t,c,template=capture_template(app,'rent',lambda:True,cached=None)
    assert template['bare_url_candidate'] is True
    assert not template['reused']
    assert 'Page.reload' not in c.methods, 'Bare URL must keep selected DOM form'
    assert 'Target.createTarget' not in c.methods
    assert panda28_api.owner_lock(template['body'])
    # On bare URL, stale cached templates cannot replace a live verified POST.
    app2=FakeApp('https://www.28hse.com/rent')
    t,c,tpl=capture_template(app2,'rent',lambda:True,cached={
        'url':'https://www.28hse.com/property/dosearch',
        'body':'landlordAgency=LANDLORD&sortBy=latest'})
    assert not tpl['reused'] and tpl['bare_url_candidate']
finally:
    panda28_api._search_control=original_search

print('PASS V1.50.22: queryless rent/buy attach candidates, ownerLock POST mandatory, no reload/tab creation, API test waits for baseline')
