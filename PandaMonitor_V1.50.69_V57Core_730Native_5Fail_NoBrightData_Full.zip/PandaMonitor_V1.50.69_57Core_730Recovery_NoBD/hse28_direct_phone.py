# -*- coding: utf-8 -*-
"""28Hse public listing ID -> documented in-browser phone-action API.

Probe evidence: with only ad_id and static action fields, the endpoint returned
B's owner contact matching B's baseline in one authenticated BitBrowser session.
Do not log payloads, response HTML, contact names or session values.
"""
import json
import re

PHONE_ENDPOINT = 'https://www.28hse.com/property/detail/doaction'


def valid_listing_id(pid):
    return bool(re.fullmatch(r'\d{6,10}', str(pid or '')))


def make_direct_expression(pid, url, timeout_ms=1900):
    """Create a single same-origin fetch; never GET property HTML or open a tab."""
    if not valid_listing_id(pid):
        raise ValueError('Invalid 28Hse listing ID')
    if not re.fullmatch(r'https://www\.28hse\.com/(rent|buy)/[a-z0-9_-]+/property-\d{6,10}', str(url), re.I):
        raise ValueError('Invalid 28Hse owner listing URL')
    if str(url).rsplit('/property-', 1)[-1] != str(pid):
        raise ValueError('28Hse listing ID and URL mismatch')
    budget = max(650, min(3500, int(timeout_ms)))
    return DIRECT_JS.replace('__PID__', json.dumps(str(pid))).replace('__URL__', json.dumps(str(url))).replace('__TIMEOUT__', str(budget))


# Values are parsed inside the already authenticated 28Hse origin. Only the
# extracted names + phone numbers cross the CDP boundary. No raw response body.
DIRECT_JS = r'''(async()=>{
  const t0=performance.now(), pid=__PID__, referrer=__URL__;
  const ctl=new AbortController(), timer=setTimeout(()=>ctl.abort(),__TIMEOUT__);
  const fail=(reason,blocked=false,status=0)=>({ok:false,reason,blocked,status,elapsedMs:Math.round(performance.now()-t0),rows:[]});
  const normalize=v=>{
    let s=String(v||'').replace(/\D/g,'');
    if(s.startsWith('00852')&&s.length===13)s=s.slice(5);
    else if(s.startsWith('852')&&s.length===11)s=s.slice(3);
    return /^[2-9]\d{7}$/.test(s)?s:'';
  };
  try{
    const body=new URLSearchParams({action:'statistic_inc',user_action:'phone',ad_id:pid,event_name:'property_contact_phone'});
    const res=await fetch('https://www.28hse.com/property/detail/doaction',{
      method:'POST',credentials:'include',cache:'no-store',redirect:'follow',
      referrer,referrerPolicy:'strict-origin-when-cross-origin',signal:ctl.signal,
      headers:{'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8',
               'X-Requested-With':'XMLHttpRequest','Cache-Control':'no-cache, no-store, max-age=0'},
      body:body.toString()});
    const final=new URL(res.url);
    if(!/^(www\.)?28hse\.com$/i.test(final.hostname)||final.pathname!=='/property/detail/doaction')
       return fail('電話 API 重定向至非預期端點',true,res.status);
    if([401,403,429,503].includes(res.status)){const bad=fail('電話 API 限流或驗證 HTTP '+res.status,true,res.status);bad.retryAfter=res.headers.get('Retry-After')||'';return bad;}
    if(!res.ok)return fail('電話 API HTTP '+res.status,false,res.status);
    const type=(res.headers.get('content-type')||'').toLowerCase();
    if(!/json/.test(type))return fail('電話 API 非 JSON 回應',true,res.status);
    let data;
    try{data=await res.json()}catch(e){return fail('電話 API JSON 解析失敗',false,res.status)}
    const obj=data&&data.data&&data.data.results;
    if(!obj||typeof obj!=='object')return fail('電話 API 沒有 results',false,res.status);
    if(obj.need_verify)return fail('電話 API 需要人工驗證',true,res.status);
    const parts=Array.isArray(obj.contacts)?obj.contacts:[];
    const rows=[],seen=new Set();
    const add=(name,value)=>{
      const number=normalize(value);
      if(number&&!seen.has(number)){seen.add(number);rows.push({name:String(name||'未知').slice(0,75),phone:number})}
    };
    for(const part of parts.slice(0,24)){
      if(typeof part!=='string')continue;
      const doc=new DOMParser().parseFromString(part,'text/html');
      const blocks=[...doc.querySelectorAll('.content_phone_information')];
      if(!blocks.length)blocks.push(doc.body);
      for(const block of blocks){
        if(!block)continue;
        const named=block.querySelector('[class*="contact-name"],[class*="contact_name"],[class*="contactName"],[class*="person-name"]');
        const defaultName=(named&&(named.textContent||'').trim().slice(0,75))||'未知';
        const txt=block.textContent||'';
        // Multiple owners/numbers: preserve separate contacts when possible.
        const rx=/(?:Tel\.?|電話|电话)\s*[:：]\s*(?:\+?852[\s-]*)?([2-9]\d{3}[\s-]?\d{4})(?!\d)/gi;
        let lastEnd=0, matched=0;
        for(const hit of txt.matchAll(rx)){
          const before=txt.slice(lastEnd,hit.index).trim();
          const title=[...before.matchAll(/([\u3400-\u9fff]{1,5}(?:小姐|女士|太太|先生|姐|生)|\b(?:Ms|Mrs|Miss|Mr)\.?\s+[A-Za-z][A-Za-z .]{0,35})/gi)];
          add(title.length?title[title.length-1][1]:matched?'未知':defaultName,hit[1]);
          matched++;lastEnd=hit.index+hit[0].length;
        }
        for(const a of block.querySelectorAll('a[href^="tel:"]'))add(defaultName,(a.getAttribute('href')||'').replace(/^tel:/i,'').split('?')[0]);
        for(const node of block.querySelectorAll('.fullPhone'))add(defaultName,node.textContent);
      }
    }
    return {ok:rows.length>0,rows,reason:rows.length?'':'電話 API 無公開電話',
            blocked:false,status:res.status,elapsedMs:Math.round(performance.now()-t0)};
  }catch(e){
    return fail((e&&e.name==='AbortError')?'電話 API 逾時':('電話 API 請求錯誤 '+(e&&e.name||'Error')));
  }finally{clearTimeout(timer)}
})()'''
