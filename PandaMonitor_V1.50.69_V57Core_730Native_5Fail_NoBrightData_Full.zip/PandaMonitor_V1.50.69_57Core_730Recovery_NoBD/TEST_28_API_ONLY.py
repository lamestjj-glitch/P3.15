# -*- coding: utf-8 -*-
"""Offline API-only regression tests. No live requests, BitBrowser or tokens."""
import json
import threading
from urllib.parse import urlencode
from panda28_api import owner_lock, extract_property_urls, parse_api_reply, capture_template, api_snapshot, ApiError

FORM = urlencode({'form_data':json.dumps({'landlordAgency':'LANDLORD','sortBy':'latest','buyRent':'rent','page':1})})
HTML = '<a href="/rent/apartment/property-4051679">A</a><a href="https://www.28hse.com/rent/office/property-4051471">B</a>'

def reply(content=HTML):return {'status':1,'data':{'results':{'resultContentHtml':content,'resultData':{'buyRent':'rent'}}}}

class DummyCDP:
    def __init__(self, emit=True):
        self.event_handler=None;self.calls=[];self.emit=emit;self.closed=False
    def call(self,name,params=None,timeout=None):
        self.calls.append((name,params))
        if name=='Page.reload' and self.event_handler and self.emit:
            self.event_handler({'method':'Network.requestWillBeSent','params':{'request':{'method':'POST','url':'https://www.28hse.com/property/dosearch','postData':FORM}}})
        if name=='Runtime.evaluate':
            expr=params['expression']
            if 'const accepted=' in expr:
                if expr.endswith('(true)') and self.event_handler and self.emit:
                    self.event_handler({'method':'Network.requestWillBeSent','params':{'request':{'method':'POST','url':'https://www.28hse.com/property/dosearch','postData':FORM}}})
                assert params.get('userGesture') is False, 'DOM click must never simulate user physical inputs'
                return {'result':{'value':{'ok':True,'method':'background-dom-click'}}}
            if expr == 'location.href':
                return {'result':{'value':'https://www.28hse.com/rent?landlordAgency=LANDLORD&sortBy=latest'}}
            if 'const started=performance.now()' in expr:
                return {'result':{'value':{'ok':True,'urls':extract_property_urls(HTML,'rent'), 'newUrls':[extract_property_urls(HTML,'rent')[1]], 'headMs':100, 'firstIdMs':150, 'firstNewMs':160, 'totalMs':333, 'early':True}}}
        return {'result':{}}
    def ev(self,expr,timeout=None):
        if "document.readyState==='interactive'" in expr:return True
        if 'cf-turnstile' in expr:return False
        if expr=='true':return True
        return None
    def close(self):self.closed=True

class DummyApp:
    def __init__(self,emits=True):
        self.c=DummyCDP(emits);self.lock=threading.Lock();self.http_target_ids=set();self.closed=[]
    def list_url(self,trade):return 'https://www.28hse.com/'+trade+'?landlordAgency=LANDLORD&sortBy=latest'
    def target(self, trade):
        return {'id':'user-opened-tab','url':'https://www.28hse.com/rent?landlordAgency=LANDLORD&sortBy=latest','webSocketDebuggerUrl':'ws://127.0.0.1:0000'}
    def create_background_target(self,url):
        raise AssertionError('V1.50.16 never opens a list tab')
    def cdp(self,t):return self.c
    def close_target_id(self,tid):self.closed.append(tid)

def main():
    assert owner_lock(FORM)
    assert owner_lock(json.dumps({'form_data':{'sortBy':'latest','landlordAgency':'LANDLORD'}}))
    for bad in ('sortBy=latest&landlordAgency=AGENT','sortBy=popular&landlordAgency=LANDLORD','invalid'):
        assert not owner_lock(bad)
    assert len(extract_property_urls(HTML,'rent'))==2
    assert not extract_property_urls(HTML,'buy')
    assert len(parse_api_reply(reply(),'rent'))==2
    try:parse_api_reply(reply(),'buy')
    except ApiError:pass
    else:raise AssertionError('wrong trade accepted')
    for malformed in ({'data':{'results':{'html':'x'}}},{'data':{'results':{'resultContentHtml':'foo'}}}):
        try:parse_api_reply(malformed,'rent')
        except ApiError:pass
        else:raise AssertionError('invalid response accepted')
    app=DummyApp()
    target,c,tpl=capture_template(app,'rent',lambda:True)
    assert target['id']=='user-opened-tab' and tpl['body']==FORM and not app.closed
    assert c.event_handler is None
    assert not any(n.startswith('Input.') or n=='Page.bringToFront' for n,_ in c.calls)
    assert [n for n,_ in c.calls].count('Page.navigate')==0 and [n for n,_ in c.calls].count('Page.reload')==1
    assert [n for n,_ in c.calls].index('Network.enable') < [n for n,_ in c.calls].index('Page.reload')
    urls,_,_,times=api_snapshot(c,'rent',tpl,['4051679'],timeout_ms=2500)
    assert len(urls)==2 and len(times['new_urls'])==1 and '4051471' in times['new_urls'][0]
    expr=[x[1]['expression'] for x in c.calls if x[0]=='Runtime.evaluate'][-1]
    assert '/property/dosearch' in expr and 'credentials:\'include\'' in expr
    assert 'GET' not in expr and [x[0] for x in c.calls].count('Page.navigate')==0
    try:api_snapshot(c,'rent',{'url':tpl['url'],'body':'form_data=bad'},[],timeout_ms=2000)
    except ApiError as e: assert e.kind=='filter'
    else:raise AssertionError('unverified template accepted')
    print('PASS: owner+latest lock, source separation, JSON parsing, one-time learning, no HTML reload, new ID, API-only request, fail-closed')

if __name__=='__main__':main()
