# -*- coding: utf-8 -*-
"""Conservative Windows thread scheduling for 6C/12T + 16GB machines.
No realtime process priority or CPU affinity is used: BitBrowser still needs CPU.
"""
from __future__ import annotations
import os
import threading

# ABOVE_NORMAL (1) for the newest-listing and phone lane; not TIME_CRITICAL.
PRIORITIZED_WORKERS = {'phone_worker'}


def apply_worker_priority(fn_name):
    if os.name != 'nt' or fn_name not in PRIORITIZED_WORKERS:
        return False
    try:
        import ctypes
        kernel = ctypes.windll.kernel32
        kernel.GetCurrentThread.restype = ctypes.c_void_p
        kernel.SetThreadPriority.argtypes = (ctypes.c_void_p, ctypes.c_int)
        kernel.SetThreadPriority.restype = ctypes.c_int
        return bool(kernel.SetThreadPriority(kernel.GetCurrentThread(), 1))
    except Exception:
        return False


def launch_worker(fn, args):
    def run():
        apply_worker_priority(getattr(fn, '__name__', ''))
        fn(*args)
    thread = threading.Thread(target=run, daemon=True,
                              name='28Hse-' + str(getattr(fn,'__name__','worker')))
    thread.start()
    return thread
