PandaMonitor V1.50.4｜28Hse CDP 啟動穩定化＋852.house 租售揭號修復
======================================================

重要：此包為完整 Python 專案，不是 EXE；以 V1.50.3 為基礎。

28Hse
- 減少啟動時目標同時建立：先學習並驗證租/售業主最新 API，再預熱揭號橋接及背景詳情 Target。
- 租售 API 學習序列化，但各自 API 輪詢仍獨立。
- 若同時開啟擴充網站，額外插件最多延後 4.5 秒啟動，避免搶 CDP。
- 僅 CDP/DOM 暫時未就緒造成的 learn 類錯誤最多退避重試三次，仍失敗就暫停。
- Cloudflare 驗證、429 限流、OwnerLock 丟失、API/DOM 不一致一律不自動重試。
- 原 JSON API-only、8 秒補查、PhoneFirst、WA 與 House730 保留。

852.house
- 租/售分開 5 秒設定；網址限定 業主盤 + publishtime desc。
- 解決賣家電話已存在但詳情頁業主標籤尚未載入時錯誤拒絕的情況。
- 修正提取陳先生 94609811 等公開聯絡人/電話，不採集 footer 客服。
- HTTP-only 不使用額外瀏覽器分頁；租售初始化請求錯開。
- 相同 host 請求串行，降低兩路同時連線導致的 HTTP read timeout。

安裝：
1. 關閉舊 PandaMonitor，解壓此 ZIP 到新資料夾（不要覆寫運行中的舊版）。
2. 將 852.house 外掛更新到持久化插件目錄：雙擊 UPGRADE_852.cmd。
   此步必須執行，因為舊 house852_owner.py 是放在 C 盤保存並優先載入的。
3. 雙擊 START.bat。配置、歷史去重及原站設定保留。
4. 測試：網站管理 -> 852.house 租/售 -> 測試首帖取號。
5. 檢查 28Hse [API-LEARN] [API-VERIFY] [API-LIST-OK] 及 852 [SITE] 日誌。

只想更新 852 插件：可單獨使用另外提供的 852 插件修復 ZIP；
但是 28Hse 的 API 學習修正只能靠更新主程式。

測試狀態：離線單元/整合測試通過，尚未能在使用者的 Windows/BitBrowser 173
或 852.house 現時實站環境確認穩定性。
