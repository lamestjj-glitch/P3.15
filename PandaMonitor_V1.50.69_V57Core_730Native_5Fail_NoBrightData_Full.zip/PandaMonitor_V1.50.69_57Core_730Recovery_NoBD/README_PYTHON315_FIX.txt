PandaMonitor V1.50.38 — Python 3.15 startup compatibility launcher

1. Extract entire ZIP, double-click START.bat.
2. Python 3.13 preferred; Python 3.12/3.14/3.15 accepted as fallback if Tkinter works.
3. Python 3.15 dependency compatibility is NOT guaranteed. Installing Python 3.13 side-by-side is recommended; do not uninstall 3.15.
4. If it fails, run DIAG_PYTHON.bat and share the contents of start_console.log and startup.log.
5. Python launcher preserved from the 1.50.37 fix. See README_V1538_FIXED_CADENCE.txt for new monitoring behavior.

Logs: %LOCALAPPDATA%\PandaMonitor_28Hse_House730\logs\
