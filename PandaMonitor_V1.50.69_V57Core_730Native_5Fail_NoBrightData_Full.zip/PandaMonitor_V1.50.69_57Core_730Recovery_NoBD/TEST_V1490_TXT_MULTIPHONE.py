# -*- coding: utf-8 -*-
"""Offline regression; NEVER sends WA or connects to BitBrowser."""
import os, tempfile, json, string, subprocess, re, textwrap
from pathlib import Path
from unittest.mock import patch

from wa_female_filter import read_female_names_txt, parse_female_names, female_name_eligible
from contact_visible import extract_visible_phones

BASE = Path(__file__).resolve().parent

def alpha(i):
    # deterministic 10000 unique alphabetical first names within 24 chars
    abc = string.ascii_lowercase
    out = []
    for _ in range(4):
        out.append(abc[i % 26]); i //= 26
    return 'name' + ''.join(reversed(out))

with tempfile.TemporaryDirectory() as td:
    p=Path(td)/'large.txt'
    sample=[alpha(i) for i in range(10000)]
    p.write_text(', '.join(sample[:5000])+'\n'+'\n'.join(sample[5000:])+'\n'+sample[0].upper(), encoding='utf-8-sig')
    names=read_female_names_txt(p)
    assert len(names)==10000, len(names)
    assert female_name_eligible(sample[9999].upper(),names)[0]
    assert female_name_eligible('Ms Liu',names)[0]
    assert not female_name_eligible('劉生 CHERRY',parse_female_names('CHERRY'))[0]
    assert not female_name_eligible('劉生 '+sample[50],names)[0]
    assert not female_name_eligible('Mr. '+sample[50],names)[0]
    assert not female_name_eligible('Alice',names)[0]
    bad=Path(td)/'bad.txt';bad.write_text('Alice\nAlice Smith\nMandy',encoding='utf-8')
    try:read_female_names_txt(bad)
    except ValueError: pass
    else: raise AssertionError('invalid file accepted')
    too_big=Path(td)/'huge.txt';too_big.write_bytes(b'A' * (2_000_001))
    try:read_female_names_txt(too_big)
    except ValueError: pass
    else: raise AssertionError('unbounded file accepted')

fixture = '''<section class="content_phone_information">
 <span class="contact-name">劉生 CHERRY</span>
 <div>Tel: 852-92975270</div><div>Tel: 852-67118650</div>
 <a href="tel:852-92975270">致電</a><a href="tel:852-67118650">致電</a>
 </section>'''
rows=extract_visible_phones(fixture)
assert {r['phone'] for r in rows} == {'92975270','67118650'},rows

# Execute the actual JS rowsFromFragments implementation, not a copied regex.
core=(BASE/'panda28_core.py').read_text(encoding='utf-8')
i=core.index('          const norm=v=>{',core.index('def http_phone_fast('))
j=core.index('          const phoneAction=async',i)
fragment=core[i:j]
js = r'''
const assert=require('assert');
class DOMParser {
 parseFromString(raw){
  const text=String(raw).replace(/<[^>]*>/g,'');
  const block={
    textContent:text,
    querySelector:(q)=> q.includes('contact-name') ? {textContent:'劉生 CHERRY'} : null,
    querySelectorAll:(q)=>{
      if(q==='a[href]' || q==='.fullPhone')return [];
      return [];
    }
  };
  return {querySelectorAll:(q)=>q==='.content_phone_information'?[block]:[],body:block};
 }
}
const url='https://www.28hse.com/rent/apartment/property-40522966';
''' + fragment + r'''
const results=rowsFromFragments(['<div class="content_phone_information">劉生 CHERRYTel: 852-92975270Tel: 852-67118650</div>']);
assert.deepEqual(results.map(x=>x.phone),['92975270','67118650']);
assert.equal(results[0].name,'劉生 CHERRY');
console.log('PASS: actual JS PhoneFirst parser extracts both contact numbers independently');
'''
r=subprocess.run(['node','-e',js],capture_output=True,text=True,check=True)
print(r.stdout.strip())

# tkinter settings integration uses a virtual display; no monitoring started.
if not os.environ.get('DISPLAY'):
    print('PASS: 10k TXT, naming gate, multi-contact fallback (GUI integration needs xvfb-run)')
else:
    from unified_gui import UnifiedApp
    import tkinter.filedialog as fd
    import tkinter.messagebox as mb
    app=UnifiedApp();app.withdraw();app.update()
    try:
        with tempfile.TemporaryDirectory() as td:
            source=Path(td)/'female_names.txt'
            source.write_text('\n'.join(sample)+'\n',encoding='utf-8')
            with patch.object(fd,'askopenfilename',return_value=str(source)),patch.object(mb,'showinfo') as info,patch.object(mb,'showerror',side_effect=AssertionError('unexpected import error')):
                app.import_female_names_txt()
            assert len(app.wa_female_name_set)==10000,len(app.wa_female_name_set)
            assert '10,000' in app.female_names_status.get()
            assert info.call_count==1
            assert Path(app.wa_female_names_file).is_file()
            assert read_female_names_txt(app.wa_female_names_file)==app.wa_female_name_set
            with open(app.config_path,encoding='utf-8') as fh: config=json.load(fh)
            assert 'wa_female_names_file' in config
            assert len(json.dumps(config,ensure_ascii=False)) < 50000, 'config bloated by 10k names'
            # Don't accept malicious/bad changes; keep the last valid list.
            invalid=Path(td)/'invalid.txt';invalid.write_text('Alice\nBad Name',encoding='utf-8')
            with patch.object(fd,'askopenfilename',return_value=str(invalid)),patch.object(mb,'showerror') as err:
                app.import_female_names_txt()
            assert err.call_count==1 and len(app.wa_female_name_set)==10000
    finally:
        for aid in app.tk.call('after', 'info'):
            app.after_cancel(aid)
        app.destroy()
    again=UnifiedApp();again.withdraw();again.update()
    try:
        assert len(again.wa_female_name_set)==10000, len(again.wa_female_name_set)
        assert '10,000' in again.female_names_status.get()
    finally:
        for aid in again.tk.call('after', 'info'):
            again.after_cancel(aid)
        again.destroy()
    print('PASS: 10k-name GUI import, persistence, restart, invalid-file rollback')

# Main PhoneFirst acceptance is still first-unique-number wins. If the first
# publicly visible telephone was already in the persistent database, continue
# to the second rather than failing the whole listing.
import threading
from panda28_core import App as Original28
class StubCDP:
    def call(self, method, args, timeout=None):
        assert method == 'Runtime.evaluate'
        return {'result':{'value':{'terminal':True,'ok':True,
            'rows':[{'name':'劉生 CHERRY','phone':'92975270'},
                    {'name':'劉生 CHERRY','phone':'67118650'}],
            'source':'phone-action-stream','headMs':50,'actionMs':70}}}
class StubApp:
    normalize_phone=staticmethod(Original28.normalize_phone)
    def __init__(self, first_duplicate=False):
        self.learning_lock=threading.Lock()
        self.speed_learning={'rent':{'budget_ms':2800}}
        self.first_duplicate=first_duplicate
        self.result_calls=[]
        self.secondary=[]
    def pid_of(self, url):return '40522966'
    def result(self,k,n,p,u,**kwargs):
        self.result_calls.append(p)
        if self.first_duplicate and p=='92975270':return False,'duplicate'
        return True,'saved'
    def bg(self,fn,*args):self.secondary.append((fn,args))
    def publish_secondary_phone(self,*args):pass
    def learn_phone_latency(self,*args):pass
    def learn_strategy(self,*args):pass
    def write(self,*args):pass
for first_duplicate in (False,True):
    fake=StubApp(first_duplicate)
    terminal,success,_=Original28.http_phone_fast(fake,StubCDP(), 'rent',
        'https://www.28hse.com/rent/apartment/property-40522966')
    assert terminal and success
    assert fake.result_calls == (['92975270','67118650'] if first_duplicate else ['92975270'])
    assert len(fake.secondary) == (0 if first_duplicate else 1)
    if fake.secondary:
        assert fake.secondary[0][1][-1]=='67118650',fake.secondary
print('PASS: duplicate primary falls through to second phone; first unique schedules secondary without clipboard overwrite')
