PandaMonitor V1.48.5 — BitBrowser 173 startup/connection repair
=============================================================

Fixes observed in the 19:17-19:18 V1.48.4 log:
- A WinError 10061 from the 28Hse BitBrowser connection prevented both 28Hse sources from ever starting; House730 could independently initialize, which was previously confusing.
- 28Hse now sends minimal /browser/list requests (page/pageSize only), checks the selected profile seq locally and never silently picks a different environment.
- BitBrowser local API requests use a proxy-free localhost opener. Transient connection refusal gets at most two controlled delayed retries, cancellable by Stop; invalid Token/profile does not repeat.
- The GUI logs [28-OFFLINE] clearly when 28Hse is not running, even if House730 starts.
- On Windows, launching a duplicate PandaMonitor GUI is rejected using a per-login-session named OS mutex. Exit/crash releases the mutex automatically. No mouse/keyboard/focus is touched.

Unchanged: 28Hse API-only /property/dosearch (0.5/1s independent, single-flight), PhoneFirst, owner lock, user files/history and cross-site dedup; 730 V56 and its independent worker/WA and verification; hidden CDP background Target; Cloudflare protection and pause conditions.

Offline tests only. Cannot verify local BitBrowser 173 remotely. A WinError 10061 can also mean the BitBrowser Local API service is actually stopped or an incorrect port; verify Settings > Local API and environment 173 before retrying. Never assume a 730 baseline means 28Hse is running.

Recommended clean test: stop all PandaMonitor instances and wait for the previous child to exit, leave BitBrowser 173 open and Local API enabled, launch START.bat once. Confirm [API-LEARN], [API-VERIFY], [API-LIST-OK] for both 28Hse streams. No saved data needs deleting.
Safety detail: startup transient retry is allowed only before /browser/open, not after it has been attempted. This avoids launching or reopening the same fingerprint profile multiple times due to a temporary CDP /json failure.
