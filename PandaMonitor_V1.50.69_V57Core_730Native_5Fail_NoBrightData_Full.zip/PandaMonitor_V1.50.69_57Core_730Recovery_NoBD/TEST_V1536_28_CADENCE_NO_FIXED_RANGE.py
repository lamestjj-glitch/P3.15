# -*- coding: utf-8 -*-
"""Offline V1.50.36 checks; no website, network, browser, or Signal calls."""
import inspect, math
from pathlib import Path
from api_cadence import parse_api_cadence, display_api_cadence
from hse28_adaptive import AdaptiveListScheduler
from panda28_core import App

for raw in ('.001', '0.01', '0.1', '0.25', '0.5', '1', '3600', '3600.001', '7200', '999999'):
    a = parse_api_cadence(raw)
    assert a > 0 and math.isfinite(a)
    assert parse_api_cadence(display_api_cadence(raw)) == a
for bad in ('', '0', '-0.1', 'NaN', 'Inf', '-Inf', 'x', '0.0001', True, None):
    try: parse_api_cadence(bad)
    except ValueError: pass
    else: raise AssertionError('accepted invalid numeric value: %r' % (bad,))
assert parse_api_cadence('1e5') == 100000.0

class Dummy:
    api_poll_interval = App.api_poll_interval
    api_poll_seconds = {'rent': .1, 'buy': 7200}
d = Dummy()
assert d.api_poll_interval('rent') == .1
assert d.api_poll_interval('buy') == 7200.0
s = AdaptiveListScheduler()
assert s.floor == 0 and s.gap == 0
s.set_user_floor(.1)
for _ in range(200): s.success()
assert s.gap == 0, s.report()
assert s.rate_limited() == 0
s.set_user_floor(5.0)
s.reset()
assert s.floor == 0 and s.gap == 0
core = inspect.getsource(App.start)
assert 'set_user_floor' in core or 'set_user_floor' in Path(__file__).with_name('panda28_core.py').read_text(encoding='utf8')
gui = Path(__file__).with_name('unified_gui.py').read_text(encoding='utf8')
assert 'self.api_adaptive_scheduler.set_user_floor(min(self.api_poll_seconds.values()))' in gui
assert 'V1.50.36' in gui and '[MERGE] V1.50.35' in gui
assert Path(__file__).with_name('house730_adaptive_rate.py').exists()
print('PASS V1.50.36: no fixed 28 interval bounds; runtime scheduler respects sub-500ms target; 429 cooldown remains separate')
