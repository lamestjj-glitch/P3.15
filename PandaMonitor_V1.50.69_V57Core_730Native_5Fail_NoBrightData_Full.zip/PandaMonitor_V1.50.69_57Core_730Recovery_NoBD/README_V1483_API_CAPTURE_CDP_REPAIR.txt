PandaMonitor V1.48.3 - 28Hse API Learning + CDP Port Repair

Changes versus V1.48.2:
1. 28Hse creates an about:blank private background Target, attaches Network listeners first, then navigates the private Target ONCE to owner + latest. Previously navigation started before listeners and might have missed the only relevant XHR.
2. If the page does not produce a valid /property/dosearch request on initial load, the program waits for the page and search controls to finish loading before ONE private DOM .click(). It does not use Windows mouse/keyboard, Chromium Input.dispatchMouseEvent or Page.bringToFront, and never touches active tabs.
3. Requests are verified with landlordAgency=LANDLORD and sortBy=latest in the POST form_data AND final page URL. Unknown/no XHR stops that source and records observed API path names only (no request payloads, cookies, tokens or telephone numbers).
4. 28Hse never falls back to high-frequency HTML list refresh. After setup, only JSON API polls; each source has a saved 0.5s or 1s target, with single-flight and 403/429/Cloudflare pause.
5. At restart, confirm that the saved CDP debugger endpoint is reachable BEFORE launching the 28Hse background workers. If CDP disconnects during operation, pause affected background lanes rather than printing thousands of WinError 10061 failures.
6. The unified GUI waits for a live CDP endpoint before offering it to the House730 child process. It cannot blindly reuse an obsolete address.
7. Retains existing 28Hse PhoneFirst, CDP fallback, dark phone popup, House730 four-source UI, cross-site phone deduplication, independent WA and Cloudflare alert.

Limitations:
- The API's one-time learning still depends on the website sending its own /property/dosearch request on the private page. DOM-simulated clicks may be rejected by the website. If [API-PAUSE] says no request captured, provide the full new error line; this release deliberately does not invent a form_data request or bypass website checks.
- The 0.5s setting is a requested minimum interval, not a guarantee; site rate limits may require a longer interval or stop.
- The release has been tested offline on Linux with a virtual GUI, not on the user's Windows BitBrowser 173. Do not delete the original configuration or deduplication database.

Use: Stop earlier PandaMonitor, wait several seconds for its House730 child process to exit, extract into a new directory, open BitBrowser 173, double-click START.bat.
Expected logs: [API-LEARN], [API-VERIFY], [API-LIST-OK]. If [API-PAUSE], inspect reason and avoid repeated starts.
