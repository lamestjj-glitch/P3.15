# -*- coding: utf-8 -*-
"""Offline regression tests for v1.50 optional site plugins."""
from __future__ import annotations
import json
import tempfile
import threading
import time
import unittest
from http.server import HTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from site_engine import (SiteConfigStore, SiteManager, validate_site, check_owner_url, generic_listings,
                         load_plugin, public_phone_links, plugin_choices, DEFAULT_BFS)

INDEX = '''<!doctype html><html><h1>Owner Listings</h1><a href="/businesses-for-sale/new-shop-42766">New Shop</a>
<a href="/businesses-for-sale/cafe-42765">Cafe</a></html>'''
DETAIL_LOCKED = '''<h1>Cafe</h1><section>Contact Number Premium Only</section>
 <form><select><option>Singapore +65</option><option>India +91</option></select>
 <input placeholder="Mobile Number" value="91234567"></form>'''
DETAIL_PHONE = '''<div><a href="tel:+6581234567">Call seller</a></div><form><input value="+65 99998888"></form>'''

class SiteTests(unittest.TestCase):
    def test_default_config_and_files(self):
        with tempfile.TemporaryDirectory() as td:
            store=SiteConfigStore(td)
            values=store.load()
            self.assertEqual(len(values),1)
            self.assertEqual(values[0]['plugin'],'businessforsale_sg')
            self.assertFalse(values[0]['enabled'])
            store.save([dict(values[0], enabled=True)])
            self.assertTrue(store.load()[0]['enabled'])
            self.assertIn('businessforsale_sg',plugin_choices())

    def test_validation_prevents_bad_config(self):
        for v in (dict(DEFAULT_BFS,interval=0),dict(DEFAULT_BFS,url='file:///etc/passwd'),
                  dict(DEFAULT_BFS,plugin='../../evil'),dict(DEFAULT_BFS,mode='cdp',cdp_endpoint='https://example.com')):
            with self.assertRaises(ValueError):validate_site(v)

    def test_plugin_list_and_phone_lock(self):
        plugin=load_plugin('businessforsale_sg')
        rows=plugin.extract_listings(INDEX,DEFAULT_BFS['url'],DEFAULT_BFS)
        self.assertEqual([r['id'] for r in rows],['42766','42765'])
        self.assertEqual(plugin.extract_contacts(DETAIL_LOCKED,rows[0]['url'],DEFAULT_BFS),[])
        self.assertFalse(plugin.accept_detail(DETAIL_LOCKED,rows[0]['url'],DEFAULT_BFS))
        self.assertTrue(plugin.accept_detail(DETAIL_LOCKED+'<div>Direct Seller</div>',rows[0]['url'],DEFAULT_BFS))
        self.assertEqual(plugin.extract_contacts(DETAIL_PHONE,rows[0]['url'],DEFAULT_BFS)[0]['phone'],'+6581234567')
        self.assertEqual(list(public_phone_links(DETAIL_LOCKED,rows[0]['url'])),[])

    def test_generic_css(self):
        cfg=dict(DEFAULT_BFS,plugin='',link_selector='a[href]',href_contains='/businesses-for-sale/')
        self.assertEqual(len(generic_listings(INDEX,cfg['url'],cfg)),2)

    def test_owner_lock_url_redirect(self):
        source='https://www.businessforsale.sg/businesses-for-sale?source=2&sort=2'
        check_owner_url(source,'https://www.businessforsale.sg/businesses-for-sale?sort=2&source=2')
        with self.assertRaises(ValueError):
            check_owner_url(source,'https://www.businessforsale.sg/businesses-for-sale?sort=2')

    def test_worker_baseline_then_new(self):
        data={'html': INDEX.replace('new-shop-42766','old-shop-42760')}
        class H(BaseHTTPRequestHandler):
            def do_GET(self):
                if self.path=='/detail/42799': content=DETAIL_LOCKED
                elif self.path.endswith('-42799'):content=DETAIL_LOCKED
                else:content=data['html']
                encoded=content.encode('utf-8')
                self.send_response(200);self.send_header('Content-type','text/html; charset=utf-8')
                self.end_headers(); self.wfile.write(encoded)
            def log_message(self,*args): pass
        srv=HTTPServer(('127.0.0.1',0),H)
        thread=threading.Thread(target=srv.serve_forever,daemon=True); thread.start()
        try:
            with tempfile.TemporaryDirectory() as td:
                store=SiteConfigStore(td)
                cfg=dict(DEFAULT_BFS, enabled=True,url='http://127.0.0.1:%d/businesses-for-sale?source=2&sort=2'%srv.server_port,
                         interval=0.3, mode='http', plugin='',link_selector="a[href*='/businesses-for-sale/']")
                mgr=SiteManager(store)
                mgr.start([cfg])
                def await_event(kind,seconds=5):
                    end=time.monotonic()+seconds
                    while time.monotonic()<end:
                        try:evt=mgr.out.get(timeout=.15)
                        except Exception:continue
                        if evt['event']==kind:return evt
                    raise AssertionError('timeout event '+kind)
                await_event('log') # initial baseline
                data['html']= INDEX.replace('new-shop-42766','old-shop-42760')+'<a href="/businesses-for-sale/next-shop-42799">Next Shop</a>'
                evt=await_event('new',8)
                self.assertTrue(evt['data']['id'].endswith('-42799'))
                self.assertEqual(evt['data']['status'],'會員限定／未揭號')
                mgr.halt()
                self.assertTrue(any(v.endswith('-42799') for v in store.read_seen()['businessforsale-sg']))
        finally:
            srv.shutdown();srv.server_close()

if __name__=='__main__':unittest.main(verbosity=2)
