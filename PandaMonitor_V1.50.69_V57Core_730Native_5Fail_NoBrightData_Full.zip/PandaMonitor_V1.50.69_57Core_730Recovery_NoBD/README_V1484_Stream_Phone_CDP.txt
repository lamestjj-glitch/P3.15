PandaMonitor V1.48.4 - 28Hse API compact streaming / CDP stability
==============================================================

Changes vs V1.48.3:

1) 28Hse /property/dosearch remains API-only, no routine page refresh. The JSON response is parsed in the dedicated browser Target; Python receives only a small array of canonical listing URLs and timings, never the whole HTML-in-JSON payload.
2) When a new property URL is seen inside the verified resultContentHtml response stream, stop reading the remainder of that single response and send the candidate to PhoneFirst immediately. The next scan obtains the complete list. One source = at most one active request. Historical baseline and known listings are preserved when an early response contains only a few IDs.
3) For normal/no-NEW polls, read the full JSON, validate response type, source and listing URLs, but transfer only compact IDs. Invalid JSON, wrong trade, challenge and HTTP 403/429 stop or back off according to original protections.
4) CDP connection exceptions and two consecutive CDP command timeouts retire the unresponsive socket instead of repeatedly querying the same dead connection. Detail target can be rebuilt on its one bounded fallback retry; failed items remain visible for manual review.
5) 730 as a separate process attaches to an already active shared CDP endpoint. If it loses that endpoint, it will NOT call BitBrowser /browser/open, which could rotate the port and disconnect 28Hse. The supervisor retries the existing port with backoff. To recover a changed port, stop both monitors, confirm browser 173 is open, then restart.
6) Four source UI, cross-site permanent phone deduplication, both independent WA settings, Windows popups (including Cloudflare) and 28Hse PhoneFirst are unchanged. No physical keyboard/mouse, no frontmost tab switching for background scans.
7) Preserves independent 28Hse 500ms or 1000ms request start cadence. These are target intervals, not guaranteed actual rates or phone times. 403/429/challenges remain hard pause conditions.

Offline tests: TEST_28_*, TEST_730_*, TEST_SHARED_CDP_GUARD.py, TEST_HIGH_PERFORMANCE.py, launch.py --self-test. Stream behavior additionally exercised with Node mock response chunks (no network).

Limitations: Not yet tested against the user's live BitBrowser 173, so expected latency improvement and 28/730 stability must be measured from the user's next run. A first NEW found from a partial JSON stream is validated against its observed owner-locked template and listing URL type; a later full scan confirms the complete list. A full-body JSON response in one network chunk may already arrive before early detection is meaningful. Avoid increasing request frequency further if the site rate limits or triggers Cloudflare.

Steps: stop the previous version, wait for House730 child to exit, unpack V1.48.4 to a NEW folder, run START.bat. Do not delete saved configuration/deduplication databases.
Watch [API-LEARN], [API-VERIFY], [API-LIST-OK], [API-STREAM-NEW], [DETECT-NEW], [RACE] NEW->CLIPBOARD, [DETAIL-WARM-RESET], and 730 reconnect logs.
