# -*- coding: utf-8 -*-
"""28Hse V1.46.5 + House730 V56, shared House730-style Tk dashboard.

The original 28Hse backend is imported unchanged, including its owner-lock,
HTTP/CDP lanes, clipboard-first logic and scheduled WhatsApp greeting.
House730 remains an independent Playwright/BitBrowser engine.
"""
import os
import re
import time
import json
import threading
import tkinter as tk
from datetime import datetime
from house730_process import House730Process
from paste_clipboard_queue import PasteClipboardQueue
from performance import launch_worker
from pathlib import Path
from tkinter import ttk, messagebox, filedialog
import webbrowser
import shutil
import uuid
from site_engine import SiteConfigStore, SiteManager, plugin_choices, validate_site

from panda28_core import App as Panda28App
from hse28_history import Hse28History
from api_cadence import parse_api_cadence, display_api_cadence
from house730_cadence import (parse_house730_cadence, display_house730_cadence,
                              valid_edit as valid_house730_interval_edit)
from wa_contact_recovery import recover_public_contact
from wa_female_filter import (DEFAULT_FEMALE_NAMES, parse_female_names,
                              female_name_eligible, read_female_names_txt)
from house730_engine import (Store, read_config, save_config, listing_key,
                              phone_key, TOKEN_PATH, APP_DIR, OLD_DB_PATH)

BG = '#0c111b'
PANEL = '#141e2d'
PANEL2 = '#1b2a3d'
INPUT = '#26344a'
TEXT = '#eff5ff'
MUTED = '#9baabe'
GREEN = '#44d9a2'
BLUE = '#64b3ff'
GOLD = '#ffc56d'
RED = '#ff7b89'
FONT = ('Microsoft JhengHei UI', 10)


class SharedPhoneStore(Store):
    """Keep phone uniqueness across both independent monitors.

    Uses exactly the same lock as the 28Hse clipboard-first result path.
    Already-saved House730 numbers are seeded into the 28Hse seen set at startup.
    """
    def __init__(self, owner):
        super().__init__()
        self.owner = owner

    def all_phones(self):
        with self.guard, self._open() as cx:
            return {r[0] for r in cx.execute('SELECT phone FROM phones') if r[0]}

    def save_phone(self, deal, url, raw_phone, contact='未提供'):
        num = phone_key(raw_phone)
        if not num:
            return False
        with self.owner.phone_lock:
            if num in self.owner.seen_phones or num in self.owner.pending_copy_phones:
                self.finish(deal, url, 'cross-site-duplicate-phone')
                return False
            success = super().save_phone(deal, url, raw_phone, contact)
            if success:
                self.owner.seen_phones.add(num)
        if success:
            self.owner.bg(self.owner.save_seen_phones_deferred)
        return success


class UnifiedApp(Panda28App):
    VERSION = 'V1.50.69｜57核心＋730五次修復'

    def __init__(self):
        super().__init__()  # Retains 28Hse configuration, owner-lock, and hot paths.
        # Requested 28Hse zero-detail workflow is the safe initial mode even
        # if a legacy config had the optional tab fallback switched on.
        self.phone_api_direct_var.set(True)
        self.phone_api_allow_detail_var.set(False)
        self.phone_api_direct_enabled = True
        self.phone_api_allow_detail = False
        self.title('PandaMonitor V1.50.69｜57原版爬取＋730自動恢復')
        self.geometry('1280x860')
        self.minsize(980, 650)
        self.protocol('WM_DELETE_WINDOW', self.on_close)
        self.hse28_history = Hse28History(self.config_dir)
        self.row_birth = {}
        self._wa_name_lock = threading.Lock()
        self._wa_name_info = {}  # url -> {'name':..., 'ready': threading.Event}
        self._wa_phone_info = {}  # (url, normalized_phone) -> name confirmed by same-phone API
        self.house_rows = {}
        self.house_engine = None
        self.house_states = {'租': {'mode': '等待啟動', 'queries': 0, 'last': '—'},
                             '售': {'mode': '等待啟動', 'queries': 0, 'last': '—'}}
        self.house_popup_numbers = set()
        self._auto_clipboard = PasteClipboardQueue(self._copy_text_raw,
            self._clipboard_sequence_number, self.write)
        self._auto_clipboard_log_ready = False
        # No Ctrl+V gate.  Retry the latest busy clipboard periodically.
        if os.name == 'nt':
            self.after(50, self._clipboard_paste_tick)
        self.house_challenge_popup = None
        self.house_challenge_incident = 0
        self.house_session = 0
        self._house_launch_serial = 0
        self._house_launch_pending = False
        self.after(180, self._house_tick)
        self.after(300, self._site_tick)
        self.after(350, self._enrich_rows)

    @staticmethod
    def _clipboard_sequence_number():
        if os.name != 'nt':
            return 0
        try:
            import ctypes
            return int(ctypes.windll.user32.GetClipboardSequenceNumber())
        except Exception:
            return 0

    @staticmethod
    def _read_ctrl_v_keys():
        if os.name != 'nt':
            return False, False
        try:
            import ctypes
            user32 = ctypes.windll.user32
            ctrl = bool((user32.GetAsyncKeyState(0x11) & 0x8000) or
                        (user32.GetAsyncKeyState(0xA2) & 0x8000) or
                        (user32.GetAsyncKeyState(0xA3) & 0x8000))
            v = bool(user32.GetAsyncKeyState(0x56) & 0x8000)
            return ctrl, v
        except Exception:
            return False, False

    def _clipboard_paste_tick(self):
        try:
            self._auto_clipboard.poll()
        except Exception as exc:
            self.write('[CLIPBOARD-POLL-WARN] %s' % type(exc).__name__)
        try:
            if self.winfo_exists():
                self.after(50, self._clipboard_paste_tick)
        except tk.TclError:
            pass

    def copy_auto_text(self, text, *, listing_key):
        # The newest number wins immediately; do not wait for Ctrl+V.
        with self.clipboard_deferred_lock:
            self.clipboard_copy_generation += 1
        outcome = self._auto_clipboard.submit(text, listing_key)
        self.clipboard_error_local.queued = (outcome == 'queued')
        return outcome == 'copied'

    def extend_auto_clipboard_group(self, listing_key, text):
        return self._auto_clipboard.extend(listing_key, text)

    def copy_auto_tail_with_defer(self, phone):
        digits = self.normalize_phone(phone)
        if not digits:
            return False
        return self.copy_auto_text(digits[-4:], listing_key=('other', digits))

    def copy_text(self, text):
        # An explicit GUI/user copy supersedes queued automatic overwrites.
        if hasattr(self, '_auto_clipboard'):
            self._auto_clipboard.manual_override()
        return super().copy_text(text)

    def _style(self):
        self.configure(bg=BG)
        style = ttk.Style(self)
        try:
            style.theme_use('clam')
        except tk.TclError:
            pass
        style.configure('Dark.TNotebook', background=BG, borderwidth=0)
        style.configure('Dark.TNotebook.Tab', background=PANEL, foreground=MUTED,
                        padding=(17, 9), font=FONT)
        style.map('Dark.TNotebook.Tab', background=[('selected', PANEL2)],
                  foreground=[('selected', TEXT)])
        style.configure('Dark.Treeview', background=PANEL, fieldbackground=PANEL,
                        foreground=TEXT, rowheight=33, font=FONT, borderwidth=0)
        style.map('Dark.Treeview', background=[('selected', '#254c74')],
                  foreground=[('selected', TEXT)])
        style.configure('Dark.Treeview.Heading', background=PANEL2,
                        foreground='#c8d7ea', font=('Microsoft JhengHei UI', 10, 'bold'),
                        padding=(7, 10), relief='flat')
        style.configure('Dark.TCheckbutton', background=PANEL, foreground=TEXT, font=FONT)
        style.map('Dark.TCheckbutton', background=[('active', PANEL)],
                  foreground=[('disabled', MUTED)])
        style.configure('Dark.TEntry', fieldbackground=INPUT, foreground=TEXT,
                        insertcolor=TEXT)
        style.configure('Dark.TCombobox', fieldbackground=INPUT, foreground=TEXT,
                        selectbackground=INPUT)
        style.configure('Dark.TLabelframe', background=PANEL, foreground=TEXT)
        style.configure('Dark.TLabelframe.Label', background=PANEL, foreground=TEXT)
        style.configure('Dark.TLabel', background=PANEL, foreground=TEXT)

    def _label(self, parent, text='', fg=TEXT, size=10, bold=False, **kw):
        return tk.Label(parent, text=text, bg=parent.cget('bg'), fg=fg,
                        font=('Microsoft JhengHei UI', size,
                              'bold' if bold else 'normal'), **kw)

    def _btn(self, parent, text, cmd, bg=INPUT):
        return tk.Button(parent, text=text, command=cmd, bg=bg, fg=TEXT,
                         activebackground=PANEL2, activeforeground='white',
                         relief='flat', bd=0, padx=13, pady=8,
                         font=('Microsoft JhengHei UI', 10, 'bold'), cursor='hand2')

    def _stat_card(self, parent, col, title, var, color):
        f = tk.Frame(parent, bg=PANEL, padx=14, pady=12)
        f.grid(row=0, column=col, sticky='nsew', padx=3)
        self._label(f, title, MUTED).pack(anchor='w')
        tk.Label(f, textvariable=var, bg=PANEL, fg=color, anchor='w',
                 font=('Microsoft JhengHei UI', 12, 'bold')).pack(anchor='w', fill='x', pady=(7, 0))

    def build(self):
        """Build House730 V56 dark UI, keeping all old 28Hse widget contracts."""
        self._style()
        self.site_store = SiteConfigStore(Path(self.config_dir))
        try:
            self.extra_sites = self.site_store.load()
            self.site_load_error = ''
        except Exception as ex:
            self.extra_sites = []
            self.site_load_error = str(ex)
        self.site_manager = None
        self.site_states = {}
        self.site_rows = {}
        self.house_cfg = read_config()
        self.house_rent = tk.BooleanVar(value=bool(self.house_cfg['rent_enabled']))
        self.house_buy = tk.BooleanVar(value=bool(self.house_cfg['buy_enabled']))
        # One set of BitBrowser fields for *both* monitor engines.  Never show
        # a competing 730 browser/port/seq/token control.
        old_token = APP_DIR.parent / 'OwnerPropertyMonitor-OtherSites' / 'bitbrowser_api_token.txt'
        token_file = TOKEN_PATH if TOKEN_PATH.exists() else old_token
        if not self.bit_key.get().strip() and token_file.exists():
            self.bit_key.set(token_file.read_text(encoding='utf-8').strip())
        # Existing 28Hse credentials take precedence. A fresh install defaults
        # to BitBrowser 173 because both sites are selected on the first start.
        if not os.path.isfile(self.config_path):
            self.browser_type.set('BitBrowser')
            self.bit_api.set(str(self.house_cfg['bitbrowser_api_url']))
            self.bit_no.set(str(self.house_cfg['bitbrowser_seq']))
        self.house_api = self.bit_api
        self.house_seq = self.bit_no
        self.house_token = self.bit_key
        # 28Hse API-only cadence is independently configurable per rent/buy.
        # Use shared plain floats for background worker reads: no Tk calls in
        # non-UI threads. New installs use 0.5s per lane; saved prefs win.
        try:
            with open(self.config_path, 'r', encoding='utf-8') as fh:
                api_settings = json.load(fh)
            if not isinstance(api_settings, dict):
                api_settings = {}
        except (OSError, ValueError, TypeError):
            api_settings = {}
        def valid_api_cadence(value):
            try:
                return display_api_cadence(value)
            except ValueError:
                return '0.5'
        self.api_rent_interval = tk.StringVar(value=valid_api_cadence(api_settings.get('api_rent_interval', '0.5')))
        self.api_buy_interval = tk.StringVar(value=valid_api_cadence(api_settings.get('api_buy_interval', '0.5')))
        self.api_poll_seconds = {
            'rent': float(self.api_rent_interval.get()),
            'buy': float(self.api_buy_interval.get()),
        }
        self.api_recheck_var = tk.BooleanVar(value=bool(api_settings.get('api_recheck_8s_enabled', True)))
        self.api_recheck_enabled = bool(self.api_recheck_var.get())
        self.low_tab_mode_var = tk.BooleanVar(value=bool(api_settings.get('low_tab_mode', True)))
        self.low_tab_mode = bool(self.low_tab_mode_var.get())
        # Store large lists in their own UTF-8 file, not in Tk Entry/config.json.
        # The legacy 150-name config remains readable on first upgrade.
        self.wa_female_names_file = os.path.join(self.config_dir, 'wa_female_names.txt')
        self.wa_female_names = tk.StringVar(value=str(api_settings.get('wa_female_names', DEFAULT_FEMALE_NAMES)))
        self.female_names_file_loaded = False
        try:
            if os.path.isfile(self.wa_female_names_file):
                self.wa_female_name_set = read_female_names_txt(self.wa_female_names_file)
                self.female_names_file_loaded = True
            else:
                self.wa_female_name_set = parse_female_names(self.wa_female_names.get())
        except (ValueError, OSError) as exc:
            # Fail closed: a damaged imported file must not silently fall back
            # to a different (possibly older) recipient allowlist.
            self.wa_female_name_set = frozenset()
            self._female_names_load_error = str(exc)
        self.wa_test_property_url = tk.StringVar(value='')
        self.female_names_status = tk.StringVar()
        self._set_female_names_status()
        self.house_interval = tk.StringVar(value=display_house730_cadence(self.house_cfg['poll_seconds']))
        self.house_cf_protection = tk.BooleanVar(value=bool(self.house_cfg.get('cloudflare_protection',True)))
        self.house_popup = self.win_notify
        self.main_topmost = tk.BooleanVar(value=False)
        # Keep the untouched Panda28App WA variables for 28Hse.  730 has its
        # OWN enable/window/message; it must not inherit or mutate 28 settings.
        self.wa_730_enable = tk.BooleanVar(value=False)
        self.wa_730_start = tk.StringVar(value='23:30')
        self.wa_730_end = tk.StringVar(value='07:00')
        self.wa_730_text = tk.StringVar(value='你好，我在House730看到你的放盤，想了解更多資料。 {url}')
        self._wa_730_lock = threading.Lock()
        try:
            with open(self.config_path, 'r', encoding='utf-8') as f:
                extra = json.load(f)
            self.wa_730_enable.set(bool(extra.get('wa_730_enable', False)))
            self.wa_730_start.set(str(extra.get('wa_730_start', '23:30')))
            self.wa_730_end.set(str(extra.get('wa_730_end', '07:00')))
            self.wa_730_text.set(str(extra.get('wa_730_text', '你好，我在House730看到你的放盤，想了解更多資料。 {url}')))
        except (OSError, ValueError, TypeError):
            pass
        self.house_store = SharedPhoneStore(self)
        # Make old and new data stores aware of one another; don't delete either.
        with self.phone_lock:
            house_phones = self.house_store.all_phones()
            self.seen_phones.update(house_phones)
            dedup_count = len(self.seen_phones)
        # Existing JSON entries do not store source labels: do not invent a
        # per-site count or claim unknown numbers came from 28Hse/House730.
        self.write('[PHONE-DEDUP-READY] 28Hse/730 共用完整電話去重已載入 %d 個；來源不分站標記；28Hse無電話帖子僅按房源ID暫時去重' % dedup_count)

        self.card_28r = tk.StringVar(value='等待啟動')
        self.card_28b = tk.StringVar(value='等待啟動')
        self.card_730r = tk.StringVar(value='等待啟動')
        self.card_730b = tk.StringVar(value='等待啟動')
        self.api_pause_banner = tk.StringVar(value='28Hse API：等待開始')
        self.house_status = tk.StringVar(value='730 未啟動')
        self.house_queries = tk.StringVar(value='730 API：0 次')
        self.house_queue = tk.StringVar(value='730 待揭號：0')
        self.global_latest = tk.StringVar(value='等待新電話')

        head = tk.Frame(self, bg=BG, padx=23, pady=16)
        head.pack(fill='x')
        self._label(head, 'PANDAMONITOR  /  業主盤即時監控', TEXT, 20, True).pack(anchor='w')
        self._label(head, '高效能模式 · 28Hse/730 直接 API 不開帖 · 四路＋自訂網站共用 UI',
                    MUTED, 10).pack(anchor='w', pady=(5, 0))
        tk.Frame(self, bg='#273447', height=1).pack(fill='x')

        outer = tk.Frame(self, bg=BG, padx=17, pady=10)
        outer.pack(fill='both', expand=True)
        opts = tk.Frame(outer, bg=PANEL, padx=12, pady=12)
        opts.pack(fill='x')
        self._label(opts, '來源', MUTED, bold=True).pack(side='left', padx=(2, 13))
        for name, var in (('28 租盤', self.rent), ('28 售盤', self.buy),
                          ('730 租盤', self.house_rent), ('730 售盤', self.house_buy)):
            ttk.Checkbutton(opts, text=name, variable=var,
                            style='Dark.TCheckbutton').pack(side='left', padx=6)
        self.start_btn = self._btn(opts, '▶ 開始監控', self.start, bg='#136e57')
        self.start_btn.pack(side='left', padx=(20, 6))
        self.stop_btn = self._btn(opts, '■ 停止監控', self.stop, bg='#743845')
        self.stop_btn.pack(side='left', padx=4)
        self.stop_btn.configure(state='disabled')
        self._label(opts, '', GREEN, textvariable=self.monitor_state).pack(side='right')

        cards = tk.Frame(outer, bg=BG)
        cards.pack(fill='x', pady=(10, 9))
        for c in range(4): cards.grid_columnconfigure(c, weight=1, uniform='status')
        self._stat_card(cards, 0, '28Hse 租盤｜極速', self.card_28r, BLUE)
        self._stat_card(cards, 1, '28Hse 售盤｜極速', self.card_28b, GREEN)
        self._stat_card(cards, 2, '730 租盤｜API/HTML', self.card_730r, GOLD)
        self._stat_card(cards, 3, '730 售盤｜API/HTML', self.card_730b, TEXT)
        tk.Label(outer, textvariable=self.api_pause_banner, bg=BG, fg=GOLD,
                 font=('Microsoft JhengHei UI', 10, 'bold'),
                 anchor='w').pack(fill='x', pady=(0, 5))

        self.tabs = ttk.Notebook(outer, style='Dark.TNotebook')
        self.tabs.pack(fill='both', expand=True)
        results = tk.Frame(self.tabs, bg=PANEL)
        logs = tk.Frame(self.tabs, bg=PANEL)
        settings = tk.Frame(self.tabs, bg=PANEL)
        self.tabs.add(results, text='   最新號碼   ')
        self.tabs.add(logs, text='   運行記錄   ')
        self.tabs.add(settings, text='   統一設定｜28Hse + House730 + WhatsApp   ')
        self.sites_tab = tk.Frame(self.tabs, bg=PANEL)
        self.tabs.add(self.sites_tab, text='   新增網站｜插件管理   ')
        self._build_sites_tab(self.sites_tab)

        toolbar = tk.Frame(results, bg=PANEL, padx=12, pady=10)
        toolbar.pack(fill='x')
        self._label(toolbar, '最新號碼：', MUTED).pack(side='left')
        self.latest_phone = self.global_latest  # V1.46.5 core writes this variable.
        self._label(toolbar, '', GOLD, 16, True,
                    textvariable=self.latest_phone).pack(side='left', padx=(4, 16))
        self._btn(toolbar, '複製號碼', lambda: self.copy(False)).pack(side='right', padx=4)
        self._btn(toolbar, '開原帖', self.open_selected).pack(side='right', padx=4)
        self._btn(toolbar, 'WA 狀態', self.toggle_house_wa).pack(side='right', padx=4)

        wrap = tk.Frame(results, bg=PANEL)
        wrap.pack(fill='both', expand=True, padx=11, pady=(0, 11))
        # FIRST FIVE COLUMN POSITIONS preserve every 28Hse core mutation.
        columns = ('source', 'phone', 'contact', 'wa_status', 'open_post',
                   'detected_at', 'tail', 'pid')
        display = ('detected_at', 'source', 'contact', 'phone', 'tail',
                   'wa_status', 'pid', 'open_post')
        self.tree = ttk.Treeview(wrap, columns=columns, displaycolumns=display,
                                 show='headings', selectmode='browse', style='Dark.Treeview')
        labels = {'detected_at': '發現時間', 'source': '來源', 'contact': '聯絡人',
                  'phone': '電話', 'tail': '尾四位', 'wa_status': 'WA 狀態',
                  'pid': '樓盤 ID', 'open_post': '原帖'}
        widths = {'detected_at': 153, 'source': 100, 'contact': 165,
                  'phone': 155, 'tail': 85, 'wa_status': 170,
                  'pid': 105, 'open_post': 83}
        for col in columns:
            self.tree.heading(col, text=labels[col])
            self.tree.column(col, width=widths[col], minwidth=56,
                             stretch=col == 'contact', anchor='w' if col == 'contact' else 'center')
        sc = ttk.Scrollbar(wrap, orient='vertical', command=self.tree.yview)
        self.tree.configure(yscrollcommand=sc.set)
        self.tree.pack(side='left', fill='both', expand=True)
        sc.pack(side='right', fill='y')
        self.tree.bind('<ButtonRelease-1>', self.on_tree_click)
        self.tree.bind('<Double-1>', self.on_tree_double_click)
        self.tree.bind('<Button-3>', self.right_click)

        bar = tk.Frame(logs, bg=PANEL, padx=14, pady=10)
        bar.pack(fill='x')
        self._label(bar, '28Hse 與 House730 實時日誌', MUTED).pack(side='left')
        self._btn(bar, '打開 730 數據資料夾', self.open_house_folder).pack(side='right')
        self.log = tk.Text(logs, bg='#0f1926', fg='#cfe0f4', insertbackground=TEXT,
                           relief='flat', font=('Consolas', 9), wrap='word')
        self.log.pack(fill='both', expand=True, padx=12, pady=(0, 11))
        # Settings extend beyond smaller displays. Keep every control accessible
        # through a real scrollbar instead of silently clipping Save/WA options.
        canvas = tk.Canvas(settings, bg=PANEL, borderwidth=0,
                           highlightthickness=0)
        scroll = ttk.Scrollbar(settings, orient='vertical', command=canvas.yview)
        canvas.configure(yscrollcommand=scroll.set)
        scroll.pack(side='right', fill='y')
        canvas.pack(side='left', fill='both', expand=True)
        settings_inner = tk.Frame(canvas, bg=PANEL)
        window_id = canvas.create_window((0, 0), window=settings_inner, anchor='nw')
        settings_inner.bind('<Configure>',
                            lambda _e: canvas.configure(scrollregion=canvas.bbox('all')))
        canvas.bind('<Configure>',
                    lambda e: canvas.itemconfigure(window_id, width=e.width))
        self._build_unified_settings(settings_inner)
        foot = tk.Frame(outer, bg=BG, pady=8)
        foot.pack(fill='x')
        self._label(foot, '28Hse：', MUTED).pack(side='left')
        self._label(foot, '', BLUE, textvariable=self.stat).pack(side='left')
        self._label(foot, '  |  ', MUTED).pack(side='left')
        self._label(foot, '', GREEN, textvariable=self.house_status).pack(side='left')
        self._label(foot, '', MUTED, textvariable=self.house_queries).pack(side='right')
        self._label(foot, '', MUTED, textvariable=self.house_queue).pack(side='right', padx=17)
        self.write('[MERGE] V1.50.26：28Hse HTTP 429 租售共用8±8秒隨機退避、遵從Retry-After；低頻試探成功後恢復原間隔；無詳情電話API優先')
        self.write('[MERGE] V1.50.27：28Hse租售共用智能列表排程；500ms為最快目標；按429/Timeout自動降速、穩定後緩升；列表逾時不再誤當CDP斷線；直接電話API不改')
        self.write('[MERGE] V1.50.28：修復隊列等待誤算為API耗時；CDP逾時不再錯誤加重全站限流；常態CDP健康檢查降頻；保留無詳情取號')
        self.write("[MERGE] V1.50.33：28／730同開時730優先獨立API通道；Runtime出錯不再當作網站429或HTML降級；原28Hse設定不動")
        self.write("[MERGE] V1.50.34：730租售共享單次JSON API排程；HTTP429共用冷卻／Retry-After；低頻逐步恢復；原28Hse、WA設定不動")
        self.write("[MERGE] V1.50.35：730 HTML／重新學習收到真正429時立即共享冷卻；修正漏登記；GUI清晰顯示429狀態；不改任何設定")
        self.write('[MERGE] V1.50.36：28Hse租售間隔移除0.5~3600秒固定範圍；接受任意正數毫秒精度目標；動態共用智能排程仍保留429/Timeout保護')
        self.write('[MERGE] V1.50.37：非前台不停止；28/730 後台 renderer active（不搶焦點）、降低CDP健康檢查；日誌合批與限制記錄量；只保留取號高優先線程；設定不變')
        self.write('[MERGE] V1.50.43：已移除 Signal；保留 28Hse／730／WA／去重功能')
        self.write('[MERGE] V1.50.44：730取消3秒起步及逐步加速／1.5秒下限；租售共用輸入秒數＋每輪隨機100–300ms；保留429冷卻／Cloudflare保護；28Hse不變')
        self.write('[MERGE] V1.50.45：28Hse 同帖主號碼＋附加號碼尾四位換行合併複製；晚到附加號僅更新本帖剪貼簿；730、Signal 狀態及 WA 不變')
        self.write('[MERGE] V1.50.46：28Hse 租售各單次請求、允許同時查詢；仍共用429冷卻；瀏覽器HTTP連線重用；新增不發額外請求的API耗時分解；電話去重庫不變')
        self.write('[MERGE] V1.50.47：新增28Hse房源歷史SQLite持久化，重啟後載入28租售紀錄；現有跨站電話去重不變')
        self.write('[MERGE] V1.50.48：730租售並行；Ctrl+V後100–300ms補複製；無Signal')
        self.write('[MERGE] V1.50.49：28／730 WA只在取號後補核對同一聯絡人姓名；支持指定原帖WA測試，未知仍不發送')
        self.write('[MERGE] V1.50.50：730瀏覽器執行故障漸進恢復／已驗證原生HTTP自動接回／首次Reload失敗先用原DOM；新增730每10輪耗時報告；原始設定不變')
        self.write('[MERGE] V1.50.51：移除730 429共享數千秒冷卻與Retry-After長等待；改為僅報429的本路短暫3秒重試；28、WA、去重不變')
        self.write('[MERGE] V1.50.52：修正PowerShell自動變數 HOME 不能覆寫；Python多版本偵測及28/730/WA邏輯不變')
        self.write('[MERGE] V1.50.53：28／730最新6帖優先、較後房源每輪內存核查；租售隔離共用快取；730減少重複SQLite；官方推送未證實不啟用')
        self.write('[MERGE] V1.50.54：730每路429短退避3–30秒、成功復原即恢復設定；修復重接舊分頁遭佔用映射排除；28 WA姓名與實際電話關聯核對；無Signal')
        self.write('[WA55] WhatsApp Web 真正發送圖示優先；DOM 點擊／CDP 鼠標／Enter 逐步回退；聊天紀錄確認後才顯示已發送')
        self.write('[WA56] 女性稱謂+指定 May 英文別名；新帖檢出時鎖定 WA 時段資格；姓名／時段略過原因日誌；無 Signal')
        self.write('[MERGE] 730 V56 租/售兩路，JSON 有效時 1 秒目標；無效切換 HTML 備援，斷線自動重連')
        self.write('[MERGE] 28／730／擴展網站共用電話去重；28Hse 和 730 核心沿用 V1.49.1 原碼')
        if self.site_load_error: self.write('[SITE-CONFIG-ERROR] ' + self.site_load_error)

    def _build_unified_settings(self, frame):
        """Single shared browser, alerts and WhatsApp control panel for both sites."""
        canvas = tk.Canvas(frame, bg=PANEL, highlightthickness=0)
        scrollbar = ttk.Scrollbar(frame, orient='vertical', command=canvas.yview)
        canvas.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side='right', fill='y')
        canvas.pack(side='left', fill='both', expand=True)
        f = tk.Frame(canvas, bg=PANEL, padx=20, pady=16)
        window = canvas.create_window((0, 0), window=f, anchor='nw')
        f.bind('<Configure>', lambda e: canvas.configure(scrollregion=canvas.bbox('all')))
        canvas.bind('<Configure>', lambda e: canvas.itemconfigure(window, width=e.width))

        self._label(f, '共用設定｜28Hse + House730', TEXT, 15, True).pack(anchor='w')
        self._label(f, '只有一個設定頁：共用瀏覽器、通知及去重；28Hse 和 House730 的 WhatsApp 設定、測試及發送各自獨立。',
                    MUTED).pack(anchor='w', pady=(3, 12))

        browser = tk.LabelFrame(f, bg=PANEL, fg=TEXT, text='  共用瀏覽器連線  ', padx=12, pady=9)
        browser.pack(fill='x', pady=(0, 10))
        line = tk.Frame(browser, bg=PANEL)
        line.pack(fill='x')
        self._label(line, '瀏覽器：', MUTED).pack(side='left')
        cb = ttk.Combobox(line, textvariable=self.browser_type,
                          values=('BitBrowser', 'AdsPower'), state='readonly', width=14)
        cb.pack(side='left', padx=(5, 14))
        cb.bind('<<ComboboxSelected>>', lambda _e: self.show_browser_frame())
        self._btn(line, '連接瀏覽器', lambda: self.bg(self.connect_browser)).pack(side='left')
        self._label(line, '選 BitBrowser 時，28Hse + 730 共用這組環境號／API／Token。',
                    MUTED).pack(side='left', padx=16)
        self.browser_host = tk.Frame(browser, bg=PANEL)
        self.browser_host.pack(fill='x', pady=(9, 3))
        self.browser_host.columnconfigure(0, weight=1)
        self.ads_frame = ttk.LabelFrame(self.browser_host, text='AdsPower（僅 28Hse）', style='Dark.TLabelframe')
        self.bit_frame = ttk.LabelFrame(self.browser_host, text='BitBrowser｜28Hse + House730 共用', style='Dark.TLabelframe')
        self._build_ads_frame()
        self._build_bit_frame()
        self.show_browser_frame()
        self.browser_note = tk.StringVar()
        self._label(browser, '', MUTED, textvariable=self.browser_note).pack(anchor='w')
        self.browser_type.trace_add('write', lambda *_: self._refresh_browser_note())
        self._refresh_browser_note()

        performance = tk.LabelFrame(f, bg=PANEL, fg=TEXT, text='  四路監控與速度  ', padx=12, pady=8)
        performance.pack(fill='x', pady=(0, 10))
        options = tk.Frame(performance, bg=PANEL); options.pack(fill='x', pady=4)
        for label, var in [('28Hse 租盤', self.rent), ('28Hse 售盤', self.buy),
                           ('730 租盤', self.house_rent), ('730 售盤', self.house_buy)]:
            ttk.Checkbutton(options, text=label, variable=var,
                            style='Dark.TCheckbutton').pack(side='left', padx=(0, 22))
        speeds = tk.Frame(performance, bg=PANEL); speeds.pack(fill='x', pady=5)
        self._label(speeds, '28Hse 租盤 API（秒）：', GOLD).pack(side='left')
        rent_poll = ttk.Entry(speeds, textvariable=self.api_rent_interval,
                              width=9, style='Dark.TEntry')
        rent_poll.pack(side='left', padx=(3, 14))
        rent_poll.bind('<Return>', lambda _e: self.update_28_api_interval('rent'))
        rent_poll.bind('<FocusOut>', lambda _e: self.update_28_api_interval('rent'))
        self._label(speeds, '28Hse 售盤 API（秒）：', GOLD).pack(side='left')
        buy_poll = ttk.Entry(speeds, textvariable=self.api_buy_interval,
                             width=9, style='Dark.TEntry')
        buy_poll.pack(side='left', padx=(3, 24))
        buy_poll.bind('<Return>', lambda _e: self.update_28_api_interval('buy'))
        buy_poll.bind('<FocusOut>', lambda _e: self.update_28_api_interval('buy'))
        self._label(speeds, '730 JSON 間隔（秒）：', MUTED).pack(side='left')
        house_interval_entry = ttk.Entry(
            speeds, textvariable=self.house_interval, width=9, style='Dark.TEntry',
            validate='key', validatecommand=(self.register(valid_house730_interval_edit), '%P'))
        house_interval_entry.pack(side='left', padx=5)
        house_interval_entry.bind('<Return>', lambda _e: self.update_house_interval(show_error=True))
        house_interval_entry.bind('<FocusOut>', lambda _e: self.update_house_interval(show_error=True))
        recheck_row = tk.Frame(performance, bg=PANEL); recheck_row.pack(fill='x', pady=(1, 2))
        ttk.Checkbutton(recheck_row, text='28Hse 8秒無成功查詢監察（正常查詢成功時自動去重，不增加額外請求）',
                        variable=self.api_recheck_var, style='Dark.TCheckbutton',
                        command=self.update_28_api_recheck).pack(side='left')
        self._label(recheck_row, '28／730都按輸入秒數＋隨機100–300ms；730的429僅本路短等3秒。', MUTED, 9).pack(side='left', padx=12)
        phone_row = tk.Frame(performance,bg=PANEL);phone_row.pack(fill='x',pady=(5,2))
        ttk.Checkbutton(phone_row,text='28Hse：新帖 ID 直接電話 API（不需要詳情 HTML）',
                        variable=self.phone_api_direct_var,style='Dark.TCheckbutton',
                        command=self.update_28_phone_mode).pack(side='left',padx=(0,20))
        ttk.Checkbutton(phone_row,text='允許 CDP 背景開帖揭號（預設關閉）',
                        variable=self.phone_api_allow_detail_var,style='Dark.TCheckbutton',
                        command=self.update_28_phone_mode).pack(side='left')
        self._label(performance,
                    'API 失敗會先嘗試舊 HTTP（只下載 HTML，不開分頁）；CDP 開帖關閉時會再補試 HTTP 一次。',
                    MUTED).pack(anchor='w',pady=(2,3))
        ttk.Checkbutton(performance, text='少分頁模式：28Hse 不在啟動時預先建立兩個備用詳情頁（首次 CDP 備援可能稍慢）',
                        variable=self.low_tab_mode_var, style='Dark.TCheckbutton',
                        command=self.update_low_tab_mode).pack(anchor='w', pady=(4,2))
        self._label(performance,
                    '28Hse／730：輸入秒數＋每輪隨機100–300ms；730不逐步加速，429不設共用長冷卻。',
                    MUTED).pack(anchor='w', pady=(2, 2))
        self._label(performance,
                    '730 直接電話 API：嚴格零開帖。API 無公開電話或失敗時不自動開帖／不點揭號；「打開原帖」僅供手動操作。',
                    MUTED).pack(anchor='w',pady=(2, 2))
        self._label(performance,
                    '730 JSON：可輸入 0.001～300 秒（最多3位小數）。Enter／離開欄位保存，運行時同步更新；'
                    '開啟 Cloudflare 保護時仍執行至少60秒間隔。',
                    MUTED).pack(anchor='w', pady=(2, 2))
        protect_row = tk.Frame(performance, bg=PANEL); protect_row.pack(fill='x', pady=(7, 2))
        ttk.Checkbutton(protect_row, text='730 Cloudflare 保護模式（建議開啟）',
                        variable=self.house_cf_protection, style='Dark.TCheckbutton').pack(side='left')
        self._label(protect_row, '啟用時租售各至少60秒查詢，轉圈暫停全部730請求；連續正常且冷卻完成後才恢復。',
                    GOLD).pack(side='left', padx=15)
        verif_row = tk.Frame(performance, bg=PANEL); verif_row.pack(fill='x', pady=(4, 0))
        self._btn(verif_row, '顯示730租盤驗證分頁', lambda: self.show_730_verification('租')).pack(side='left', padx=(0, 8))
        self._btn(verif_row, '顯示730售盤驗證分頁', lambda: self.show_730_verification('售')).pack(side='left')
        self._label(performance, '28／730 測試及 WhatsApp 各自獨立；28Hse 原有極速偵測不受保護模式影響。',
                    MUTED).pack(anchor='w')

        notifications = tk.LabelFrame(f, bg=PANEL, fg=TEXT, text='  共用電話／通知／去重  ', padx=12, pady=8)
        notifications.pack(fill='x', pady=(0, 10))
        nt = tk.Frame(notifications, bg=PANEL); nt.pack(fill='x', pady=4)
        ttk.Checkbutton(nt, text='28Hse + House730：新電話 Windows 置頂通知',
                        variable=self.win_notify, style='Dark.TCheckbutton').pack(side='left', padx=(0, 25))
        ttk.Checkbutton(nt, text='主視窗始終置頂', variable=self.main_topmost,
                        command=self._change_topmost, style='Dark.TCheckbutton').pack(side='left')
        self._label(notifications, '跨 28Hse／730 永久電話去重、同樓盤 ID 去重、成功後自動複製尾四位；手動按鈕複製完整電話。',
                    MUTED).pack(anchor='w')

        # Only ONE settings tab, with clearly separated per-site WA controllers.
        wa28 = tk.LabelFrame(f, bg=PANEL, fg=TEXT, text='  28Hse｜WhatsApp（原版 V1.46.5 功能）  ', padx=12, pady=8)
        wa28.pack(fill='x', pady=(0, 10))
        r = tk.Frame(wa28, bg=PANEL); r.pack(fill='x', pady=4)
        ttk.Checkbutton(r, text='28Hse 自動打招呼', variable=self.wa_enable,
                        style='Dark.TCheckbutton').pack(side='left', padx=(0, 16))
        self._label(r, '開始').pack(side='left')
        ttk.Entry(r, textvariable=self.wa_start, width=7).pack(side='left', padx=(5, 10))
        self._label(r, '結束').pack(side='left')
        ttk.Entry(r, textvariable=self.wa_end, width=7).pack(side='left', padx=(5, 10))
        self._label(r, '跨午夜可用', MUTED).pack(side='left')
        m = tk.Frame(wa28, bg=PANEL); m.pack(fill='x', pady=(5, 8))
        self._label(m, '28 訊息：', MUTED).pack(side='left')
        ttk.Entry(m, textvariable=self.wa_text).pack(side='left', fill='x', expand=True, padx=(8, 0))
        tests = tk.Frame(wa28, bg=PANEL); tests.pack(fill='x', pady=(9, 0))
        self._btn(tests, '28Hse 租盤 API 測試', lambda: self.bg(self.api_test_28, 'rent')).pack(side='left', padx=(0, 8))
        self._btn(tests, '28Hse 售盤 API 測試', lambda: self.bg(self.api_test_28, 'buy')).pack(side='left', padx=(0, 8))
        self._btn(tests, '28Hse WA 發送測試', self.test_28_wa).pack(side='left')

        wa730 = tk.LabelFrame(f, bg=PANEL, fg=TEXT, text='  House730｜WhatsApp（獨立設定）  ', padx=12, pady=8)
        wa730.pack(fill='x', pady=(0, 10))
        r = tk.Frame(wa730, bg=PANEL); r.pack(fill='x', pady=4)
        ttk.Checkbutton(r, text='730 自動打招呼', variable=self.wa_730_enable,
                        style='Dark.TCheckbutton').pack(side='left', padx=(0, 16))
        self._label(r, '開始').pack(side='left')
        ttk.Entry(r, textvariable=self.wa_730_start, width=7).pack(side='left', padx=(5, 10))
        self._label(r, '結束').pack(side='left')
        ttk.Entry(r, textvariable=self.wa_730_end, width=7).pack(side='left', padx=(5, 10))
        self._label(r, '跨午夜可用', MUTED).pack(side='left')
        m = tk.Frame(wa730, bg=PANEL); m.pack(fill='x', pady=(5, 8))
        self._label(m, '730 訊息：', MUTED).pack(side='left')
        ttk.Entry(m, textvariable=self.wa_730_text).pack(side='left', fill='x', expand=True, padx=(8, 0))
        tests = tk.Frame(wa730, bg=PANEL); tests.pack(fill='x', pady=(9, 0))
        self._btn(tests, '730 租盤 API 取號測試（前3帖）', lambda: self.test_730('租')).pack(side='left', padx=(0, 8))
        self._btn(tests, '730 售盤 API 取號測試（前3帖）', lambda: self.test_730('售')).pack(side='left', padx=(0, 8))
        self._btn(tests, '730 租盤 WA 測試', lambda: self.test_730_wa('租')).pack(side='left', padx=(0, 8))
        self._btn(tests, '730 售盤 WA 測試', lambda: self.test_730_wa('售')).pack(side='left')
        self._label(wa730, '兩邊 WA 開關、發送時間與訊息互不影響。WA 測試按鈕會真正發送，需要先確認。',
                    MUTED).pack(anchor='w', pady=(8, 0))

        url_row = tk.Frame(f, bg=PANEL); url_row.pack(fill='x', pady=(0,8))
        self._label(url_row, 'WA 測試指定原帖（可留空）', MUTED).pack(side='left')
        ttk.Entry(url_row, textvariable=self.wa_test_property_url).pack(side='left', fill='x', expand=True, padx=(9,0))
        self._label(f, '貼入完整 28Hse／730 原帖網址，兩站 WA 測試改測指定帖；留空才測列表首帖。', MUTED, 9).pack(anchor='w',pady=(0,6))
        namebox = tk.LabelFrame(f, bg=PANEL, fg=TEXT,
                                text='  兩站 WA：只對符合女性稱謂／英文名字清單的聯絡人自動打招呼  ',
                                padx=12, pady=7)
        namebox.pack(fill='x', pady=(0, 9))
        nr = tk.Frame(namebox, bg=PANEL); nr.pack(fill='x')
        self._label(nr, '女性英文名 TXT（每行一個，或用逗號分隔）', MUTED).pack(side='left')
        self._btn(nr, '匯入 TXT…', self.import_female_names_txt).pack(side='left', padx=(12, 8))
        self._label(nr, '', GREEN, 10, False, textvariable=self.female_names_status).pack(side='left', padx=6)
        self._label(namebox,
          '同時識別：小姐／女士／姐／Mrs／Ms／Miss。未知、僅姓氏、非名單者不自動發送。名字只作規則匹配，不保證實際性別。',
          MUTED, 9).pack(anchor='w', pady=(6, 0))
        actions = tk.Frame(f, bg=PANEL);actions.pack(fill='x', pady=(9, 4))
        self._btn(actions, '保存全部設定（28 + 730 + WA）', self.save_all_settings,
                  bg='#136e57').pack(side='left', padx=(0, 10))
        self._btn(actions, '匯入舊版 730 去重庫', self.import_730_history).pack(side='left', padx=5)
        self._btn(actions, '打開 730 資料夾', self.open_house_folder).pack(side='left', padx=5)
        self._label(f, '28Hse 原有高優先級抓號引擎與 730 監控引擎各自獨立；此處只合併設定和功能控制。',
                    MUTED).pack(anchor='w', pady=(7, 0))

    def _refresh_browser_note(self):
        if self.browser_type.get() == 'BitBrowser':
            self.browser_note.set('共用 BitBrowser：28Hse 和 House730 均以同一組 Local API / Token / 環境序號連線。')
        else:
            self.browser_note.set('AdsPower 僅支援 28Hse；同時啟用 730 請改選 BitBrowser。')

    def update_28_api_recheck(self):
        self.api_recheck_enabled = bool(self.api_recheck_var.get())
        self.save_config()
        self.write('[API-RECHECK-CONFIG] 28Hse 8秒無成功監察：%s（正常輪次成功則去重，不增加查詢）' %
                   ('啟用' if self.api_recheck_enabled else '停用'))

    def update_low_tab_mode(self):
        self.low_tab_mode = bool(self.low_tab_mode_var.get())
        self.save_config()
        self.write('[TABS] 少分頁模式：' + ('啟用' if self.low_tab_mode else '停用') + '（下次開始監控生效）')

    def _set_female_names_status(self):
        count = len(getattr(self, 'wa_female_name_set', ()))
        label = '已匯入 %s 個（本機 TXT）' if getattr(self, 'female_names_file_loaded', False) else '內建／舊設定 %s 個'
        if not count:
            self.female_names_status.set('名字清單無法讀取；WA 自動發送將略過')
        else:
            self.female_names_status.set(label % format(count, ','))

    def import_female_names_txt(self):
        """Explicit GUI action; validate then replace local allowlist atomically."""
        source = filedialog.askopenfilename(parent=self, title='匯入女性英文名字 TXT',
                   filetypes=[('文字檔', '*.txt'), ('所有檔案', '*.*')])
        if not source:
            return
        try:
            names = read_female_names_txt(source)
            # Persist to original C: configuration folder. Never change seen IDs
            # or delete existing config / WA preferences.
            os.makedirs(self.config_dir, exist_ok=True)
            dest = self.wa_female_names_file
            tmp = dest + '.tmp'
            try:
                with open(tmp, 'w', encoding='utf-8', newline='\n') as fh:
                    fh.write('\n'.join(sorted(names)) + '\n')
                os.replace(tmp, dest)
            finally:
                if os.path.isfile(tmp):
                    os.unlink(tmp)
            self.wa_female_name_set = names
            self.female_names_file_loaded = True
            self._set_female_names_status()
            self.save_config()
            self.write('[WA-NAME-TXT] 已匯入 %d 個不同英文名，兩站即時生效；原有去重庫不變' % len(names))
            messagebox.showinfo('女性英文名 TXT', '成功匯入 %s 個不同名字。\n兩站 WA 篩選已更新。' % format(len(names), ','), parent=self)
        except (ValueError, OSError) as exc:
            messagebox.showerror('匯入失敗（舊清單未改動）', str(exc), parent=self)

    def update_female_names(self, show_error=False):
        # Deliberately avoid reparsing an old 150-name Entry on every Save/Start.
        # The TXT allowlist is precompiled into a frozenset for O(1) lookups.
        if self.wa_female_name_set:
            return True
        if show_error:
            messagebox.showerror('WA 女性名字清單',
                '目前名字清單為空或損壞。請先匯入有效 TXT。', parent=self)
        return False

    def _wa_test_url_for(self, site, deal=None):
        raw = self.wa_test_property_url.get().strip()
        if not raw: return ''
        if site == '730':
            key = listing_key(raw)
            if not key or key[0] != deal:
                raise ValueError('指定 WA 測試網址必須是 730 %s盤房源' % deal)
        elif not (raw.startswith('https://www.28hse.com/') or raw.startswith('https://28hse.com/')) or not self.pid_of(raw):
            raise ValueError('指定 WA 測試網址必須是有效 28Hse 房源')
        return raw

    def _wa_verified_name(self, name, url, phone, *, row_id=None):
        """Only an eligible API contact or phone-associated public name may pass.

        Runs exclusively in background WA thread, after phone was displayed and
        clipboard handled. Unknown persons remain blocked; no message sent.
        """
        candidate = str(name or '未知').strip()
        ok, reason = female_name_eligible(candidate, self.wa_female_name_set)
        if ok or reason == '有男性稱謂':
            self.write('[WA56-NAME-SOURCE] %s · %s · %s' % (
                url, '已符合條件' if ok else '男性稱謂排除', str(reason)))
            return candidate
        if not self.cdp_base: return candidate
        recovered, evidence = recover_public_contact(self.cdp_base, url, phone)
        if recovered:
            eligible, _ = female_name_eligible(recovered,self.wa_female_name_set)
            if eligible:
                self.write('[WA-NAME-VERIFIED] %s · %s · %s' % (url,recovered,evidence))
                if row_id: self.update_row_field(row_id,2,recovered)
                return recovered
        self.write('[WA-NAME-UNCONFIRMED] %s · %s；未能核對對應號碼姓名，不發送' % (url, str(evidence)[:90]))
        return candidate

    def _wa_female_gate(self, name, url='', row_id=None):
        ok, reason = female_name_eligible(name, self.wa_female_name_set)
        if ok:
            self.write('[WA56-ELIGIBLE] %s · 姓名=%s · %s' % (
                url, str(name or '未知')[:45], reason))
        if not ok:
            if row_id:
                self.update_row_field(row_id, 3, '未發送：' + reason)
            self.write('[WA-FEMALE-SKIP] %s · 姓名=%s · %s' %
                       (url, str(name or '未知')[:55], reason))
        return ok

    def note_wa_contact(self, url, name, final=False):
        with self._wa_name_lock:
            record = self._wa_name_info.get(url)
            if record is None:
                record = {'name': '未知', 'ready': threading.Event()}
                self._wa_name_info[url] = record
            name = str(name or '未知').strip() or '未知'
            if name not in ('未知', '未提供', '补充中…', '補充中…'):
                record['name'] = name
                record['ready'].set()
            elif final:
                record['ready'].set()
            # Keep this cache bounded for long-lived processes.
            if len(self._wa_name_info) > 1600:
                for old_key in list(self._wa_name_info)[:300]:
                    if old_key != url:
                        self._wa_name_info.pop(old_key, None)

    def note_wa_phone_contact(self, url, phone, name):
        """Associate a contact name with its exact phone, never property-wide."""
        key = (str(url), re.sub(r'\D','',str(phone or ''))[-8:])
        name = str(name or '').strip()
        if len(key[1]) == 8 and name not in ('', '未知', '未提供', '补充中…', '補充中…'):
            with self._wa_name_lock:
                self._wa_phone_info[key] = name
                if len(self._wa_phone_info) > 1600:
                    for old in list(self._wa_phone_info)[:300]:
                        self._wa_phone_info.pop(old, None)

    def _wait_28_wa_phone_name(self, url, phone, seconds=8.0):
        """Wait on backfill, but trust only a name explicitly tied to this phone.

        Site-wide contact label could describe a different person on multi-phone
        listings. Unknown gets a public phone-matching recovery attempt instead.
        """
        key = (str(url), re.sub(r'\D','',str(phone or ''))[-8:])
        with self._wa_name_lock:
            contact = self._wa_phone_info.get(key)
        if contact: return contact
        self._wait_28_wa_name(url, seconds=seconds)
        with self._wa_name_lock:
            return self._wa_phone_info.get(key, '未知')

    def _wait_28_wa_name(self, url, seconds=8.0):
        with self._wa_name_lock:
            record = self._wa_name_info.get(url)
            if record is None:
                record = {'name': '未知', 'ready': threading.Event()}
                self._wa_name_info[url] = record
            event = record['ready']
        event.wait(seconds)
        with self._wa_name_lock:
            return str(record.get('name') or '未知')

    def update_28_api_interval(self, k, show_error=False):
        """Commit editable seconds from Tk; workers only see committed floats."""
        var = self.api_rent_interval if k == 'rent' else self.api_buy_interval
        label = '租盤' if k == 'rent' else '售盤'
        old_value = self.api_poll_seconds[k]
        try:
            value = parse_api_cadence(var.get())
        except ValueError as exc:
            var.set(display_api_cadence(old_value))
            self.write('[API-CADENCE-INVALID] 28Hse %s · %s；已恢復上次有效值' % (label, exc))
            if show_error:
                messagebox.showerror('28Hse API 查詢間隔', str(exc), parent=self)
            return False
        var.set(display_api_cadence(value))
        if value == old_value:
            return True
        self.api_poll_seconds[k] = value
        self.api_adaptive_scheduler.set_user_floor(min(self.api_poll_seconds.values()))
        if not self.save_config():
            self.write('[API-CADENCE] 28Hse %s · 設定未能保存到磁碟' % label)
        self.write('[API-CADENCE] 28Hse %s · %dms + 每輪隨機100–300ms；下輪生效，429則自動重試' %
                   (label, round(value * 1000)))
        return True

    def _commit_28_api_intervals(self, show_error=False):
        """Commit text still focused when Save or Start is pressed."""
        return (self.update_28_api_interval('rent', show_error=show_error)
                and self.update_28_api_interval('buy', show_error=show_error))

    def save_all_settings(self):
        if not self._commit_28_api_intervals(show_error=True):
            return False
        if not self.update_female_names(show_error=True):
            return False
        if (self._has_730() and self.browser_type.get() != 'BitBrowser'):
            messagebox.showerror('瀏覽器設定', '28Hse + 730 同時使用時請選 BitBrowser；AdsPower 只可用於 28Hse。', parent=self)
            return False
        if not self.save_house_settings(quiet=True) or not self.save_config():
            messagebox.showerror('保存失敗', '請檢查 BitBrowser Local API、環境號、時間與目標間隔。', parent=self)
            return False
        messagebox.showinfo('已保存', '共用連線與 WhatsApp 設定已保存。', parent=self)
        return True

    def test_28_wa(self):
        if not messagebox.askyesno('28Hse WA 實際發送測試',
               '此測試會揭號，僅當姓名符合女性稱謂／名字清單才實際發送 WA。是否繼續？', parent=self):
            return
        try:
            self.wa_test_selected_url = self._wa_test_url_for('28')
        except ValueError as exc:
            messagebox.showerror('WA 測試網址',str(exc),parent=self);return
        self.bg(self.whatsapp_test)

    def test_730(self, deal, greeting=False):
        enabled = self.house_rent.get() if deal == '租' else self.house_buy.get()
        if not enabled:
            messagebox.showinfo('730 API 取號測試', '請先勾選 730 %s盤來源。' % deal, parent=self)
            return
        if not self._house_alive():
            messagebox.showinfo('730 API 取號測試', '請先開始 730 監控，才可用當前列表前3帖測試 API 取號。', parent=self)
            return
        try:
            selected = self._wa_test_url_for('730', deal) if greeting else ''
        except ValueError as exc:
            messagebox.showerror('WA 測試網址',str(exc),parent=self);return
        self.house_engine.test_first(deal, greeting=greeting, listing_url=selected)
        self.write('[730-TEST] 已要求測試%s盤首帖；測試不寫入去重庫%s' %
                   (deal, '；測試會實際發送 WA' if greeting else ''))

    def test_730_wa(self, deal='租'):
        enabled = self.house_rent.get() if deal == '租' else self.house_buy.get()
        if not enabled:
            messagebox.showinfo('730 WA 測試', '請先勾選 730 %s盤來源。' % deal, parent=self)
            return
        if not self._house_alive():
            messagebox.showinfo('730 WA 測試', '請先啟動 730 監控。', parent=self)
            return
        if not messagebox.askyesno('730 WA 實際發送測試',
                  '此測試只會向姓名符合女性稱謂／名字清單的 730 %s盤聯絡人發送 WhatsApp。確認繼續？' % deal, parent=self):
            return
        self.test_730(deal, greeting=True)

    def _house_test_wa_job(self, phone, url, contact='未提供'):
        contact = self._wa_verified_name(contact,url,phone)
        if not self._wa_female_gate(contact, url):
            self.test_popup('730 WA 測試略過', False,
                            '聯絡人姓名未命中女性稱謂／名字清單，未發送訊息')
            return
        try:
            if not self.cdp_base:
                self.connect_browser()
            if not self.cdp_base:
                self.test_popup('730 WA 發送測試', False, 'BitBrowser CDP 未連線')
                return
            with self._wa_730_lock:
                ok, msg = self.whatsapp_send(phone, url, message=self.wa_730_text.get())
            self.test_popup('730 WA 發送測試', ok, ('電話：' + phone + '｜' + str(msg)))
        except Exception as exc:
            self.test_popup('730 WA 發送測試', False, str(exc))

    def _change_topmost(self):
        self.attributes('-topmost', bool(self.main_topmost.get()))

    def save_config(self):
        """Retain all 28Hse keys and add WA source scopes to the same config."""
        ok = super().save_config()
        if not ok or not hasattr(self, 'wa_730_enable'):
            return ok
        try:
            with open(self.config_path, 'r', encoding='utf-8') as fh:
                data = json.load(fh)
            # Discard obsolete messaging integration keys, preserve WA and API settings.
            for key in list(data):
                if key.startswith('signal_'):
                    del data[key]
            data['wa_730_enable'] = bool(self.wa_730_enable.get())
            data['wa_730_start'] = self.wa_730_start.get().strip()
            data['wa_730_end'] = self.wa_730_end.get().strip()
            data['wa_730_text'] = self.wa_730_text.get()
            data['api_recheck_8s_enabled'] = bool(self.api_recheck_enabled)
            data['low_tab_mode'] = bool(getattr(self, 'low_tab_mode', True))
            # Keep old short config value for migration, but the large TXT
            # never goes into config.json (avoids large writes on every save).
            if self.female_names_file_loaded:
                data['wa_female_names_file'] = self.wa_female_names_file
            if hasattr(self, 'api_rent_interval'):
                # Save only validated/committed intervals, never in-progress text.
                data['api_rent_interval'] = display_api_cadence(self.api_poll_seconds['rent'])
                data['api_buy_interval'] = display_api_cadence(self.api_poll_seconds['buy'])
            tmp = self.config_path + '.merged.tmp'
            with open(tmp, 'w', encoding='utf-8') as fh:
                json.dump(data, fh, ensure_ascii=False, indent=2)
            os.replace(tmp, self.config_path)
        except Exception as exc:
            self.write('[CONFIG] WA 來源設定保存失敗: ' + str(exc))
            return False
        return True

    def maybe_whatsapp(self, phone, url, source, row_id=None):
        """Conservative female-name check, after PhoneFirst, before ANY WA send."""
        if not self.wa_enable.get():
            self.update_row_field(row_id, 3, '未啟用')
            self.write('[WA56-SKIP] 28Hse · WA 未啟用 · ' + str(url))
            return
        # Eligibility belongs to detection time, not to the end of a slow
        # name/phone backfill or the follow-on base-class check.
        if not self.in_wa_window():
            self.update_row_field(row_id, 3, '時段外')
            self.write('[WA56-SKIP] 28Hse · 時段外 · ' + str(url))
            return
        name = self._wait_28_wa_phone_name(url, phone, seconds=8.0)
        name = self._wa_verified_name(name,url,phone,row_id=row_id)
        if not self._wa_female_gate(name, url, row_id):
            return
        return super().maybe_whatsapp(phone, url, source, row_id, window_approved=True)

    def maybe_whatsapp_contact(self, phone, url, source, row_id, contact_name):
        """WA for a second public phone tied to its *own* contact name.

        Unlike maybe_whatsapp(), this cannot consult property-level name cache:
        another person in the same listing could be a man. This is reached
        only after the first phone was copied and the secondary UI row exists.
        """
        if not self.wa_enable.get():
            self.update_row_field(row_id, 3, '未啟用')
            return
        if not self.in_wa_window():
            self.update_row_field(row_id, 3, '時段外')
            return
        contact_name = self._wa_verified_name(contact_name,url,phone,row_id=row_id)
        if not self._wa_female_gate(contact_name, url, row_id):
            return
        return super().maybe_whatsapp(phone, url, source, row_id, window_approved=True)

    def manual_whatsapp_send(self, phone, url, source, row_id=None):
        """Even explicit WA tests must not send to an unverified contact name."""
        name = self._wait_28_wa_phone_name(url, phone, seconds=8.0)
        name = self._wa_verified_name(name,url,phone,row_id=row_id)
        if not self._wa_female_gate(name, url, row_id):
            self.test_popup('WhatsApp 測試略過', False,
                            '聯絡人姓名未命中女性稱謂／名字清單，未發送訊息')
            return
        return super().manual_whatsapp_send(phone, url, source, row_id)

    def update_row_field(self, iid, index, value):
        """Persist 730 WA status as well as updating the shared result row."""
        if iid and str(iid).startswith('house:') and index == 3:
            row = self.house_rows.get(iid)
            if row:
                self.house_store.set_wa(row['deal'], row['pid'], str(value))
                row['wa_status'] = str(value)
        return super().update_row_field(iid, index, value)

    def _house_in_wa_window(self):
        if not self.wa_730_enable.get():
            return False
        begin = self._parse_hhmm(self.wa_730_start.get())
        finish = self._parse_hhmm(self.wa_730_end.get())
        now = datetime.now().hour * 60 + datetime.now().minute
        return (True if begin == finish else
                begin <= now < finish if begin < finish else
                (now >= begin or now < finish))

    def _house_wa_job(self, phone, url, row_id, contact='未提供', window_approved=None):
        """Send 730 greeting using *only* 730's window and message."""
        if not self.wa_730_enable.get():
            self.update_row_field(row_id, 3, '未啟用（730）')
            self.write('[WA56-SKIP] 730 · WA 未啟用 · ' + str(url))
            return
        if window_approved is None:
            window_approved = self._house_in_wa_window()
        if not window_approved:
            self.update_row_field(row_id,3,'時段外（730）')
            self.write('[WA56-SKIP] 730 · 時段外 · ' + str(url))
            return
        contact = self._wa_verified_name(contact,url,phone,row_id=row_id)
        if not self._wa_female_gate(contact, url, row_id):
            return
        try:
            # Eligibility was captured at the event time. A slow phone-name
            # recovery must not invalidate that already-approved window.
            if not self.cdp_base:
                self.connect_browser()
            if not self.cdp_base:
                self.update_row_field(row_id, 3, '失敗：瀏覽器未連線')
                return
            key = '%s|%s' % (phone,url)
            with self.lock:
                if key in self.wa_sent:
                    self.update_row_field(row_id, 3, '已處理')
                    return
                self.wa_sent.add(key)
            self.update_row_field(row_id, 3, '發送中')
            with self._wa_730_lock:
                ok, msg = self.whatsapp_send(phone, url, message=self.wa_730_text.get())
            if ok:
                self.update_row_field(row_id, 3, '已發送')
                self.write('[730-WA] 已發送：' + phone)
            elif str(msg).startswith('可能已发送'):
                self.update_row_field(row_id, 3, '待確認')
                self.write('[730-WA] 待確認：' + str(msg))
            else:
                with self.lock:
                    self.wa_sent.discard(key)
                self.update_row_field(row_id, 3, '失敗：' + str(msg)[:40])
                self.write('[730-WA] 失敗：' + str(msg))
        except Exception as exc:
            self.update_row_field(row_id, 3, '失敗：' + str(exc)[:40])
            self.write('[730-WA] ' + str(exc))

    def save_28_settings(self):
        return self.save_all_settings()

    def update_house_interval(self, show_error=False):
        """Commit typed 730 cadence without changing other settings."""
        try:
            value = parse_house730_cadence(self.house_interval.get())
            self.house_cfg['poll_seconds'] = value
            save_config(self.house_cfg)
            self.house_interval.set(display_house730_cadence(value))
            if self._house_alive():
                self.house_engine.update_poll_seconds(value)
            return True
        except ValueError as exc:
            if show_error:
                messagebox.showerror('730 JSON 間隔錯誤', str(exc), parent=self)
            return False

    def save_house_settings(self, quiet=False):
        try:
            seq = int(self.house_seq.get())
            if seq < 1: raise ValueError('BitBrowser 環境序號必須是正整數')
            url = self.house_api.get().strip()
            if not (url.startswith('http://127.0.0.1:') or url.startswith('http://localhost:')):
                raise ValueError('730 Local API 必須是 127.0.0.1 或 localhost')
            interval = parse_house730_cadence(self.house_interval.get())
            self.house_cfg.update({'bitbrowser_seq': seq, 'bitbrowser_api_url': url,
                                   'rent_enabled': self.house_rent.get(),
                                   'buy_enabled': self.house_buy.get(),
                                   'poll_seconds': interval,
                                   'cloudflare_protection': bool(self.house_cf_protection.get()),
                                   'popup_enabled': self.house_popup.get(),
                                   'topmost': self.main_topmost.get()})
            save_config(self.house_cfg)
            if self._house_alive():
                # Poll cadence is read at each cycle in the child; changing it
                # needs neither a browser restart nor interrupting 28Hse.
                self.house_engine.update_poll_seconds(interval)
            TOKEN_PATH.write_text(self.house_token.get().strip(), encoding='utf-8')
            try: os.chmod(TOKEN_PATH, 0o600)
            except OSError: pass
            if not quiet:
                messagebox.showinfo('已儲存', 'House730 設定已保存。', parent=self)
            return True
        except Exception as exc:
            if not quiet:
                messagebox.showerror('730 設定錯誤', str(exc), parent=self)
            return False

    def show_730_verification(self, deal):
        if self._house_alive():
            self.house_engine.show_verification(deal)
        else:
            messagebox.showinfo('House730 驗證', '請先開始監控，再打開 BitBrowser 173 的租盤／售盤分頁。', parent=self)

    def _has_730(self):
        return bool(self.house_rent.get() or self.house_buy.get())

    def _house_alive(self):
        e = getattr(self, 'house_engine', None)
        return bool(e and e.is_alive())

    def _start_house_process(self):
        if not self._house_launch_pending:
            return
        self._house_launch_pending = False
        cfg = dict(self.house_cfg)
        # Runtime-only (not stored in any configuration).  If 28 and 730 run
        # together inside profile 173, 730 prefers a browser-session native
        # APIRequestContext for LIST requests to avoid CDP Runtime contention.
        cfg['shared_28_active'] = bool(self.running and
                         any(self.api_source_enabled.get(k, False) for k in ('rent','buy')))
        if cfg['shared_28_active']:
            self.write('[730-CDP-ISOLATION] 28與730同開：730列表優先獨立HTTP通道（共用現有會話），失敗自動恢復原瀏覽器查詢；不變更設定')
        if self.cdp_base and self.browser_type.get() == 'BitBrowser' and self._cdp_base_alive():
            cfg['shared_cdp_endpoint'] = self.cdp_base
            self.write('[PERF] 730 將重用 28Hse 已連接的 CDP 端口；不再次調用 /browser/open')
        self.house_engine = House730Process(cfg=cfg, store=self.house_store)
        try:
            self.house_engine.start()
            self.write('[PERF] 28Hse 優先線程；House730 獨立 Python 子程序已啟動')
        except Exception as exc:
            self._house_launch_pending = False
            self.write('[730-ERROR] 獨立監控子程序啟動失敗：' + str(exc))
        self.set_monitor_controls(True)

    def _wait_for_28_cdp(self, serial, deadline):
        if serial != self._house_launch_serial or not self._house_launch_pending:
            return
        if self.cdp_base and self._cdp_base_alive():
            selected = [k for k in ('rent','buy') if self.api_source_enabled.get(k, False)]
            events = getattr(self, 'api_capture_ready', {})
            verified = all(events.get(k) and events[k].is_set() for k in selected)
            paused = any(self.api_paused.get(k) for k in selected)
            if verified or paused or time.monotonic() >= deadline:
                if not verified:
                    self.write('[PERF] 28Hse API尚未全部驗證或已暫停；放行730獨立監控，不長期等待')
                self._start_house_process()
            else:
                self.after(300, lambda: self._wait_for_28_cdp(serial, deadline))
        elif not self.running or time.monotonic() >= deadline:
            # Never hand an obsolete CDP endpoint to the 730 subprocess.
            self.write('[28-OFFLINE] 28Hse CDP 未連線；730 可獨立嘗試啟動，但28租／售目前沒有監控')
            self.cdp_base = None
            self._start_house_process()
        else:
            self.after(250, lambda: self._wait_for_28_cdp(serial, deadline))

    def start(self):
        if self.running or self._house_alive() or self._house_launch_pending:
            return
        if self.site_manager and any(t.is_alive() for t in self.site_manager.threads):
            messagebox.showwarning('網站程序正在結束', '上一輪網站程序尚未結束，請等約 10 秒後再開始。', parent=self)
            return
        use28 = self.rent.get() or self.buy.get()
        use730 = self._has_730()
        useextra = any(v.get('enabled') for v in self.extra_sites)
        if not (use28 or use730 or useextra):
            messagebox.showwarning('沒有監控來源', '請至少勾選一個來源。', parent=self)
            return
        if use730 and self.browser_type.get() != 'BitBrowser':
            messagebox.showerror('共用瀏覽器', 'House730 需要 BitBrowser。請在「統一設定」選擇 BitBrowser（可共用 173）。', parent=self)
            self.tabs.select(2)
            return
        if use730 and not self.save_house_settings(quiet=True):
            messagebox.showerror('730 設定錯誤', '請檢查 730 API、環境號及查詢間隔。', parent=self)
            self.tabs.select(2)
            return
        # Ensure saved/user-selected rates are visible to both 28Hse workers
        # before bootstrap launches any threads.
        if not self._commit_28_api_intervals(show_error=True):
            return
        if not self.update_female_names(show_error=True):
            return
        self.save_config()
        if self.wa_enable.get() or self.wa_730_enable.get():
            try:
                if self.wa_enable.get():
                    self._parse_hhmm(self.wa_start.get())
                    self._parse_hhmm(self.wa_end.get())
                if self.wa_730_enable.get():
                    self._parse_hhmm(self.wa_730_start.get())
                    self._parse_hhmm(self.wa_730_end.get())
            except ValueError as exc:
                messagebox.showerror('WA 時間錯誤', str(exc), parent=self)
                return
        if use730 and self.house_engine and self.house_engine.alive_process_even_if_stopping():
            messagebox.showwarning('730 正在結束', '上一輪 House730 子程序尚未完全退出，請稍候再按開始。', parent=self)
            return
        if use28:
            super().start()  # preserved 28 bootstrap / warm CDP / WA scheduling
            if not self.running:  # WA settings failed validation, don't start 730 silently
                return
        if use730:
            self._house_launch_serial += 1
            self._house_launch_pending = True
            if use28:
                self.write('[PERF] 等待 28Hse CDP 端口实际可用，再让 730 附加；不会使用旧端口')
                self._wait_for_28_cdp(self._house_launch_serial, time.monotonic() + 35.0)
            else:
                self._start_house_process()
        if useextra:
            # Site plugins (notably a BitBrowser-backed SG adapter) may also
            # open CDP contexts. Allow the two 28Hse owner-locked API learners
            # a short head start before launching any extra-site workers.
            # Never stall Tk or defer plugin-only mode.
            target_run_id = self.run_id
            wait_until = time.monotonic() + 2.5
            def start_extra_sites():
                if use28 and (not self.running or self.run_id != target_run_id):
                    return  # Stop/Start invalidated this pending launch.
                if use28 and time.monotonic() < wait_until:
                    self.after(250, start_extra_sites)
                    return
                if self.site_manager and any(t.is_alive() for t in self.site_manager.threads):
                    self.write('[SITE] 上一次插件程序尚未完成關閉，本輪暫不重啟插件；28/730不受影響')
                    return
                self.site_manager = SiteManager(self.site_store)
                self.site_manager.start(self._site_runtime_configs())
                self.write('[SITE] 已啟動 %s 個新增網站獨立監控程序' % sum(v['enabled'] for v in self.extra_sites))
            if use28:
                self.write('[CDP-STARTUP] 插件延後2.5秒初始化；使用BitBrowser的插件必須等28 API驗證通過再連CDP')
                self.after(250, start_extra_sites)
            else:
                start_extra_sites()
        self.set_monitor_controls(True)

    def stop(self):
        if self.site_manager: self.site_manager.halt()
        self._house_launch_serial += 1
        self._house_launch_pending = False
        if self.running:
            super().stop()
        if self.house_engine:
            self.house_engine.halt()
        self.api_pause_banner.set('監控已手動停止；不會自行重啟28Hse')
        self.set_monitor_controls(False)

    def bg(self, fn, *args):
        """28Hse detection and phone lanes get mild Windows priority boost.

        730 is a different OS process, preventing Python-GIL contention.  This
        avoids a global process HIGH_PRIORITY_CLASS that could starve Chrome.
        """
        if getattr(fn, '__name__', '') in ('phone_worker', 'worker', 'cdp_fallback_worker'):
            return launch_worker(fn, args)
        return super().bg(fn, *args)

    def on_28_api_reset(self):
        # Explicit Start/Restart is the only way to clear a 429 stop.
        def ui():
            if not self.winfo_exists(): return
            self.api_pause_banner.set('28Hse：依輸入間隔＋100–300ms；429等候結束後自動重試')
            self.card_28r.set('啟動中' if self.rent.get() else '未啟用')
            self.card_28b.set('啟動中' if self.buy.get() else '未啟用')
        self.after(0, ui)

    def on_28_api_cooldown(self, source, seconds):
        # Worker -> Tk queue; 730 continues independently.
        def ui():
            if not self.winfo_exists(): return
            self.api_pause_banner.set('28Hse 429 等候中：剩餘約%.1f秒後自動重試；730狀態請看右側卡片' % seconds)
            for k, card, enabled in (('rent', self.card_28r, self.rent.get()),
                                     ('buy', self.card_28b, self.buy.get())):
                if enabled and not self.api_paused.get(k):
                    card.set('429 退避中')
        self.after(0, ui)

    def on_28_api_paused(self, k, reason, extra=''):
        # Called only via Tk's event queue; 28 background threads never touch
        # Tk state. The 730 child process is intentionally left running.
        def ui():
            if not self.winfo_exists(): return
            label='租盤' if k=='rent' else '售盤'
            if reason=='rate':
                headline='HTTP 429｜限流暫停'
                self.api_pause_banner.set(
                    '⚠ 28Hse HTTP 429：租／售暫停；730目前狀態請看右側卡片。')
                self.monitor_state.set('⚠ 28Hse 限流暫停｜730 狀態獨立顯示')
            else:
                headline='暫停：'+str(reason)[:25]
                self.api_pause_banner.set('28Hse '+label+' '+headline+'；請檢查網站，不會自動重試')
            (self.card_28r if k=='rent' else self.card_28b).set(headline)
        self.after(0, ui)

    def set_monitor_controls(self, running):
        def ui():
            # 28Hse sometimes stops due to a browser error while 730 is still running.
            active = bool(self.running or self._house_alive() or self._site_alive())
            rate_paused=self.api_rate_limit_event.is_set()
            self.monitor_state.set('⚠ 28Hse 限流暫停｜730 狀態獨立顯示' if rate_paused and active
                                   else ('● 運行中' if active else '● 已停止'))
            self.start_btn.configure(state='disabled' if active else 'normal')
            self.stop_btn.configure(state='normal' if active else 'disabled')
            pause_names={'rate':'HTTP 429｜限流暫停','challenge':'驗證暫停',
                         'filter':'篩選驗證失敗','learn':'API學習失敗',
                         'invalid-list':'列表異常','invalid-json':'JSON異常'}
            for k,card,selected in (('rent',self.card_28r,self.rent.get()),
                                    ('buy',self.card_28b,self.buy.get())):
                reason=self.api_paused.get(k,'')
                if reason:
                    label = pause_names.get(reason,'暫停：'+reason)
                elif self.running and selected:
                    # Start means threads launched; it does NOT mean API
                    # verified. Avoid the misleading blue "運行中" in GUI.
                    with self.lock:
                        verified = bool(self.http_stats.get(k,{}).get('last_ok'))
                    label = 'API 監控中' if verified else '等待列表 API 驗證'
                else:
                    label = '已停止'
                card.set(label)
        if threading.current_thread() == threading.main_thread(): ui()
        else: self.after(0, ui)

    def _house_tick(self):
        try:
            cooldown = self.api_429_guard.remaining()
            if self.running and cooldown > 0:
                line = '28Hse 429 等候中：約%.1f秒後自動重試（730狀態獨立顯示）' % cooldown
                if self.api_pause_banner.get() != line:
                    self.api_pause_banner.set(line)
                for lane, card, selected in (('rent', self.card_28r, self.rent),
                                             ('buy', self.card_28b, self.buy)):
                    if selected.get() and not self.api_paused.get(lane):
                        card.set('429 退避 %.0fs' % cooldown)
            elif self.running and self.api_429_guard.recovery():
                self.api_pause_banner.set('28Hse 429 已結束：自動恢復設定間隔＋100–300ms')
            elif self.running and self.api_pause_banner.get().startswith(('28Hse 429', '28Hse HTTP 429')):
                self.api_pause_banner.set('28Hse API：按設定間隔＋100–300ms運行')
            # A 28Hse lane is only running once an actual, verified JSON
            # result exists. This also updates the UI after first success.
            if self.running and not self.api_rate_limit_event.is_set() and cooldown <= 0:
                for lane, card, flag in (('rent', self.card_28r, self.rent),
                                         ('buy', self.card_28b, self.buy)):
                    if flag.get() and not self.api_paused.get(lane):
                        with self.lock:
                            verified = bool(self.http_stats.get(lane,{}).get('last_ok'))
                        new_text = 'API 監控中' if verified else '等待列表 API 驗證'
                        if card.get() != new_text:
                            card.set(new_text)
            if self.house_engine:
                for _ in range(100):
                    try: x = self.house_engine.out.get_nowait()
                    except Exception: break
                    event = x.get('event')
                    if event == 'log':
                        self.write('[730] ' + x.get('text', ''))
                    elif event == 'new':
                        self._new_house_result(x.get('data', {}))
                    elif event == 'test_phone':
                        d = x.get('data', {})
                        getattr(self, 'copy_auto_tail_with_defer', lambda raw: self.copy_text(self.normalize_phone(raw)[-4:]))(d.get('phone', ''))
                        if d.get('greeting'):
                            self.bg(self._house_test_wa_job, d.get('phone',''), d.get('url',''), d.get('contact','未提供'))
                        else:
                            self.test_popup('730 %s盤 API 取號測試' % d.get('deal'), True,
                                            '測試電話：%s（尾四位已自動複製；未寫入去重資料庫）' % d.get('phone'))
                    elif event == 'test_error':
                        self.test_popup('730 API 取號測試', False, str(x.get('text','未知錯誤')))
                    elif event == 'source':
                        deal, data = x.get('deal'), x.get('data', {})
                        if deal in self.house_states:
                            self.house_states[deal] = data
                            mode = str(data.get('mode', '—'))
                            if mode == 'html-fallback':
                                mode = 'HTML 每60秒'
                            elif mode == 'api-json':
                                mode = 'JSON 快速'
                            elif mode == 'cloudflare-wait':
                                mode = 'Cloudflare 驗證中｜730 已暫停'
                            elif mode == 'cf-safe-json':
                                mode = 'JSON 保護低頻'
                            elif mode == 'cf-safe-html':
                                mode = 'HTML 保護低頻'
                            elif mode == 'api-relearn':
                                mode = 'JSON 重新學習中'
                            elif mode == 'rate-limited':
                                mode = 'HTTP 429｜本路短等3秒後重試'
                            elif mode == 'api-backoff':
                                mode = '730 API 暫停／恢復中'
                            elif mode == 'transport-retry':
                                mode = '730 連線恢復中'
                            st = mode + '｜' + str(data.get('last', '—'))
                            (self.card_730r if deal == '租' else self.card_730b).set(st)
                            self.house_queries.set('730 列表檢查：%d 次' % sum(
                                s.get('queries', 0) for s in self.house_states.values()))
                            if any(s.get('mode') == 'rate-limited' for s in self.house_states.values()):
                                self.house_status.set('730 HTTP429｜本路短暫重試中')
                            elif self._house_alive():
                                self.house_status.set('730 監控中')
                    elif event == 'challenge':
                        self._show_house_challenge_alert(x)
                    elif event == 'challenge_cleared':
                        self._close_house_challenge_alert()
                    elif event == 'browser':
                        self.house_status.set('730 HTTP429｜本路短暫重試中' if any(s.get('mode') == 'rate-limited' for s in self.house_states.values()) else x.get('label', '730 已連接'))
                    elif event == 'queue':
                        self.house_queue.set('730 待揭號：%s' % x.get('count', 0))
                    elif event == 'fatal':
                        self.house_status.set('730 啟動失敗')
                        self.write('[730-ERROR] ' + x.get('text', '未知錯誤'))
                    elif event == 'running':
                        active = bool(x.get('active'))
                        is_429 = any(s.get('mode') == 'rate-limited' for s in self.house_states.values())
                        self.house_status.set('730 HTTP429｜本路短暫重試中' if active and is_429
                                              else ('730 監控中' if active else '730 已停止'))
                        if not active:
                            self._close_house_challenge_alert()
                            self.set_monitor_controls(False)
                if not self._house_alive():
                    self.set_monitor_controls(False)
            if self.winfo_exists():
                self.after(230, self._house_tick)
        except tk.TclError:
            pass

    def _close_house_challenge_alert(self):
        win = getattr(self, 'house_challenge_popup', None)
        self.house_challenge_popup = None
        if win is not None:
            try:
                if win.winfo_exists(): win.destroy()
            except tk.TclError:
                pass

    def _show_house_challenge_alert(self, event):
        """One non-repeating Windows topmost alert for a 730 challenge episode.

        The engine emits one 'challenge' per global rent/buy pause; this UI
        also deduplicates in case events are delivered twice after reconnect.
        The alert stays until dismissed or the site recovers; no auto-click.
        """
        if getattr(self, 'house_challenge_popup', None) is not None:
            try:
                if self.house_challenge_popup.winfo_exists():
                    self.house_challenge_popup.lift()
                    return
            except tk.TclError:
                pass
        self.house_challenge_incident += 1
        w = tk.Toplevel(self)
        self.house_challenge_popup = w
        w.title('PandaMonitor｜House730 需要驗證')
        w.configure(bg=PANEL)
        w.resizable(False, False)
        try:
            w.attributes('-topmost', True)
        except tk.TclError:
            pass
        w.geometry('440x238')
        self._label(w, '⚠ House730 需要真人驗證', GOLD, 15, True).pack(
            anchor='w', padx=18, pady=(17, 9))
        self._label(w, '730 租盤及售盤已暫停請求；28Hse 繼續運行。', TEXT).pack(
            anchor='w', padx=18)
        reason = str(event.get('reason') or '網站要求驗證').replace('\n',' ')[:85]
        self._label(w, '原因：' + reason, MUTED, 9, wraplength=400, justify='left').pack(
            anchor='w', padx=18, pady=(8, 4))
        self._label(w, '請在 BitBrowser 完成驗證；程式確認列表恢復後會自動續跑。', MUTED,
                    9, wraplength=410, justify='left').pack(anchor='w', padx=18)
        row = tk.Frame(w, bg=PANEL)
        row.pack(fill='x', padx=11, pady=(13, 6))
        self._btn(row, '查看730租盤', lambda: self.show_730_verification('租')).pack(side='left', padx=4)
        self._btn(row, '查看730售盤', lambda: self.show_730_verification('售')).pack(side='left', padx=4)
        self._btn(row, '關閉提醒', self._close_house_challenge_alert).pack(side='right', padx=4)
        w.protocol('WM_DELETE_WINDOW', self._close_house_challenge_alert)
        w.update_idletasks()
        w.geometry('+%d+%d' % (max(0,w.winfo_screenwidth()-470),
                                  max(0,w.winfo_screenheight()-310)))
        try:
            w.bell()
        except tk.TclError:
            pass
        self.write('[730-CF-ALERT] 730驗證中，已顯示 Windows 置頂提醒（每輪只提醒一次）')

    def _new_house_result(self, data):
        phone = phone_key(data.get('phone'))
        if not phone:
            return
        # True hot path: copy the new tail before any Tk row or popup work.
        auto = getattr(self, 'copy_auto_text', None)
        if callable(auto):
            copied = auto(phone[-4:], listing_key=('730', data.get('deal'), data.get('pid')))
        else:  # Old unit-test fakes without the auto clipboard interface.
            copied = self.copy_text(phone[-4:])
        queued = bool(getattr(getattr(self, 'clipboard_error_local', None), 'queued', False))
        self.latest_phone.set(phone)
        self.house_session += 1
        self._show_house_row(data)
        self.write('[730] %s盤 %s：電話 %s，尾四位%s' % (
            data.get('deal'), data.get('pid'), phone,
            ('暫未寫入，重試最新號碼' if queued else ('已複製' if copied else '複製失敗'))))
        if self.house_popup.get():
            self._popup_house(data)
        if self.wa_730_enable.get():
            in_window = self._house_in_wa_window()
            self.bg(self._house_wa_job, phone, data.get('url',''),
                    'house:' + str(data.get('deal')) + ':' + str(data.get('pid')),
                    data.get('contact','未提供'), in_window)
        else:
            self.update_row_field('house:' + str(data.get('deal')) + ':' + str(data.get('pid')),
                                  3, '未啟用')
            self.write('[WA56-SKIP] 730 · WA 未啟用 · ' + str(data.get('url','')))

    def _show_house_row(self, data):
        key = str(data.get('deal')) + ':' + str(data.get('pid'))
        iid = 'house:' + key
        self.house_rows[iid] = dict(data)
        detected = str(data.get('detected_at') or '')
        try:
            detected = datetime.fromisoformat(detected).strftime('%m-%d %H:%M:%S')
        except ValueError:
            pass
        vals = ('730%s盤' % data.get('deal'), data.get('phone', ''),
                data.get('contact', '未提供'), data.get('wa_status', '未聯絡'),
                '打開 ↗', detected, phone_key(data.get('phone'))[-4:], data.get('pid', ''))
        if self.tree.exists(iid): self.tree.item(iid, values=vals)
        else: self.tree.insert('', 0, iid=iid, values=vals)
        self.row_urls[iid] = data.get('url', '')

    def show_28_phone_popup(self, kind, phone, tail, url, test=False):
        """Match House730's dark topmost phone popup; clipboard was handled first."""
        if not self.win_notify.get():
            return
        w = tk.Toplevel(self)
        w.title('28Hse 新業主盤')
        w.configure(bg=PANEL)
        try: w.attributes('-topmost', True)
        except tk.TclError: pass
        w.resizable(False, False)
        w.geometry('350x180')
        deal = '租' if kind == 'rent' else '售'
        suffix = ' · 測試' if test else ''
        self._label(w, '28Hse%s盤 · 新號碼%s' % (deal, suffix), GREEN, 13, True).pack(
            anchor='w', padx=16, pady=(13, 5))
        self._label(w, str(phone), TEXT, 20, True).pack(anchor='w', padx=16)
        self._label(w, '尾四位：'+str(tail), GOLD).pack(anchor='w', padx=16, pady=3)
        buttons=tk.Frame(w,bg=PANEL)
        buttons.pack(fill='x',padx=10,pady=9)
        self._btn(buttons,'複製完整號碼',lambda:self.copy_text(self.normalize_phone(phone))).pack(side='left',padx=4)
        self._btn(buttons,'開原帖',lambda:self._open_url(url)).pack(side='left',padx=4)
        w.update_idletasks()
        sw,sh=w.winfo_screenwidth(),w.winfo_screenheight()
        w.geometry('+%d+%d' % (sw-380,sh-285))
        w.after(8000,lambda:w.destroy() if w.winfo_exists() else None)

    def _popup_house(self, data):
        w = tk.Toplevel(self)
        w.title('House730 新業主盤')
        w.configure(bg=PANEL)
        try: w.attributes('-topmost', True)
        except tk.TclError: pass
        w.resizable(False, False)
        w.geometry('350x180')
        self._label(w, '730%s盤 · 新號碼' % data.get('deal'), GREEN, 13, True).pack(
            anchor='w', padx=16, pady=(13, 5))
        self._label(w, str(data.get('phone', '')), TEXT, 20, True).pack(anchor='w', padx=16)
        self._label(w, '尾四位：' + str(data.get('phone', ''))[-4:], GOLD).pack(
            anchor='w', padx=16, pady=3)
        buttons = tk.Frame(w, bg=PANEL)
        buttons.pack(fill='x', padx=10, pady=9)
        self._btn(buttons, '複製完整號碼',
                  lambda: self.copy_text(self.normalize_phone(data.get('phone', '')))).pack(side='left', padx=4)
        self._btn(buttons, '開原帖',
                  lambda: self._open_url(data.get('url', ''))).pack(side='left', padx=4)
        w.update_idletasks()
        screen_w, screen_h = w.winfo_screenwidth(), w.winfo_screenheight()
        w.geometry('+%d+%d' % (screen_w - 380, screen_h - 285))
        w.after(8000, lambda: w.destroy() if w.winfo_exists() else None)

    def _enrich_rows(self):
        try:
            for iid in self.tree.get_children(''):
                if iid.startswith('house:'):
                    continue
                vals = list(self.tree.item(iid, 'values') or ())
                if len(vals) < 5: continue
                # V1.46.5 always mutates the FIRST five fields only.
                while len(vals) < 8: vals.append('')
                if not vals[5]:
                    vals[5] = self.row_birth.setdefault(iid,
                                  datetime.now().strftime('%m-%d %H:%M:%S'))
                phone = self.normalize_phone(vals[1])
                if len(phone) >= 8:
                    vals[6] = phone[-4:]
                if not vals[7]:
                    u = self.row_urls.get(iid, '')
                    m = re.search(r'property-(\d+)', u)
                    vals[7] = m.group(1) if m else ''
                if tuple(vals) != tuple(self.tree.item(iid, 'values')):
                    self.tree.item(iid, values=vals)
            self.set_monitor_controls(bool(self.running or self._house_alive() or self._site_alive()))
            if self.winfo_exists(): self.after(500, self._enrich_rows)
        except tk.TclError:
            pass

    def on_tree_click(self, event):
        try:
            iid = self.tree.identify_row(event.y)
            col = self.tree.identify_column(event.x)
            if iid and col == '#8':
                self.tree.selection_set(iid)
                self.open_selected()
            elif iid and col == '#6':
                self.tree.selection_set(iid)
                self.toggle_house_wa()
        except Exception as e:
            self.write('[UI] 列表點擊失敗：' + str(e))

    def on_tree_double_click(self, event):
        iid = self.tree.identify_row(event.y)
        col = self.tree.identify_column(event.x)
        if not iid: return
        self.tree.selection_set(iid)
        if col == '#8': self.open_selected()
        elif col == '#6': self.toggle_house_wa()
        else: self.copy(False)

    def right_click(self, event):
        iid = self.tree.identify_row(event.y)
        if not iid: return
        self.tree.selection_set(iid)
        menu = tk.Menu(self, tearoff=0, bg=PANEL2, fg=TEXT)
        menu.add_command(label='複製完整電話', command=lambda: self.copy(False))
        menu.add_command(label='打開原帖', command=self.open_selected)
        menu.add_command(label='更改 WA 狀態', command=self.toggle_house_wa)
        menu.tk_popup(event.x_root, event.y_root)
        menu.grab_release()

    def open_selected(self):
        s = self.tree.selection()
        if not s: return
        iid = s[0]
        self._open_url(self.row_urls.get(iid, ''), iid)

    def _open_url(self, url, iid=None):
        if not url: return
        if listing_key(url):
            if self._house_alive():
                self.house_engine.open_original(url)
            else:
                self.write('[730] 監控已停止，請先開始監控後在 BitBrowser 開啟原帖')
        elif '28hse.com' in url:
            self.bg(self.open_original_post, url)
        else:
            webbrowser.open(url)

    def toggle_house_wa(self):
        """One WA status interaction for both 28 and 730 rows."""
        s = self.tree.selection()
        if not s: return
        iid = s[0]
        v = list(self.tree.item(iid, 'values') or ())
        if len(v) < 4: return
        statuses = ('未聯絡', '已聯絡', '不聯絡')
        current = str(v[3])
        next_status = statuses[(statuses.index(current) + 1) % 3] if current in statuses else '已聯絡'
        if iid.startswith('house:'):
            row = self.house_rows.get(iid)
            if not row or not self.house_store.set_wa(row['deal'], row['pid'], next_status): return
            row['wa_status'] = next_status
        v[3] = next_status
        self.tree.item(iid, values=v)

    def _load_house_history(self):
        for row in reversed(self.house_store.rows(limit=500)):
            self._show_house_row(row)

    def _load_28_history(self):
        # Before v1.50.47, 28Hse wrote only anonymous numbers to
        # seen_phones.json. Those numbers cannot be assigned to 28Hse or 730.
        try:
            entries = self.hse28_history.rows(limit=500)
            for item in reversed(entries):
                kind, pid = item['kind'], item['pid']
                iid = 'hse28-history:' + str(item['id'])
                phone = item['phone']
                extra = bool(item['is_extra'])
                source = ('28租盘' if kind == 'rent' else '28售盘') + (' · 附加号码' if extra else '')
                try:
                    when = datetime.fromisoformat(item['detected_at']).strftime('%m-%d %H:%M:%S')
                except (TypeError, ValueError):
                    when = str(item['detected_at'])[:19]
                vals = (source,phone,item['contact'],item['wa_status'],'打開 ↗',when,phone[-4:],pid)
                if not self.tree.exists(iid):
                    self.tree.insert('', 0, iid=iid, values=vals)
                self.row_urls[iid] = item['url']
                if not extra:
                    self.listing_rows[(kind, pid)] = iid
            self.write('[28-HISTORY-READY] 已還原 %d 筆28Hse歷史；獨立SQLite=%s；舊seen_phones.json只負責去重' %
                       (len(entries), self.hse28_history.path))
        except Exception as exc:
            self.write('[28-HISTORY-ERROR] 28Hse歷史載入失敗：%s' % str(exc)[:170])

    def _28_history_saved(self, kind, url, phone, name, extra=False):
        try:
            return self.hse28_history.save(kind, url, phone, name, is_extra=extra)
        except Exception as exc:
            self.write('[28-HISTORY-ERROR] 寫入歷史失敗：%s' % str(exc)[:170])
            return False

    def result(self, k, n, p, u, test_mode=False, wa_test=False,
               race_t0=None, extra_phones=()):
        # The superclass must keep clipboard-first, dedup and phone extraction.
        ret = super().result(k, n, p, u, test_mode=test_mode,
                             wa_test=wa_test, race_t0=race_t0,
                             extra_phones=extra_phones)
        if '_wa_phone_info' in self.__dict__:
            self.note_wa_phone_contact(u, p, n)
        if not test_mode and not wa_test and ret[0]:
            self._28_history_saved(k, u, p, n)
        return ret

    def publish_secondary_phone(self, k, url, name, phone):
        ok = super().publish_secondary_phone(k, url, name, phone)
        if ok:
            self._28_history_saved(k, url, phone, name, extra=True)
        return ok

    def set_listing_contact_name(self, k, url, name):
        super().set_listing_contact_name(k, url, name)
        if hasattr(self, 'hse28_history'):
            try: self.hse28_history.update_contact(k, url, name)
            except Exception as exc: self.write('[28-HISTORY-ERROR] 聯絡人更新失敗：%s' % str(exc)[:120])

    def update_row_field(self, iid, index, value):
        super().update_row_field(iid, index, value)
        # Schedule after the superclass UI mutation; never touch Tk from worker threads.
        if not iid or index not in (2,3) or not hasattr(self, 'hse28_history'):
            return
        def sync():
            if not self.tree.exists(iid): return
            row=self.tree.item(iid,'values') or ()
            if len(row)<3 or not str(row[0]).startswith(('28租盘','28售盘')): return
            kind='rent' if str(row[0]).startswith('28租盘') else 'buy'
            url=self.row_urls.get(iid,'')
            try:
                if index==2: self.hse28_history.update_contact(kind,url,row[2],row[1])
                elif len(row)>3: self.hse28_history.update_wa(kind,url,row[1],row[3])
            except Exception as exc: self.write('[28-HISTORY-ERROR] 更新歷史失敗：%s' % str(exc)[:120])
        self.after(0, sync)

    def import_730_history(self):
        try:
            summary = self.house_store.import_legacy(OLD_DB_PATH)
            with self.phone_lock:
                self.seen_phones.update(self.house_store.all_phones())
            self.bg(self.save_seen_phones_deferred)
            self._load_house_history()
            messagebox.showinfo('匯入完成', '已匯入 730 舊版記錄：%s' % summary, parent=self)
        except Exception as exc:
            messagebox.showerror('匯入失敗', str(exc), parent=self)

    def open_house_folder(self):
        if os.name == 'nt':
            os.startfile(str(APP_DIR))
        else:
            messagebox.showinfo('House730 資料夾', str(APP_DIR), parent=self)

    def on_close(self):
        self._user_requested_close = True
        self._house_launch_serial += 1
        self._house_launch_pending = False
        if self.house_engine:
            self.house_engine.halt()
        if self.site_manager: self.site_manager.halt()
        self.save_house_settings(quiet=True)
        super().on_close()

    def copy(self, tail=False):
        """Preserve 28Hse `copy()` behavior; both sites use index 1 for phone."""
        selection = self.tree.selection()
        if not selection: return
        vals = self.tree.item(selection[0], 'values')
        p = self.normalize_phone(vals[1] if len(vals) > 1 else '')
        if p:
            self.copy_text(p)



    # ---------------- V1.50 optional sites UI and event handling ----------------
    def _site_runtime_configs(self):
        configs=[]
        for cfg in self.extra_sites:
            item=dict(cfg)
            if cfg.get('mode')=='bitbrowser':
                item['bitbrowser_api_url']=self.bit_api.get().strip()
                item['bitbrowser_api_token']=self.bit_key.get().strip()
                # Only re-use 28Hse's CDP when the target seq is identical.
                if (self.browser_type.get()=='BitBrowser' and self.cdp_base
                    and self._cdp_base_alive()
                    and str(cfg.get('bitbrowser_seq',173)) == self.bit_no.get().strip()):
                    item['shared_cdp_endpoint']=self.cdp_base
                    if self.running:
                        selected = [k for k in ('rent','buy') if self.api_source_enabled.get(k, False)]
                        item['_startup_api_events'] = [self.api_capture_ready[k] for k in selected
                                                     if k in getattr(self, 'api_capture_ready', {})]
                        item['_startup_selected_lanes'] = selected
                        item['_startup_paused_states'] = self.api_paused
            configs.append(item)
        return configs

    def _site_alive(self):
        return bool(self.site_manager and self.site_manager.is_alive())

    def _build_sites_tab(self, parent):
        top = tk.Frame(parent, bg=PANEL, padx=14, pady=12)
        top.pack(fill='x')
        self._label(top, '新增網站：網址＋CSS 規則，或安裝專用 Python 插件', TEXT, 12, True).pack(anchor='w')
        self._label(top, '插件與配置保存在 C:\\使用者設定資料夾，主程式更新不會清空；新增網站默認關閉', MUTED, 9).pack(anchor='w', pady=(4,0))
        btn = tk.Frame(parent, bg=PANEL, padx=12, pady=8)
        btn.pack(fill='x')
        for title,method in [('＋ 新增網址',lambda:self._edit_site(None)),('編輯設定',self._edit_selected_site),
                             ('啟用／停用',self._toggle_site), ('刪除',self._delete_site),
                             ('測試抓帖',self._test_site),('測試首帖取號',self._test_site_detail),('測試已開帖取號',self._test_site_open_detail),('安裝 .py 插件',self._install_plugin)]:
            self._btn(btn,title,method).pack(side='left', padx=3)
        self.extra_tree = ttk.Treeview(parent, show='headings', style='Dark.Treeview',
                                       columns=('name','url','plugin','interval','status'), selectmode='browse')
        widths = {'name':190,'url':460,'plugin':160,'interval':90,'status':170}
        labels = {'name':'網站名稱','url':'列表 URL','plugin':'模式／插件','interval':'刷新（秒）','status':'狀態'}
        for c in widths:
            self.extra_tree.heading(c,text=labels[c]); self.extra_tree.column(c,width=widths[c],anchor='w',stretch=c=='url')
        self.extra_tree.pack(fill='both',expand=True,padx=12,pady=9)
        self._label(parent, '首次建立基線，不報舊帖。測試首帖＝列表第一條；測試已開帖＝BitBrowser 中已開的賣家詳情。', MUTED, 9).pack(anchor='w',padx=16,pady=5)
        self._reload_sites_list()

    def _reload_sites_list(self):
        if not hasattr(self,'extra_tree'): return
        for iid in self.extra_tree.get_children(''): self.extra_tree.delete(iid)
        for s in self.extra_sites:
            status = self.site_states.get(s['id'], '已啟用｜待開始' if s['enabled'] else '已停用')
            self.extra_tree.insert('', 'end', iid=s['id'], values=(s['name'],s['url'],
                                   (s['plugin'] or s['mode'] + ' CSS'), s['interval'], status))

    def _selected_site(self):
        chosen=self.extra_tree.selection()
        return next((s for s in self.extra_sites if chosen and s['id']==chosen[0]), None)

    def _edit_selected_site(self):
        site=self._selected_site()
        if site: self._edit_site(site)

    def _edit_site(self, site):
        win=tk.Toplevel(self); win.title('PandaMonitor｜新增／編輯網站'); win.configure(bg=PANEL)
        win.geometry('790x700'); win.transient(self); win.grab_set()
        form=tk.Frame(win,bg=PANEL,padx=18,pady=12);form.pack(fill='both',expand=True)
        defaults = site or {'name':'','url':'','plugin':'','link_selector':'a[href]', 'href_contains':'',
                            'phone_selector':"a[href^='tel:']",'mode':'http','cdp_endpoint':'','bitbrowser_seq':173,'interval':1,'enabled':False}
        vals = {k:tk.StringVar(value=str(defaults.get(k,''))) for k in
                ('name','url','plugin','link_selector','href_contains','phone_selector','mode','cdp_endpoint','bitbrowser_seq','interval')}
        enable=tk.BooleanVar(value=defaults.get('enabled',False))
        labelmap=[('name','網站顯示名稱'),('url','已篩選的新帖列表網址'),
                  ('plugin','網站插件（留空＝通用 CSS 解析）'),('link_selector','新帖連結 CSS 選擇器'),
                  ('href_contains','連結路徑必須包含（選填）'),('phone_selector','詳情公開電話 CSS 選擇器'),
                  ('mode','監控模式：HTTP、CDP 或 BitBrowser'),('cdp_endpoint','CDP 地址（僅 CDP 模式使用）'),
                  ('bitbrowser_seq','BitBrowser 環境序號（例如 173）'),
                  ('interval','刷新間隔（秒，支援小數，例如 0.5、1、1.25）')]
        for r,(key,label) in enumerate(labelmap):
            tk.Label(form,text=label,bg=PANEL,fg=TEXT).grid(row=r,column=0,sticky='w',padx=(0,12),pady=7)
            if key == 'plugin':
                combo=ttk.Combobox(form,textvariable=vals[key],values=['']+plugin_choices(),width=50)
                combo.grid(row=r,column=1,sticky='ew',pady=7)
            elif key == 'mode':
                combo=ttk.Combobox(form,textvariable=vals[key],values=['http','cdp','bitbrowser'],state='readonly',width=50)
                combo.grid(row=r,column=1,sticky='ew',pady=7)
            else:
                ttk.Entry(form,textvariable=vals[key]).grid(row=r,column=1,sticky='ew',pady=7)
        form.grid_columnconfigure(1,weight=1)
        ttk.Checkbutton(form,text='啟用這個網站',variable=enable,style='Dark.TCheckbutton').grid(row=len(labelmap),column=1,sticky='w',pady=7)
        tk.Label(form,text='BitBrowser 模式連接已啟動的指定環境，讀取手動打開的詳情頁及已顯示電話；不會繞過會員限制或人機驗證。',
                 bg=PANEL,fg=MUTED,wraplength=550,justify='left').grid(row=len(labelmap)+1,column=0,columnspan=2,sticky='w',pady=6)
        def confirm():
            cfg={k:v.get().strip() for k,v in vals.items()}
            cfg['id']=site['id'] if site else 'extra_'+uuid.uuid4().hex[:12]
            cfg['enabled']=bool(enable.get())
            try:
                cfg=validate_site(cfg)
                temp=[s for s in self.extra_sites if s['id']!=cfg['id']]+[cfg]
                self.site_store.save(temp)
                self.extra_sites=temp
            except Exception as exc:
                messagebox.showerror('配置錯誤',str(exc),parent=win); return
            win.destroy(); self._reload_sites_list(); self._reload_running_sites()
        self._btn(form,'保存設定',confirm,bg='#136e57').grid(row=len(labelmap)+2,column=1,sticky='e',pady=9)

    def _toggle_site(self):
        site=self._selected_site()
        if not site: return
        update=[dict(s,enabled=not s['enabled']) if s['id']==site['id'] else s for s in self.extra_sites]
        try: self.site_store.save(update)
        except Exception as ex:
            messagebox.showerror('保存錯誤',str(ex),parent=self);return
        self.extra_sites=update; self._reload_sites_list(); self._reload_running_sites()

    def _delete_site(self):
        site=self._selected_site()
        if not site:return
        if not messagebox.askyesno('刪除網站','刪除監控配置：'+site['name']+'？\n歷史去重記錄會保留。',parent=self):return
        remaining=[s for s in self.extra_sites if s['id']!=site['id']]
        self.site_store.save(remaining);self.extra_sites=remaining
        self._reload_sites_list();self._reload_running_sites()

    def _install_plugin(self):
        f=filedialog.askopenfilename(title='選擇可信任網站插件 .py',filetypes=[('Python 插件','*.py')],parent=self)
        if not f:return
        import re as _re
        name=Path(f).stem
        if not _re.fullmatch(r'[a-zA-Z][a-zA-Z0-9_]{0,63}',name):
            messagebox.showerror('文件名錯誤','請使用英文字母、數字、底線命名插件',parent=self);return
        dest=self.site_store.root/'site_plugins'/(name+'.py')
        if dest.exists() and not messagebox.askyesno('覆蓋插件','已有同名插件。確認覆蓋？',parent=self):return
        try:
            import ast
            ast.parse(Path(f).read_text(encoding='utf-8-sig'))
            shutil.copy2(f,dest)
            self.write('[SITE] 已安裝插件 %s；可在網站編輯器選擇它' % name)
            messagebox.showinfo('安裝完成',str(dest),parent=self)
        except Exception as ex:messagebox.showerror('安裝失敗',str(ex),parent=self)

    def _test_site(self):
        site=self._selected_site()
        if not site:return
        # No persistence / no auto phone reveal or popups on test.
        runtime = next(s for s in self._site_runtime_configs() if s['id']==site['id'])
        def task():
            try:
                from site_engine import fetch_http, BrowserFetcher, BitBrowserFetcher, load_plugin, generic_listings
                if site['mode']=='cdp':
                    with BrowserFetcher(site['cdp_endpoint']) as bf: html=bf.fetch(site['url'])
                elif site['mode']=='bitbrowser':
                    with BitBrowserFetcher(runtime) as bf: html=bf.fetch(site['url'])
                else: html=fetch_http(site['url'])
                plugin=load_plugin(site['plugin']) if site.get('plugin') else None
                rows=plugin.extract_listings(html,site['url'],site) if plugin else generic_listings(html,site['url'],site)
                self.after(0,lambda:messagebox.showinfo('抓帖測試','成功讀取 %d 個候選帖。\n測試不寫入去重庫，也不發 WA。' % len(rows),parent=self))
            except Exception as ex:
                detail=str(ex)
                self.after(0,lambda:messagebox.showerror('抓帖測試失敗',detail,parent=self))
        threading.Thread(target=task,daemon=True,name='SiteTest').start()

    def _test_site_detail(self):
        """Explicit one-post test, including browser-authenticated detail parse.

        Does not write into the phone/history database or fire WA/clipboard.
        """
        site = self._selected_site()
        if not site: return
        runtime = next(s for s in self._site_runtime_configs() if s['id']==site['id'])
        def task():
            try:
                from site_engine import (fetch_http, BrowserFetcher, BitBrowserFetcher,
                                         load_plugin, generic_listings, public_phone_links)
                plugin = load_plugin(site['plugin']) if site.get('plugin') else None
                fetcher = None
                try:
                    if site['mode']=='cdp': fetcher = BrowserFetcher(site['cdp_endpoint'])
                    elif site['mode']=='bitbrowser': fetcher = BitBrowserFetcher(runtime)
                    if fetcher: fetcher.__enter__()
                    html = fetcher.fetch(site['url']) if fetcher else fetch_http(site['url'])
                    rows = plugin.extract_listings(html,site['url'],site) if plugin else generic_listings(html,site['url'],site)
                    if not rows: raise RuntimeError('沒有讀到候選帖，無法測試詳情')
                    first = rows[0]
                    test_cfg = dict(site)
                    if site.get('plugin') == 'businessforsale_sg' and site.get('mode') == 'bitbrowser' and getattr(fetcher, 'last_fetch_mode', '') != 'snapshot':
                        test_cfg['_verified_listing_ids'] = {r['id'] for r in rows}
                    detail = fetcher.fetch_detail(first['url'], plugin, test_cfg) if fetcher else fetch_http(first['url'])
                    if plugin and callable(getattr(plugin,'accept_detail',None)) and not plugin.accept_detail(detail,first['url'],test_cfg):
                        raise RuntimeError('詳情不是直接賣家或尚未載入，無法取號')
                    contacts = plugin.extract_contacts(detail,first['url'],test_cfg) if plugin and callable(getattr(plugin,'extract_contacts',None)) else [{'phone':p} for p in public_phone_links(detail,first['url'],site)]
                    phones = [v.get('phone') for v in contacts if isinstance(v,dict) and v.get('phone')]
                    diagnosis = (plugin.contact_diagnostic(detail) if not phones and
                                 plugin and callable(getattr(plugin,'contact_diagnostic',None)) else '')
                    source = getattr(fetcher,'last_detail_mode','獨立 HTTP') if fetcher else '獨立 HTTP'
                    text = ('測試連結：'+first['url']+'\n\n讀取方式：'+source+'\n\n'+
                            ('取得號碼：'+', '.join(phones) if phones else
                             '未取到賣家電話：'+(diagnosis or '頁面無有效賣家聯絡資料'))+
                            '\n\n測試不影響歷史去重，也不發 WA。')
                    self.after(0,lambda msg=text: messagebox.showinfo('首帖背景取號測試',msg,parent=self))
                finally:
                    if fetcher: fetcher.__exit__(None,None,None)
            except Exception as ex:
                detail=str(ex)
                self.after(0,lambda msg=detail:messagebox.showerror('首帖取號測試失敗',msg,parent=self))
        threading.Thread(target=task,daemon=True,name='SiteDetailTest').start()

    def _test_site_open_detail(self):
        """Test only already-open BitBrowser details; no navigation or refresh."""
        site = self._selected_site()
        if not site: return
        if site.get('mode') != 'bitbrowser':
            messagebox.showinfo('已開帖取號測試', '此功能需要先設定為 BitBrowser 模式。', parent=self)
            return
        runtime = next(s for s in self._site_runtime_configs() if s['id'] == site['id'])
        def task():
            try:
                from site_engine import BitBrowserFetcher, load_plugin
                plugin = load_plugin(site['plugin']) if site.get('plugin') else None
                if not plugin or not callable(getattr(plugin, 'extract_contacts', None)):
                    raise RuntimeError('此網站插件未提供 extract_contacts()')
                with BitBrowserFetcher(runtime) as fetcher:
                    opened = fetcher.open_details(site)
                    if not opened:
                        msg = 'BitBrowser 當前環境沒有打開這個網站的詳情頁。請先手動打開一個已顯示電話的帖子。'
                    else:
                        selected = None
                        # Prefer a tab with a visible phone, otherwise diagnose
                        # the most recently discovered matching detail tab.
                        for url, html in reversed(opened):
                            contacts = plugin.extract_contacts(html, url, site)
                            if contacts:
                                selected = (url, contacts, '')
                                break
                        if selected is None:
                            url, html = opened[-1]
                            diagnosed = plugin.contact_diagnostic(html) if callable(getattr(plugin,'contact_diagnostic',None)) else '目前 DOM 沒有電話'
                            selected = (url, [], diagnosed)
                        url, contacts, diagnosed = selected
                        phones = [str(c['phone']) for c in contacts if c.get('phone')]
                        msg = ('已開啟詳情：'+url+'\n\n'+
                               ('讀取到電話：'+', '.join(phones) if phones else '沒有電話：'+diagnosed)+
                               '\n\n這次只讀取已開分頁，不會打開新帖、不寫入去重庫或發 WA。')
                self.after(0, lambda msg=msg: messagebox.showinfo('已開帖取號測試',msg,parent=self))
            except Exception as exc:
                detail = str(exc)
                self.after(0, lambda msg=detail: messagebox.showerror('已開帖取號測試失敗',msg,parent=self))
        threading.Thread(target=task,daemon=True,name='OpenDetailTest').start()

    def _reload_running_sites(self):
        # Restart only extra-site lanes; neither 28Hse nor 730 worker is touched.
        if not self.site_manager or not self.site_manager.active: return
        old=self.site_manager
        old.halt()
        self.write('[SITE] 設定變更，正在停止舊網站程序，不重啟 28/730')
        def wait_old():
            if any(t.is_alive() for t in old.threads):
                self.after(350,wait_old);return
            if not self.winfo_exists():return
            self.site_manager=SiteManager(self.site_store)
            self.site_manager.start(self._site_runtime_configs())
            self.set_monitor_controls(True)
        self.after(350,wait_old)

    def _site_tick(self):
        try:
            m=self.site_manager
            if m:
                for _ in range(150):
                    try: event=m.out.get_nowait()
                    except Exception:break
                    et=event.get('event');sid=event.get('id','')
                    if et=='new' and m.active: self._new_site_result(event['data'])
                    elif et in ('state','error'):
                        text=event.get('text','')
                        self.site_states[sid]=text if et=='state' else '錯誤：'+text[:90]
                        if et=='error':self.write('[SITE-ERROR:%s] %s' % (sid,text))
                        if self.extra_tree.exists(sid):
                            v=list(self.extra_tree.item(sid,'values'));v[-1]=self.site_states[sid]
                            self.extra_tree.item(sid,values=v)
                    elif et=='log':self.write('[SITE:%s] %s' % (sid,event.get('text','')))
            if self.winfo_exists():self.after(300,self._site_tick)
        except tk.TclError:pass

    def _new_site_result(self,item):
        phone=str(item.get('phone') or '').strip()
        digits=self.normalize_phone(phone)
        # Cross-site dedup uses full country code for SG, but never invents
        # the prefix for unrelated sites.
        if item['url'].lower().find('businessforsale.sg')>=0 and len(digits)==8 and digits[0] in '89':
            digits='65'+digits
        valid=bool(digits) and 8<=len(digits)<=15 and digits[0] not in '23'
        if valid:
            with self.phone_lock:
                if digits in self.seen_phones or digits in self.pending_copy_phones:
                    self.write('[SITE-DUP] 已存在跨站電話：'+digits)
                    return
                self.seen_phones.add(digits)
            self.bg(self.save_seen_phones_deferred)
            self.latest_phone.set(digits)
            getattr(self, 'copy_auto_tail_with_defer', lambda raw: self.copy_text(raw[-4:]))(digits)
        sid=item['site_id']; key=sid+':'+str(item['id'])
        iid='extra:'+key
        if iid in self.site_rows:
            old=self.site_rows[iid]
            if valid and not old.get('phone'):
                old.update(item)
                current=list(self.tree.item(iid,'values'))
                if len(current)>6:
                    current[1]=digits;current[2]=item.get('contact','未知')
                    current[3]=item.get('status') or '已取登入頁號碼';current[6]=digits[-4:]
                    self.tree.item(iid,values=current)
            return
        self.site_rows[iid]=dict(item)
        status=(item.get('status') or '未揭號') if not valid else '未啟用｜新網站'
        vals=(item.get('site_name',sid)[:25],digits if valid else '',
              item.get('contact','未知'),status,'打開 ↗',
              datetime.now().strftime('%m-%d %H:%M:%S'),digits[-4:] if valid else '',str(item['id'])[:18])
        self.tree.insert('',0,iid=iid,values=vals)
        self.row_urls[iid]=item['url']
        self.write('[SITE-NEW] %s｜%s｜%s' % (sid,item.get('title',''),('尾四位已自動複製' if valid else status)))
        for pos,c in enumerate(item.get('extra_contacts',[])):
            extra=dict(item);extra['id']=str(item['id'])+'#'+str(pos)
            extra['phone']=c.get('phone','');extra['contact']=c.get('name','未知')
            extra['extra_contacts']=[]
            self._new_site_result(extra)
        if valid and self.win_notify.get():
            try:self._popup_house({'deal':'｜'+sid,'phone':digits,'url':item['url']})
            except Exception:pass

def main():
    app = UnifiedApp()
    app._load_house_history()
    app._load_28_history()
    app.mainloop()


if __name__ == '__main__':
    main()
