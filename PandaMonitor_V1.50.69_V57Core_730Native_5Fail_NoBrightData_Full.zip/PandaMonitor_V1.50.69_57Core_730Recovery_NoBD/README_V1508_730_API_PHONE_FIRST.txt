PandaMonitor V1.50.8｜House730 API PhoneFirst（不點擊）

實測來源：用戶提供 HOUSE730_BEFORE_CLICK_RESULT.json，樓盤 9292554。
GetPropertyUserInfoById 的 result[].telphone 在點擊遮罩前已是完整香港8位電話，
isShowTel=true。這證明至少該測試帖可不點擊直接取得電話。

新增功能：
1. House730 的新帖詳情背景導航後，立即監聽網站原生 GET /Property/GetPropertyUserInfoById 回應。
2. 從 result[].telphone／customerTel 解析已公開的完整號碼，過濾 2/3 開頭、重複號碼。
3. 取得有效號碼就直接進入舊 UI／去重庫，不執行藍色遮罩點擊。
4. 無有效電話或未收到 API 時，等候約 3.5 秒後使用既有 DOM 點擊備援。
5. HTTP 401/403/429 或驗證時保留保護，不能透過重試繞過限制。
6. 原有 28Hse、852.house、BusinessForSale.sg、女性名字／WA 規則保留。

重要限制：
- 目前仍需用背景詳情頁取得真實 API 請求，不是只憑 Property ID 拼接未驗證參數。
- 不保證每個樓盤都會在揭號前回傳完整電話；本版本保留舊揭號途徑。
- 主 UI 和 House730 資料庫現階段仍以每個樓盤一條主要電話記錄。
- 對多位聯絡人的 API，會按順序採用第一個未重複且符合規則的電話；
  這不等於在 UI 完整展示同帖的全部電話。
- 這是離線測試通過的版本，尚未在用戶實際 BitBrowser 173 執行實站測試。

安裝：
解壓到新的資料夾，停止舊 PandaMonitor，直接執行 START.bat。
所有 C 盤的既有設定和去重資料會保留，無需更換 C 盤站點插件。
日誌應出現「API PhoneFirst 開始（不點擊揭號）」及成功時「電話 API 已返回...」。

離線驗證：
python TEST_730_API_PHONE_FIRST_V1508.py
python TEST_730_OFFLINE.py
python TEST_730_RECOVERY.py
python TEST_730_API_HEADERS.py
