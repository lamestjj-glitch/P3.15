PandaMonitor V1.47.6｜28Hse + House730 統一 UI／WhatsApp 各自控制
================================================================

【這個版本的重點】
主程式只有一個「統一設定」分頁，不再分開 28Hse 設定與 730 設定。
BitBrowser Local API、Token、環境序號（預設 173）、Windows 浮窗提示與跨站去重共用。

但 WhatsApp 完全獨立：
  28Hse：自動打招呼開關、開始/結束時間、訊息內容、模擬揭號測試、WA 發送測試。
  House730：另外一套開關、開始/結束時間、訊息內容、租盤/售盤揭號測試、租盤/售盤 WA 發送測試。
兩邊時間、訊息、開關互不影響。730 的 WA 預設關閉；28Hse 保留舊版設定。
WA 測試真的會向業主號碼發出訊息，必須先按確認。

【四路監控】
28Hse 租盤、28Hse 售盤：保留原版 V1.46.5 DetectionRace／OwnerLock／PhoneFirst／WarmDetailReuse。
House730 租盤、House730 售盤：JSON 列表優先、HTML 備援。
四路在同一 UI 呈現，但各自監控與揭號。跨站相同電話只提示一次。

【運行】
1. 關閉舊版程式，將此 ZIP 解壓到新資料夾。
2. 開 BitBrowser，確認環境 173 已可用。
3. 雙擊 START.bat。CMD 啟動錯誤會保存日誌，不會刻意直接閃退。
4. 在「統一設定」填 API／Token／環境號，按「保存全部設定」。
5. 分別勾選需要的四路監控、調整每個網站的 WA 開關，按開始監控。
6. 要編譯 Windows EXE，使用 BUILD_EXE.cmd。ZIP 內提供原始碼，並非已預編譯 EXE。

【保留資料】
28Hse：%USERPROFILE%\PandaMonitor_28Hse
House730：%LOCALAPPDATA%\House730Standalone173
設定與歷史記錄未要求刪除；不會自動清除舊庫。

【V1.47.6：730 JSON 接口修復】
1. 重播 QueryProperty 時保留原網站自訂 HTTP 請求標頭，例如 appkey、appsignature、language、platform（只在記憶體內保留，日誌不記值）。
2. JSON 無有效租／售樓盤連結時，將頁面正常重新載入一次以學習最新請求，再嘗試 JSON。
3. 若重新學習後仍不成功，採用每60秒 HTML 備援，不會把 HTTP200 錯誤 JSON 誤當成有效樓盤。
4. 遇 HTTP401／403／429 仍按站點限制退避；每來源只允許一個進行中的 JSON 查詢。
5. 新日誌有 JSON 頂層欄位名稱和陣列數量（沒有 Cookie、Token 或回傳欄位值），便於排查失效原因。
6. 使用者先看 730 顯示「JSON 快速」是否持續，若仍是「HTML 每60秒」，提交 House730 的最新 20 行日誌即可。

【已知限制】
730 的 QueryProperty JSON 若無法解析有效樓盤，可能退回每 60 秒 HTML 模式。
「每秒 JSON 查詢」是目標，不代表網站允許 120 次／分鐘且實際成功。
本版本做過 Python 編譯、離線解析／去重測試、獨立 WA 設定保存及模擬發送、GUI 啟動測試；
尚未在你的 Windows 10／BitBrowser 173 真機測過 WhatsApp 實際發送。


V1.48.4 新增：28Hse JSON串流在背景分頁內提取房源ID，首NEW先揭號；730共用CDP斷線後不重新啟動BitBrowser；詳見 README_V1484_Stream_Phone_CDP.txt。
