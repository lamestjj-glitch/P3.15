PandaMonitor V1.50.5｜多網站連線隔離與穩定性修正
=====================================================
完整 Python 版（不是 EXE），基於 V1.50.4；原 28Hse、730、852.house、BusinessForSale.sg 插件保留。

本次主要修改
1. 852.house 租售 HTTP 使用不同執行緒的 requests.Session 與 HTTPS keep-alive。
   移除跨租售 12 秒全域連線鎖，失效連線會關閉並在下一輪重建。
   連線與讀取各有超時，保持 5 秒設定；超時時採退避，不保證實際每 5 秒成功。
   HTTP 最終列表網址須仍保有業主盤＋publishtime|desc，否則拒絕處理。
2. BusinessForSale.sg 首次 CDP 連線失敗：10、20 秒退避後最多嘗試三次，
   三次仍失敗則只停止該插件，不拖累其他站。
3. 28Hse 原有 API 學習、OwnerLock、API/DOM 驗證、8 秒補查保留。
   私有 CDP Target 臨時中斷，只有根 CDP 端口還健康才受限重建；
   180 秒最多重建 2 次，每次重新學習及驗證 API，不能跳過 OwnerLock。
   429/人工驗證/業主條件失效仍暫停，絕不自動繞過。
4. 28Hse 啟動時優先：House730 最多等待 35 秒或 28 的 API 驗證完成後附加；
   BitBrowser 插件一直等所需 28Hse 已選租/售 API 驗證完成後才另接 CDP。
   若 28 長期不能驗證，請自行選擇停止28、切換選項後重新開始。
5. House730 如果重用的分頁跳出 s1u14 業主＋最新列表，該路暫停等待手動切回，
   不在每隔 3 秒自動重啟整個730並新增新分頁。另一條路不受影響。
6. 增加 requests>=2.31,<3 依賴；START.bat 的安裝程序應依 requirements.txt 安裝。

更新方式
- 完全退出舊版，解壓整個 ZIP 至獨立資料夾，執行 START.bat。
- 設定和電話去重仍沿用 C 盤資料，不應刪除 C 盤原設定。
- 原來 852.house 的插件更新步驟仍需使用 UPGRADE_852.cmd（若 C 盤還是舊插件）。
- 若 852.house 持續 SSL 超時，檢查本機 Windows 網絡、網站連線和代理設定；
  代碼無法保證目標伺服器永遠可連線。

建議檢查日誌
  [API-VERIFY]、[API-LIST-OK]、[API-BRIDGE-RECOVER]、
  [SITE-ERROR:852house-rent]、[SITE-ERROR:852house-buy]、
  [SITE-ERROR:businessforsale-sg]、[730] filter-paused。

測試範圍：離線單元與主要回歸測試；沒有在使用者 BitBrowser 173 或實站做驗收。
