# -*- coding: utf-8 -*-
"""Offline tests: no browser, network, saved user config, or WhatsApp."""
from pathlib import Path
import re
import subprocess
from contact_visible import extract_visible_phones
from wa_female_filter import female_name_eligible
from panda28_core import App

# A page like the supplied screenshot; independent names & phones.
fragment = '''<div class="content_phone_information">
  <div class="owner-card"><strong class="contact-name">曾先生 Mr.Tsang</strong><p>Tel: 852-91582671</p><a href="tel:852-91582671">致電</a></div>
  <div class="owner-card"><strong class="contact-name">曾太 I</strong><p>Tel: 852-56066717</p><a href="tel:852-56066717">致電</a></div>
</div>'''
rows = extract_visible_phones(fragment)
assert rows == [{'name':'曾先生 Mr.Tsang','phone':'91582671'},{'name':'曾太 I','phone':'56066717'}],rows
assert not female_name_eligible('曾先生 Mr.Tsang')[0]
assert female_name_eligible('曾太 I')[0]
assert not female_name_eligible('曾先生 Mr.Tsang Alice')[0]
assert App.normalize_phone('852-91582671') == '91582671'
assert App.normalize_phone('852-56066717') == '56066717'

# Same text flattened to one line in API JSON returns both separate contacts.
core=Path(__file__).with_name('panda28_core.py').read_text(encoding='utf-8')
a=core.index('          const norm=v=>{',core.index('    def http_phone_fast('))
b=core.index('          const phoneAction=async',a)
actual_js=core[a:b]
node_js=r'''
const assert=require('assert');
class DOMParser {
 parseFromString(raw){
  const text=String(raw).replace(/<[^>]*>/g,'');
  const block={textContent:text,
    querySelector:(q)=>q.includes('contact-name')?{textContent:'曾先生 Mr.Tsang'}:null,
    querySelectorAll:()=>[]};
  return {querySelectorAll:(q)=>q==='.content_phone_information'?[block]:[],body:block};
 }
}
const url='https://www.28hse.com/rent/apartment/property-4053077';
''' + actual_js + r'''
const rows=rowsFromFragments(['<div class="content_phone_information">曾先生 Mr.TsangTel: 852-91582671致電曾太 ITel: 852-56066717致電</div>']);
assert.deepEqual(rows,[{name:'曾先生 Mr.Tsang',phone:'91582671'},{name:'曾太 I',phone:'56066717'}]);
const reversed=rowsFromFragments(['<div>曾太 ITel: 852-56066717致電曾先生 Mr.TsangTel: 852-91582671</div>']);
assert.deepEqual(reversed,[{name:'曾太 I',phone:'56066717'},{name:'曾先生 Mr.Tsang',phone:'91582671'}]);
console.log('PASS: JS PhoneFirst multi-contact name and phone association');
'''
p=subprocess.run(['node','-e',node_js],text=True,capture_output=True)
assert p.returncode == 0, p.stdout+'\n'+p.stderr
print(p.stdout.strip())
print('PASS: HTML parser per-contact pairing and gender-honorific detection')
