# -*- coding: utf-8 -*-
"""Ensure learn retry survives and 429 initiates cooldown, not terminal halt."""
import threading, time
import panda28_core as m
from panda28_api import ApiError
from hse28_429_cooldown import RateCooldown
from hse28_adaptive import AdaptiveListScheduler

class Fake:
    worker=m.App.worker
    api_poll_interval=m.App.api_poll_interval
    _record_28_api_pause=m.App._record_28_api_pause
    def __init__(self):
        self.running=True; self.run_id=4
        self.cdp_fault_event=threading.Event()
        self.api_rate_limit_event=threading.Event()
        self.api_429_guard=RateCooldown(jitter=lambda:0)
        self.api_adaptive_scheduler=AdaptiveListScheduler()
        self.api_pause_lock=threading.Lock()
        self.api_paused={'rent':'','buy':''}
        self.api_source_enabled={'rent':True,'buy':True}
        self.api_poll_seconds={'rent':0.5,'buy':0.5}
        self.api_template_cache={}
        self.messages=[]
        self.lock=threading.Lock()
        self.cdp_base='http://127.0.0.1:12345'
    def write(self,msg):
        self.messages.append(msg)
        if '[API-429-RETRY]' in msg:
            self.running=False  # end offline simulation after observing cooldown
    def status(self,msg):pass
    def toast(self,*args):pass
    def _cdp_base_alive(self):return True
    def target(self,k):return {'id':'user-rent-tab'}
    def _list_tab_alive(self,k,tid):return True
    def close_target_id(self,*args):pass

original=m.capture_template
calls=[]
def mock(app,trade,is_running,cached=None,allow_reload=True):
    calls.append(trade)
    if len(calls)==1:raise ApiError('learn','Background search control unavailable (waiting-for-background-DOM)')
    raise ApiError('rate','HTTP 429')
try:
    m.capture_template=mock
    app=Fake()
    started=time.monotonic()
    app.worker('rent',0,4)
    assert len(calls)==2,calls
    assert any('[API-LEARN-RETRY]' in x for x in app.messages),app.messages
    assert not app.api_rate_limit_event.is_set()
    assert all(v=='' for v in app.api_paused.values())
    assert app.api_429_guard.remaining()>0
    print('PASS: transient learn retry followed by shared 429 cooldown; no permanent pause')
finally:
    m.capture_template=original
