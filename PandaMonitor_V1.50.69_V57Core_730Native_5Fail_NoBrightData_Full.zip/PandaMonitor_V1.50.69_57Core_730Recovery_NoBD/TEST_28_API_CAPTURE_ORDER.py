# -*- coding: utf-8 -*-
"""Offline regression: listener installed before a reload of an already opened tab."""
import json
import threading
from urllib.parse import urlencode
from panda28_api import capture_template, owner_lock
from unified_gui import UnifiedApp

FORM=urlencode({'form_data':json.dumps({'landlordAgency':'LANDLORD','sortBy':'latest','buyRent':'rent'})})

class CDP:
    def __init__(self):
        self.calls=[]
        self.event_handler=None
        self.closed=False
    def call(self,method,params=None,timeout=None):
        self.calls.append((method,params or {}))
        if method=='Page.reload':
            assert self.event_handler is not None
            assert 'Network.enable' in [n for n,p in self.calls]
            assert params.get('ignoreCache') is False
            # The normal initial page load can produce its own API request.
            self.event_handler({'method':'Network.requestWillBeSent','params':{
                'request':{'method':'POST','url':'https://www.28hse.com/property/dosearch','postData':FORM}}})
        elif method=='Runtime.evaluate':
            expr=params['expression']
            if expr=='location.href':
                return {'result':{'value':'https://www.28hse.com/rent?landlordAgency=LANDLORD&sortBy=latest'}}
            if 'const accepted=' in expr:
                raise AssertionError('Search must not be clicked after a valid initial XHR')
        return {'result':{}}
    def ev(self,expr,timeout=None):
        return False
    def close(self):self.closed=True

class App:
    def __init__(self):
        self.lock=threading.Lock()
        self.http_target_ids=set()
        self.c=CDP()
        self.initial=[]
    def target(self,k):
        return {'id':'user-rent-tab','url':'https://www.28hse.com/rent?landlordAgency=LANDLORD&sortBy=latest','webSocketDebuggerUrl':'ws://localhost:1234'}
    def create_background_target(self,url):
        raise AssertionError('No new list page should be created')
    def list_url(self,k):return 'https://www.28hse.com/'+k+'?landlordAgency=LANDLORD&sortBy=latest'
    def cdp(self,t):return self.c
    def close_target_id(self,tid):raise AssertionError('Successful target should stay open')

class Waiter:
    _house_launch_serial=1
    _house_launch_pending=True
    running=True
    cdp_base='http://127.0.0.1:52359'
    def __init__(self):self.started=0;self.waited=0
    def _cdp_base_alive(self):return False
    def _start_house_process(self):self.started+=1
    def after(self,ms,cb):self.waited+=1
    def write(self,text):pass

def main():
    a=App()
    target,c,tpl=capture_template(a,'rent',lambda:True)
    assert target['id']=='user-rent-tab' and owner_lock(tpl['body'])
    assert c.event_handler is None
    cmds=[n for n,p in c.calls]
    assert cmds.index('Network.enable')<cmds.index('Page.reload')
    assert cmds.count('Page.reload')==1 and cmds.count('Page.navigate')==0
    assert not any(n.startswith('Input.') or n in ('Page.bringToFront','Page.navigate') for n in cmds)
    w=Waiter()
    import time
    UnifiedApp._wait_for_28_cdp(w,1,time.monotonic()+6)
    assert w.waited==1 and w.started==0, 'Should not give stale CDP port to 730'
    print('PASS: existing user tab, Network BEFORE reload, early XHR captured, no extra tab/navigation, 730 stale-port guard')

if __name__=='__main__':main()
