# -*- coding: utf-8 -*-
"""BusinessForSale.sg owner-listing parser -- V1.50.7.

Only extract rendered seller contact text or seller-owned call links.
Do not read enquiry-form fields, hidden JS state, site-wide phone numbers or
unavailable premium contact information.
"""
import re
from urllib.parse import urljoin, urlsplit, parse_qs
from bs4 import BeautifulSoup

DETAIL_URL = re.compile(r'^/businesses-for-sale/[a-z0-9-]+-\d+/?$', re.I)
# Both layouts currently occur on the service, including /...-28398.
SELLER_HEADING = re.compile(
    r'\bSeller\s+Contact\s*(?:(?:&|and)\s*)?(?:Listing\s+)?(?:Information|Statistics|Details)\b', re.I)
PHONE_LABEL = re.compile(r'\b(?:Mobile\s+Number|Contact\s+Number|Seller\s+Phone|Phone\s+Number)\b', re.I)
SG_SELLER_PHONE = re.compile(r'(?<!\d)(?:\+?65[\s-]*)?[89](?:[\s-]*\d){7}(?!\d)')
SKIP_NAME = {'mobile number', 'email address', 'direct seller', 'member only',
             'premium only', 'seller contact', 'phone', 'seller phone',
             'contact number', 'secure access'}


def extract_listings(html, url, cfg):
    soup = BeautifulSoup(html, 'html.parser')
    rows, seen = [], set()
    for el in soup.select("a[href*='/businesses-for-sale/']"):
        href = urljoin(url, el.get('href', ''))
        path = urlsplit(href).path
        if not DETAIL_URL.fullmatch(path):
            continue
        if urlsplit(href).hostname not in ('www.businessforsale.sg', 'businessforsale.sg'):
            continue
        ident = path.rsplit('-', 1)[-1].strip('/')
        if ident in seen:
            continue
        seen.add(ident)
        rows.append({'id': ident, 'url': href.split('#')[0],
                     'title': el.get_text(' ', strip=True)[:180]})
    return rows


def _visible_soup(html):
    soup = BeautifulSoup(html, 'html.parser')
    # Exclude input fields / phone selectors in the enquiry form.  These belong
    # to the visitor, never to the seller.
    for node in soup.select('script,style,template,noscript,form,select,footer,nav'):
        node.decompose()
    return soup


def _panel_text(soup):
    text = soup.get_text(' ', strip=True)
    m = SELLER_HEADING.search(text)
    if not m:
        return ''
    panel = text[m.end():m.end()+1200]
    # Prevent capture of contact details elsewhere after the seller section.
    for boundary in (r'\bSeller information is provided\b', r'\bAI Business Analysis\b',
                     r'\bSubmit Enquiry\b', r'\bShare Listing\b',
                     r'\bSend Enquiry\b', r'\bContact Seller Directly\b'):
        hit = re.search(boundary, panel, re.I)
        if hit:
            panel = panel[:hit.start()]
    return panel.strip()


def _contact_name(panel):
    if not panel:
        return '未知'
    hit = re.search(r'\bContact\s+Person\b\s*:?(.*)', panel, re.I)
    if not hit:
        return '未知'
    part = hit.group(1)[:220]
    part = SG_SELLER_PHONE.split(part, maxsplit=1)[0]
    part = re.split(r'[\w.+-]+@[\w.-]+', part, maxsplit=1)[0]
    part = re.split(r'\b(?:Total Enquiries|Date Published|Last Enquiry|AI Business Analysis)\b', part, maxsplit=1, flags=re.I)[0]
    part = re.sub(r'\b(?:Mobile Number|Contact Number|Phone Number|Seller Phone|Email Address|Premium Only|Member Only|Secure Access)\b', ' ', part, flags=re.I)
    part = re.sub(r'\s+', ' ', part).strip(' :-|')
    if len(part) > 45 or not re.fullmatch(r"[A-Za-z][A-Za-z0-9 .'-]*", part or ''):
        return '未知'
    return part if part.lower() not in SKIP_NAME else '未知'


def _phone(raw):
    digits = re.sub(r'\D', '', raw)
    if len(digits) == 10 and digits.startswith('65'):
        digits = digits[2:]
    return '+65'+digits if len(digits) == 8 and digits[0] in '89' else None


def extract_contacts(html, url, cfg):
    soup = _visible_soup(html)
    panel = _panel_text(soup)
    name = _contact_name(panel)
    people, seen = [], set()

    def add(raw):
        phone = _phone(raw)
        if phone and phone not in seen:
            seen.add(phone)
            people.append({'phone':phone, 'name':name})

    # Seller's Premium Member Access panel. Recognise both "Mobile Number"
    # and newer "Contact Number" headings, including column-first grids.
    if panel and PHONE_LABEL.search(panel):
        for match in SG_SELLER_PHONE.finditer(panel):
            add(match.group())

    # An alternative authenticated layout puts the call button in a seller
    # card separate from the statistics table. Require seller-specific button
    # context; never blindly accept every tel: link on a locked page.
    if not people:
        for a in soup.select('a[href^="tel:"]'):
            vicinity = ' '.join(
                p.get_text(' ', strip=True)[:320] for p in (a, a.parent, a.parent.parent if a.parent else None)
                if p is not None)
            if re.search(r'\bCall\s+Seller\b|\bSeller\s+Contact\b', vicinity, re.I) or (
                re.search(r'\bDirect\s+Seller\b', vicinity, re.I)
                and re.search(r'\bCall\b', vicinity, re.I)):
                add(a.get('href', '')[4:])
    return people


def contact_diagnostic(html):
    soup = _visible_soup(html)
    text = soup.get_text(' ', strip=True)
    panel = _panel_text(soup)
    if panel and re.search(r'\bPremium\s+Only\b', panel, re.I) and not SG_SELLER_PHONE.search(panel):
        return '本帖聯絡欄位顯示 Premium Only；目前讀到的是會員鎖定頁，而非已顯示電話的頁面'
    if re.search(r'\bSeller\s+phone\s+and\s+email\s+locked\b', text, re.I) and not SG_SELLER_PHONE.search(panel):
        return '此詳情回應仍是會員鎖定版本；請在 BitBrowser 檢查此帖是否真的顯示電話'
    if not SELLER_HEADING.search(text):
        return '沒有讀到 Seller Contact 聯絡區；可能載入未完成、登入失效或版面改動'
    if not PHONE_LABEL.search(panel):
        return '已找到 Seller Contact，但尚無 Mobile Number／Contact Number 欄位'
    return '已找到賣家聯絡欄位，但沒有可見的新加坡手機號碼；請確認該帖會員權限'


def accept_detail(html, url, cfg):
    """Do not accept agent listings: check explicit seller or proven owner list.

    `source=2` alone is not enough for a manually opened detail; the ID must
    also have been observed in that filtered list during this run.
    """
    soup = _visible_soup(html)
    # Exact seller badge only: 'Direct seller phone and email' in a
    # Premium upsell is NOT proof that the advertiser is an owner.
    if any(t.strip().casefold() == 'direct seller' for t in soup.stripped_strings):
        return True
    ident = urlsplit(url).path.rstrip('/').rsplit('-', 1)[-1]
    approved = cfg.get('_verified_listing_ids') or ()
    selected_url = urlsplit(cfg.get('url', ''))
    if (selected_url.hostname in ('www.businessforsale.sg', 'businessforsale.sg')
        and parse_qs(selected_url.query).get('source') == ['2']
        and ident in approved and SELLER_HEADING.search(soup.get_text(' ', strip=True))):
        return True
    return False
