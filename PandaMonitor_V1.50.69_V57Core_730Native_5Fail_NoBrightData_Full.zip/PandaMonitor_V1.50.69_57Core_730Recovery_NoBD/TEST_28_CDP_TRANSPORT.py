# -*- coding: utf-8 -*-
"""Offline regression for retiring an unhealthy CDP connection."""
import socket
from panda28_core import CDP

class FakeSocket:
    def __init__(self, failure): self.failure=failure;self.sent=0
    def settimeout(self, seconds): pass
    def send(self, msg): self.sent+=1
    def recv(self):raise self.failure
    def close(self):pass

def main():
    c=CDP('ws://127.0.0.1:12345/devtools/page/fake')
    c.ws=FakeSocket(socket.timeout('test timeout'))
    try:c.call('Runtime.evaluate',{'expression':'true'},timeout=.05)
    except TimeoutError:pass
    else:raise AssertionError('missing timeout')
    assert c.dead and c.timeout_streak==1
    try:c.call('DOM.getDocument',{},timeout=.05)
    except ConnectionError as e: assert 'CDP_TRANSPORT_LOST' in str(e)
    else: raise AssertionError('retired socket accepted a call')
    assert c.ws.sent==1
    c2=CDP('ws://127.0.0.1:12345/devtools/page/fake')
    c2.ws=FakeSocket(ConnectionAbortedError(10053,'connection aborted'))
    try:c2.call('Runtime.evaluate',{},timeout=.05)
    except ConnectionError as e: assert 'CDP_TRANSPORT_LOST' in str(e)
    else: raise AssertionError('broken socket accepted call')
    assert c2.dead and c2.ws.sent==1
    print('PASS: transport closed on WinError 10053 and one CDP timeout; retired sockets never reused')
if __name__=='__main__':main()
