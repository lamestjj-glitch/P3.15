PandaMonitor V1.50.2 — BitBrowser 173 / BusinessForSale.sg 回復修正
日期：2026-10-13

【依據實際日誌修正】
1) [SITE-ERROR] asyncio.run() cannot be called from a running event loop
   原因：V1.50.1 的 site_engine.BitBrowserFetcher 先啟動 sync_playwright，
   再於同一執行緒 asyncio.run() 搜尋 BitBrowser 環境與 CDP 端口。
   現在先從 BitBrowser Local API 查詢已開啟環境的 CDP 端口，再啟動 Playwright。
   有可用 shared_cdp_endpoint 時重用原 CDP；不再呼叫 /browser/open。

2) [SITE-ERROR] Page.goto Timeout 11000ms waiting for domcontentloaded
   新站獨立背景列表分頁優先 wait_until='commit'（8.5 秒上限），
   再有限時等待 DOM 載入；同網址使用 page.reload，不創建多個分頁；
   若導航生命周期超時，但 DOM 已載入有效列表，可取回現有列表。
   這不能保證網站必定在 8.5 秒內返回，超時仍會記錄並退避重試。

3) Cloudflare 誤判防護
   不再僅憑 HTML 中出現 cf-chl- / captcha challenge 字串就認定頁面在驗證。
   只在可見驗證頁時標示需人工處理；暫停列表請求 30 秒，
   期間仍可嘗試讀取使用者已打開的賣家詳情（不點擊，不轉發訊息）。

4) BitBrowser 已打開的列表頁只讀備援
   若背景頁超時或顯示驗證，但你的瀏覽器已有符合 Direct Owner / 最新排序條件的列表，
   可只讀該分頁 DOM；不重新載入，不切換焦點。
   此模式 UI 顯示「僅讀取已開頁面快照｜需手動刷新」。
   注意快照本身不會自動獲得更新！請手動刷新原分頁或等待背景連線恢復。

5) 保留 V1.50.1 的新站小數秒間隔、TXT、雙聯絡人、跨站去重，
   28Hse / House730 原監控核心無改動。

【使用】
1. 完全退出舊版 PandaMonitor，解壓本次完整 ZIP 到新資料夾。
2. BitBrowser 環境 173 先手動開啟，確保 BusinessForSale.sg 已登入。
3. 運行 START.bat，「新增網站｜插件管理」中選擇 BusinessForSale.sg，
   模式 bitbrowser，環境 173，刷新 1 秒（或自訂小數）。
4. 檢查新站狀態：
   - 「監控中｜...」代表最近一次列表抓取成功；
   - 「僅讀取已開頁面快照｜需手動刷新」代表只在讀取舊頁資料；
   - 「需要人工完成驗證」代表網站有驗證畫面，需在 BitBrowser 手動完成。
5. 如想取賣家電話，先手動打開已登入的賣家詳情，確認 Mobile Number 顯示，
   程式會只讀開啟頁面上已可見的電話，不會繞過會員權限。

【測試範圍】
已通過離線模擬 CDP 端口查詢、背景導航、已開列表快照、人機驗證判斷、
新站配置/解析/GUI，及 28Hse、730 主要離線解析測試。
尚未在用戶 Windows、BitBrowser 173 與網站真人驗證環境進行實際連線測試。
高頻刷新可能觸發網站風控，設定 1 秒不代表每次網絡更新都能在 1 秒完成。
