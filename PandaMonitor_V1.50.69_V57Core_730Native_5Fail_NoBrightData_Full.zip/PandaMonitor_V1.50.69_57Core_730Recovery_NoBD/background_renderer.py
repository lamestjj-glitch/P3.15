# -*- coding: utf-8 -*-
"""Best-effort *non-foreground* Chromium page lifecycle hints.

This is not an anti-detection mechanism and does not disable website limits.
It must never bring a page to front or change the user's window focus.
"""


async def keep_background_renderer_active(page):
    """Once per attached House730 tab; a failure doesn't block monitoring."""
    if page is None or page.is_closed():
        return False
    session = None
    applied = False
    try:
        session = await page.context.new_cdp_session(page)
        for method, params in (
            ('Emulation.setFocusEmulationEnabled', {'enabled': True}),
            ('Page.setWebLifecycleState', {'state': 'active'}),
        ):
            try:
                await session.send(method, params)
                applied = True
            except Exception:
                # A Chrome derivative may not implement one of these methods.
                pass
    except Exception:
        pass
    finally:
        if session is not None:
            try:
                await session.detach()
            except Exception:
                pass
    return applied
