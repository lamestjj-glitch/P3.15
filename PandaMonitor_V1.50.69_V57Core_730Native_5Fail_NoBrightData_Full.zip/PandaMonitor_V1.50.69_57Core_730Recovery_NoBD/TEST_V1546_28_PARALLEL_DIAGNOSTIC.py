# -*- coding: utf-8 -*-
"""V1.50.46 offline checks: no BitBrowser or real website requests."""
import inspect
import threading
import time

from hse28_adaptive import AdaptiveListScheduler
from hse28_429_cooldown import RateCooldown
from panda28_api import api_snapshot, owner_lock
from panda28_core import App
from unified_gui import SharedPhoneStore


def check_independent_lanes():
    gate = AdaptiveListScheduler()
    barrier = threading.Barrier(3)
    release_pair = threading.Event()
    entered = []
    errors = []
    def job(lane):
        try:
            with gate.lease(lane, lambda: True) as yes:
                assert yes
                entered.append(lane)
                barrier.wait(1.0)
                assert release_pair.wait(2)
        except BaseException as error:
            errors.append(error)
    a = threading.Thread(target=job, args=('rent',))
    b = threading.Thread(target=job, args=('buy',))
    a.start(); b.start()
    barrier.wait(timeout=2)
    assert set(gate.report()['active_lanes']) == {'rent', 'buy'}
    release_pair.set()
    a.join(3); b.join(3)
    assert not (a.is_alive() or b.is_alive()) and not errors, errors
    assert sorted(entered) == ['buy','rent']

    first = threading.Event()
    release = threading.Event()
    second = threading.Event()
    def same_lane_first():
        with gate.lease('rent', lambda: True) as allowed:
            assert allowed
            first.set()
            assert release.wait(2)
    def same_lane_second():
        with gate.lease('rent', lambda: True) as allowed:
            assert allowed
            second.set()
    a = threading.Thread(target=same_lane_first)
    b = threading.Thread(target=same_lane_second)
    a.start(); assert first.wait(2); b.start()
    assert not second.wait(.06), 'Same-lane overlap'
    release.set(); assert second.wait(2)
    a.join(3); b.join(3)
    assert not gate.report()['active_lanes'] and not gate.report()['pending']
    assert gate.report()['gap_ms'] == 0


def check_shutdown_cancellation():
    gate = AdaptiveListScheduler()
    go = threading.Event()
    result = []
    with gate.lease('buy', lambda: True) as yes:
        assert yes
        def wait_on_buy():
            with gate.lease('buy', lambda: not go.is_set()) as allowed:
                result.append(allowed)
        thread = threading.Thread(target=wait_on_buy)
        thread.start(); time.sleep(.06); go.set()
        thread.join(2)
        assert result == [False]
    assert not gate.report()['pending']


def check_429_recovery_shared():
    limiter = RateCooldown(jitter=lambda:0)
    seconds, _, _ = limiter.rate_limited('0.01')
    assert seconds >= 2 and limiter.remaining() >= 1.5
    assert limiter.recovery()


def check_diagnostics_no_extra_requests():
    src = inspect.getsource(api_snapshot)
    assert src.count('await fetch(') == 1
    assert 'networkConnectMs' in src and 'networkWaitMs' in src
    assert 'jsonMs' in src and 'streamMs' in src
    assert 'performance.getEntriesByName(' in src
    assert 'POST' in src and 'owner_lock(' in src
    worker = inspect.getsource(App.worker)
    assert '[28-API-TIMING]' in worker
    assert 'self.api_adaptive_scheduler.lease(k,' in worker
    assert 'self.api_429_guard.slot(' in worker
    assert 'self.phone_jobs[k].put((u,detected_t0))' in worker
    assert '[28-CADENCE] 租售獨立並行' in worker


def check_phones_shared_lock():
    source = inspect.getsource(SharedPhoneStore.save_phone)
    assert 'with self.owner.phone_lock:' in source
    assert 'self.owner.seen_phones' in source
    assert 'self.owner.pending_copy_phones' in source
    src = inspect.getsource(App.result)
    assert 'if digits_guard in self.seen_phones or digits_guard in self.pending_copy_phones' in src
    assert 'self.pending_copy_phones.add(digits_guard)' in src
    # Never use tail four digits as a dedup key.
    assert 'digits_guard = self.normalize_phone(p)' in src
    assert 'phone in self.seen_phones' in inspect.getsource(App.publish_secondary_phone)


if __name__ == '__main__':
    check_independent_lanes()
    check_shutdown_cancellation()
    check_429_recovery_shared()
    check_diagnostics_no_extra_requests()
    check_phones_shared_lock()
    print('PASS V1.50.46: concurrent rent/buy; single-flight per lane; cancellation; shared 429; timings; cross-site full-phone dedup')
