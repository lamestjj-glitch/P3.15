# -*- coding: utf-8 -*-
"""V1.50 optional site runners; isolated from 28Hse/730 hot paths.

A site owns one sequential fetch loop and a private stop Event.  No Tk or
clipboard access is permitted in workers: all events go through a queue.
"""
from __future__ import annotations
import importlib.util
import asyncio
import math
import json
import os
import queue
import re
import sys
import threading
import time
from pathlib import Path
from urllib.parse import urljoin, urlsplit, parse_qs
from urllib.request import Request, urlopen
from bs4 import BeautifulSoup

try:
    from playwright.sync_api import TimeoutError as PlaywrightTimeoutError
except ImportError:  # Site HTTP mode works without Playwright until CDP is requested.
    PlaywrightTimeoutError = TimeoutError

APP_HOME = Path(sys.executable).resolve().parent if getattr(sys, 'frozen', False) else Path(__file__).resolve().parent
BUNDLE_HOME = Path(getattr(sys, '_MEIPASS', APP_HOME))
EXTERNAL_PLUGIN_DIR = None
DEFAULT_BFS = {
    'id': 'businessforsale-sg', 'name': 'BusinessForSale.sg｜新加坡業主',
    'url': 'https://www.businessforsale.sg/businesses-for-sale?source=2&sort=2',
    'plugin': 'businessforsale_sg', 'link_selector': "a[href*='/businesses-for-sale/']",
    'href_contains': '/businesses-for-sale/', 'phone_selector': "a[href^='tel:']",
    'interval': 1.0, 'enabled': False, 'mode': 'bitbrowser', 'cdp_endpoint': '',
    'bitbrowser_seq': 173,
}


def validate_site(raw):
    if not isinstance(raw, dict):
        raise ValueError('網站配置必須是 JSON 物件')
    value = dict(raw)
    for key in ('id', 'name', 'url'):
        if not isinstance(value.get(key), str) or not value[key].strip():
            raise ValueError(f'{key} 不能為空')
        value[key] = value[key].strip()
    if not re.fullmatch(r'[a-zA-Z0-9_-]{1,64}', value['id']):
        raise ValueError('網站 ID 只可用英文、數字、底線、-')
    sp = urlsplit(value['url'])
    if sp.scheme not in ('http', 'https') or not sp.hostname:
        raise ValueError('網址必須為有效的 http(s) 地址')
    value['mode'] = str(value.get('mode', 'http')).lower()
    if value['mode'] not in ('http', 'cdp', 'bitbrowser'):
        raise ValueError('模式只支援 http / cdp / bitbrowser')
    try:
        value['bitbrowser_seq'] = int(value.get('bitbrowser_seq') or 173)
        if value['bitbrowser_seq'] <= 0: raise ValueError()
    except (TypeError, ValueError):
        raise ValueError('BitBrowser 環境序號必須是正整數')
    if value['mode'] == 'cdp':
        ep = str(value.get('cdp_endpoint') or '')
        if not ep.startswith(('http://127.0.0.1:', 'http://localhost:', 'ws://127.0.0.1:', 'ws://localhost:')):
            raise ValueError('CDP 模式請填本機 127.0.0.1/localhost 的 DevTools 地址')
    try:
        value['interval'] = float(str(value.get('interval', 1)).strip())
    except (TypeError, ValueError):
        raise ValueError('刷新間隔請輸入秒數，例如 0.5、1、1.25')
    if not math.isfinite(value['interval']) or not 0.1 <= value['interval'] <= 3600:
        raise ValueError('刷新間隔必須介於 0.1–3600 秒，支援小數點')
    value['enabled'] = bool(value.get('enabled', False))
    value['plugin'] = str(value.get('plugin') or '').strip()
    if value['plugin'] and not re.fullmatch(r'[a-zA-Z][a-zA-Z0-9_]{0,63}', value['plugin']):
        raise ValueError('插件名不合法')
    for key in ('link_selector', 'href_contains', 'phone_selector'):
        value[key] = str(value.get(key) or '').strip()
    if not value['plugin'] and not value['link_selector']:
        raise ValueError('通用網站必須填抓帖連結 CSS 選擇器；或選擇專用插件')
    # Catch syntax errors now rather than silently displaying an empty listing.
    if not value['plugin']:
        try: BeautifulSoup('<html></html>', 'html.parser').select(value['link_selector'])
        except Exception as ex: raise ValueError('CSS 選擇器錯誤：' + str(ex))
    return value


class SiteConfigStore:
    def __init__(self, root):
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        global EXTERNAL_PLUGIN_DIR
        EXTERNAL_PLUGIN_DIR = self.root / 'site_plugins'
        EXTERNAL_PLUGIN_DIR.mkdir(parents=True, exist_ok=True)
        self.path = self.root / 'extra_sites.json'
        self.history = self.root / 'extra_site_seen.json'
        self.lock = threading.Lock()

    def load(self):
        if not self.path.exists():
            # Disabled until explicitly checked. Do not automatically begin new site networking.
            self.save([DEFAULT_BFS])
        try:
            obj = json.loads(self.path.read_text(encoding='utf-8'))
            if isinstance(obj, dict): obj = obj.get('sites', [])
            if not isinstance(obj, list): raise ValueError('sites 應為列表')
            normalized = []
            for v in obj:
                # Upgrade the unmodified v1.50.0 SG preset without touching
                # custom sites or intentional non-default HTTP settings.
                if (isinstance(v, dict) and v.get('id') == 'businessforsale-sg'
                    and v.get('plugin') == 'businessforsale_sg'
                    and v.get('mode') == 'http' and 'bitbrowser_seq' not in v):
                    v = dict(v, mode='bitbrowser', bitbrowser_seq=173)
                    v['interval'] = 1.0  # SG upgrade requested 1 second
                normalized.append(validate_site(v))
            return normalized
        except Exception as ex:
            raise ValueError('載入 extra_sites.json 失敗：' + str(ex))

    def save(self, sites):
        normalized = [validate_site(s) for s in sites]
        if len(set(s['id'] for s in normalized)) != len(normalized):
            raise ValueError('網站 ID 不能重複')
        content = json.dumps({'schema':1, 'sites':normalized}, ensure_ascii=False, indent=2)
        tmp = self.path.with_suffix('.json.tmp')
        tmp.write_text(content, encoding='utf-8')
        os.replace(tmp, self.path)

    def read_seen(self):
        try:
            data = json.loads(self.history.read_text(encoding='utf-8'))
            return {k: set(v) for k,v in data.items() if isinstance(v,list)}
        except (OSError, ValueError, TypeError): return {}

    def write_seen(self, seen):
        with self.lock:
            content = json.dumps({k:list(sorted(v))[-3000:] for k,v in seen.items()}, ensure_ascii=False)
            temp = self.history.with_suffix('.json.tmp')
            temp.write_text(content, encoding='utf-8')
            os.replace(temp, self.history)


def plugin_choices():
    names = set()
    for folder in (EXTERNAL_PLUGIN_DIR, BUNDLE_HOME / 'site_plugins', APP_HOME / 'site_plugins'):
        if folder is None: continue
        if folder.exists():
            names.update(p.stem for p in folder.glob('*.py') if not p.stem.startswith('_'))
    return sorted(names)


def load_plugin(name):
    # External module install is intentional: plugins are local executable code.
    if not re.fullmatch(r'[a-zA-Z][a-zA-Z0-9_]{0,63}', name or ''):
        raise ValueError('Invalid plugin name')
    for folder in (EXTERNAL_PLUGIN_DIR, APP_HOME / 'site_plugins', BUNDLE_HOME / 'site_plugins'):
        if folder is None: continue
        path = folder / (name + '.py')
        if path.is_file():
            spec = importlib.util.spec_from_file_location('panda_site_' + name, path)
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            if not callable(getattr(module, 'extract_listings', None)):
                raise ValueError(name + ' 插件缺少 extract_listings(html, url, config)')
            return module
    raise FileNotFoundError('網站插件不存在：' + name)


def check_owner_url(request_url, actual_url):
    """Fail closed when the BusinessForSale.sg owner/date URL redirects away."""
    origin, final = urlsplit(request_url), urlsplit(actual_url)
    if origin.hostname in ('852.house', 'www.852.house') and origin.path.rstrip('/') in ('/zh/buy', '/zh/rent'):
        if final.hostname not in ('852.house', 'www.852.house') or final.path.rstrip('/') != origin.path.rstrip('/'):
            raise ValueError('852.house 列表重定向到其他頁面，停止處理本輪')
        expected = parse_qs(origin.query)
        actual = parse_qs(final.query)
        if any(actual.get(key) != expected.get(key) for key in ('features[0]', 'order')):
            raise ValueError('852.house 業主／最新篩選條件在重定向後丟失')
    if origin.hostname in ('www.businessforsale.sg', 'businessforsale.sg') and origin.path == '/businesses-for-sale':
        if final.hostname not in ('www.businessforsale.sg', 'businessforsale.sg'):
            raise ValueError('BusinessForSale.sg 重定向到其他網站，停止處理本輪')
        expected = parse_qs(origin.query)
        actual = parse_qs(final.query)
        if any(actual.get(key) != expected[key] for key in ('source', 'sort') if key in expected):
            raise ValueError('業主／最新篩選在重定向後丟失，已停止處理本輪')


# Persistent connections are thread-owned: one rental worker, one sale worker.
# The former shared host-wide mutex caused a twelve-second sale timeout to
# block rent too. A requests.Session provides keep-alive TLS reuse instead.
_http_worker_local = threading.local()


def _get_http_session():
    session = getattr(_http_worker_local, 'session', None)
    if session is None:
        import requests
        from requests.adapters import HTTPAdapter
        session = requests.Session()
        session.mount('https://', HTTPAdapter(pool_connections=2, pool_maxsize=2, max_retries=0))
        session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml',
            'Accept-Language': 'zh-HK,zh;q=0.9,en;q=0.8',
        })
        _http_worker_local.session = session
    return session


def _close_http_session():
    session = getattr(_http_worker_local, 'session', None)
    if session is not None:
        try: session.close()
        except Exception: pass
        _http_worker_local.session = None


def _fetch_852_keepalive(url):
    import requests
    session = _get_http_session()
    try:
        # Connect and read have independent caps. There is never an overlapping
        # request in a given site's worker; buy and rent do NOT share this lock.
        reply = session.get(url, timeout=(3.5, 7.0), allow_redirects=True)
        check_owner_url(url, reply.url)
        if reply.status_code in (403, 429):
            raise RuntimeError('852.house HTTP %s；請降低刷新頻率或檢查網站狀態' % reply.status_code)
        reply.raise_for_status()
        content_type = reply.headers.get('Content-Type', '').lower()
        if 'html' not in content_type and 'text/' not in content_type:
            raise ValueError('852.house 返回非 HTML 內容')
        if len(reply.content) > 6_000_000:
            raise ValueError('852.house HTML 超過 6MB')
        return reply.text
    except (requests.exceptions.Timeout, requests.exceptions.SSLError,
            requests.exceptions.ConnectionError) as exc:
        # A broken pooled TLS connection must not be reused on the next poll.
        _close_http_session()
        raise TimeoutError('852.house 網絡／SSL 超時，已重建連線；下輪退避重試 (%s)' % type(exc).__name__) from exc



def _fetch_http_once(url, timeout=10):
    request = Request(url, headers={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/125.0 Safari/537.36',
                                    'Accept':'text/html,application/xhtml+xml', 'Accept-Language':'en-SG,en;q=0.9'})
    with urlopen(request, timeout=timeout) as response:
        check_owner_url(url, response.geturl())
        if response.status != 200: raise RuntimeError('HTTP ' + str(response.status))
        ctype = response.headers.get('Content-Type', '')
        if 'html' not in ctype and 'text/' not in ctype: raise ValueError('不是 HTML 列表')
        payload = response.read(6_000_001)
        if len(payload) > 6_000_000: raise ValueError('HTML 太大')
        charset = response.headers.get_content_charset() or 'utf-8'
        return payload.decode(charset, errors='replace')


def fetch_http(url, timeout=10):
    # Do not hold a shared mutex across a slow TLS handshake.
    if urlsplit(url).hostname in ('852.house', 'www.852.house'):
        return _fetch_852_keepalive(url)
    return _fetch_http_once(url, timeout=timeout)


def generic_listings(html, url, cfg):
    soup = BeautifulSoup(html, 'html.parser')
    origin = urlsplit(url)
    result = []
    for node in soup.select(cfg['link_selector']):
        href = node.get('href')
        if not href:
            a = node.find('a', href=True)
            href = a.get('href') if a else ''
        link = urljoin(url, href)
        dest = urlsplit(link)
        if dest.scheme not in ('http', 'https') or dest.hostname != origin.hostname: continue
        if cfg.get('href_contains') and cfg['href_contains'] not in dest.path: continue
        title = node.get_text(' ', strip=True)
        if not title and node.name != 'a':
            a = node.find('a', href=True)
            title = a.get_text(' ', strip=True) if a else ''
        result.append({'id':link.split('#')[0], 'title':title[:150] or '新帖子', 'url':link.split('#')[0]})
    return dedup_listings(result)


def dedup_listings(items):
    out, seen = [], set()
    for d in items:
        if not isinstance(d,dict): continue
        u = str(d.get('url','')).strip()
        ident = str(d.get('id') or u)
        if not u or not ident or ident in seen: continue
        if urlsplit(u).scheme not in ('http','https'): continue
        seen.add(ident)
        out.append({'id':ident, 'url':u, 'title':str(d.get('title') or '')[:200], 'contact':str(d.get('contact') or '未知')[:100]})
    return out


def public_phone_links(html, detail_url, cfg=None):
    soup = BeautifulSoup(html, 'html.parser')
    css = (cfg or {}).get('phone_selector', "a[href^='tel:']")
    # Never scrape arbitrary 8-digit strings from an HTML form: this is likely a
    # country code dropdown or user-supplied form, not seller contact details.
    seen = set()
    for el in soup.select(css):
        raw = el.get('href', '') if el.name == 'a' else ''
        if not raw.startswith('tel:'): continue
        num = re.sub(r'[^0-9+]','', raw[4:])
        digits = re.sub(r'\D','',num)
        if 8 <= len(digits) <= 15 and digits not in seen:
            seen.add(digits)
            yield num


def is_verification_page(html):
    """Detect an actual visible verification screen, not stray JS keywords.

    Cloudflare strings occur in application bundles and hidden widgets on
    otherwise-working pages. Do not mistake those for a blocking challenge.
    """
    if not html: return False
    soup = BeautifulSoup(html, 'html.parser')
    title = (soup.title.get_text(' ', strip=True) if soup.title else '').lower()
    visible = BeautifulSoup(str(soup), 'html.parser')
    for node in visible.select('script, style, template, noscript, svg'):
        node.decompose()
    text = visible.get_text(' ', strip=True).lower()
    if 'just a moment' in title and ('checking' in text or 'verify' in text or 'cloudflare' in text):
        return True
    if 'attention required' in title and ('cloudflare' in text or 'verify' in text):
        return True
    if visible.select_one('#challenge-form, #cf-challenge-running, #challenge-stage, #cf-chl-widget'):
        # A real challenge screen typically blocks the listing; a hidden widget
        # alongside a valid listing must not freeze all monitoring.
        if not visible.select("a[href*='/businesses-for-sale/']"):
            return True
    challenges = ('verify you are human', 'verification is required',
                  'checking your browser', 'please complete the security check')
    if any(k in text for k in challenges):
        if not visible.select("a[href*='/businesses-for-sale/']"):
            return True
    return False


class BrowserFetcher:
    """CDP optional mode uses a new private page in an already-authenticated profile.
    Does not automate login, reveal, CAPTCHA, premium or messaging.
    """
    def __init__(self, url):
        self.url, self.pw, self.browser, self.page = url, None, None, None
        self.detail_page = None
        self.last_detail_mode = ''
    def __enter__(self):
        from playwright.sync_api import sync_playwright
        self.pw = sync_playwright().start()
        self.browser = self.pw.chromium.connect_over_cdp(self.url, timeout=10000)
        self.page = self.browser.contexts[0].new_page()
        self.page.set_default_navigation_timeout(11000)
        return self
    def fetch(self, url):
        self.page.goto(url, wait_until='domcontentloaded', timeout=11000)
        check_owner_url(url, self.page.url)
        return self.page.content()

    def fetch_detail(self, url, plugin=None, cfg=None):
        """Read exact already-open seller tab first, then authenticated response,
        then one reusable background renderer if contact fields are JS-driven.
        Never navigate or focus a user-owned tab, and never treat a label as a phone.
        """
        context = self.browser.contexts[0]
        self.last_detail_mode = '未取得詳情'
        html = ''
        extractor = getattr(plugin, 'extract_contacts', None)

        def has_seller_phone(source):
            if not source or is_verification_page(source):
                return False
            try:
                if callable(extractor):
                    return bool(extractor(source, url, cfg or {}))
                return bool(list(public_phone_links(source, url, cfg)))
            except Exception:
                return False

        # Authenticated open tabs sometimes contain client-side seller details
        # which context.request.get() cannot reproduce (e.g. session tokens).
        target = urlsplit(url)
        for page in list(context.pages):
            if page == self.page or page == self.detail_page or page.is_closed():
                continue
            try:
                actual = urlsplit(page.url)
                if (actual.hostname in ('businessforsale.sg', 'www.businessforsale.sg')
                    and target.hostname in ('businessforsale.sg', 'www.businessforsale.sg')
                    and actual.path.rstrip('/') == target.path.rstrip('/')) or (
                    actual.hostname == target.hostname
                    and actual.path.rstrip('/') == target.path.rstrip('/')):
                    visible = page.content()
                    if has_seller_phone(visible):
                        self.last_detail_mode = '已開啟的登入詳情頁'
                        return visible
                    if visible and not is_verification_page(visible):
                        html = visible
            except Exception:
                pass

        try:
            response = context.request.get(url, timeout=5500, fail_on_status_code=False)
            if response.ok and 'text/html' in response.headers.get('content-type', '').lower():
                source = response.text()
                if has_seller_phone(source):
                    self.last_detail_mode = '已登入 HTTP 會話'
                    return source
                if source and not is_verification_page(source):
                    html = html or source
        except Exception:
            pass

        if self.detail_page is None or self.detail_page.is_closed():
            self.detail_page = context.new_page()
            self.detail_page.set_default_navigation_timeout(8500)
        try:
            self.detail_page.goto(url, wait_until='commit', timeout=8500)
        except PlaywrightTimeoutError:
            if urlsplit(self.detail_page.url).path != target.path:
                raise

        # A visible "Mobile Number" label is NOT proof the number has loaded.
        # Wait briefly for an actual contact, with bounded DOM reads. This is
        # especially important when Premium seller panels hydrate via JS.
        for attempt in range(12):
            try:
                candidate = self.detail_page.content()
                if has_seller_phone(candidate):
                    self.last_detail_mode = '背景渲染詳情頁'
                    return candidate
                if candidate and not is_verification_page(candidate):
                    html = candidate
            except Exception:
                pass
            if attempt == 11:
                break
            try:
                self.detail_page.wait_for_timeout(350)
            except AttributeError:  # Lightweight offline mock pages.
                break
            except Exception:
                break
        self.last_detail_mode = '未取到電話：背景/已開詳情/會話回應均未提供'
        return html

    def __exit__(self, *_):
        try:
            if self.detail_page and not self.detail_page.is_closed():
                self.detail_page.close()
            if self.page and not self.page.is_closed():
                self.page.close()
        finally:
            if self.pw: self.pw.stop()


class BitBrowserFetcher(BrowserFetcher):
    """Attach to the *running* BitBrowser profile, without /browser/open.

    Each plugin owns its CDP connection and its own private listing tab. It
    only reads existing detail tabs, never clicks/focuses/navigates them.
    """
    def __init__(self, cfg):
        self.cfg = cfg
        super().__init__(str(cfg.get('shared_cdp_endpoint') or ''))

    def _endpoint_candidates(self):
        """Resolve profile CDP *before* starting sync_playwright.

        sync_playwright runs its own asyncio loop on the worker thread. Calling
        asyncio.run() after start() raises RuntimeError even without concurrent
        work; this was the V1.50.1 fatal startup regression.
        """
        from bitbrowser_adapter import (_find_profile_by_seq, _query_port_endpoints,
                                        _resolve_api_token)
        shared = self.url  # Current core port, may be stale after manual restart.
        api = str(self.cfg.get('bitbrowser_api_url') or 'http://127.0.0.1:54345').rstrip('/')
        token = str(self.cfg.get('bitbrowser_api_token') or '').strip() or _resolve_api_token(self.cfg)
        seq = int(self.cfg.get('bitbrowser_seq') or 173)
        if not token:
            if shared: return [shared]
            raise RuntimeError('BitBrowser Token 未設定；請在統一設定填寫 Token')

        async def resolve():
            profile = await _find_profile_by_seq(api, token, seq)
            browser_id = str(profile.get('id') or '').strip()
            if not browser_id:
                raise RuntimeError('BitBrowser 找不到環境 %s 的 browser id' % seq)
            return await _query_port_endpoints(api, token, browser_id)

        try:
            endpoints = asyncio.run(resolve())
        except Exception:
            if shared: return [shared]
            raise
        endpoints = ([shared] if shared else []) + [x for x in endpoints if x != shared]
        if not endpoints:
            raise RuntimeError('BitBrowser %s 沒有可用 CDP 端口。請先手動打開該環境' % seq)
        return endpoints

    def __enter__(self):
        from playwright.sync_api import sync_playwright
        # Resolve local API first (outside Playwright's event loop).
        endpoints = self._endpoint_candidates()
        self.pw = sync_playwright().start()
        failures=[]
        for endpoint in endpoints:
            browser=None
            try:
                browser = self.pw.chromium.connect_over_cdp(endpoint, timeout=12000)
                if not browser.contexts: raise RuntimeError('缺少 BrowserContext')
                self.browser = browser
                # Do not spawn a new tab on monitor startup. Prefer same-origin
                # fetch in an already-open list tab; create one private tab only
                # when the existing page cannot supply a fresh listing.
                self.page = None
                self.detail_page = None
                self.url = endpoint
                self.last_list_url = ''
                self.last_fetch_mode = 'network'
                self.snapshot_until = 0.0
                return self
            except Exception as exc:
                failures.append(str(exc)[:130])
                if browser:
                    try: browser.close()
                    except Exception: pass
        # __exit__ is not called if a context manager's __enter__ fails.
        self.pw.stop()
        self.pw = None
        raise RuntimeError('BitBrowser CDP 連接失敗：'+'; '.join(failures[-2:]))

    def fetch(self, url):
        """Attach-only BitBrowser list monitoring; never make a new page."""
        connected = getattr(self.browser, 'is_connected', None)
        if not self.browser or (callable(connected) and not connected()):
            raise RuntimeError('[SITE-CDP-RECONNECT] BitBrowser 已斷線；等待重接已開環境')
        if self._open_list_page(url) is None:
            raise RuntimeError('[SITE-TAB-WAIT] 網站監控分頁已關閉／未開啟，等待手動打開；不自動建立分頁')
        fresh = self._read_list_without_new_tab(url)
        if fresh is not None:
            return fresh
        snapshot = self._open_list_snapshot(url)
        if snapshot is not None:
            return snapshot
        raise RuntimeError('已開網站列表暫未取得有效資料；不自動新增分頁')

    def _open_list_snapshot(self, url):
        """Read, never reload, a user's already-open filtered listing tab.

        This is a degraded fallback: its DOM is not guaranteed to reflect new
        posts. The GUI explicitly reports SNAPSHOT instead of live monitoring.
        """
        requested = urlsplit(url)
        for p in list(self.browser.contexts[0].pages):
            if p == self.page or p.is_closed():
                continue
            try:
                live = urlsplit(p.url)
                if live.hostname != requested.hostname and not (
                    {live.hostname, requested.hostname} <= {'businessforsale.sg','www.businessforsale.sg'}):
                    continue
                if live.path.rstrip('/') != requested.path.rstrip('/'):
                    continue
                check_owner_url(url, p.url)
                html = p.content()
                if is_verification_page(html): continue
                if self.cfg.get('plugin') == 'businessforsale_sg':
                    from site_plugins.businessforsale_sg import extract_listings
                    has_list = bool(extract_listings(html,url,self.cfg))
                else:
                    has_list = bool(generic_listings(html,url,self.cfg))
                if has_list:
                    self.last_fetch_mode = 'snapshot'
                    return html
            except Exception:
                continue
        return None

    def _open_list_page(self, url):
        """Read only: select an existing user-owned filtered list page."""
        want = urlsplit(url)
        for p in list(self.browser.contexts[0].pages):
            if p == self.page or p == self.detail_page or p.is_closed():
                continue
            try:
                have = urlsplit(p.url)
                allowed = ({'www.businessforsale.sg', 'businessforsale.sg'}
                           if want.hostname in ('www.businessforsale.sg', 'businessforsale.sg')
                           else {want.hostname})
                if have.hostname not in allowed:
                    continue
                if have.path.rstrip('/') != want.path.rstrip('/'):
                    continue
                check_owner_url(url, p.url)
                return p
            except Exception:
                continue
        return None

    def _read_list_without_new_tab(self, url):
        """Use browser-session fetch; never reload or focus the user's tab."""
        existing = self._open_list_page(url)
        if existing is None:
            return None
        try:
            data = existing.evaluate('''async (u) => {
              const c = new AbortController();
              const timer = setTimeout(() => c.abort(), 6000);
              try {
                const resp = await fetch(u, {credentials: 'include', cache:'no-store', signal:c.signal});
                if (!resp.ok) return null;
                return {url:resp.url, html: await resp.text()};
              } finally {clearTimeout(timer)}
            }''', url)
            if not isinstance(data, dict) or not data.get('html'):
                return None
            check_owner_url(url, data.get('url',''))
            html = data['html']
            if is_verification_page(html):
                return None
            if self.cfg.get('plugin') == 'businessforsale_sg':
                from site_plugins.businessforsale_sg import extract_listings
                valid = bool(extract_listings(html,url,self.cfg))
            else:
                valid = bool(generic_listings(html,url,self.cfg))
            if valid:
                self.last_fetch_mode='browser-fetch'
                return html
        except Exception:
            pass
        return None

    def open_details(self, cfg):
        """Return rendered DOM from previously opened seller detail tabs."""
        target_host = urlsplit(cfg['url']).hostname
        plugin = cfg.get('plugin') or ''
        rows=[]
        for page in list(self.browser.contexts[0].pages):
            if page == self.page or page == self.detail_page or page.is_closed(): continue
            try:
                url = page.url
                parsed = urlsplit(url)
                if parsed.hostname != target_host and not (plugin == 'businessforsale_sg' and
                        parsed.hostname in ('www.businessforsale.sg','businessforsale.sg')):
                    continue
                if plugin == 'businessforsale_sg':
                    if not re.fullmatch(r'/businesses-for-sale/[a-z0-9-]+-\d+/?', parsed.path, re.I): continue
                elif parsed.path == urlsplit(cfg['url']).path:
                    continue
                html=page.content()
                rows.append((url,html))
            except Exception:
                continue
        return rows


class SiteManager:
    def __init__(self, store):
        self.store = store
        self.out = queue.Queue(maxsize=2000)
        self.stop_event = threading.Event()
        self.threads = []
        self.seen = store.read_seen()
        self.active = False

    def emit(self, event, **kwargs):
        try: self.out.put_nowait({'event':event, **kwargs})
        except queue.Full: pass

    def start(self, configs):
        if self.active: return
        self.stop_event.clear()
        self.active = True
        house852_count = 0
        for cfg in configs:
            if not cfg['enabled']: continue
            # Stagger HTTP-only 852 jobs WITHOUT sleeping on the Tk GUI thread.
            is_852 = (cfg.get('mode') == 'http' and
                      urlsplit(cfg.get('url', '')).hostname in ('852.house','www.852.house'))
            delay = house852_count * 0.35 if is_852 else 0.0
            if is_852: house852_count += 1
            t = threading.Thread(target=self._worker, args=(dict(cfg), delay), name='Site-'+cfg['id'], daemon=True)
            self.threads.append(t)
            t.start()

    def is_alive(self):
        return self.active and any(t.is_alive() for t in self.threads)

    def halt(self):
        self.active = False
        self.stop_event.set()
        # Workers may finish the current bounded network fetch; never block Tk.

    def _scan_open_detail_tabs(self, fetcher, plugin, cfg, manual_seen):
        if not fetcher or not hasattr(fetcher, 'open_details') or plugin is None:
            return
        extractor = getattr(plugin, 'extract_contacts', None)
        if not callable(extractor): return
        for url, html in fetcher.open_details(cfg):
            if url in manual_seen: continue
            accept = getattr(plugin, 'accept_detail', None)
            if callable(accept) and not accept(html, url, cfg): continue
            contacts = [c for c in extractor(html, url, cfg)
                        if isinstance(c, dict) and c.get('phone')]
            if not contacts: continue  # user may reveal after opening the page
            m = re.search(r'-([0-9]+)/?$', urlsplit(url).path)
            ident = m.group(1) if m else url.split('#')[0]
            item = {'id':ident, 'site_id':cfg['id'], 'site_name':cfg['name'],
                    'title':'已開啟的賣家詳情', 'url':url, 'phone':str(contacts[0]['phone']),
                    'contact':str(contacts[0].get('name') or '未知'),
                    'extra_contacts':contacts[1:], 'status':'已取登入頁號碼'}
            manual_seen.add(url)
            self.emit('new', id=cfg['id'], data=item)
            self.emit('log', id=cfg['id'], text='已登入詳情頁取號 '+str(item['phone']))

    def _worker(self, cfg, initial_delay=0.0):
        if initial_delay and self.stop_event.wait(initial_delay): return
        sid = cfg['id']
        gates = cfg.get('_startup_api_events') or []
        if cfg.get('mode') == 'bitbrowser' and gates:
            self.emit('state', id=sid, text='等待28Hse業主＋最新API驗證完成；不搶用CDP')
            while not self.stop_event.is_set() and not all(e.is_set() for e in gates):
                paused = cfg.get('_startup_paused_states') or {}
                if any(paused.get(k) for k in cfg.get('_startup_selected_lanes', [])):
                    self.emit('state', id=sid, text='28Hse已有監控路徑暫停；獨立啟動本插件')
                    break
                self.stop_event.wait(0.5)
            if self.stop_event.is_set(): return
        was_seeded = sid in self.seen
        known = set(self.seen.get(sid, set()))
        plugin = None
        try:
            plugin = load_plugin(cfg['plugin']) if cfg.get('plugin') else None
        except Exception as exc:
            self.emit('error', id=sid, text='插件加載失敗：'+str(exc)); return
        fetcher = None
        try:
            if cfg['mode'] == 'cdp':
                fetcher = BrowserFetcher(cfg['cdp_endpoint'])
            elif cfg['mode'] == 'bitbrowser':
                fetcher = BitBrowserFetcher(cfg)
            if fetcher:
                attempts = 0
                while not self.stop_event.is_set():
                    try:
                        fetcher.__enter__()
                        break
                    except Exception as startup_error:
                        attempts += 1
                        self.emit('error', id=sid, text='瀏覽器 CDP 初始化失敗（%d/3）：%s' %
                                  (attempts, str(startup_error)[:125]))
                        if attempts >= 3 and cfg['mode'] != 'bitbrowser':
                            self.emit('state', id=sid,
                                      text='CDP 持續無法連接；本插件已停止，不影響 28／730')
                            return
                        if cfg['mode'] == 'bitbrowser':
                            self.emit('state', id=sid,
                                      text='等待手動打開 BitBrowser；自動重接現有環境，不開新分頁')
                        if self.stop_event.wait(min(30, attempts*10)):
                            return
                if self.stop_event.is_set(): return
            fetch = fetcher.fetch if fetcher else fetch_http
            failures = 0
            manual_seen = set()
            while not self.stop_event.is_set():
                try:
                    # Capture a seller's manually opened, already-rendered page
                    # even when the listing predates this monitor's baseline.
                    self._scan_open_detail_tabs(fetcher, plugin, cfg, manual_seen)
                    html = fetch(cfg['url'])
                    if is_verification_page(html):
                        self.emit('error', id=sid, text='此網站需要人工完成驗證；請到 BitBrowser 中完成，暫停列表請求 30 秒')
                        # Keep scanning manually opened seller tabs while the
                        # background listing tab is waiting for verification.
                        for _ in range(6):
                            if self.stop_event.wait(5): break
                            self._scan_open_detail_tabs(fetcher, plugin, cfg, manual_seen)
                        if self.stop_event.is_set(): break
                        continue
                    results = (plugin.extract_listings(html,cfg['url'],cfg) if plugin
                               else generic_listings(html,cfg['url'],cfg))
                    rows = dedup_listings(results)
                    if not rows: raise ValueError('沒有找到帖子；請檢查 URL、篩選條件與 CSS 選擇器')
                    # Only IDs from this successfully fetched source=2 owner list
                    # can count as verified when the detail omits Direct Seller.
                    if cfg.get('plugin') == 'businessforsale_sg' and getattr(fetcher, 'last_fetch_mode', '') != 'snapshot':
                        cfg['_verified_listing_ids'] = {r['id'] for r in rows}
                    # On first observation of a new site, seed a baseline only.
                    if not was_seeded:
                        known.update(r['id'] for r in rows)
                        self.seen[sid] = set(known)
                        self.store.write_seen(self.seen)
                        was_seeded = True
                        self.emit('log', id=sid, text='建立基線 %d 條（不報舊帖）' % len(rows))
                    else:
                        new = [r for r in rows if r['id'] not in known]
                        for item in reversed(new):
                            # Never fetch a detail page twice; it can be empty/premium.
                            if self.stop_event.is_set(): break
                            known.add(item['id'])
                            item['site_id'], item['site_name'] = sid, cfg['name']
                            item['phone'] = ''
                            item['status'] = '未揭號'
                            try:
                                self.emit('log', id=sid, text='[AUTO-DETAIL] 新帖 '+str(item['id'])+' 背景讀取詳情')
                                # Do not navigate the site's listing renderer to
                                # each new post. Detail uses authenticated HTTP
                                # and an owned reusable background page if needed.
                                detail = (fetcher.fetch_detail(item['url'], plugin, cfg) if fetcher
                                          else fetch_http(item['url']))
                                if plugin and callable(getattr(plugin,'accept_detail', None)) and not plugin.accept_detail(detail, item['url'], cfg):
                                    self.emit('log', id=sid, text='略過非直接業主頁面 '+item['url'][:120])
                                    continue
                                if plugin and callable(getattr(plugin,'extract_contacts', None)):
                                    contacts = plugin.extract_contacts(detail,item['url'],cfg)
                                else:
                                    contacts = [{'phone':x} for x in public_phone_links(detail,item['url'],cfg)]
                                phones = [x for x in contacts if isinstance(x,dict) and x.get('phone')]
                                if phones:
                                    item['phone'] = str(phones[0]['phone'])
                                    item['contact'] = str(phones[0].get('name') or item['contact'])
                                    item['extra_contacts'] = phones[1:]
                                    item['status'] = '已獲公開號碼'
                                elif plugin and callable(getattr(plugin, 'contact_diagnostic', None)):
                                    item['status'] = '未揭號：' + str(plugin.contact_diagnostic(detail))[:95]
                                elif 'Premium Only' in detail or 'seller phone and email locked' in detail.lower():
                                    item['status'] = '會員限定／未揭號'
                            except Exception as exc:
                                self.emit('log', id=sid, text='詳情失敗：' + str(exc)[:120])
                            self.seen[sid] = set(known)
                            self.store.write_seen(self.seen)
                            self.emit('new', id=sid, data=item)
                    failures = 0
                    if fetcher and getattr(fetcher, 'last_fetch_mode', '') == 'snapshot':
                        self.emit('state', id=sid, text='僅讀取已開頁面快照｜需手動刷新｜%d 條' % len(rows))
                    else:
                        self.emit('state', id=sid, text='監控中｜%d 條｜每 %gs' %(len(rows),cfg['interval']))
                    if self.stop_event.wait(cfg['interval']): break
                except Exception as exc:
                    failures += 1
                    self.emit('error', id=sid, text=str(exc)[:180])
                    # Only reattach an EXISTING BitBrowser profile. Never
                    # start/open the browser or create a new monitoring tab.
                    if cfg['mode'] == 'bitbrowser' and fetcher is not None:
                        disconnected = False
                        try:
                            disconnected = not fetcher.browser.is_connected()
                        except Exception:
                            disconnected = True
                        if disconnected:
                            try: fetcher.__exit__(None, None, None)
                            except Exception: pass
                            fetcher = BitBrowserFetcher(cfg)
                            try:
                                fetcher.__enter__()
                                fetch = fetcher.fetch
                                self.emit('log', id=sid, text='[SITE-REATTACH] 已重接現有BitBrowser，待原列表頁手動開啟')
                            except Exception:
                                pass
                    if self.stop_event.wait(min(30, max(1.0, cfg['interval']) * (2 ** min(4, failures-1)))): break
        except Exception as exc:
            self.emit('error', id=sid, text='無法初始化網站瀏覽器：'+str(exc)[:240])
        finally:
            if fetcher:
                try: fetcher.__exit__(None,None,None)
                except Exception: pass
            if cfg.get('mode') == 'http':
                _close_http_session()
            if self.stop_event.is_set():
                self.emit('state', id=sid, text='已停止')
