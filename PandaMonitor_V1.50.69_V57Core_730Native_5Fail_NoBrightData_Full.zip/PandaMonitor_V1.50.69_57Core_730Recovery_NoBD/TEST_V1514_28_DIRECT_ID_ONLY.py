# -*- coding: utf-8 -*-
"""Offline contract tests. Must not contact a live site or expose owner phones."""
from __future__ import annotations
import threading
from types import SimpleNamespace
from hse28_direct_phone import make_direct_expression, valid_listing_id
from panda28_core import App

URL='https://www.28hse.com/rent/flat/property-3125421'
assert valid_listing_id('3125421')
for bad in ('', '../etc', 'not-an-id', '123', '12345678901'):
    assert not valid_listing_id(bad)
e=make_direct_expression('3125421',URL)
assert 'ad_id:pid' in e and 'user_action:\'phone\'' in e
assert 'uid_code' not in e and 'timeStamp' not in e
assert "fetch('https://www.28hse.com/property/detail/doaction'" in e
assert 'Page.navigate' not in e and 'Target.createTarget' not in e and 'fetch(referrer' not in e
try:make_direct_expression('3125421', 'https://evil.example/rent/flat/property-3125421')
except ValueError:pass
else:raise AssertionError('unexpected origin accepted')

class FakeCDP:
    def __init__(self, reply):
        self.reply=reply
        self.calls=[]
    def call(self, name, args, timeout=None):
        self.calls.append((name,args,timeout))
        return {'result':{'value':self.reply}}

def fake_app():
    app=object.__new__(App)
    app.logged=[]
    app.write=app.logged.append
    app.report=[]
    app.result=lambda k,name,number,url,**kw: (app.report.append((k,name,number,url,kw)) or (True,'OK'))
    app.bg=lambda fun,*args: app.logged.append('secondary triggered')
    app.publish_secondary_phone=lambda *args:None
    app.set_listing_status=lambda *args: app.logged.append(str(args))
    app.phone_api_allow_detail=False
    app.running=True
    app.cdp_pending={'rent':set(),'buy':set()}
    app.lock=threading.Lock()
    app.cdp_jobs={'rent': SimpleNamespace(put=lambda x: (_ for _ in ()).throw(AssertionError('created CDP detail job')))}
    return app

app=fake_app()
c=FakeCDP({'ok':True,'rows':[{'name':'Mrs Sample','phone':'98765432'}], 'status':200,'elapsedMs':28})
t,o,why=app.http_phone_direct(c,'rent',URL)
assert (t,o)==(True,True),why
assert app.report[0][2]=='98765432'
assert len(c.calls)==1 and c.calls[0][0]=='Runtime.evaluate'
assert 'uid_code' not in c.calls[0][1]['expression']
assert any('[28-DIRECT]' in str(x) for x in app.logged)
assert app.queue_cdp_fallback('rent', URL) is False, 'no tab mode must block fallback'

for status,blocked,terminal in ((429,True,True),(403,True,True),(200,False,False)):
    app=fake_app()
    c=FakeCDP({'ok':False,'rows':[], 'blocked':blocked,'status':status,'reason':'unavailable'})
    assert app.http_phone_direct(c,'rent',URL)[0]==terminal
    assert not app.report

app=fake_app()
app.result=lambda *a,**kw: (False,'duplicated')
t,o,_=app.http_phone_direct(FakeCDP({'ok':True,'rows':[{'phone':'98765432'}]}),'rent',URL)
assert t and not o, 'duplicate phone must NOT open detail'
app=fake_app()
app.run_id=7
app.http_retry_attempts={'rent': {}, 'buy': {}}
app.inflight={'rent': {'3125421'}, 'buy': set()}
app.cdp_fault_event=threading.Event()
app.no_detail_phone_fallback('rent',URL,1.25,'empty',7)
assert any('[28-HTTP-RETRY]' in str(line) for line in app.logged)
app.no_detail_phone_fallback('rent',URL,1.25,'empty again',7)
assert any('[28-NO-DETAIL]' in str(line) for line in app.logged)
assert '3125421' not in app.inflight['rent']

print('PASS V1.50.14: direct ad_id only, no detail, dedup, fallback, block/429, origin, logging')
