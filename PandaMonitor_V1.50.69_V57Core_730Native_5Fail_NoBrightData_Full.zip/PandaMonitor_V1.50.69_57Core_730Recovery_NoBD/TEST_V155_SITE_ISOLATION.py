# -*- coding: utf-8 -*-
"""Offline regression for V1.50.5: independent HTTP sessions and CDP retry."""
import unittest
import threading
import tempfile
from pathlib import Path
from unittest.mock import patch
from concurrent.futures import ThreadPoolExecutor
from types import SimpleNamespace
import site_engine

URL_RENT=('https://852.house/zh/rent?price=0%3B90000&grossarea=0%3B90000'
          '&features%5B0%5D=%E6%A5%AD%E4%B8%BB%E7%9B%A4&order=publishtime%7Cdesc')
URL_BUY=URL_RENT.replace('/zh/rent?', '/zh/buy?')

class Tests(unittest.TestCase):
    def test_filtered_redirect_rejected(self):
        with self.assertRaisesRegex(ValueError, '篩選'):
            site_engine.check_owner_url(URL_RENT, 'https://852.house/zh/rent?order=publishtime%7Cdesc')
        with self.assertRaisesRegex(ValueError, '其他頁面'):
            site_engine.check_owner_url(URL_BUY, 'https://852.house/zh/rent')
        site_engine.check_owner_url(URL_BUY, URL_BUY)

    def test_852_threads_connect_independently_and_keep_session(self):
        barrier = threading.Barrier(2, timeout=2.5)
        session_threads = []
        class FakeResponse:
            status_code=200
            headers={'Content-Type':'text/html; charset=utf-8'}
            content=b'<html><p>owner list</p></html>'
            text='<html><p>owner list</p></html>'
            def __init__(self,url): self.url=url
            def raise_for_status(self): pass
        def mocked_get(session,url,**kwargs):
            session_threads.append((threading.current_thread().name, id(session)))
            # Both request calls must be allowed to enter simultaneously.
            barrier.wait()
            return FakeResponse(url)
        def one(url):
            try:return site_engine.fetch_http(url)
            finally: site_engine._close_http_session()
        import requests
        with patch.object(requests.Session,'get',mocked_get):
            with ThreadPoolExecutor(max_workers=2) as pool:
                a=pool.submit(one, URL_BUY)
                b=pool.submit(one, URL_RENT)
                self.assertIn('owner list',a.result(timeout=4))
                self.assertIn('owner list',b.result(timeout=4))
        self.assertEqual(len({v[1] for v in session_threads}),2)

    def test_bitbrowser_attach_retries_without_restarting_28(self):
        cfg=dict(site_engine.DEFAULT_BFS,enabled=True,interval=0.1)
        class FakeBrowser:
            count=0
            def __init__(self,cfg): pass
            def __enter__(self):
                self.__class__.count+=1
                if self.count<3: raise TimeoutError('CDP connect timeout')
                return self
            def fetch(self,url):
                mgr.stop_event.set()
                return '<a href="/businesses-for-sale/owner-listing-42769">Seller</a>'
            def open_details(self,cfg): return []
            def __exit__(self,*args): pass
        with tempfile.TemporaryDirectory() as temp:
            store=site_engine.SiteConfigStore(temp)
            mgr=site_engine.SiteManager(store)
            # No baseline notification; only testing recoverable connection errors.
            orig_wait=mgr.stop_event.wait
            def quick_wait(seconds): return orig_wait(.001)
            with patch('site_engine.BitBrowserFetcher',FakeBrowser),patch.object(mgr.stop_event,'wait',side_effect=quick_wait):
                mgr._worker(cfg)
            self.assertEqual(FakeBrowser.count,3)
            events=list(mgr.out.queue)
            self.assertEqual(sum(e['event']=='error' for e in events),2)
            self.assertTrue(any(e['event']=='log' and '基線' in e['text'] for e in events))

if __name__=='__main__':unittest.main(verbosity=2)
