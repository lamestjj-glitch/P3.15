﻿param([switch]$DiagnoseOnly)
# PowerShell 5.1 compatible. Never change the monitoring engines or saved settings.
$ErrorActionPreference = 'Continue'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$base = if ($env:LOCALAPPDATA) { $env:LOCALAPPDATA } elseif ($env:TEMP) { $env:TEMP } else { $root }
$logs = Join-Path $base 'PandaMonitor_28Hse_House730\logs'
New-Item -ItemType Directory -Path $logs -Force -ErrorAction SilentlyContinue | Out-Null
$log = Join-Path $logs $(if ($DiagnoseOnly) { 'python_diag.log' } else { 'start_console.log' })
try { Set-Content -LiteralPath $log -Value ('==== Startup '+(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')+' ====') -Encoding UTF8 -ErrorAction Stop } catch { $log = Join-Path $root $(if ($DiagnoseOnly) { 'python_diag.log' } else { 'start_console.log' }); Set-Content -LiteralPath $log -Value ('==== Startup '+(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')+' ====') -Encoding UTF8 }
function Say([string]$msg) {
    Write-Host $msg
    try { Add-Content -LiteralPath $log -Value $msg -Encoding UTF8 -ErrorAction Stop } catch { }
}
Say "Program dir: $root"
Say "Log file: $log"
Set-Location -LiteralPath $root
if (-not $DiagnoseOnly) {
    foreach ($file in @('bootstrap.py','launch.py','unified_gui.py','requirements.txt')) {
        if (-not (Test-Path -LiteralPath (Join-Path $root $file) -PathType Leaf)) {
            Say "ERROR: Missing $file. Extract the entire ZIP before running."
            exit 33
        }
    }
}

# List launchers once, then look up registered installations and conventional Windows paths.
$script:candidates = New-Object System.Collections.ArrayList
$script:keys = @{}
function Add-Candidate([string]$exe, [string[]]$prefix, [string]$origin) {
    if ([string]::IsNullOrWhiteSpace($exe)) { return }
    $actual = $null
    if ($exe -match '[\\/]') {
        try { if (Test-Path -LiteralPath $exe -PathType Leaf) { $actual = [System.IO.Path]::GetFullPath($exe) } } catch { }
    } else {
        $cmd = Get-Command -Name $exe -CommandType Application -ErrorAction SilentlyContinue | Select-Object -First 1
        if ($cmd) { $actual = $cmd.Source }
    }
    if (-not $actual) { return }
    $prefix = [string[]]@($prefix | Where-Object { $null -ne $_ -and $_ -ne '' })
    $key = ($actual.ToLowerInvariant() + '|' + ($prefix -join '|'))
    if ($script:keys.ContainsKey($key)) { return }
    $script:keys[$key] = $true
    [void]$script:candidates.Add([pscustomobject]@{Exe=$actual; Args=$prefix; Origin=$origin})
}

# User override, when they know the Python executable path.
if ($env:PANDA_PYTHON) { Add-Candidate $env:PANDA_PYTHON @() 'PANDA_PYTHON override' }
if ($env:VIRTUAL_ENV) { Add-Candidate (Join-Path $env:VIRTUAL_ENV 'Scripts\python.exe') @() 'active venv' }
Add-Candidate (Join-Path $root '.venv\Scripts\python.exe') @() 'project venv'

# Installed Python 3.13 is preferred over pre-release versions of 3.15.
foreach ($ver in @('3.13','3.12','3.14','3.15')) {
    $digits = $ver.Replace('.', '')
    Add-Candidate 'py' @("-$ver") "Python launcher $ver"
    foreach ($searchRoot in @($env:LOCALAPPDATA, $env:ProgramFiles, ${env:ProgramFiles(x86)})) {
        if ([string]::IsNullOrWhiteSpace($searchRoot)) { continue }
        Add-Candidate (Join-Path $searchRoot "Programs\Python\Python$digits\python.exe") @() "common path $ver"
        Add-Candidate (Join-Path $searchRoot "Python$digits\python.exe") @() "common path $ver"
        Add-Candidate (Join-Path $searchRoot "Python\Python$digits\python.exe") @() "common path $ver"
    }
    foreach ($regBase in @('HKCU:\Software\Python\PythonCore','HKLM:\SOFTWARE\Python\PythonCore','HKLM:\SOFTWARE\WOW6432Node\Python\PythonCore')) {
        $installKey = "$regBase\$ver\InstallPath"
        try {
            if (-not (Test-Path -LiteralPath $installKey)) { continue }
            $item = Get-Item -LiteralPath $installKey -ErrorAction Stop
            $path = $item.GetValue('ExecutablePath', $null)
            if ($path) { Add-Candidate $path @() "registry $ver" }
            $folder = $item.GetValue('', $null)
            if ($folder) { Add-Candidate (Join-Path $folder 'python.exe') @() "registry $ver" }
        } catch { }
    }
}
# Generic commands can find py-manager installs and nonstandard versions >=3.12.
Add-Candidate 'py' @('-3') 'Python launcher default 3.x'
Add-Candidate 'python' @() 'PATH python'
Add-Candidate 'python3' @() 'PATH python3'
# Explicit legacy Python launcher path if it is not on PATH.
if ($env:WINDIR) { Add-Candidate (Join-Path $env:WINDIR 'py.exe') @('-3') 'Windows launcher' }

Say ("DISCOVERED: {0} Python candidate(s)" -f $script:candidates.Count)
$chosen = $null
# Invoke a Python file, not `-c` with embedded double quotes.
# Windows PowerShell 5.1 strips embedded quotes in native process arguments
# and can corrupt perfectly valid inline Python into SyntaxError.
$probeFile = Join-Path $root 'python_runtime_probe.py'
if (-not (Test-Path -LiteralPath $probeFile -PathType Leaf)) {
    Say 'ERROR: python_runtime_probe.py is missing. Extract the complete ZIP.'
    exit 33
}
foreach ($candidate in $script:candidates) {
    $exe = [string]$candidate.Exe
    $prefix = [string[]]@($candidate.Args)
    $label = "$exe $($prefix -join ' ')"
    Say "TRY: $($candidate.Origin): $label"
    try {
        # Keep output visible in diagnostics, including actual module or DLL errors.
        $outputLines = & $exe @prefix $probeFile 2>&1
        $code = $LASTEXITCODE
        $message = ((@($outputLines) | ForEach-Object { [string]$_ }) -join ' ').Trim()
        if ($message.Length -gt 850) { $message = $message.Substring(0,850) + '...' }
        if ($code -eq 0 -and $message -match 'TK_OK=') {
            Say "FOUND: $label | $message"
            $chosen = $candidate
            break
        }
        Say "SKIP: exit=$code $message"
    } catch {
        Say "SKIP: probe error: $($_.Exception.Message)"
    }
}
if (-not $chosen) {
    Say 'ERROR: No working Python 3.12+ with Tkinter/Tcl found.'
    Say 'ACTION: Run INSTALL_PYTHON_313.bat (optional installer) or install Python 3.13 (64-bit) with Tcl/Tk from python.org.'
    Say 'ACTION: You can also set PANDA_PYTHON to the full python.exe path and start again.'
    Say "DIAGNOSTICS: $log"
    exit 34
}
$python = [string]$chosen.Exe
$prefix = [string[]]@($chosen.Args)
Say "SELECTED: $python $($prefix -join ' ')"
if ($DiagnoseOnly) { Say 'DIAG_OK: Supported interpreter and Tcl/Tk detected.'; exit 0 }
Say 'BOOTSTRAP: Running application dependency checks...'
try {
    & $python @prefix -u (Join-Path $root 'bootstrap.py')
    $exitCode = $LASTEXITCODE
} catch {
    Say "ERROR: Could not start bootstrap: $($_.Exception.Message)"
    exit 35
}
if ($null -eq $exitCode) { $exitCode = 35 }
if ($exitCode -ne 0) { Say "ERROR: Bootstrap exit=$exitCode; review $log and startup.log"; exit $exitCode }
Say 'GUI closed successfully.'
exit 0
