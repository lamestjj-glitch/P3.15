# -*- coding: utf-8 -*-
"""Offline regression test; does not send WA or contact external sites."""
import threading
import time
import os
import sys
from unittest.mock import patch

from api_recheck import RecheckSchedule
from wa_female_filter import (DEFAULT_FEMALE_NAMES, female_name_eligible, parse_female_names)
from unified_gui import UnifiedApp
from panda28_core import App as Panda28App

names = parse_female_names(DEFAULT_FEMALE_NAMES)
for female in ('陳小姐', '王女士', '張姐', '姐', 'Mrs Chan', 'Ms. Wong', 'miss Lee',
               'Alice', 'Mandy Chan', 'LILY TANG'):
    ok, why = female_name_eligible(female, names)
    assert ok, (female, why)
for excluded in ('', '未知', '未提供', '业主', 'Mr Andy', '王先生', 'Alice先生',
                 'Mr. Alice', 'Alex', 'Malice', '姓陳', 'John', 'Annabelle', 'owner'):
    ok, why = female_name_eligible(excluded, names)
    assert not ok, (excluded, why)
assert female_name_eligible('Jenny Wong', parse_female_names('Jenny'))[0]
assert not female_name_eligible('Mandy', parse_female_names('Alice'))[0]
for bad in ('', 'name with space', 'Alice, 66'):
    try:
        parse_female_names(bad)
    except ValueError:
        continue
    raise AssertionError('did not reject: '+bad)

s = RecheckSchedule(True, now=100.)
assert s.kind(False, 109) == 'normal'
assert s.kind(True, 107.9) == 'normal'
assert s.kind(True, 108) == 'extra'
s.completed('extra', 108.5)
assert s.kind(True, 114) == 'normal'
assert s.kind(True, 116.5) == 'extra'
assert s.wait(30, True, 114) == 2.5
s.enabled = False
assert s.kind(True, 9999) == 'normal'
assert s.wait(30, True, 114) == 30

if sys.platform.startswith('linux') and not os.path.exists('/tmp/.X11-unix/' + 'X' + os.environ.get('DISPLAY', ':0').split(':')[-1].split('.')[0]):
    print('PASS: name-list and 8s scheduler tests (GUI integration requires xvfb-run)')
    sys.exit(0)

app = UnifiedApp()
app.withdraw()
app.update()
# Tests must not depend on a previous run's imported 10k-name TXT.
app.wa_female_name_set = names
app.wa_enable.set(True)
app.wa_start.set('00:00')
app.wa_end.set('00:00')
app.wa_730_enable.set(True)

# First prove unknown and male candidates cannot reach any sender.
url = 'https://www.28hse.com/rent/apartment/property-9990990'
with patch.object(Panda28App, 'maybe_whatsapp', side_effect=AssertionError('WA must not run')):
    app.note_wa_contact(url, 'Mr Andy', final=True)
    assert app.maybe_whatsapp('91234567', url, '28租盤') is None
url2 = 'https://www.28hse.com/buy/apartment/property-9990991'
app.note_wa_contact(url2, '未知', final=True)
with patch.object(Panda28App, 'maybe_whatsapp', side_effect=AssertionError('WA must not run')):
    assert app.maybe_whatsapp('91234567', url2, '28售盤') is None

# Only a name explicitly matched to this phone can pass the scheduler.
url3 = 'https://www.28hse.com/rent/apartment/property-9990992'
app.note_wa_contact(url3, 'Mandy', final=True)
app.note_wa_phone_contact(url3, '91234567', 'Mandy')
with patch.object(Panda28App, 'maybe_whatsapp', return_value='eligible') as sender:
    assert app.maybe_whatsapp('91234567', url3, '28租盤') == 'eligible'
    assert sender.call_count == 1

# Unknown first: delayed *phone-matched* name backfill must resolve before greeting.
url4='https://www.28hse.com/rent/apartment/property-9990993'
app.note_wa_contact(url4, '未知', final=False)
def later_name():
    time.sleep(.06)
    app.note_wa_contact(url4, '陳小姐', final=True)
    app.note_wa_phone_contact(url4, '91234567', '陳小姐')
t=threading.Thread(target=later_name)
t.start()
with patch.object(Panda28App, 'maybe_whatsapp', return_value='eligible') as sender:
    assert app.maybe_whatsapp('91234567', url4, '28租盤') == 'eligible'
    assert sender.call_count == 1
t.join()

# 730 unknown cannot reach WA even though its auto greet toggle is ON.
with patch.object(app, 'whatsapp_send', side_effect=AssertionError('730 WA must not run')):
    app._house_wa_job('91234567','https://www.house730.com/buy/s1u14/',None,'未知')
# GUI has explicit enable and cached settings; no Windows-only action required.
assert app.api_recheck_enabled
assert app.api_recheck_var.get()
assert app.wa_female_name_set == names
app.destroy()
print('PASS: 8s serial rechecks, 28/730 female-name WA gate, unknown/male skip, delayed backfill, GUI')
