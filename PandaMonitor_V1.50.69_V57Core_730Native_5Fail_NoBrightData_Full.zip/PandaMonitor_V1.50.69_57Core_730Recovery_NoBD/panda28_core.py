import json, os, re, threading, time, tkinter as tk, queue, socket, random
from collections import deque
from contextlib import nullcontext
from tkinter import ttk, messagebox
from urllib import request, parse

# Local BitBrowser / Chrome debugger calls must not travel through a system proxy.
_LOCAL_OPENER = request.build_opener(request.ProxyHandler({}))
from datetime import datetime
from contact_visible import extract_visible_phones
from panda28_api import capture_template, api_snapshot, ApiError, existing_list_url_kind
from listing_incremental import ListingDeltaCache
from api_cadence import parse_api_cadence
from api_recheck import RecheckSchedule
from hse28_429_cooldown import RateCooldown
from hse28_adaptive import AdaptiveListScheduler
from windows_session_state import is_locked as windows_session_locked


class CDP:
    def __init__(self, url):
        self.url = url
        self.ws = None
        self.i = 0
        self.lock = threading.Lock()
        self.deadline = None  # monotonic hard per-detail budget
        self.event_handler = None  # optional Network diagnostic callback for one-time template capture
        self.dead = False
        self.timeout_streak = 0

    def connect(self):
        import websocket
        self.ws = websocket.create_connection(self.url, timeout=3.5, suppress_origin=True)
        self.dead = False
        self.timeout_streak = 0

    def call(self, m, p=None, timeout=None):
        # Each command has one overall deadline, not one timeout per received CDP event.
        import websocket
        with self.lock:
            if self.dead:
                raise ConnectionError("CDP_TRANSPORT_LOST:%s (socket retired)" % m)
            end = time.monotonic() + (3.5 if timeout is None else max(0.05, float(timeout)))
            if self.deadline is not None:
                end = min(end, self.deadline)
            def remaining():
                left = end - time.monotonic()
                if left <= 0:
                    raise TimeoutError("CDP_CALL_DEADLINE:%s" % m)
                self.ws.settimeout(max(.001, left))
            self.i += 1
            i = self.i
            try:
                remaining()
                self.ws.send(json.dumps({"id": i, "method": m, "params": p or {}}))
                while True:
                    remaining()
                    x = json.loads(self.ws.recv())
                    if x.get("id") is None and self.event_handler is not None:
                        try: self.event_handler(x)
                        except Exception: pass
                    if x.get("id") == i:
                        self.timeout_streak = 0
                        if "error" in x:
                            raise RuntimeError(str(x["error"]))
                        return x.get("result", {})
            except (websocket.WebSocketTimeoutException, socket.timeout) as exc:
                # A timed-out request may still complete later, leaving a reply
                # on this websocket with an unknown lifecycle. Never run the
                # next CDP command on the same ambiguous socket: reconnect to
                # the SAME existing target using its latest /json descriptor.
                self.timeout_streak += 1
                self.dead = True
                raise TimeoutError("CDP_CALL_TIMEOUT:%s" % m) from exc
            except (websocket.WebSocketConnectionClosedException, ConnectionError, OSError) as exc:
                self.dead = True
                raise ConnectionError("CDP_TRANSPORT_LOST:%s" % m) from exc

    def pump_event(self, timeout=0.30):
        """Receive Network CDP events without a Runtime.evaluate roundtrip.

        A quiet websocket is NORMAL when no network request is outstanding;
        unlike a CDP command timeout, the absence of unsolicited events must
        never retire the socket. This function never navigates/opens a tab.
        """
        import websocket
        with self.lock:
            if self.dead:
                raise ConnectionError("CDP_TRANSPORT_LOST:event-pump (socket retired)")
            try:
                self.ws.settimeout(max(0.02, float(timeout)))
                raw = self.ws.recv()
                item = json.loads(raw)
                if item.get('id') is None and self.event_handler is not None:
                    try: self.event_handler(item)
                    except Exception: pass
                return bool(item.get('id') is None)
            except (websocket.WebSocketTimeoutException, socket.timeout):
                return False
            except (websocket.WebSocketConnectionClosedException, ConnectionError, OSError) as exc:
                self.dead = True
                raise ConnectionError("CDP_TRANSPORT_LOST:event-pump") from exc

    def ev(self, s, timeout=None):
        x = self.call("Runtime.evaluate", {
            "expression": s,
            "returnByValue": True,
            "userGesture": True,
        }, timeout=timeout)
        return (x.get("result") or {}).get("value")

    def close(self):
        try:
            self.ws.close()
        except Exception:
            pass


from hse28_direct_phone import make_direct_expression


class App(tk.Tk):
    VERSION = "1.46.5"

    def __init__(self):
        super().__init__()
        self.title("PandaMonitor - 28Hse V1.46.5 WarmDetailReuse OwnerLock")
        self.geometry("1280x790")

        # Persistent config: saved on the Windows C: drive under the current user.
        # Example: C:\Users\<user>\PandaMonitor_28Hse\config.json
        home = os.path.expanduser("~")
        if os.name == "nt":
            drive = os.path.splitdrive(home)[0] or "C:"
            if drive.upper() != "C:":
                home = os.path.join("C:\\", "Users", os.environ.get("USERNAME", "Public"))
        self.config_dir = os.path.join(home, "PandaMonitor_28Hse")
        self.config_path = os.path.join(self.config_dir, "config.json")
        self.phone_db_path = os.path.join(self.config_dir, "seen_phones.json")
        self.learning_path = os.path.join(self.config_dir, "speed_learning.json")
        # UI-thread-only lifecycle accounting: never blocks the phone/clipboard lane.
        self.data_timings = {}
        self.learning_lock = threading.Lock()
        self.strategy_learning = {k: {m: {"success": 0, "failure": 0, "ema_ms": 0} for m in ("http", "cdp")} for k in ("rent", "buy")}
        self.learning_file_lock = threading.Lock()
        self.hedge_slots = {"rent": threading.BoundedSemaphore(1), "buy": threading.BoundedSemaphore(1)}
        self.speed_learning = {"rent": {"success": 0, "failure": 0, "ema_ms": 0, "budget_ms": 2800}, "buy": {"success": 0, "failure": 0, "ema_ms": 0, "budget_ms": 2800}}

        # Browser selector
        self.browser_type = tk.StringVar(value="AdsPower")

        # AdsPower
        self.ads_api = tk.StringVar(value="http://local.adspower.com:50325")
        self.ads_key = tk.StringVar()
        self.ads_no = tk.StringVar(value="19")

        # BitBrowser
        self.bit_api = tk.StringVar(value="http://127.0.0.1:54345")
        self.bit_key = tk.StringVar()
        self.bit_no = tk.StringVar(value="173")

        # Monitor options
        self.sec = tk.StringVar(value="0.5")
        self.rent = tk.BooleanVar(value=True)
        self.buy = tk.BooleanVar(value=True)
        self.monitor_state = tk.StringVar(value="● 已停止")
        self.win_notify = tk.BooleanVar(value=True)
        self.background_run = tk.BooleanVar(value=True)
        # V1.50.14: zero-detail-tab PhoneFirst; optional old CDP reveal fallback.
        self.phone_api_direct_var = tk.BooleanVar(value=True)
        self.phone_api_allow_detail_var = tk.BooleanVar(value=False)
        # Worker threads read these plain booleans only (never Tk variables).
        self.phone_api_direct_enabled = True
        self.phone_api_allow_detail = False
        self.http_retry_attempts = {'rent': {}, 'buy': {}}


        # WhatsApp auto greeting
        self.wa_enable = tk.BooleanVar(value=False)
        self.wa_start = tk.StringVar(value="23:30")
        self.wa_end = tk.StringVar(value="07:00")
        self.wa_text = tk.StringVar(value="你好，我在28Hse看到你的放盘，想了解更多资料。\n{url}")
        self.wa_sent = set()
        self.wa_tid = None
        self.wa_lock = threading.Lock()

        self.stat = tk.StringVar(value="等待连接")
        self.port = None
        self.cdp_base = None
        self.pid = None
        self.running = False
        self.run_id = 0

        self.seen = {"rent": set(), "buy": set()}
        self.processed = {"rent": set(), "buy": set()}
        self.inflight = {"rent": set(), "buy": set()}
        self.retry_count = {"rent": {}, "buy": {}}
        # When Input.dispatchMouseEvent stalls for a property, retries use DOM only.
        self.cdp_mouse_unhealthy = set()
        self.last_count = {"rent": None, "buy": None}
        self.lock = threading.Lock()
        self.phone_lock = threading.Lock()
        self.reconnect_lock = threading.Lock()
        # V1.48.3: shared per-run CDP outage gate; prevents four background
        # lanes from retrying a stale BitBrowser port endlessly.
        self.cdp_fault_event = threading.Event()
        # V1.48.6: a 429 applies to the shared 28Hse origin/profile, not just
        # one rent/buy tab. Stop BOTH API lanes and keep the GUI / 730 alive.
        self.api_rate_limit_event = threading.Event()
        # V1.50.26: 429 cools both lanes, then probes serially before 500ms resumes.
        self.api_429_guard = RateCooldown()
        # V1.50.46: rent/buy independent lanes; each lane single-flight.
        # 429 origin-wide cooldown and recovery probes remain shared.
        self.api_adaptive_scheduler = AdaptiveListScheduler()
        # V1.50.16: rent/buy cadence is controlled only by each input value.
        # No extra cross-lane FIFO/1.5s minimum. Single-flight per lane remains.
        self.api_pause_lock = threading.Lock()
        self.api_paused = {'rent': '', 'buy': ''}
        self.api_source_enabled = {'rent': False, 'buy': False}
        # API request templates: memory-only, scoped to the selected profile.
        # Never write captured POST data into config/logs.
        self.api_template_cache = {}
        self.api_template_profile = None
        self.seen_phones = set()
        self.pending_copy_phones = set()

        # V1.31 LiteHTTP: list monitoring runs as same-origin fetch() inside tiny
        # background 28Hse bridge tabs. The heavy rent/buy result pages are never
        # re-rendered every 500ms. BitBrowser/AdsPower is used for network context
        # and only opens a real detail page when a NEW listing appears.
        self.http_interval = 0.10
        self.http_latest = {"rent": [], "buy": []}
        self.http_stats = {
            "rent": {"polls": 0, "last_ms": 0, "last_ok": 0.0},
            "buy": {"polls": 0, "last_ms": 0, "last_ok": 0.0},
        }
        self.detect_stats = {
            "rent": {"first_byte_ms": 0, "first_id_ms": 0, "first_new_ms": 0, "return_ms": 0},
            "buy": {"first_byte_ms": 0, "first_id_ms": 0, "first_new_ms": 0, "return_ms": 0},
        }
        self.http_target_ids = set()

        # V1.38 Race Mode: list polling and phone extraction are independent lanes.
        # A slow phone/detail request can no longer pause the 500ms list detector.
        self.phone_jobs = {"rent": queue.Queue(), "buy": queue.Queue()}
        # StablePhoneLane: don't start speculative CDP Targets while an HTTP
        # reveal is still alive. One bounded fallback worker per category.
        self.cdp_jobs = {"rent": queue.Queue(), "buy": queue.Queue()}
        self.cdp_pending = {"rent": set(), "buy": set()}
        self.phone_bridge_ready = {"rent": threading.Event(), "buy": threading.Event()}
        self.race_stats = {
            "rent": {"last_total_ms": 0, "best_total_ms": 0},
            "buy": {"last_total_ms": 0, "best_total_ms": 0},
        }
        self.phone_db_write_lock = threading.Lock()
        self.row_urls = {}  # Treeview iid -> original post URL
        self.listing_rows = {}  # (trade, property id) -> UI row; only Tk thread reads/writes

        self.load_config()
        self.phone_api_direct_enabled = bool(self.phone_api_direct_var.get())
        self.phone_api_allow_detail = bool(self.phone_api_allow_detail_var.get())
        # V1.35: 28Hse navigation/clicking is always performed in a dedicated CDP
        # background Target. Never touch/activate the user's visible tabs.
        self.background_run.set(True)
        # V1.30: refresh cadence is fixed at 500ms; ignore older saved interval values.
        self.sec.set("0.5")
        self.load_seen_phones()
        self.load_speed_learning()
        self.build()
        # Windows clipboard requires a real HWND owner: OpenClipboard(NULL)
        # followed by EmptyClipboard can leave the clipboard owner NULL,
        # causing SetClipboardData to fail even though the phone was found.
        # Cache the Tk HWND on the UI thread; worker threads never call Tk.
        self.clipboard_owner_hwnd = None
        if os.name == "nt":
            self.update_idletasks()
            self.clipboard_owner_hwnd = int(self.winfo_id())
        self.clipboard_write_lock = threading.Lock()
        self.clipboard_deferred_lock = threading.RLock()
        self.clipboard_copy_generation = 0
        # V1.50.45: the newest 28Hse listing can own a multi-line clipboard.
        # An older listing's late supplementary phone must never replace it.
        self.latest_28_clipboard_group = None
        self.clipboard_error_local = threading.local()
        self.protocol("WM_DELETE_WINDOW", self.on_close)

    # Learning is observational: it never probes live listings or holds the clipboard path.
    def load_speed_learning(self):
        try:
            with open(self.learning_path, "r", encoding="utf-8") as fh:
                data = json.load(fh)
            if not isinstance(data, dict):
                return
            for k in ("rent", "buy"):
                row = data.get(k, {})
                if not isinstance(row, dict):
                    continue
                with self.learning_lock:
                    self.speed_learning[k] = {
                        "success": max(0, min(100000, int(row.get("success", 0)))),
                        "failure": max(0, min(100000, int(row.get("failure", 0)))),
                        "ema_ms": max(0, min(10000, float(row.get("ema_ms", 0)))),
                        "budget_ms": max(1800, min(3500, int(row.get("budget_ms", 2800))))}
                    methods = row.get("strategies", {}) if isinstance(row.get("strategies", {}), dict) else {}
                    for method in ("http", "cdp"):
                        item = methods.get(method, {})
                        if isinstance(item, dict):
                            self.strategy_learning[k][method] = {
                                "success": max(0, min(100000, int(item.get("success", 0)))),
                                "failure": max(0, min(100000, int(item.get("failure", 0)))),
                                "ema_ms": max(0, min(10000, float(item.get("ema_ms", 0))))}
        except (OSError, ValueError, TypeError):
            pass

    def learn_phone_latency(self, k, success, elapsed_ms, test_mode=False):
        if test_mode or k not in ("rent", "buy"):
            return
        elapsed_ms = max(0, min(10000, int(elapsed_ms)))
        with self.learning_lock:
            row = self.speed_learning[k]
            row["success" if success else "failure"] += 1
            if success:
                old = row["ema_ms"]
                row["ema_ms"] = elapsed_ms if not old else old * .80 + elapsed_ms * .20
                # Reserve headroom for network variance, never too aggressive.
                if row["success"] >= 5:
                    row["budget_ms"] = max(1800, min(3500, int(row["ema_ms"] * 1.8 + 500)))
            elif row["failure"] >= 3:
                # Failures suggest congestion, not necessarily a slow algorithm.
                row["budget_ms"] = min(3500, row["budget_ms"] + 150)
            snapshot = self.learning_snapshot_locked()
        self.save_learning_snapshot(snapshot)

    def learning_snapshot_locked(self):
        # Caller holds learning_lock. Keep backward-compatible speed_learning.json.
        return {k: dict(self.speed_learning[k], strategies={
            m: dict(self.strategy_learning[k][m]) for m in ("http", "cdp")})
            for k in ("rent", "buy")}

    def learn_strategy(self, k, method, success, elapsed_ms, test_mode=False):
        if test_mode or k not in ("rent", "buy") or method not in ("http", "cdp"):
            return
        with self.learning_lock:
            r = self.strategy_learning[k][method]
            r["success" if success else "failure"] += 1
            if success:
                ms = max(1, min(10000, int(elapsed_ms)))
                r["ema_ms"] = ms if not r["ema_ms"] else .8*r["ema_ms"] + .2*ms
            snapshot = self.learning_snapshot_locked()
        self.save_learning_snapshot(snapshot)

    def save_learning_snapshot(self, snapshot):
        # Serialize file writes so concurrent rent/buy workers cannot corrupt JSON.
        if not hasattr(self, "learning_file_lock"):
            self.learning_file_lock = threading.Lock()
        def save():
            try:
                with self.learning_file_lock:
                    os.makedirs(self.config_dir, exist_ok=True)
                    tmp = self.learning_path + ".tmp"
                    with open(tmp, "w", encoding="utf-8") as fh:
                        json.dump(snapshot, fh, ensure_ascii=False, indent=2)
                    os.replace(tmp, self.learning_path)
            except OSError:
                pass
        self.bg(save)

    def hedge_delay_ms(self, k):
        # HTTP stays first; CDP only hedges requests that have become slow.
        # Avoid extra browser work if HTTP is reliably fast.
        with self.learning_lock:
            h = dict(self.strategy_learning[k]["http"])
            d = dict(self.strategy_learning[k]["cdp"])
        if h["success"] >= 6 and h["ema_ms"] and h["ema_ms"] < 850 and h["failure"] < h["success"] // 3:
            return 1300
        # If CDP has proved more effective, start it earlier, but never for every immediate hit.
        if d["success"] >= 3 and h["success"] >= 3 and d["ema_ms"] < h["ema_ms"] * .8:
            return 500
        if h["success"] >= 3 and h["ema_ms"]:
            return max(600, min(1300, int(h["ema_ms"] * 1.3)))
        return 1000

    def hedged_cdp(self, k, url, detected_t0, settled):
        """Only one detail Target per category, but never silently drop a NEW.

        The earlier non-blocking semaphore acquire returned immediately when the
        CDP lane was busy. The HTTP worker had already marked a hedge as started,
        so it did not schedule another fallback. This left a row '取号中' forever.
        Waiting occurs on a background thread, never on DetectionRace or clipboard.
        """
        if settled.is_set() or not self.running or not self.phone_api_allow_detail:
            return
        slot = self.hedge_slots[k]
        owned = False
        until = time.monotonic() + 12.0
        while self.running and not settled.is_set() and time.monotonic() < until:
            if slot.acquire(timeout=0.15):
                owned = True
                break
        if not owned:
            if not settled.is_set() and self.running:
                self.set_listing_status(k, url, "取号排队超时")
                self.write("[PHONE-QUEUE-TIMEOUT] %s %s · CDP繁忙超过12秒，保留房源链接；没有冒称取号成功" % (k, self.pid_of(url)))
                with self.lock:
                    pid = self.pid_of(url)
                    self.inflight[k].discard(pid)
            return
        try:
            if settled.is_set() or not self.running:
                return
            self.set_listing_status(k, url, "正在揭号…")
            started = time.perf_counter()
            ok, reason = self.detail(k, url, False, False, detected_t0)
            self.learn_strategy(k, "cdp", ok, int((time.perf_counter()-started)*1000))
            if ok:
                settled.set()
                self.write("[LEARN] CDP竞速成功；正式结果由电话去重锁保证只复制一次")
        except Exception as e:
            self.write("[LEARN] CDP竞速异常：" + str(e))
            self.learn_strategy(k, "cdp", False, 0)
            self.set_listing_status(k, url, "取号失败")
        finally:
            slot.release()

    # ---------------- Persistent config ----------------
    def load_config(self):
        try:
            if not os.path.isfile(self.config_path):
                return
            with open(self.config_path, "r", encoding="utf-8") as fh:
                cfg = json.load(fh)
            if not isinstance(cfg, dict):
                return

            mapping = {
                "browser_type": self.browser_type,
                "ads_api": self.ads_api,
                "ads_key": self.ads_key,
                "ads_no": self.ads_no,
                "bit_api": self.bit_api,
                "bit_key": self.bit_key,
                "bit_no": self.bit_no,
                "sec": self.sec,
                "rent": self.rent,
                "buy": self.buy,
                "win_notify": self.win_notify,
                "background_run": self.background_run,
                "wa_enable": self.wa_enable,
                "wa_start": self.wa_start,
                "wa_end": self.wa_end,
                "wa_text": self.wa_text,
                "phone_api_direct_enabled": self.phone_api_direct_var,
                "phone_api_allow_detail": self.phone_api_allow_detail_var,
            }
            for key, var in mapping.items():
                if key in cfg:
                    var.set(cfg[key])
        except Exception:
            # Never block startup just because an old config is malformed.
            pass

    def save_config(self):
        cfg = {
            "version": self.VERSION,
            "browser_type": self.browser_type.get(),
            "ads_api": self.ads_api.get().strip(),
            "ads_key": self.ads_key.get().strip(),
            "ads_no": self.ads_no.get().strip(),
            "bit_api": self.bit_api.get().strip(),
            "bit_key": self.bit_key.get().strip(),
            "bit_no": self.bit_no.get().strip(),
            "sec": self.sec.get().strip(),
            "rent": bool(self.rent.get()),
            "buy": bool(self.buy.get()),
            "win_notify": bool(self.win_notify.get()),
            "background_run": bool(self.background_run.get()),
            "wa_enable": bool(self.wa_enable.get()),
            "wa_start": self.wa_start.get().strip(),
            "wa_end": self.wa_end.get().strip(),
            "wa_text": self.wa_text.get(),
            "phone_api_direct_enabled": bool(self.phone_api_direct_var.get()),
            "phone_api_allow_detail": bool(self.phone_api_allow_detail_var.get()),
        }
        try:
            os.makedirs(self.config_dir, exist_ok=True)
            tmp = self.config_path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as fh:
                json.dump(cfg, fh, ensure_ascii=False, indent=2)
            os.replace(tmp, self.config_path)
            return True
        except Exception as e:
            try:
                self.write("! 配置保存失败：" + str(e))
            except Exception:
                pass
            return False

    @staticmethod
    def normalize_phone(value):
        digits = re.sub(r"\D", "", str(value or ""))
        if digits.startswith("00852") and len(digits) >= 13:
            digits = digits[5:]
        elif digits.startswith("852") and len(digits) == 11:
            digits = digits[3:]
        return digits

    def load_seen_phones(self):
        try:
            if not os.path.isfile(self.phone_db_path):
                return
            with open(self.phone_db_path, "r", encoding="utf-8") as fh:
                data = json.load(fh)
            if isinstance(data, dict):
                data = data.get("phones", [])
            if isinstance(data, list):
                self.seen_phones = {self.normalize_phone(x) for x in data if self.normalize_phone(x)}
        except Exception:
            self.seen_phones = set()

    def save_seen_phones(self):
        try:
            with self.phone_lock:
                snapshot = sorted(self.seen_phones)
            with self.phone_db_write_lock:
                os.makedirs(self.config_dir, exist_ok=True)
                tmp = self.phone_db_path + ".tmp"
                with open(tmp, "w", encoding="utf-8") as fh:
                    json.dump({"version": self.VERSION, "phones": snapshot}, fh, ensure_ascii=False, indent=2)
                os.replace(tmp, self.phone_db_path)
            return True
        except Exception as e:
            try:
                self.write("! 电话去重库保存失败：" + str(e))
            except Exception:
                pass
            return False

    def save_seen_phones_deferred(self):
        # Keep disk IO out of NEW -> clipboard hot path.
        try:
            time.sleep(0.03)
            self.save_seen_phones()
        except Exception:
            pass

    def on_close(self):
        self.running = False
        self.run_id += 1
        self._allow_system_sleep()
        self.save_config()
        # save_seen_phones() already acquires phone_lock.  Avoid recursive
        # locking on shutdown (threading.Lock is not re-entrant).
        self.save_seen_phones()
        self.destroy()

    # ---------------- UI ----------------
    def build(self):
        f = ttk.Frame(self)
        f.pack(fill="both", expand=True, padx=12, pady=10)

        ttk.Label(
            f,
            text=f"PandaMonitor - 28Hse V{self.VERSION} BackgroundNoThrottle + OwnerLock",
            font=("Microsoft YaHei UI", 16, "bold"),
        ).grid(row=0, column=0, columnspan=8, sticky="w")

        ttk.Label(f, text="浏览器").grid(row=1, column=0, sticky="w", pady=(8, 2))
        box = ttk.Combobox(
            f,
            textvariable=self.browser_type,
            values=("AdsPower", "BitBrowser"),
            state="readonly",
            width=16,
        )
        box.grid(row=1, column=1, sticky="w", pady=(8, 2))
        box.bind("<<ComboboxSelected>>", lambda _e: self.show_browser_frame())
        ttk.Button(f, text="连接浏览器", command=lambda: self.bg(self.connect_browser)).grid(
            row=1, column=2, sticky="w", padx=8, pady=(8, 2)
        )
        ttk.Checkbutton(f, text="Windows 浮窗提示", variable=self.win_notify).grid(
            row=1, column=3, sticky="w", padx=8, pady=(8, 2)
        )
        self.bg_mode_cb = ttk.Checkbutton(
            f, text="纯 CDP 背景 Target（固定启用，不抢前台）", variable=self.background_run, state="disabled"
        )
        self.bg_mode_cb.grid(row=1, column=4, columnspan=3, sticky="w", padx=8, pady=(8, 2))

        self.browser_host = ttk.Frame(f)
        self.browser_host.grid(row=2, column=0, columnspan=8, sticky="ew", pady=(3, 5))
        self.browser_host.columnconfigure(0, weight=1)

        self.ads_frame = ttk.LabelFrame(self.browser_host, text="AdsPower")
        self.bit_frame = ttk.LabelFrame(self.browser_host, text="BitBrowser")
        self._build_ads_frame()
        self._build_bit_frame()
        self.show_browser_frame()

        o = ttk.Frame(f)
        o.grid(row=3, column=0, columnspan=8, sticky="ew", pady=8)
        o_top = ttk.Frame(o)
        o_top.pack(fill="x", anchor="w")
        ttk.Checkbutton(o_top, text="28Hse 租盘", variable=self.rent).pack(side="left", padx=5)
        ttk.Checkbutton(o_top, text="28Hse 售盘", variable=self.buy).pack(side="left", padx=5)
        ttk.Label(o_top, text="UltraRace：200ms自适应列表 / 目标100-500ms").pack(side="left", padx=(15, 8))
        self.start_btn = ttk.Button(o_top, text="▶ 开始监控", command=self.start, width=11)
        self.start_btn.pack(side="left", padx=(4, 3))
        self.stop_btn = ttk.Button(o_top, text="■ 停止监控", command=self.stop, width=11, state="disabled")
        self.stop_btn.pack(side="left", padx=3)
        ttk.Label(o_top, text="当前：").pack(side="left", padx=(10, 2))
        ttk.Label(o_top, textvariable=self.monitor_state, font=("Microsoft YaHei UI", 10, "bold")).pack(side="left")

        o_test = ttk.Frame(o)
        o_test.pack(fill="x", anchor="w", pady=(6, 0))
        ttk.Label(o_test, text="测试：").pack(side="left", padx=(5, 2))
        ttk.Button(o_test, text="租盤直接API測試", command=lambda: self.bg(self.api_test_28, 'rent'), width=16).pack(side="left", padx=4)
        ttk.Button(o_test, text="售盤直接API測試", command=lambda: self.bg(self.api_test_28, 'buy'), width=16).pack(side="left", padx=4)
        ttk.Button(o_test, text="WhatsApp 打招呼测试", command=lambda: self.bg(self.whatsapp_test), width=20).pack(side="left", padx=4)
        ttk.Label(o_test, text="测试完成一定弹窗：成功显示成功；失败显示具体原因").pack(side="left", padx=(10, 0))

        waf = ttk.LabelFrame(f, text="指定时段自动 WhatsApp 打招呼")
        waf.grid(row=4, column=0, columnspan=8, sticky="ew", pady=(2, 7))
        ttk.Checkbutton(waf, text="启用", variable=self.wa_enable).grid(row=0, column=0, padx=6, pady=6)
        ttk.Label(waf, text="开始").grid(row=0, column=1)
        ttk.Entry(waf, textvariable=self.wa_start, width=7).grid(row=0, column=2, padx=(3, 8))
        ttk.Label(waf, text="结束").grid(row=0, column=3)
        ttk.Entry(waf, textvariable=self.wa_end, width=7).grid(row=0, column=4, padx=(3, 10))
        ttk.Label(waf, text="内容").grid(row=0, column=5)
        ttk.Entry(waf, textvariable=self.wa_text, width=60).grid(row=0, column=6, sticky="ew", padx=(4, 8))
        ttk.Label(waf, text="支持跨午夜，例如 23:30 - 07:00；{url} 会替换成帖子链接").grid(
            row=1, column=0, columnspan=7, sticky="w", padx=7, pady=(0, 5)
        )
        waf.columnconfigure(6, weight=1)

        ttk.Label(f, text="状态：").grid(row=5, column=0, sticky="w")
        ttk.Label(f, textvariable=self.stat).grid(row=5, column=1, columnspan=7, sticky="w")

        self.latest_phone = tk.StringVar(value="等待新号码")
        lp = ttk.Frame(f)
        lp.grid(row=6, column=0, columnspan=8, sticky="ew", pady=(6, 2))
        ttk.Label(lp, text="最新号码：", font=("Microsoft YaHei UI", 11, "bold")).pack(side="left")
        tk.Label(lp, textvariable=self.latest_phone, font=("Consolas", 22, "bold"), anchor="w").pack(
            side="left", padx=(4, 18)
        )
        ttk.Label(lp, text="抓到新號碼後自動複製尾四位；手動按鈕複製完整號碼").pack(side="left")

        cols = ("source", "phone", "contact", "wa_status", "open_post")
        self.tree = ttk.Treeview(f, columns=cols, show="headings", height=14)
        style = ttk.Style(self)
        style.configure("Treeview", font=("Microsoft YaHei UI", 12), rowheight=31)
        style.configure("Treeview.Heading", font=("Microsoft YaHei UI", 11, "bold"))
        self.tree.heading("source", text="类别")
        self.tree.column("source", width=135, anchor="center", stretch=False)
        self.tree.heading("phone", text="电话")
        self.tree.column("phone", width=185, anchor="center", stretch=False)
        self.tree.heading("contact", text="联系人名")
        self.tree.column("contact", width=235, anchor="center")
        self.tree.heading("wa_status", text="WA状态")
        self.tree.column("wa_status", width=260, anchor="center")
        self.tree.heading("open_post", text="打开原帖")
        self.tree.column("open_post", width=115, anchor="center", stretch=False)
        self.tree.grid(row=7, column=0, columnspan=8, sticky="nsew", pady=8)
        self.tree.bind("<ButtonRelease-1>", self.on_tree_click)

        b = ttk.Frame(f)
        b.grid(row=8, column=0, columnspan=8, sticky="w")
        ttk.Button(b, text="复制号码", command=self.copy).pack(side="left", padx=5)

        self.log = tk.Text(f, height=9, font=("Consolas", 9))
        self.log.grid(row=9, column=0, columnspan=8, sticky="nsew", pady=8)

        f.columnconfigure(7, weight=1)
        f.rowconfigure(7, weight=2)
        f.rowconfigure(9, weight=1)

        self.write("V1.35：详情导航/点击改为纯 CDP 背景 Target；不操作用户正在看的租/售标签页，也不 bringToFront/window.focus。")
        self.write("进入帖子使用纯CDP背景Target；致电优先DOM点击，必要时限时CDP鼠标，不触碰前台标签。")
        self.write("V1.44 DetectionRace：同来源仍严格 single-flight；最快100ms起下一轮；首NEW一出现立即返回，不等整页/12条帖子。")
        self.write("租/售使用独立轻量后台 bridge；只有发现 NEW 才创建详情页抓号，切走环境也不依赖前台页面。")
        self.write("配置自动读取/保存：%s" % self.config_path)
        self.write("电话去重库：%s（已载入 %d 个号码）" % (self.phone_db_path, len(self.seen_phones)))
        self.write("[LEARN] 自适应取号已启用：租盘 %dms / 售盘 %dms；记录在 speed_learning.json" % (self.speed_learning["rent"]["budget_ms"], self.speed_learning["buy"]["budget_ms"]))
        self.write("V1.46.5 WarmDetailReuse：HTTP PhoneFirst；备用CDP每类预热一个隐藏详情Target并复用；失效自动重建。")

    def _build_ads_frame(self):
        ttk.Label(self.ads_frame, text="API 地址").grid(row=0, column=0, padx=6, pady=5, sticky="w")
        ttk.Entry(self.ads_frame, textvariable=self.ads_api, width=46).grid(row=0, column=1, padx=4, pady=5, sticky="ew")
        ttk.Label(self.ads_frame, text="API Key").grid(row=0, column=2, padx=(12, 4), pady=5)
        ttk.Entry(self.ads_frame, textvariable=self.ads_key, show="●", width=25).grid(row=0, column=3, padx=4, pady=5)
        ttk.Label(self.ads_frame, text="环境编号").grid(row=0, column=4, padx=(12, 4), pady=5)
        ttk.Entry(self.ads_frame, textvariable=self.ads_no, width=8).grid(row=0, column=5, padx=4, pady=5)
        self.ads_frame.columnconfigure(1, weight=1)

    def _build_bit_frame(self):
        ttk.Label(self.bit_frame, text="Local API").grid(row=0, column=0, padx=6, pady=5, sticky="w")
        ttk.Entry(self.bit_frame, textvariable=self.bit_api, width=46).grid(row=0, column=1, padx=4, pady=5, sticky="ew")
        ttk.Label(self.bit_frame, text="Token").grid(row=0, column=2, padx=(12, 4), pady=5)
        ttk.Entry(self.bit_frame, textvariable=self.bit_key, show="●", width=25).grid(row=0, column=3, padx=4, pady=5)
        ttk.Label(self.bit_frame, text="环境序号").grid(row=0, column=4, padx=(12, 4), pady=5)
        ttk.Entry(self.bit_frame, textvariable=self.bit_no, width=8).grid(row=0, column=5, padx=4, pady=5)
        self.bit_frame.columnconfigure(1, weight=1)

    def show_browser_frame(self):
        try:
            self.ads_frame.grid_forget()
            self.bit_frame.grid_forget()
            if self.browser_type.get() == "BitBrowser":
                self.bit_frame.grid(row=0, column=0, sticky="ew")
            else:
                self.ads_frame.grid(row=0, column=0, sticky="ew")
        except Exception:
            pass

    def bg(self, fn, *args):
        threading.Thread(target=fn, args=args, daemon=True).start()

    def write(self, s):
        """Batch log paints. The phone/monitor workers must not wait for Tk.

        In high-frequency runs scheduling one Tk callback + scroll per log line
        unnecessarily burns a whole CPU core and delays CDP processing.
        """
        if not hasattr(self, '_log_buffer'):
            self._log_buffer = deque(maxlen=1800)
            self._log_buffer_lock = threading.Lock()
            self._log_flush_pending = False
            self._log_trim_counter = 0
        with self._log_buffer_lock:
            self._log_buffer.append(str(s))
            if self._log_flush_pending:
                return
            self._log_flush_pending = True
        try:
            self.after(150, self._flush_log_buffer)
        except (RuntimeError, tk.TclError):
            with self._log_buffer_lock:
                self._log_flush_pending = False

    def _flush_log_buffer(self):
        with self._log_buffer_lock:
            pending = list(self._log_buffer)
            self._log_buffer.clear()
            self._log_flush_pending = False
        if not pending:
            return
        try:
            self.log.insert('end', '\n'.join(pending) + '\n')
            self._log_trim_counter += len(pending)
            if self._log_trim_counter >= 180:
                self._log_trim_counter = 0
                total = int(self.log.index('end-1c').split('.')[0])
                if total > 1600:
                    self.log.delete('1.0', '%d.0' % (total - 1200))
            # Do not force costly scrolling when the user is on a different tab.
            tabs = getattr(self, 'tabs', None)
            if tabs is None or tabs.select() == str(self.log.master):
                self.log.see('end')
        except (RuntimeError, tk.TclError):
            pass

    def status(self, s):
        self.after(0, lambda: self.stat.set(s))

    def test_popup(self, title, ok, reason=""):
        """Always show an on-screen modal result for manual tests."""
        reason = str(reason or "").strip()
        def ui():
            try:
                self.deiconify()
                self.lift()
                try:
                    self.attributes("-topmost", True)
                    self.after(250, lambda: self.attributes("-topmost", False))
                except Exception:
                    pass
                if ok:
                    msg = "成功" + (("\n\n" + reason) if reason else "")
                    messagebox.showinfo(title, msg, parent=self)
                else:
                    msg = "失败" + (("\n\n原因：" + reason) if reason else "\n\n原因：未知")
                    messagebox.showerror(title, msg, parent=self)
            except Exception as e:
                self.write("! 测试结果弹窗失败：" + str(e))
        self.after(0, ui)

    def set_monitor_controls(self, running):
        def ui():
            self.monitor_state.set("● 运行中" if running else "● 已停止")
            try:
                self.start_btn.configure(state="disabled" if running else "normal")
                self.stop_btn.configure(state="normal" if running else "disabled")
            except Exception:
                pass
        if threading.current_thread() is threading.main_thread():
            ui()
        else:
            self.after(0, ui)

    def _native_windows_toast(self, title, message):
        """Show a Windows 10/11 Action Center toast without stealing focus."""
        if os.name != "nt":
            return False
        try:
            import subprocess, base64
            ps = r'''[Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, ContentType = WindowsRuntime] > $null
[Windows.Data.Xml.Dom.XmlDocument, Windows.Data.Xml.Dom.XmlDocument, ContentType = WindowsRuntime] > $null
$template = [Windows.UI.Notifications.ToastNotificationManager]::GetTemplateContent([Windows.UI.Notifications.ToastTemplateType]::ToastText02)
$textNodes = $template.GetElementsByTagName('text')
$textNodes.Item(0).AppendChild($template.CreateTextNode('__TITLE__')) > $null
$textNodes.Item(1).AppendChild($template.CreateTextNode('__MESSAGE__')) > $null
$toast = [Windows.UI.Notifications.ToastNotification]::new($template)
[Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier('PandaMonitor 28Hse').Show($toast)
'''
            def esc(v):
                return str(v).replace("'", "''").replace("`", "``")
            ps = ps.replace('__TITLE__', esc(title)).replace('__MESSAGE__', esc(message))
            enc = base64.b64encode(ps.encode('utf-16le')).decode('ascii')
            flags = getattr(subprocess, 'CREATE_NO_WINDOW', 0)
            subprocess.Popen(
                ['powershell.exe', '-NoProfile', '-NonInteractive', '-WindowStyle', 'Hidden', '-EncodedCommand', enc],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                creationflags=flags,
            )
            return True
        except Exception:
            return False

    def toast(self, title, message, ms=4200):
        if not self.win_notify.get():
            return
        if self._native_windows_toast(title, message):
            return
        def ui():
            try:
                w = tk.Toplevel(self)
                w.overrideredirect(True)
                try:
                    w.attributes('-topmost', True)
                except Exception:
                    pass
                outer = tk.Frame(w, bd=1, relief='solid', bg='white')
                outer.pack(fill='both', expand=True)
                tk.Label(outer, text=title, font=('Microsoft YaHei UI', 11, 'bold'), bg='white', anchor='w').pack(fill='x', padx=12, pady=(10, 2))
                tk.Label(outer, text=message, font=('Microsoft YaHei UI', 10), bg='white', justify='left', anchor='w', wraplength=330).pack(fill='both', padx=12, pady=(0, 10))
                w.update_idletasks()
                ww, wh = 380, max(92, w.winfo_reqheight())
                sw, sh = w.winfo_screenwidth(), w.winfo_screenheight()
                w.geometry(f"{ww}x{wh}+{sw-ww-22}+{sh-wh-70}")
                w.after(ms, lambda: w.destroy() if w.winfo_exists() else None)
            except Exception:
                pass
        self.after(0, ui)

    def copy_text(self, text):
        """Normal/manual clipboard writes supersede older deferred auto-copies."""
        gate = getattr(self, 'clipboard_deferred_lock', None)
        if gate is not None:
            with gate:
                self.clipboard_copy_generation += 1
        return self._copy_text_raw(text)

    def _copy_text_raw(self, text):
        """Write text without changing the most-recent clipboard priority token.

        Uses the captured Tk HWND but never calls Tk from Windows worker threads.
        """
        text = str(text or "")
        self.clipboard_error_local.error = ""
        if not text:
            self.clipboard_error_local.error = "empty text"
            return False
        if os.name != "nt":
            try:
                self.clipboard_clear()
                self.clipboard_append(text)
                self.update_idletasks()
                return True
            except Exception as exc:
                self.clipboard_error_local.error = repr(exc)
                return False
        try:
            from clipboard_win import copy_unicode_to_clipboard
            with self.clipboard_write_lock:
                copy_unicode_to_clipboard(text, self.clipboard_owner_hwnd)
            return True
        except Exception as exc:
            self.clipboard_error_local.error = str(exc)
            return False

    def _retry_clipboard_after_lock(self, phone, tail, generation, run_id):
        """Retry only the newest phone after a locked/busy Windows clipboard.

        Copying a stale number *after* a newer automatic/manual copy is worse
        than leaving it for manual retry, so any later write cancels this job.
        No Tk / foreground activation; do not claim dedup success before copy.
        """
        try:
            deadline = time.monotonic() + 12 * 60 * 60
            last_try = 0.0
            while time.monotonic() < deadline and self.running and run_id == self.run_id:
                with self.clipboard_deferred_lock:
                    if self.clipboard_copy_generation != generation:
                        return
                if windows_session_locked():
                    time.sleep(3)
                    continue
                gate = self.clipboard_deferred_lock
                with gate:
                    if self.clipboard_copy_generation != generation:
                        return
                    if time.monotonic() - last_try >= 3:
                        last_try = time.monotonic()
                        if self._copy_text_raw(tail):
                            if phone is not None:
                                with self.phone_lock:
                                    self.seen_phones.add(phone)
                                self.bg(self.save_seen_phones_deferred)
                            self.write('[CLIPBOARD-RECOVER] 解鎖／佔用解除後已補複製最新尾四位')
                            return
                time.sleep(2)
            self.write('[CLIPBOARD-PENDING] 未能補複製；完整電話已顯示，可手動複製')
        finally:
            if phone is not None:
                with self.phone_lock:
                    self.pending_copy_phones.discard(phone)

    def copy_auto_tail_with_defer(self, phone):
        """730/extra-sites automatic tail copy; preserve latest-wins on Win+L."""
        digits = self.normalize_phone(phone)
        tail = digits[-4:]
        if not tail:
            return False
        ok = self.copy_text(tail)
        if (not ok and os.name == 'nt' and
            ('busy' in getattr(self.clipboard_error_local, 'error', '').lower()
             or windows_session_locked())):
            self.bg(self._retry_clipboard_after_lock, None, tail,
                    self.clipboard_copy_generation, self.run_id)
        return ok

    # ---------------- Background / Windows keep-alive ----------------
    def _prevent_system_sleep(self):
        if os.name != "nt" or not self.background_run.get():
            return
        try:
            import ctypes
            ES_CONTINUOUS = 0x80000000
            ES_SYSTEM_REQUIRED = 0x00000001
            ctypes.windll.kernel32.SetThreadExecutionState(ES_CONTINUOUS | ES_SYSTEM_REQUIRED)
        except Exception:
            pass

    def _allow_system_sleep(self):
        if os.name != "nt":
            return
        try:
            import ctypes
            ctypes.windll.kernel32.SetThreadExecutionState(0x80000000)
        except Exception:
            pass

    def keep_page_active(self, c):
        if not self.background_run.get():
            return
        # Keep renderer active WITHOUT activating the actual Windows/profile window.
        # Never use Page.bringToFront() or window.focus() here: either can make
        # BitBrowser/AdsPower jump to the foreground while the user is working.
        calls = [
            ("Page.enable", {}),
            ("Emulation.setFocusEmulationEnabled", {"enabled": True}),
            ("Page.setWebLifecycleState", {"state": "active"}),
        ]
        for method, params in calls:
            try:
                c.call(method, params)
            except Exception:
                pass

    @staticmethod
    def clean_contact_name(value):
        if not isinstance(value, str):
            return "未知"
        name = " ".join(value.split()).strip()
        if not name or len(name) > 60:
            return "未知"
        lowered = name.lower()
        invalid = ("$(document)", ".ready(", "function(", "javascript:",
                   "<script", "</", "document.", "window.", "=>", "{", "}",
                   "queryselector", "getelementbyid", "jquery(")
        if any(token in lowered for token in invalid):
            return "未知"
        return name

    @staticmethod
    def keep_bridge_active(c):
        # The robots.txt-origin LiteHTTP bridge should stay awake even if
        # the Background checkbox is off. Do not bring the window to front.
        for method, params in (
            ("Page.enable", {}),
            ("Emulation.setFocusEmulationEnabled", {"enabled": True}),
            ("Page.setWebLifecycleState", {"state": "active"}),
        ):
            try:
                c.call(method, params)
            except Exception:
                pass
        # CDP support differs across Chromium releases; use best-effort flags.
        try:
            c.call("Emulation.setIdleOverride", {"isUserActive": True, "isScreenUnlocked": True})
        except Exception:
            pass

    @staticmethod
    def block_nonessential(c):
        # CDP URL matching: block heavy media, not scripts/CSS/XHR/fetch.
        try:
            c.call("Network.enable")
            c.call("Network.setBlockedURLs", {"urls": [
                "*.jpg*", "*.jpeg*", "*.png*", "*.gif*", "*.webp*",
                "*.avif*", "*.woff*", "*.woff2*", "*.ttf*", "*.otf*",
                "*.mp4*", "*.webm*", "*.mp3*", "*.m4a*"
            ]})
        except Exception:
            pass

    def _cdp_base_alive(self):
        if not self.cdp_base:
            return False
        try:
            with _LOCAL_OPENER.open(self._debug_url("/json"), timeout=2.0) as r:
                data = json.loads(r.read().decode(errors="replace"))
            return isinstance(data, list)
        except Exception:
            return False

    def recover_browser(self):
        if not self.background_run.get():
            return False
        try:
            if self._cdp_base_alive():
                return True
            self.write('[BG] CDP 已斷線：只尋找已啟動瀏覽器，不調用 /browser/open')
            # _attach_running_browser manages reconnect_lock itself.
            return self._attach_running_browser()
        except Exception as e:
            self.write('[BG] 自動重連暫時未成功：' + str(e)[:120])
            return False

    # ---------------- Browser connection ----------------
    def ads_headers(self):
        if not self.ads_key.get().strip():
            raise RuntimeError("请填写 AdsPower API Key")
        return {
            "Authorization": "Bearer " + self.ads_key.get().strip(),
            "Content-Type": "application/json",
        }

    def ads_call(self, m, path, params=None, body=None):
        u = self.ads_api.get().strip().rstrip("/") + path
        if params:
            u += "?" + parse.urlencode(params, doseq=True)
        q = request.Request(
            u,
            data=None if body is None else json.dumps(body).encode(),
            headers=self.ads_headers(),
            method=m,
        )
        with request.urlopen(q, timeout=15) as r:
            return json.loads(r.read().decode(errors="replace"))

    def bit_call(self, path, body=None):
        u = self.bit_api.get().strip().rstrip("/") + path
        headers = {"Content-Type": "application/json"}
        token = self.bit_key.get().strip()
        if token:
            headers["x-api-key"] = token
        q = request.Request(
            u,
            data=json.dumps(body or {}).encode(),
            headers=headers,
            method="POST",
        )
        with _LOCAL_OPENER.open(q, timeout=20) as r:
            return json.loads(r.read().decode(errors="replace"))

    def _find_bit_profile(self, seq_raw):
        """Fetch the configured profile without the unreliable 'seq' API filter.

        Some Local API versions reject the extra seq parameter. Always compare
        the returned sequence in Python; never silently connect to another profile.
        Only used at startup/recovery, not in the polling hot path.
        """
        expected = str(seq_raw).strip()
        for page in range(0, 30):
            response = self.bit_call('/browser/list', {'page': page, 'pageSize': 100})
            if response.get('success') is False or (response.get('code') not in (None, 0, '0')):
                raise RuntimeError('BitBrowser /browser/list 拒絕查詢，請檢查 Local API Token/版本')
            data = response.get('data') or {}
            rows = (data.get('list') or data.get('rows') or data.get('items') or []) if isinstance(data, dict) else (data if isinstance(data, list) else [])
            for item in rows:
                if not isinstance(item, dict):
                    continue
                values = [item.get(k) for k in ('seq', 'sequence', 'serialNumber', 'sort')]
                if any(str(value) == expected for value in values if value is not None):
                    return item
            if not rows or len(rows) < 100:
                break
        raise RuntimeError('找不到 BitBrowser 環境序號 '+expected+'（已核對本機列表，未選用其他環境）')

    @staticmethod
    def _base_from_http_or_ws(http_url=None, ws_url=None):
        if http_url:
            x = parse.urlparse(str(http_url))
            if x.hostname and x.port:
                return f"http://{x.hostname}:{x.port}"
        if ws_url:
            x = parse.urlparse(str(ws_url))
            if x.hostname and x.port:
                return f"http://{x.hostname}:{x.port}"
        return None

    def connect_browser(self):
        self.save_config()
        if self.browser_type.get() == "BitBrowser":
            return self.connect_bit()
        return self.connect_ads()

    def connect_ads(self):
        try:
            no = self.ads_no.get().strip()
            x = self.ads_call(
                "POST",
                "/api/v2/browser-profile/list",
                body={"profile_no": [no], "page": 1, "limit": 10},
            )
            a = (x.get("data") or {}).get("list") or []
            if not a:
                raise RuntimeError("找不到 AdsPower 环境 " + no)
            self.pid = a[0]["profile_id"]
            x = self.ads_call("GET", "/api/v2/browser-profile/active", params={"profile_id": self.pid})
            d = x.get("data") or {}
            if d.get("status") != "Active":
                raise RuntimeError("AdsPower 环境未启动")
            self.port = d.get("debug_port")
            if not self.port:
                raise RuntimeError("AdsPower 未返回 debug_port")
            self.cdp_base = f"http://127.0.0.1:{self.port}"
            hits = [p for p in self.targets() if "28hse.com/rent" in p.get("url", "") or "28hse.com/buy" in p.get("url", "")]
            self.write("✓ AdsPower 已连接：%s / Port %s" % (self.pid, self.port))
            self.status("AdsPower 连接成功，找到 %d 个 28Hse 标签页" % len(hits))
        except Exception as e:
            self.write("✗ AdsPower：" + str(e))
            self.status("AdsPower 连接失败")

    def connect_bit(self):
        self._last_bit_connect_stage = 'list'
        try:
            seq_raw = self.bit_no.get().strip()
            if not seq_raw:
                raise RuntimeError("请填写 BitBrowser 环境序号")
            try:
                seq = int(seq_raw)
            except Exception:
                seq = seq_raw

            item = self._find_bit_profile(seq_raw)
            bid = item.get("id") or item.get("browserId")
            if not bid:
                raise RuntimeError("BitBrowser 列表未返回浏览器 ID")

            self._last_bit_connect_stage = 'open'
            opened = self.bit_call("/browser/open", {"id": bid, "queue": True})
            od = opened.get("data") or {}
            self.cdp_base = self._base_from_http_or_ws(od.get("http"), od.get("ws") or od.get("webdriver"))
            if not self.cdp_base:
                raise RuntimeError("BitBrowser 未返回 CDP http/ws 地址")

            self.pid = bid
            xurl = parse.urlparse(self.cdp_base)
            self.port = xurl.port
            self._last_bit_connect_stage = 'cdp'
            hits = [p for p in self.targets() if "28hse.com/rent" in p.get("url", "") or "28hse.com/buy" in p.get("url", "")]
            self._last_bit_connect_error = ''
            self.write("✓ BitBrowser 已连接：环境 %s / %s" % (seq_raw, self.cdp_base))
            self.status("BitBrowser 连接成功，找到 %d 个 28Hse 标签页" % len(hits))
        except Exception as e:
            self._last_bit_connect_error = str(e)
            self.cdp_base = None
            self.port = None
            self.write("✗ BitBrowser：" + str(e))
            self.status("BitBrowser 连接失败")

    def _debug_url(self, path):
        if not self.cdp_base:
            raise RuntimeError("浏览器尚未连接")
        return self.cdp_base.rstrip("/") + path

    def targets(self):
        with _LOCAL_OPENER.open(self._debug_url("/json"), timeout=5) as r:
            return [x for x in json.loads(r.read().decode()) if x.get("type") == "page"]

    def create_background_target(self, url):
        """Create an isolated CDP page Target that is never activated in the UI.

        V1.35 deliberately has NO /json/new or Page.bringToFront fallback. If the
        browser build cannot create a background Target, fail that operation rather
        than stealing focus from the user's desktop/profile window.
        """
        try:
            with _LOCAL_OPENER.open(self._debug_url("/json/version"), timeout=3) as r:
                ver = json.loads(r.read().decode(errors="replace"))
            bws = ver.get("webSocketDebuggerUrl")
            if not bws:
                raise RuntimeError("browser websocket unavailable")
            bc = CDP(bws)
            bc.connect()
            try:
                rr = bc.call("Target.createTarget", {
                    "url": url or "about:blank",
                    "background": True,
                }) or {}
                tid = rr.get("targetId")
            finally:
                bc.close()
            if not tid:
                raise RuntimeError("Target.createTarget did not return targetId")
            deadline = time.monotonic() + 4.0
            while time.monotonic() < deadline:
                for t in self.targets():
                    if t.get("id") == tid:
                        return t
                time.sleep(.025)
            raise RuntimeError("background Target not visible in /json")
        except Exception as e:
            raise RuntimeError("纯CDP后台建页失败（禁止任何抢前台回退）：" + str(e))

    def target(self, k):
        """Attach to an existing list; queryless tabs are UNVERIFIED candidates.

        Only the real owner/latest POST + API/DOM comparison can promote a
        queryless candidate to a monitoring source. Never create a tab.
        """
        bare_candidate = None
        for p in self.targets():
            kind = existing_list_url_kind(p.get('url', ''), k)
            if kind == 'explicit':
                return p
            if kind == 'bare' and bare_candidate is None:
                bare_candidate = p
        return bare_candidate

    def _list_tab_alive(self, lane, tab_id):
        try:
            tab = self.target(lane)
            return bool(tab and tab.get('id') == tab_id)
        except Exception:
            return False

    def _attach_running_browser(self):
        """Re-discover an ALREADY RUNNING BitBrowser CDP port. No /browser/open."""
        if self._cdp_base_alive():
            return True
        if self.browser_type.get() != 'BitBrowser':
            return False
        if not self.reconnect_lock.acquire(blocking=False):
            return False
        try:
            from bitbrowser_adapter import _extract_port_from_ports, _extract_endpoint_candidates
            bid = self.pid
            if not bid:
                profile = self._find_bit_profile(self.bit_no.get().strip())
                bid = profile.get('id') or profile.get('browserId')
            if not bid:
                return False
            for payload in ({'ids':[str(bid)]}, {'id':str(bid)}):
                try:
                    ans = self.bit_call('/browser/ports', payload)
                    possible = _extract_endpoint_candidates(ans, str(bid))
                    port = _extract_port_from_ports(ans, str(bid))
                    if port:
                        possible.append(f'http://127.0.0.1:{port}')
                    for endpoint in possible:
                        u = parse.urlparse(endpoint)
                        if u.port and u.hostname in ('127.0.0.1','localhost'):
                            old = self.cdp_base
                            self.cdp_base = f'http://127.0.0.1:{u.port}'
                            if self._cdp_base_alive():
                                self.port = u.port
                                self.pid = bid
                                self.cdp_fault_event.clear()
                                if old != self.cdp_base:
                                    self.write('[28-REATTACH] 已重新接上原有 BitBrowser CDP；未開啟瀏覽器／分頁')
                                return True
                            self.cdp_base = old
                except Exception:
                    continue
            return False
        finally:
            self.reconnect_lock.release()

    def cdp(self, t):
        c = CDP(t["webSocketDebuggerUrl"])
        c.connect()
        return c

    def pid_of(self, u):
        m = re.search(r"/property-(\d{6,10})(?!\d)(?:[/?#]|$)", str(u), re.I)
        return m.group(1) if m else None

    def urls(self, c):
        js = r'''(()=>{const o=[];for(const a of document.querySelectorAll('a[href*="property-"]')){try{const u=new URL(a.href,location.href);if(/(^|\.)28hse\.com$/i.test(u.hostname)&&/\/property-\d{6,10}\/?$/i.test(u.pathname)){u.search='';u.hash='';o.push(u.href.replace(/\/$/,''));}}catch(e){}}return [...new Set(o)].slice(0,120)})()'''
        return c.ev(js) or []

    def refresh(self, c, label=""):
        # V1.30 fixed 500ms trigger: never wait on request-completion state.
        self.keep_page_active(c)
        info = c.ev(r'''(()=>{
          const clean=v=>((v&&((v.innerText||v.value)||''))+'').replace(/\s+/g,' ').trim();
          const nodes=[...document.querySelectorAll('button,input[type=button],input[type=submit],a,div[role=button]')];
          const e=nodes.find(x=>['搜尋','搜索','搜 尋'].includes(clean(x)))
               || nodes.find(x=>/搜尋|搜索/.test(clean(x)));
          if(!e) return {ok:false,reason:'search_button_missing'};
          try{e.click();return {ok:true};}
          catch(err){return {ok:false,reason:String(err&&err.message||err)}};
        })()''') or {}
        if not info.get("ok"):
            self.write("[%s] 500ms刷新：未能点击搜索（%s）" % (label or "搜索", info.get("reason", "unknown")))
            return False
        return True

    def stable_urls(self, c):
        deadline = time.monotonic() + 1.8
        last = None
        same = 0
        best = []
        while time.monotonic() < deadline:
            cur = self.urls(c)
            ids = tuple(sorted(self.pid_of(u) for u in cur if self.pid_of(u)))
            if len(cur) >= len(best):
                best = cur
            if ids and ids == last:
                same += 1
            else:
                last = ids
                same = 0
            if ids and same >= 2:
                return cur
            time.sleep(.16)
        return best

    def build_baseline(self, k, c):
        all_urls = {}
        deadline = time.monotonic() + 3.0
        stable_rounds = 0
        last_ids = None
        while time.monotonic() < deadline and self.running:
            cur = self.urls(c)
            for u in cur:
                pid = self.pid_of(u)
                if pid:
                    all_urls[pid] = u
            ids = tuple(sorted(all_urls))
            if ids and ids == last_ids:
                stable_rounds += 1
            else:
                stable_rounds = 0
                last_ids = ids
            if ids and stable_rounds >= 4:
                break
            time.sleep(.20)
        return list(all_urls.values())

    # ---------------- LiteHTTP list monitoring ----------------
    @staticmethod
    def list_url(k):
        trade = "rent" if k == "rent" else "buy"
        return "https://www.28hse.com/%s?landlordAgency=LANDLORD&sortBy=latest" % trade

    def close_target_id(self, tid):
        if not tid:
            return
        try:
            with _LOCAL_OPENER.open(self._debug_url("/json/version"), timeout=2.5) as r:
                ver = json.loads(r.read().decode(errors="replace"))
            bws = ver.get("webSocketDebuggerUrl")
            if not bws:
                return
            bc = CDP(bws)
            bc.connect()
            try:
                bc.call("Target.closeTarget", {"targetId": tid})
            finally:
                bc.close()
        except Exception:
            pass
        finally:
            with self.lock:
                self.http_target_ids.discard(tid)

    def open_http_bridge(self, k):
        # robots.txt is intentionally tiny. It gives the bridge the 28Hse origin,
        # browser profile cookies and the environment's proxy without rendering a
        # full search page. Image blocking in BitBrowser does not affect it.
        anchor = "https://www.28hse.com/robots.txt"
        t = self.create_background_target(anchor)
        tid = t.get("id")
        if tid:
            with self.lock:
                self.http_target_ids.add(tid)
        c = None
        try:
            c = self.cdp(t)
            c.call("Runtime.enable")
            self.keep_bridge_active(c)
            deadline = time.monotonic() + 5.0
            while time.monotonic() < deadline:
                # A retired CDP socket must be replaced by its caller, not
                # retried until the end of the 5-second origin wait.
                if c.dead:
                    raise ConnectionError('28Hse HTTP bridge socket retired')
                try:
                    host = c.ev("location.hostname") or ""
                    if str(host).lower().endswith("28hse.com"):
                        return t, c
                except Exception:
                    if c.dead:
                        raise
                time.sleep(.05)
            raise RuntimeError("低资源 HTTP bridge 未能取得 28Hse origin")
        except BaseException:
            # A connect/Runtime.enable failure previously left the temporary
            # robots.txt Target alive and leaked background browser resources.
            if c:
                try: c.close()
                except Exception: pass
            if tid:
                self.close_target_id(tid)
            raise

    def http_snapshot(self, c, k, timeout_ms=650, known_ids=None, baseline=False):
        # DetectionRace: normal rounds stop as soon as the top of the latest list
        # proves whether a NEW burst exists. Only the first baseline reads 12 ids.
        url = self.list_url(k)
        trade = "rent" if k == "rent" else "buy"
        timeout_ms = max(1350, min(5000, int(timeout_ms or 2200)))
        known_ids = [str(x) for x in (known_ids or []) if str(x)]
        expr = r'''(async()=>{
          const base=__URL__, trade=__TRADE__, timeoutMs=__TIMEOUT__;
          const known=new Set(__KNOWN__), baseline=__BASELINE__;
          const ctl=new AbortController();
          const timer=setTimeout(()=>ctl.abort(),timeoutMs);
          const urls=[], newUrls=[], seen=new Set();
          let firstByteMs=0, firstIdMs=0, firstNewMs=0, bytes=0;
          let hitKnownAfterNew=false, carry='', pre='';
          const started=performance.now();

          const pidOf=(u)=>{const m=(u.pathname||'').match(/\/property-(\d{6,10})\/?$/i);return m?m[1]:''};
          const addHref=(href)=>{
            try{
              const u=new URL(href,base);
              if(!/(^|\.)28hse\.com$/i.test(u.hostname))return;
              if(!new RegExp('^/'+trade+'/[^/]+/property-[0-9]{6,10}/?$','i').test(u.pathname))return;
              if(!/\/property-\d{6,10}\/?$/i.test(u.pathname))return;
              u.search='';u.hash='';const v=u.href.replace(/\/$/,'');
              if(seen.has(v))return;
              seen.add(v);urls.push(v);
              const pid=pidOf(u);
              if(!firstIdMs)firstIdMs=Math.max(1,Math.round(performance.now()-started));
              if(pid && !known.has(pid)){
                newUrls.push(v);
                if(!firstNewMs)firstNewMs=Math.max(1,Math.round(performance.now()-started));
              }else if(newUrls.length){hitKnownAfterNew=true}
            }catch(e){}
          };
          // 28Hse may place property links in HTML attributes, JSON strings,
          // escaped slash strings or relative URLs. Extract all property categories for the same trade.
          // OwnerLock is verified against response.url before reading this content.
          const scan=(text)=>{
            if(!text)return;
            const normal=text.replace(/\\\//g,'/').replace(/&amp;/gi,'&')
                 .replace(/&#0*47;|&#x0*2f;/gi,'/');
            const re=/(?:https?:\/\/(?:www\.)?28hse\.com)?\/(?:rent|buy)\/[a-z0-9_-]+\/property-\d{6,10}(?=[\/?#&\s'"<>\\])(?:\/)?(?:\?[^\s"'<>\\]*)?/gi;
            let m;
            while((m=re.exec(normal))!==null){
              addHref(m[0]);
              if(shouldStop())break;
            }
          };
          const shouldStop=()=>{
            if(baseline)return urls.length>=12;
            if(newUrls.length)return true;
            // Do not stop after unrelated page links; scan until a real NEW or EOF.
            return false;
          };

          try{
            const r=await fetch(base,{
              method:'GET',credentials:'include',cache:'no-cache',redirect:'follow',signal:ctl.signal,priority:'high',
              headers:{'Cache-Control':'no-cache, max-age=0','Pragma':'no-cache','Accept':'text/html,application/xhtml+xml'}
            });
            if(!r.ok){
              const ra=r.headers.get('Retry-After')||'';
              return {ok:false,status:r.status,kind:r.status===429?'rate':((r.status===401||r.status===403)?'access':'transient'),retryAfter:ra,error:'HTTP '+r.status};
            }
            // Enforce owner-only/latest after redirects; never consume a filtered-out response.
            const finalUrl=new URL(r.url,base);
            if(!/(^|\.)28hse\.com$/i.test(finalUrl.hostname)||
               finalUrl.searchParams.get('landlordAgency')!=='LANDLORD'||
               finalUrl.searchParams.get('sortBy')!=='latest'||
               !new RegExp('^/'+trade+'/?$','i').test(finalUrl.pathname)||
               finalUrl.searchParams.has('category')||finalUrl.searchParams.has('propertyType')){
              return {ok:false,status:r.status,kind:'filter',error:'OWNERLOCK_FINAL_URL_MISMATCH: '+finalUrl.href};
            }
            if(r.body&&r.body.getReader){
              const reader=r.body.getReader(), dec=new TextDecoder();
              while(true){
                const part=await reader.read();
                if(part.done)break;
                if(!firstByteMs)firstByteMs=Math.max(1,Math.round(performance.now()-started));
                const chunk=dec.decode(part.value,{stream:true});
                bytes += part.value ? part.value.byteLength : 0;
                // Scan streaming bytes immediately. Waiting for an exact
                // search_results_div marker misses newer page layouts.
                const text=carry+chunk;
                scan(text);
                carry=text.slice(-512);
                if(shouldStop()){try{await reader.cancel()}catch(e){};break}
              }

            }else{
              const html=await r.text();bytes=html.length;
              firstByteMs=Math.max(1,Math.round(performance.now()-started));
              scan(html);
            }
            if(!urls.length){
              const text=(pre||carry||'');
              if(/verify you are human|checking your browser|attention required|人機驗證|人机验证|請完成驗證|请完成验证/i.test(text))
                return {ok:false,status:r.status,kind:'access',error:'网站要求人工验证'};
              return {ok:false,status:r.status,kind:'transient',error:'LIST_PARSE_EMPTY bytes='+bytes+' final='+finalUrl.href};
            }
            return {ok:true,status:r.status,rows:urls.slice(0,120).map(url=>({url,name:'未知',phones:[]})),newUrls:newUrls.slice(0,12),bytes,firstByteMs,firstIdMs,firstNewMs,totalMs:Math.max(1,Math.round(performance.now()-started))};
          }catch(e){
            if(e&&e.name==='AbortError')return {ok:false,status:0,kind:'timeout',error:'LIST_TIMEOUT'};
            return {ok:false,status:0,kind:'transient',error:String(e)};
          }finally{clearTimeout(timer)}
        })()'''.replace('__URL__', json.dumps(url, ensure_ascii=False)).replace('__TRADE__', json.dumps(trade)).replace('__TIMEOUT__', str(timeout_ms)).replace('__KNOWN__', json.dumps(known_ids)).replace('__BASELINE__', 'true' if baseline else 'false')
        rr = c.call("Runtime.evaluate", {"expression": expr, "awaitPromise": True, "returnByValue": True, "userGesture": False}) or {}
        value = ((rr.get("result") or {}).get("value"))
        if not isinstance(value, dict): raise RuntimeError("DetectionRace 未返回有效结果")
        if not value.get("ok"):
            kind=value.get("kind") or "transient"; msg=value.get("error") or "HTTP读取失败"
            if kind=="timeout": raise TimeoutError("LIST_TIMEOUT")
            if kind=="rate": raise RuntimeError("RATE_LIMIT:%s" % (value.get("retryAfter") or "2"))
            if kind=="access": raise PermissionError(msg)
            raise RuntimeError(msg)
        clean=[]; seen=set(); meta={}
        for row in value.get("rows") or []:
            u=str((row or {}).get("url") or "").strip().rstrip("/")
            pid=self.pid_of(u)
            if not pid or u in seen: continue
            seen.add(u);clean.append(u);meta[pid]={"name":"未知","phones":[]}
        timing={
            "first_byte_ms":int(value.get("firstByteMs") or 0),
            "first_id_ms":int(value.get("firstIdMs") or 0),
            "first_new_ms":int(value.get("firstNewMs") or 0),
            "js_total_ms":int(value.get("totalMs") or 0),
            "new_urls":[str(x).rstrip("/") for x in (value.get("newUrls") or []) if self.pid_of(str(x))],
        }
        return clean, int(value.get("bytes") or 0), meta, timing

    def http_phone_direct(self, c, k, url, test_mode=False, wa_test=False, race_t0=None):
        """PhoneFirst: ad_id + static fields only; NO GET detail, NO detail Target.

        Returns (terminal, accepted, reason).  The caller may try the legacy
        HTTP detail-HTML path if a complete phone is not returned.  If the
        origin reports an access challenge/429, stop instead of retrying it.
        """
        pid = self.pid_of(url)
        if not pid:
            return False, False, '樓盤 ID 無效'
        started = time.perf_counter()
        try:
            expr = make_direct_expression(pid, url, timeout_ms=1900)
            rr = c.call('Runtime.evaluate', {
                'expression': expr, 'awaitPromise': True,
                'returnByValue': True, 'userGesture': False,
            }, timeout=2.75) or {}
            value = ((rr.get('result') or {}).get('value'))
        except Exception as exc:
            reason = 'API 執行失敗：' + str(exc)[:130]
            self.write('[28-DIRECT-FALLBACK] %s %s · %s' % (k, pid, reason))
            return False, False, reason
        duration_ms = int((time.perf_counter()-started)*1000)
        if not isinstance(value, dict):
            return False, False, 'API 無有效結果'
        if value.get('blocked'):
            reason = str(value.get('reason') or '電話 API 限流或需要人工驗證')[:140]
            if value.get('status') == 429 and self.__dict__.get('api_429_guard') is not None:
                cooldown, _, _ = self.api_429_guard.rate_limited(value.get('retryAfter'))
                if self.__dict__.get('api_adaptive_scheduler') is not None:
                    self.api_adaptive_scheduler.rate_limited()
                self.write('[28-PHONE-429] %s %s · HTTP 429；租售共用冷卻 %.1fs，不丟失待取號樓盤' % (k,pid,cooldown))
                if callable(getattr(self, 'on_28_api_cooldown', None)):
                    self.on_28_api_cooldown('電話 API', cooldown)
            self.write('[28-DIRECT-BLOCKED] %s %s · %s；停止本帖後續請求' % (k,pid,reason))
            return True, False, reason
        rows = value.get('rows') or []
        if value.get('ok') and rows:
            success, notes = False, []
            for idx, item in enumerate(rows):
                if not isinstance(item, dict):
                    continue
                number = self.normalize_phone(item.get('phone'))
                if not number or len(number)!=8:
                    continue
                name = item.get('name') or '未知'
                ok, reason = self.result(k, name, number, url, test_mode=test_mode,
                                         wa_test=wa_test, race_t0=race_t0,
                                         extra_phones=rows[idx+1:])
                if ok:
                    success=True
                    if not (test_mode or wa_test):
                        for extra in rows[idx+1:]:
                            if isinstance(extra,dict):
                                self.bg(self.publish_secondary_phone, k, url,
                                        extra.get('name') or '未知',extra.get('phone') or '')
                    break
                notes.append(reason or '號碼已過濾')
            end_ms=int((time.perf_counter()-race_t0)*1000) if race_t0 else duration_ms
            self.write('[28-DIRECT] %s %s · %dms API · NEW→PHONE %dms · %s' % (
                k,pid,duration_ms,end_ms,'成功・0詳情頁・0揭號點擊' if success else '電話已過濾或去重'))
            # Don't open details when API returned phones already known/filtered.
            return True, success, '直接 API 已取得電話' if success else '；'.join(notes)
        reason = str(value.get('reason') or '電話 API 沒有公開電話')[:140]
        self.write('[28-DIRECT-FALLBACK] %s %s · %dms · %s' % (k,pid,duration_ms,reason))
        return False, False, reason

    def update_28_phone_mode(self):
        """Called on Tk thread for live setting updates."""
        self.phone_api_direct_enabled = bool(self.phone_api_direct_var.get())
        self.phone_api_allow_detail = bool(self.phone_api_allow_detail_var.get())
        self.save_config()

    def no_detail_phone_fallback(self, k, url, detected_t0, reason, run_id):
        """One delayed HTTP-only retry, never open a detail page or spin."""
        pid=self.pid_of(url)
        if not pid:return
        with self.lock:
            n=self.http_retry_attempts[k].get(pid,0)
            self.http_retry_attempts[k][pid]=n+1
        if n>=1 or not self.running or run_id!=self.run_id:
            self.set_listing_status(k,url,'HTTP 取號失敗（不開帖）')
            self.write('[28-NO-DETAIL] %s %s · HTTP 未取號，禁止打開詳情 · %s' % (k,pid,str(reason)[:110]))
            with self.lock:self.inflight[k].discard(pid)
            return
        self.set_listing_status(k,url,'HTTP 補抓排程中…')
        self.write('[28-HTTP-RETRY] %s %s · 2秒後再查一次，不開詳情' % (k,pid))
        def later():
            time.sleep(2)
            if self.running and self.run_id==run_id and not self.cdp_fault_event.is_set():
                self.phone_jobs[k].put((url,detected_t0))
            else:
                # Important: don't leave the property permanently 'inflight'
                # when a delayed retry is cancelled by a CDP outage/Stop.
                # A subsequent manual retry or a fresh run must not be blocked.
                with self.lock:
                    self.inflight[k].discard(pid)
                if self.running and self.run_id==run_id:
                    self.set_listing_status(k,url,'HTTP 補試取消：等候 CDP 恢復')
                    self.write('[28-HTTP-RETRY-CANCEL] %s %s · CDP暫停；釋放取號中狀態' % (k,pid))
        self.bg(later)

    def http_phone_fast(self, c, k, url, test_mode=False, wa_test=False, race_t0=None):
        # V1.40 UltraRace hot path.  The old code waited for detail response.text(),
        # then parsed action parameters.  This version parses the streaming HTML
        # head and fires the public phone action the moment uid_code+timeStamp exist.
        pid = self.pid_of(url)
        if not pid:
            return False, False, "房源链接没有 property id"
        started = time.perf_counter()
        with self.learning_lock:
            budget_ms = self.speed_learning[k]["budget_ms"]
        expr = r'''(async()=>{
          const url=__URL__, pid=__PID__, t0=performance.now();
          const totalCtl=new AbortController();
          const totalTimer=setTimeout(()=>totalCtl.abort(),__BUDGET__);
          const norm=v=>{
            let d=((v||'')+'').replace(/\D/g,'');
            if(d.startsWith('00852'))d=d.slice(5);
            else if(d.length===11&&d.startsWith('852'))d=d.slice(3);
            return /^[2-9]\d{7}$/.test(d)?d:'';
          };
const contactNameFromSegment=(segment,fallback='未知')=>{
            let t=String(segment||'').replace(/放盤聯絡人|放盘联络人|(?:致[電电]|撥打電話|拨打电话|WhatsApp|發訊|发讯|複製|复制)/ig,' ').trim();
            const titled=[...t.matchAll(/([\u3400-\u9fff]{1,5}(?:太太|先生|小姐|女士|太|姐|生)(?:\s*[A-Za-z][A-Za-z .]{0,35})?)/g)];
            if(titled.length)return titled[titled.length-1][1].trim();
            const english=[...t.matchAll(/\b(?:Mrs|Ms|Miss|Mr)\.?\s*[A-Za-z][A-Za-z .]{0,35}/gi)];
            if(english.length)return english[english.length-1][0].trim();
            const lines=t.split(/[\n\r]+/).map(x=>x.trim()).filter(Boolean);
            const last=lines[lines.length-1]||'';
            if(last.length>=2&&last.length<=60&&/[A-Za-z]/.test(last)&&
              !/Tel\s*[:：]|電話|电话|^https?:|房源|(?:^|\s)Phone/i.test(last))return last;
            return fallback;
          };
          const textTelephoneRows=(t,defaultName='未知')=>{
            const rows=[],rx=/(?:Tel\.?|電話|电话)\s*[:：]\s*(?:\+?852[\s-]*)?([2-9]\d{3}[\s-]?\d{4})(?!\d)/ig;
            let cursor=0;
            for(const m of String(t||'').matchAll(rx)){
              const segment=String(t).slice(cursor,m.index);
              const name=contactNameFromSegment(segment,rows.length?'未知':defaultName);
              rows.push({name,phone:m[1].replace(/\D/g,'')});
              cursor=m.index+m[0].length;
            }
            return rows;
          };
          const rowsFromFragments=(contacts)=>{
            const rows=[],seen=new Set();
            const add=(name,phone)=>{let p=norm(phone);if(p&&!seen.has(p)){seen.add(p);rows.push({name:name||'未知',phone:p})}};
            for(const frag of (Array.isArray(contacts)?contacts:[])){
              if(typeof frag!=='string')continue;
              const fd=new DOMParser().parseFromString(frag,'text/html');
              const blocks=[...fd.querySelectorAll('.content_phone_information')];
              if(!blocks.length)blocks.push(fd.body||fd);
              for(const block of blocks){
                const named=block.querySelector('[class*="contact-name"],[class*="contact_name"],[class*="contactName"],[class*="person-name"]');
                const defaultName=(named&&(named.textContent||'').trim().slice(0,70))||'未知';
                const text=block.textContent||'';
                // Read *each* Tel + its preceding contact separately. Never assign
                // the first contact's name to a later person's number.
                const telRows=textTelephoneRows(text,defaultName);
                for(const item of telRows)add(item.name,item.phone);
                // Some results expose phone via tel: instead of Tel: labels.
                // Take the nearest compact ancestor's name when possible.
                for(const a of block.querySelectorAll('a[href]')){
                  const h=a.getAttribute('href')||'';
                  if(/^tel:/i.test(h)){
                    const context=(a.parentElement&&a.parentElement.textContent)||'';
                    add(contactNameFromSegment(context.split(/Tel\s*[:：]/i)[0],telRows.length?'未知':defaultName),h.replace(/^tel:/i,'').split('?')[0]);
                  }
                }
                for(const x of block.querySelectorAll('.fullPhone')){
                  add(telRows.length?'未知':defaultName,x.textContent||'');
                }
              }
            }
            return rows;
          };
                    const phoneAction=async(uid,stamp)=>{
            const action='https://www.28hse.com/property/detail/doaction';
            const actionStart=performance.now();
            const body=new URLSearchParams({action:'statistic_inc',user_action:'phone',uid_code:uid,ad_id:String(pid),timeStamp:stamp,event_name:'property_contact_phone'});
            const rr=await fetch(action,{
              method:'POST',credentials:'include',cache:'no-store',redirect:'follow',signal:totalCtl.signal,
              referrer:url,referrerPolicy:'strict-origin-when-cross-origin',priority:'high',
              headers:{'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest','Cache-Control':'no-cache, no-store, max-age=0','Pragma':'no-cache'},
              body:body.toString()
            });
            if(!rr.ok)return {rows:[],reason:'致电接口 HTTP '+rr.status,actionMs:Math.round(performance.now()-actionStart)};
            let data=null; try{data=await rr.json()}catch(e){return {rows:[],reason:'致电接口响应无法解析',actionMs:Math.round(performance.now()-actionStart)}}
            const values=data&&data.data&&data.data.results;
            if(!values||typeof values!=='object')return {rows:[],reason:'致电接口没有 results',actionMs:Math.round(performance.now()-actionStart)};
            if(values.need_verify)return {rows:[],reason:'致电接口要求人工验证',actionMs:Math.round(performance.now()-actionStart)};
            const rows=rowsFromFragments(values.contacts);
            return {rows,reason:rows.length?'':'致电接口未返回公开号码',actionMs:Math.round(performance.now()-actionStart)};
          };
          try{
            const detailStart=performance.now();
            const r=await fetch(url,{
              method:'GET',credentials:'include',cache:'no-store',redirect:'follow',signal:totalCtl.signal,priority:'high',
              headers:{'Cache-Control':'no-cache, no-store, max-age=0','Pragma':'no-cache','Accept':'text/html,application/xhtml+xml'}
            });
            if(!r.ok)return {terminal:false,ok:false,reason:'详情 HTTP '+r.status,totalMs:Math.round(performance.now()-t0)};
            let buf='', uid='', stamp='', bytes=0, actionPromise=null, headMs=0;
            const inspect=()=>{
              if(!uid){const m=buf.match(/var\s+uid_code\s*=\s*'([^']+)'/);if(m)uid=m[1];}
              if(!stamp){const m=buf.match(/timeStamp\s*:\s*'([0-9]+)'/);if(m)stamp=m[1];}
              if(uid&&stamp&&!actionPromise){
                headMs=Math.round(performance.now()-detailStart);
                actionPromise=phoneAction(uid,stamp).catch(e=>({rows:[],reason:String(e)}));
              }
            };
            // V1.46.2: do not discard the remainder of the HTML when the
            // contact action parameters appear in the <head>. The actual
            // owner contact telephone can be in later streaming bytes.
            const visibleFromBuffer=(html)=>{
              if(!/content_phone_information|放盤聯絡人|放盘联络人/i.test(html) ||
                 !/Tel\.?\s*[:：]|電話\s*[:：]|电话\s*[:：]|href\s*=\s*["']tel:/i.test(html))return [];
              const buf=html;
              const doc=new DOMParser().parseFromString(buf,'text/html');
              const blocks=[...doc.querySelectorAll('.content_phone_information,[class*="contact_information"],[class*="contact-info"],[class*="contactInformation"]')];
              const headings=[...doc.querySelectorAll('h2,h3,h4,h5,strong,b,div,span')].filter(e=>
                e.childElementCount<=2&&/^(放盤聯絡人|放盘联络人)$/.test((e.textContent||'').trim()));
              for(const h of headings.slice(0,2)){
                for(let p=h.parentElement,d=0;p&&p!==doc.body&&d<6;p=p.parentElement,d++){
                  if(/Tel\.?\s*[:：]|電話\s*[:：]|电话\s*[:：]/i.test((p.textContent||'').slice(0,6500))){blocks.push(p);break;}
                }
              }
              const visible=[], seen=new Set();
              const telRx=/(?:Tel\.?|電話|电话)\s*[:：]\s*(?:\+?852[\s-]*)?([2-9]\d{3}[\s-]?\d{4})(?!\d)/ig;
              for(const block of blocks.slice(0,8)){
                if(block.closest('.recommend,.recommendation,.related,.advertisement,.ads,aside'))continue;
                const named=block.querySelector('[class*="contact-name"],[class*="contact_name"],[class*="contactName"],[class*="person-name"]');
                const defaultName=(named&&(named.textContent||'').trim().slice(0,70))||'未知';
                const t=(block.textContent||'').slice(0,6500);
                const add=(name,p)=>{const v=norm(p);if(v&&!seen.has(v)){seen.add(v);visible.push({name:name||'未知',phone:v})}};
                const telRows=textTelephoneRows(t,defaultName);
                for(const item of telRows)add(item.name,item.phone);
                for(const a of block.querySelectorAll('a[href^="tel:"]')){
                  const context=(a.parentElement&&a.parentElement.textContent)||'';
                  add(contactNameFromSegment(context.split(/Tel\s*[:：]/i)[0],telRows.length?'未知':defaultName),a.getAttribute('href')||'');
                }
              }
              return visible;
            };
            let visibleRows=[], actionResult=null, activeReader=null, actionWon=false;
            // PhoneFirst: race each subsequent HTML chunk against the pending
            // authorized phone action. The old code awaited reader.read() before
            // observing action completion; a stalled HTML stream could add
            // seconds even after the phone endpoint had already responded.
            if(r.body&&r.body.getReader){
              activeReader=r.body.getReader();
              const reader=activeReader, dec=new TextDecoder();
              while(true){
                // Only one read() in flight. Never issue overlapping reads.
                const pendingRead=reader.read().then(
                  part=>({kind:'chunk',part}),
                  error=>({kind:'read-error',error})
                );
                let outcome;
                if(actionPromise && !actionResult){
                  outcome=await Promise.race([
                    pendingRead,
                    actionPromise.then(pr=>({kind:'action',pr}),
                                       error=>({kind:'action',pr:{rows:[],reason:String(error)}}))
                  ]);
                  if(outcome.kind==='action'){
                    actionResult=outcome.pr;
                    if(actionResult.rows && actionResult.rows.length){
                      actionWon=true;
                      // Cancel without waiting for a slow network teardown.
                      try{reader.cancel().catch(()=>{})}catch(e){}
                      break;
                    }
                    // A failed action is not proof the owner has no visible Tel;
                    // resume the SAME pending read, without starting a second.
                    outcome=await pendingRead;
                  }
                }else{
                  outcome=await pendingRead;
                }
                if(outcome.kind==='read-error'){
                  if(actionPromise)break; // still accept a valid action result
                  throw outcome.error;
                }
                const part=outcome.part;
                if(part.done)break;
                bytes += part.value ? part.value.byteLength : 0;
                buf += dec.decode(part.value,{stream:true});
                if(buf.length>850000)buf=buf.slice(-780000);
                inspect();
                // Parse visible numbers only when contact markers are present.
                if(/放盤聯絡人|放盘联络人|content_phone_information/i.test(buf) &&
                   /Tel\.?\s*[:：]|href\s*=\s*["']tel:/i.test(buf)){
                  visibleRows=visibleFromBuffer(buf);
                  if(visibleRows.length){
                    try{reader.cancel().catch(()=>{})}catch(e){}
                    break;
                  }
                }
                if(bytes>1050000){
                  try{reader.cancel().catch(()=>{})}catch(e){}
                  break;
                }
              }
            }else{
              buf=await r.text(); inspect();
              visibleRows=visibleFromBuffer(buf);
            }
            if(/verify you are human|checking your browser|attention required|人機驗證|人机验证|請完成驗證|请完成验证/i.test(buf))
              return {terminal:false,ok:false,reason:'网站要求人工验证',totalMs:Math.round(performance.now()-t0)};
            if(visibleRows.length){
              // This path does not need a CDP target or a phone click.
              totalCtl.abort();
              return {terminal:true,ok:true,rows:visibleRows,source:'detail-stream-visible-tel',headMs,totalMs:Math.round(performance.now()-t0)};
            }
            if(actionPromise){
              const pr=actionResult || await actionPromise;
              if(pr.rows&&pr.rows.length)return {terminal:true,ok:true,rows:pr.rows,source:(actionWon?'phone-action-early':'phone-action-stream'),headMs,actionMs:pr.actionMs,totalMs:Math.round(performance.now()-t0)};
              return {terminal:false,ok:false,reason:pr.reason||'致电接口未返回公开号码',headMs,actionMs:pr.actionMs,totalMs:Math.round(performance.now()-t0)};
            }
            return {terminal:false,ok:false,reason:'详情前段未及时取得电话动作参数',headMs,totalMs:Math.round(performance.now()-t0)};
          }catch(e){
            return {terminal:false,ok:false,reason:(e&&e.name==='AbortError')?'UltraRace取号超过自适应等待上限':String(e),totalMs:Math.round(performance.now()-t0)};
          }finally{clearTimeout(totalTimer);}
        })()'''.replace('__URL__', json.dumps(url, ensure_ascii=False)).replace('__PID__', json.dumps(str(pid))).replace('__BUDGET__', str(budget_ms))
        try:
            # The browser-side fetch has its own budget. Give the CDP reply
            # slightly longer than that budget, otherwise the host closes the
            # command precisely when JavaScript is finishing normally.
            ack_timeout = min(4.75, max(2.5, float(budget_ms) / 1000.0 + 0.65))
            rr = c.call("Runtime.evaluate", {"expression": expr, "awaitPromise": True, "returnByValue": True, "userGesture": True}, timeout=ack_timeout) or {}
            value = ((rr.get("result") or {}).get("value"))
        except Exception as e:
            return False, False, "UltraRace HTTP异常：" + str(e)
        ms = int((time.perf_counter() - started) * 1000)
        total_ms = int((time.perf_counter() - race_t0) * 1000) if race_t0 else ms
        if not isinstance(value, dict):
            self.learn_phone_latency(k, False, ms, test_mode or wa_test)
            self.learn_strategy(k, "http", False, ms, test_mode or wa_test)
            return False, False, "UltraRace未返回有效结果"
        rows = value.get("rows") or []
        if value.get("terminal") and rows:
            accepted=False; reasons=[]
            for idx, row in enumerate(rows):
                phone=self.normalize_phone((row or {}).get("phone") or "")
                name=(row or {}).get("name") or "未知"
                if not phone: continue
                ok,reason=self.result(k,name,phone,url,test_mode=test_mode,wa_test=wa_test,
                                      race_t0=race_t0, extra_phones=rows[idx+1:])
                if ok:
                    accepted=True; reasons.append(reason or "抓号成功")
                    if not (test_mode or wa_test):
                        for extra in rows[idx+1:]:
                            self.bg(self.publish_secondary_phone, k, url,
                                    extra.get('name') or name, extra.get('phone') or '')
                    break
                elif reason: reasons.append(reason)
            source=value.get("source") or "HTTP"
            head_ms=int(value.get("headMs") or 0); action_ms=int(value.get("actionMs") or 0)
            if accepted:
                self.learn_phone_latency(k, True, ms, test_mode or wa_test)
                self.learn_strategy(k, "http", True, ms, test_mode or wa_test)
                self.write("[PHONE] %dms · head %dms · action %dms · %s" % (total_ms,head_ms,action_ms,source))
                return True,True,"UltraRace抓号成功（NEW→PHONE %dms）" % total_ms
            self.write("[ULTRA] %dms：已取得号码，但被过滤/去重" % total_ms)
            return True,False,"；".join(reasons) or "号码已被过滤或去重"
        self.learn_phone_latency(k, False, ms, test_mode or wa_test)
        self.learn_strategy(k, "http", False, ms, test_mode or wa_test)
        reason=value.get("reason") or "UltraRace未取得号码"
        self.write("[ULTRA] %dms：%s -> %s" % (total_ms, reason,
                   'CDP后台备援' if self.phone_api_allow_detail else '零開帖 HTTP 備援（不開詳情）'))
        return False,False,reason

    def fast_test_detail(self, k, url, test_mode=False, wa_test=False):
        # V1.44.3: A test must NEVER queue behind real NEW phone jobs or
        # consume an UltraRace worker for a long CDP fallback. A disposable
        # HTTP bridge is used for tests; real monitoring lanes stay warm.
        t = c = None
        tid = None
        terminal = False
        reason = ""
        try:
            self.write('[TEST] 独立测试 bridge；正式取号 lane 不排队、不阻塞')
            t, c = self.open_http_bridge(k)
            tid = t.get("id")
            if self.phone_api_direct_enabled:
                terminal, ok, reason = self.http_phone_direct(
                    c, k, url, test_mode=test_mode, wa_test=wa_test)
                if terminal: return ok, reason
            terminal, ok, reason = self.http_phone_fast(
                c, k, url, test_mode=test_mode, wa_test=wa_test)
            if terminal:
                return ok, reason
        except Exception as e:
            reason = '测试 HTTP bridge 异常：' + str(e)
            self.write('[TEST] ' + reason)
        finally:
            if c:
                try: c.close()
                except Exception: pass
            if tid:
                self.close_target_id(tid)
        if not self.phone_api_allow_detail:
            self.write('[TEST] 28Hse 零開帖模式：API/HTTP 失敗，不啟動詳情')
            return False, reason or 'API/HTTP 未取得電話（零開帖模式）'
        self.write('[TEST] HTTP 快速路径未成功：%s；转独立 CDP 详情' % (reason or '未取得号码'))
        return self.detail(k, url, test_mode=test_mode, wa_test=wa_test)

    def probe_http_once(self, k):
        t = c = None
        tid = None
        try:
            t, c = self.open_http_bridge(k)
            tid = t.get("id")
            try:
                return self.http_snapshot(c, k, timeout_ms=2200, known_ids=[], baseline=True)[0]
            except TimeoutError:
                self.write('[TEST] 列表首次超时，使用同一个 bridge 重试一次（2200ms）')
                return self.http_snapshot(c, k, timeout_ms=2200, known_ids=[], baseline=True)[0]
        finally:
            if c:
                try:
                    c.close()
                except Exception:
                    pass
            if tid:
                self.close_target_id(tid)

    # ---------------- Monitoring ----------------
    def api_test_28(self, k):
        """Test 28Hse rent/buy separately via the *direct* phone API only.

        The production phone job lanes and duplicate database are untouched.
        This never navigates to a listing/detail page; the short-lived
        robots.txt same-origin bridge is disposed of at the end.  No legacy
        HTML/UltraRace/CDP-detail fallback in an API-only test.
        """
        if k not in ('rent', 'buy'):
            raise ValueError('API test requires rent or buy')
        label = '租盤' if k == 'rent' else '售盤'
        title = '28Hse %s API 取號測試' % label
        t = c = None
        tid = None
        try:
            if not self.running or not self.api_source_enabled.get(k, False):
                raise RuntimeError('請先勾選並啟動 28Hse %s監控，確認列表查詢正常後再測試' % label)
            if self.api_rate_limit_event.is_set():
                raise RuntimeError('28Hse 已因 HTTP 429 暫停，請先人工確認後重新啟動監控')
            if not self.cdp_base or not self._cdp_base_alive():
                if not self._attach_running_browser():
                    raise RuntimeError('BitBrowser CDP 未連線；請先啟動監控並打開相應業主＋最新列表')
            # Use ONLY the listing results already obtained by the matching
            # lane. Never probe the other lane or generate new list requests.
            with self.lock:
                cached = list(self.http_latest.get(k) or [])
            seen_ids, urls = set(), []
            for u in cached:
                pid = self.pid_of(u)
                if pid and pid not in seen_ids:
                    seen_ids.add(pid)
                    urls.append(u)
                if len(urls) >= 3:
                    break
            if not urls:
                # The GUI can say "running" while the worker is still learning
                # or verifying its first owner-locked list. Wait in THIS test
                # thread rather than immediately reporting a false failure.
                test_run_id = self.run_id
                self.write('[28-API-TEST-WAIT] %s · 等待本路業主＋最新列表完成 API 驗證／建立快取（最多25秒；不另發列表請求）' % label)
                deadline = time.monotonic() + 25.0
                while (time.monotonic() < deadline and self.running and
                       self.run_id == test_run_id and
                       not self.api_rate_limit_event.is_set()):
                    with self.lock:
                        cached = list(self.http_latest.get(k) or [])
                    seen_ids, urls = set(), []
                    for u in cached:
                        pid = self.pid_of(u)
                        if pid and pid not in seen_ids:
                            seen_ids.add(pid)
                            urls.append(u)
                        if len(urls) >= 3:
                            break
                    if urls:
                        break
                    time.sleep(.25)
                if not urls:
                    if not self.running or self.run_id != test_run_id:
                        raise RuntimeError('監控已停止／重新開始；本次測試已取消')
                    if self.api_rate_limit_event.is_set():
                        raise RuntimeError('HTTP 429 全局暫停，無法執行測試')
                    current = self.target(k)
                    if current is None:
                        raise RuntimeError('找不到已開啟的 28Hse %s列表分頁。請手動開啟並選擇業主盤＋最新放盤；程式不會自動開頁' % label)
                    if existing_list_url_kind(current.get('url',''),k) == 'bare':
                        raise RuntimeError('已找到 /%s 列表，但尚未驗證「業主盤＋最新放盤」。請確認網站的兩個篩選項已選中並按「搜尋」，再查看 [API-LEARN]/[API-VERIFY] 日誌' % k)
                    raise RuntimeError('已找到%s列表，尚未完成業主＋最新 API 驗證。請查看 [API-LEARN]/[API-VERIFY] 或錯誤日誌後重試' % label)
            self.write('[28-API-TEST] %s · 使用本路最後成功列表快取前%d帖；只查直接電話 API／不開詳情／不寫入去重庫' % (label,len(urls)))
            t, c = self.open_http_bridge(k)
            tid = t.get('id')
            reasons=[]
            for u in urls:
                if self.api_rate_limit_event.is_set():
                    reasons.append('429 全局暫停')
                    break
                pid = self.pid_of(u)
                terminal, ok, reason = self.http_phone_direct(c,k,u,test_mode=True)
                if ok:
                    self.write('[28-API-TEST-SUCCESS] %s #%s · 0詳情頁／0揭號點擊' % (label,pid))
                    self.test_popup(title, True, '樓盤 #%s · 直接 API 成功（0詳情頁、0揭號點擊）' % pid)
                    return
                reasons.append('#%s: %s' % (pid,str(reason or '無完整電話')[:90]))
                self.write('[28-API-TEST-SKIP] %s #%s · %s' % (label,pid,str(reason or '無完整電話')[:90]))
                # 403/429/challenge: stop immediately; don't probe other IDs.
                if terminal and any(x in str(reason or '').lower() for x in
                                    ('429','403','限流','驗證','challenge','cloudflare','blocked')):
                    break
                if c.dead:
                    break
            self.test_popup(title, False,
                            '本路前%d帖沒有成功取號（0詳情頁）。\n%s' %
                            (len(urls), '\n'.join(reasons)))
        except Exception as exc:
            self.write('[28-API-TEST-ERROR] %s · %s' % (label,str(exc)[:180]))
            self.test_popup(title, False, str(exc))
        finally:
            if c:
                try: c.close()
                except Exception: pass
            if tid:
                self.close_target_id(tid)

    def ultra_test(self):
        """Legacy entry point: keep compatibility while testing direct API."""
        k = 'rent' if self.api_source_enabled.get('rent', False) else 'buy'
        return self.api_test_28(k)

    def whatsapp_test(self):
        """Send one real WhatsApp greeting to the first current listing, independent of schedule."""
        try:
            if not self.cdp_base:
                self.connect_browser()
            if not self.cdp_base:
                self.test_popup("WhatsApp 打招呼测试", False, "浏览器未连接 / 未取得 CDP 调试地址")
                return
            explicit = str(getattr(self, 'wa_test_selected_url', '') or '').strip()
            chosen = None
            url = None
            if explicit:
                from urllib.parse import urlsplit
                u = urlsplit(explicit)
                if u.scheme != 'https' or u.hostname not in ('28hse.com','www.28hse.com') or not self.pid_of(explicit):
                    raise ValueError('WA 測試指定房源網址不合法')
                chosen = 'rent' if u.path.startswith('/rent/') else 'buy' if u.path.startswith('/buy/') else None
                if not chosen:
                    raise ValueError('WA 測試指定房源必須是租盤或售盤')
                url = explicit
            else:
                ks = (["rent"] if self.rent.get() else []) + (["buy"] if self.buy.get() else [])
                if not ks:
                    ks = ["rent", "buy"]
                for k in ks:
                    with self.lock:
                        urls = list(self.http_latest.get(k) or [])
                    if not urls:
                        urls = self.probe_http_once(k)
                    if urls:
                        chosen, url = k, urls[0]
                        break
            if not url:
                raise RuntimeError("低资源 HTTP 列表没有找到可测试的房源")
            pid = self.pid_of(url) or "?"
            self.write("[WA-TEST] %s：%s %s；将抓取有效号码并实际发送测试消息" %
                       ("指定原帖" if explicit else "列表第一帖", "租盘" if chosen == "rent" else "售盘", pid))
            ok, reason = self.fast_test_detail(chosen, url, test_mode=True, wa_test=True)
            # On success, manual_whatsapp_send owns the final popup after WhatsApp confirms send.
            if not ok:
                self.test_popup("WhatsApp 打招呼测试", False, reason)
        except Exception as e:
            reason = str(e) or e.__class__.__name__
            self.write("✗ WhatsApp 测试失败：" + reason)
            self.test_popup("WhatsApp 打招呼测试", False, reason)

    def start(self):
        if self.running:
            return
        # Drop any unfinished jobs left by a previous Stop in this same process.
        # The fresh baseline below will decide what is actually new.
        for q in list(self.phone_jobs.values()) + list(self.cdp_jobs.values()):
            try:
                while True:
                    q.get_nowait()
                    q.task_done()
            except queue.Empty:
                pass
        self.http_retry_attempts = {'rent': {}, 'buy': {}}
        for ev in self.phone_bridge_ready.values():
            ev.clear()
        with self.lock:
            for ids in self.cdp_pending.values(): ids.clear()
            # A UI test must never use last run's listing as proof that the
            # CURRENT existing browser tab passed owner/latest verification.
            # Retain seen/processed dedup and the in-memory API templates.
            for lane in ('rent', 'buy'):
                self.http_latest[lane] = []
                self.http_stats[lane]['last_ok'] = 0.0
        # The cache is only safe for the same BitBrowser profile. Changing
        # browser selection/profile invalidates it before any worker starts.
        profile_key=(str(self.browser_type.get()),
                     str(self.bit_no.get()) if self.browser_type.get()=='BitBrowser' else
                     str(self.ads_no.get()))
        if self.api_template_profile != profile_key:
            self.api_template_cache.clear()
            self.api_template_profile = profile_key
        self.save_config()
        self.cdp_fault_event.clear()
        self.api_rate_limit_event.clear()
        self.api_429_guard.reset()
        self.api_adaptive_scheduler.reset()
        self.api_adaptive_scheduler.set_user_floor(min(self.api_poll_seconds.values()))
        self.api_source_enabled = {'rent': bool(self.rent.get()), 'buy': bool(self.buy.get())}
        with self.api_pause_lock:
            self.api_paused.update(rent='', buy='')
        if callable(getattr(self, 'on_28_api_reset', None)):
            self.on_28_api_reset()
        if self.wa_enable.get():
            try:
                self._parse_hhmm(self.wa_start.get())
                self._parse_hhmm(self.wa_end.get())
            except Exception as e:
                self.status("WhatsApp 时段格式错误")
                self.write("✗ WhatsApp 时段格式错误：" + str(e))
                return
        self.running = True
        self.run_id += 1
        run_id = self.run_id
        self.set_monitor_controls(True)
        self._prevent_system_sleep()
        self.bg(self.bootstrap, run_id)

    def stop(self):
        self.running = False
        self.set_monitor_controls(False)
        self._allow_system_sleep()
        self.save_config()
        self.status("已停止")
        for ev in self.phone_bridge_ready.values():
            ev.clear()
        self.write("■ 已停止；LiteHTTP worker 将在当前请求结束后关闭后台 bridge")

    def bootstrap(self, run_id):
        if run_id != self.run_id or not self.running:
            return
        # A previous run may have left an obsolete debugger port in memory.
        # Validate it *before* starting rent/buy phone and API workers.
        if self.cdp_base and not self._cdp_base_alive():
            self.write('[CDP-STALE] 上次 BitBrowser CDP 端口已失效；重新获取现有环境端口')
            self.cdp_base = None
            self.port = None
        if not self.cdp_base:
            # Local API may be briefly unavailable while BitBrowser is opening.
            # Retry connection failures only; do not hammer wrong Token/profile
            # or re-open a healthy browser. Workers are not started until ready.
            for attempt in range(3):
                if run_id != self.run_id or not self.running:
                    return
                self.connect_browser()
                if self.cdp_base and self._cdp_base_alive():
                    break
                msg = str(getattr(self, '_last_bit_connect_error', '')).lower()
                transient = any(x in msg for x in ('10061', '10053', 'connection refused',
                                                    'actively refused', 'timed out', 'timeout',
                                                    'connection reset'))
                # After /browser/open is attempted, repeating it could rotate a
                # live CDP port or bring the profile to foreground. Only a
                # refusal during profile LIST is safe to auto-retry.
                if (attempt >= 2 or not transient or
                        getattr(self, '_last_bit_connect_stage', '') != 'list'):
                    break
                delay = (0.8, 1.8)[attempt]
                self.write('[BIT-RETRY] Local API 暫時未就緒；%.1f秒後重試 (%d/2)' % (delay, attempt+1))
                until = time.monotonic() + delay
                while time.monotonic() < until:
                    if run_id != self.run_id or not self.running:
                        return
                    time.sleep(0.10)
        if not self.cdp_base or not self._cdp_base_alive():
            self.write('[28-OFFLINE] 28Hse 未連線，租／售不會監控；House730 的狀態須分開確認')
            self.running = False
            self.set_monitor_controls(False)
            self.status("启动失败：浏览器未连接")
            return
        ks = (["rent"] if self.rent.get() else []) + (["buy"] if self.buy.get() else [])
        if not ks:
            self.write("! 请至少选择租盘或售盘")
            self.running = False
            self.set_monitor_controls(False)
            self.status("已停止：未选择租盘/售盘")
            return

        # Wait for manually opened rent/buy owner/latest pages. No list tab is
        # created by the monitor; each lane attaches to an existing page.
        self.status("LiteHTTP 低资源监控启动中…")
        # Avoid opening four warm CDP targets while two 28Hse workers are
        # capturing the search request. Extra-site plugins may start too.
        self.api_learn_gate = threading.Lock()
        self.api_capture_ready = {k: threading.Event() for k in ('rent', 'buy')}
        for i, k in enumerate(ks):
            self.bg(self.worker, k, i * 0.10, run_id)
        for k in ks:
            self.bg(self.phone_worker, k, run_id)
            self.bg(self.cdp_fallback_worker, k, run_id)
        self.write('[CDP-STARTUP] 28Hse先學習業主＋最新 API，再建立揭號橋接/詳情Target；減少多站啟動時CDP擠塞')
        self.write('[28-API-PHONEFIRST] ad_id直接API取號=%s；CDP開詳情備援=%s；HTTP不開帖路徑保留' % (self.phone_api_direct_enabled, self.phone_api_allow_detail))

    def queue_cdp_fallback(self, k, url, detected_t0=None):
        """Enqueue once; never create concurrent detail targets for one source."""
        if not self.running or not self.phone_api_allow_detail:
            return False
        pid = self.pid_of(url)
        if not pid:
            return False
        with self.lock:
            if pid in self.cdp_pending[k]:
                return False
            self.cdp_pending[k].add(pid)
        self.set_listing_status(k, url, '等候揭号…')
        self.cdp_jobs[k].put((url, detected_t0 or time.perf_counter()))
        self.write('[PHONE-FALLBACK-QUEUE] %s %s · HTTP未取到，按序进入独立CDP lane' % (k,pid))
        return True

    def prime_detail_target(self, k):
        """Prepare one background CDP page outside the phone critical path.

        This warm page is owned solely by the *single* CDP fallback worker
        for its source; neither user tabs nor HTTP/detection bridges are used.
        It starts at about:blank, with media blocked before any detail loads.
        """
        t = self.create_background_target('about:blank')
        c = None
        try:
            c = self.cdp(t)
            c.call('Page.enable', timeout=1.5)
            c.call('Runtime.enable', timeout=1.5)
            self.block_nonessential(c)
            try:
                c.call('Emulation.setFocusEmulationEnabled', {'enabled': True}, timeout=0.5)
                c.call('Page.setWebLifecycleState', {'state': 'active'}, timeout=0.5)
            except Exception:
                pass
            return t, c
        except Exception:
            self.retire_detail_target((t, c))
            raise

    def retire_detail_target(self, warm):
        """Close a worker-owned background detail; never a user tab."""
        if not warm:
            return
        t, c = warm
        if c is not None:
            try: c.deadline = None; c.close()
            except Exception: pass
        tid = (t or {}).get('id')
        if tid:
            self.close_target_id(tid)

    @staticmethod
    def detail_target_unhealthy(reason):
        text = str(reason or '')
        return any(x in text for x in (
            'CDP_CALL_', 'WebSocket', 'Connection to remote host',
            '后台详情加载失败', '后台建页失败', '导航',
            '详情页处理异常', 'renderer is not responding',
            'CDP_TRANSPORT_LOST', 'WinError 10053', 'WinError 10054',
            '连接已建立', 'established connection'))

    def cdp_fallback_worker(self, k, run_id=0):
        ready = getattr(self, 'api_capture_ready', {}).get(k)
        if ready is not None:
            while self.running and run_id == self.run_id and not ready.wait(0.20):
                pass
        if not self.running or run_id != self.run_id:
            return
        # Single-owner, reusable hidden detail Target. Warm-up is done before
        # the first NEW whenever possible, not on the critical phone path.
        warm = None
        try:
            # The phone bridges start first; allow them a short head start
            # before prewarming a detail renderer. No UI/focus operations.
            self.phone_bridge_ready[k].wait(timeout=2.0)
            if (self.phone_api_allow_detail and not getattr(self, 'low_tab_mode', False)
                and self.running and self.run_id == run_id and not self.cdp_fault_event.is_set()):
                try:
                    warm = self.prime_detail_target(k)
                    self.write('[DETAIL-WARM] %s · 后台详情Target预热完成' % k)
                except Exception as e:
                    self.write('[DETAIL-WARM] %s · 预热失败，首次详情走原路径：%s' % (k, str(e)[:130]))
            while self.running and self.run_id == run_id and not self.cdp_fault_event.is_set():
                try:
                    url, detected_t0 = self.cdp_jobs[k].get(timeout=.12)
                except queue.Empty:
                    continue
                pid = self.pid_of(url)
                try:
                    if self.running and self.run_id == run_id and self.phone_api_allow_detail:
                        self.set_listing_status(k, url, '正在揭号…')
                        started = time.perf_counter()
                        # If prewarming failed, the old cold path remains
                        # functional. Avoid any unbounded warm-up wait here.
                        ok, reason = self.detail(k, url, False, False, detected_t0, warm_target=warm)
                        self.learn_strategy(k, 'cdp', ok, int((time.perf_counter()-started)*1000))
                        if not ok:
                            self.write('[PHONE-FALLBACK] %s %s · %s' % (k, pid, str(reason)[:150]))
                            if warm and self.detail_target_unhealthy(reason):
                                self.write('[DETAIL-WARM-RESET] %s %s · 失效Target关闭，下次重新预热' % (k, pid))
                                self.retire_detail_target(warm)
                                warm = None
                except Exception as exc:
                    self.write('[PHONE-FALLBACK-ERROR] %s %s · %s' % (k, pid, str(exc)[:150]))
                    self.set_listing_status(k, url, '取号失败')
                    if warm:
                        self.retire_detail_target(warm)
                        warm = None
                finally:
                    with self.lock:
                        self.cdp_pending[k].discard(pid)
                    self.cdp_jobs[k].task_done()
                # Rebuild only when the queue is empty, so pending phone
                # jobs never wait behind a fresh Target initialization.
                if (self.phone_api_allow_detail and not getattr(self, 'low_tab_mode', False)
                    and warm is None and self.running and self.run_id == run_id and self.cdp_jobs[k].empty()):
                    try:
                        warm = self.prime_detail_target(k)
                        self.write('[DETAIL-WARM] %s · 备用Target重新预热完成' % k)
                    except Exception as exc:
                        self.write('[DETAIL-WARM] %s · 预热暂不可用：%s' % (k, str(exc)[:130]))
        finally:
            if warm:
                self.retire_detail_target(warm)

    def phone_worker(self, k, run_id=0):
        # Two independent fast HTTP lanes, backed by exactly ONE serial CDP
        # fallback per source. No hedge timer means no excessive detail tabs.
        label = '租盘' if k == 'rent' else '售盘'
        c = None
        tid = None
        self.write('[%s] UltraRace取号 lane 启动：等待本路API學習後預熱' % label)
        # Do not allocate a new CDP target while a list worker is still
        # navigating its private page to learn/verify the owner-only POST.
        ready = getattr(self, 'api_capture_ready', {}).get(k)
        if ready is not None:
            while self.running and run_id == self.run_id and not ready.wait(0.20):
                pass
        if not self.running or run_id != self.run_id:
            return
        try:
            errors=0
            while self.running and run_id == self.run_id:
                # The phone action helpers return ordinary fallback results on
                # CDP transport errors. Without this check an expired socket
                # stays in `c` indefinitely and every subsequent phone fails.
                if c is not None and c.dead:
                    self.write('[28-PHONE-SOCKET-RESET] %s · 已退役的取號socket丟棄，重新接上現有環境' % label)
                    try: c.close()
                    except Exception: pass
                    c = None
                    self.phone_bridge_ready[k].clear()
                    if tid:
                        self.close_target_id(tid)
                        tid = None
                if self.api_rate_limit_event.is_set() or self.api_429_guard.remaining() > 0:
                    # Do not issue contact requests during an origin-wide 429 cooldown.
                    time.sleep(.20)
                    continue
                if c is None:
                    # No user-opened list = no automatic monitor tab or extra
                    # background bridge. Reconnect only after manual reopening.
                    if not self._cdp_base_alive():
                        self._attach_running_browser()
                    if not self._cdp_base_alive() or not self.target(k):
                        time.sleep(1.5)
                        continue
                    try:
                        t, c = self.open_http_bridge(k)
                        tid = t.get('id')
                        self.write('[%s] ✓ UltraRace取号 bridge 已预热' % label)
                        self.phone_bridge_ready[k].set()
                        errors=0
                    except Exception as e:
                        errors+=1
                        if self.run_id==run_id and not self._cdp_base_alive():
                            self.write('[28-PHONE-REATTACH] %s · CDP暫時失聯，等候手動開啟原環境／列表後重連' % label)
                            self._attach_running_browser()
                            time.sleep(1.5)
                            continue
                        if errors==1 or errors%5==0:
                            self.write('[%s] ! Race取号 bridge：%s (第%d次)' % (label, str(e)[:140],errors))
                        # Do not spin every 150ms when renderer is unhealthy.
                        time.sleep(min(5.0,0.5*errors))
                        continue
                try:
                    job = self.phone_jobs[k].get(timeout=.15)
                except queue.Empty:
                    continue
                try:
                    url, detected_t0 = job[:2]
                    test_job = len(job) > 2
                    direct_reason = ''
                    if self.phone_api_direct_enabled:
                        terminal, ok, direct_reason = self.http_phone_direct(
                            c, k, url, test_mode=job[4] if test_job else False,
                            wa_test=job[5] if test_job else False, race_t0=detected_t0)
                    else:
                        terminal, ok = False, False
                    if not terminal:
                        terminal, ok, reason = self.http_phone_fast(
                            c, k, url, test_mode=job[4] if test_job else False,
                            wa_test=job[5] if test_job else False, race_t0=detected_t0)
                    else:
                        reason = direct_reason
                    if not test_job and terminal and not ok and 'HTTP 429' in str(reason):
                        # A 429 means "not now", not "no phone". Preserve the
                        # queued property and retry it only after shared cooldown.
                        self.phone_jobs[k].put(job)
                        self.set_listing_status(k, url, '429 冷卻後續取號')
                        continue
                    if test_job:
                        if not terminal and self.phone_api_allow_detail:
                            ok, reason = self.detail(k, url, test_mode=job[4], wa_test=job[5])
                        job[3].update(ok=ok, reason=reason)
                        job[2].set()
                    else:
                        pid = self.pid_of(url)
                        if terminal:
                            if pid:
                                with self.lock:
                                    self.inflight[k].discard(pid)
                                    self.processed[k].add(pid)
                            if not ok and '限流' in str(reason):
                                self.set_listing_status(k,url,'API 限流／驗證中')
                        else:
                            # IMPORTANT: a fallback is created only AFTER HTTP
                            # returned an actual failure, not speculatively.
                            if self.phone_api_allow_detail:
                                self.queue_cdp_fallback(k, url, detected_t0)
                            else:
                                self.no_detail_phone_fallback(k,url,detected_t0,reason,run_id)
                except Exception as e:
                    url = job[0] if job else ''
                    self.write('[%s] ! Race取号异常：%s' % (label, e))
                    if job and len(job) > 2:
                        job[3].update(ok=False, reason=str(e))
                        job[2].set()
                    else:
                        if self.phone_api_allow_detail:
                            self.queue_cdp_fallback(k, url, job[1] if job else None)
                        else:
                            self.no_detail_phone_fallback(k,url,job[1] if job else None,str(e),run_id)
                    if c:
                        try: c.close()
                        except Exception: pass
                    c = None
                    if tid:
                        self.close_target_id(tid)
                        tid = None
                finally:
                    try: self.phone_jobs[k].task_done()
                    except Exception: pass
        finally:
            if c:
                try: c.close()
                except Exception: pass
            if tid: self.close_target_id(tid)

    def api_poll_interval(self, k):
        """Read 28Hse rent/buy cadence without touching Tk in worker threads.

        UnifiedApp updates its small shared dict from the Tk thread.  An old
        28Hse-only App without this option remains at the 1-second default.
        """
        values = getattr(self, 'api_poll_seconds', None)
        try:
            return parse_api_cadence(values.get(k, 1.0) if isinstance(values, dict) else 1.0)
        except ValueError:
            return 1.0

    def _record_28_api_pause(self, k, reason, extra=''):
        # Background workers may not read or mutate Tk variables. This is a
        # thread-safe source state which the unified UI mirrors using after().
        if k not in ('rent', 'buy'):
            return
        with self.api_pause_lock:
            was = self.api_paused.get(k, '')
            self.api_paused[k] = reason
        if was != reason and callable(getattr(self, 'on_28_api_paused', None)):
            self.on_28_api_paused(k, reason, extra)

    def worker(self, k, stagger=0.0, run_id=0):
        label = "租盘" if k == "rent" else "售盘"
        if stagger: time.sleep(min(stagger, .05))
        c=None;tid=None;baseline_done=False
        # Latest six prioritized, remainder examined in-memory every response.
        # Site seen/processed locks are still the final de-dup authority.
        listing_delta = ListingDeltaCache(head_size=6)
        last_error="";last_error_at=0.0;last_status_at=0.0;last_scan_log_at=0.0
        # V1.48.2: configurable 500ms/1000ms targets per lane; always
        # single-flight. Challenge/rate/timeout backoff overrides preferences.
        interval=self.api_poll_interval(k);last_good_ms=350;timeout_streak=0;template=None
        learn_errors = 0  # Transient CDP contention only; filter/challenge remain terminal.
        bridge_recovery_times = []  # max two private Target rebuilds per 180 seconds
        # V1.50.28: /json status and tab discovery are local HTTP calls, but
        # doing both before EVERY 500ms fetch congests BitBrowser's CDP server.
        # Probe periodically when healthy, immediately when the socket is gone.
        next_tab_healthcheck = 0.0
        last_browser_info = None
        # Extra JSON recheck is one more SERIAL query, never another worker.
        rechecks = RecheckSchedule(enabled=getattr(self, 'api_recheck_enabled', True),
                                    deduplicate=True)
        # Normal successful polls refresh the 8s watchdog; never submit a
        # second query just because the 8s deadline was reached.
        if k == 'rent':
            self.write('[28-CADENCE] 租售獨立並行：各最多1個列表API；按輸入間隔＋隨機100–300ms；429兩路共用冷卻／復原試探')
        self.write("[%s] API-ONLY：POST /property/dosearch · %dms目标 · 同来源single-flight · 无列表Reload" % (label,int(interval*1000)))

        def bridge_alive():
            if c is None or c.dead:
                return False
            try:return str(c.ev("location.hostname", timeout=2.5) or "").lower().endswith("28hse.com")
            except Exception:return False
        def drop_bridge():
            nonlocal c,tid
            if c:
                try:c.close()
                except Exception:pass
                c=None
            # List tab belongs to the user, NEVER close it.
            tid=None

        def park_failed_cdp_until_unlock():
            """Only park an ALREADY FAILED CDP lane while Windows is locked.

            Healthy JSON requests continue through Win+L. We never force the
            browser or desktop to the foreground to 'fix' a locked session.
            """
            if not windows_session_locked():
                return False
            drop_bridge()
            self.write('[28-LOCK-CDP-WAIT] %s · Windows 已鎖屏且 CDP 失效；保留基線，解鎖後重接現有分頁' % label)
            while (self.running and self.run_id == run_id
                   and not self.api_rate_limit_event.is_set()
                   and windows_session_locked()):
                self.api_rate_limit_event.wait(3)
            if self.running and self.run_id == run_id and not self.api_rate_limit_event.is_set():
                # A lock-related transport outage must not exhaust the 3-min
                # bridge-rebuild budget or cause the next listing to be treated
                # as a fresh historical baseline.
                bridge_recovery_times.clear()
                self.write('[28-LOCK-RESUME] %s · 已解鎖，重新接回現有列表；0新分頁' % label)
            return True

        def repair_private_bridge(cause):
            """Recover only if BitBrowser's root CDP endpoint remains healthy.

            Full API owner-lock verification is repeated; never silently replay
            a stale request or retry a genuine 429/challenge/filter failure.
            """
            now=time.monotonic()
            bridge_recovery_times[:] = [t for t in bridge_recovery_times if now-t < 180]
            if len(bridge_recovery_times) >= 2:
                # Do not reopen any browser/tab. The outer loop will wait for
                # the user to restore the list if CDP remains unavailable.
                self.write('[28-RECONNECT-WAIT] %s · 3分鐘內暫停本路反覆重建，等候CDP／原列表恢復' % label)
                return False
            if not self._cdp_base_alive() and not self._attach_running_browser():
                return False
            bridge_recovery_times.append(now)
            drop_bridge()
            delay = 3.0 if len(bridge_recovery_times)==1 else 8.0
            self.write('[API-BRIDGE-RECOVER] %s · 私有CDP連線失效(%s)，%.1f秒後重新驗證業主＋最新 (%d/2)' %
                       (label,str(cause)[:65],delay,len(bridge_recovery_times)))
            self.api_rate_limit_event.wait(delay)
            return (self.running and self.run_id == run_id
                    and not self.api_rate_limit_event.is_set()
                    and not self.cdp_fault_event.is_set())

        try:
            reconnect_notice = False
            while (self.running and run_id==self.run_id
                   and not self.api_rate_limit_event.is_set()):
                # Preserve existing list, seen IDs and the phone queue during
                # origin-wide cooldown: no template-learning or list API calls.
                cooling = self.api_429_guard.remaining()
                if cooling > 0:
                    time.sleep(min(.20, cooling))
                    continue
                # Healthy CDP connections need no fresh /json + tab listing on
                # every search iteration. The current owner-locked API fetch
                # remains independently verified and unchanged.
                needs_healthcheck = (c is None or c.dead or time.monotonic() >= next_tab_healthcheck)
                if needs_healthcheck:
                    next_tab_healthcheck = time.monotonic() + 10.0
                    browser_alive = self._cdp_base_alive()
                    if not browser_alive and windows_session_locked():
                        park_failed_cdp_until_unlock()
                        continue
                    if not browser_alive and not self._attach_running_browser():
                        if not reconnect_notice:
                            self.write('[28-RECONNECT-WAIT] %s · CDP 未連線，等待手動打開瀏覽器／原列表；不建立新分頁' % label)
                            reconnect_notice = True
                        time.sleep(2.0)
                        continue
                    last_browser_info = self.target(k)
                    if not last_browser_info:
                        if not reconnect_notice:
                            self.write('[28-TAB-WAIT] %s · 業主＋最新列表未開啟，等待你手動打開；不自動開帖' % label)
                            reconnect_notice = True
                        drop_bridge()
                        time.sleep(1.5)
                        continue
                    if c is not None and tid and last_browser_info.get('id') != tid:
                        drop_bridge()  # Closed/replaced by user: never reopen.
                        self.write('[28-TAB-REATTACH] %s · 原列表已更換；接管手動開啟的分頁，保留已知樓盤基線' % label)
                if reconnect_notice:
                    self.cdp_fault_event.clear()
                    reconnect_notice = False
                    self.write('[28-RECONNECTED] %s · 已連接現有列表分頁，繼續監控' % label)
                round_started=time.monotonic()
                rechecks.enabled = bool(getattr(self, 'api_recheck_enabled', True))
                poll_kind = rechecks.kind(baseline_done, round_started)
                succeeded = False
                try:
                    if c is None:
                        if not self.cdp_base and not self.recover_browser():raise RuntimeError("浏览器 CDP 未连接")
                        # Only one 28Hse profile navigates/searches at once.
                        # The actual list polls remain independent after template learning.
                        with getattr(self, 'api_learn_gate', nullcontext()):
                            if not self.running or run_id != self.run_id:
                                return
                            with self.api_429_guard.slot(lambda: self.running and run_id == self.run_id) as allowed:
                                if not allowed: return
                                # Initial capture can trigger a real site search.
                                # Per-lane scheduler prevents duplicate fetch in the
                                # same lane; rent and buy may overlap.
                                with self.api_adaptive_scheduler.lease(k, lambda: self.running and run_id == self.run_id) as admitted:
                                    if not admitted: return
                                    t,c,template=capture_template(self,k,
                                        lambda:self.running and run_id==self.run_id,
                                        cached=self.api_template_cache.get(k),
                                        allow_reload=(learn_errors == 0))
                        tid=t.get("id")
                        if template.get('reused'):
                            self.write('[API-CACHE] %s · 重用本次程式先前驗證的請求格式；仍會重新比對API與DOM' % label)
                        self.write("[API-LEARN] %s · 已从站点真实搜索请求取得 /property/dosearch form_data（仅保存在内存）" % label)
                        self.write("[FILTER] 28Hse API OwnerLock: landlordAgency=LANDLORD / sortBy=latest")
                        # Compare against the original visible source document once;
                        # a misidentified XHR must not be allowed to notify users.
                        with self.api_429_guard.slot(lambda: self.running and run_id == self.run_id) as allowed:
                            if not allowed: return
                            with self.api_adaptive_scheduler.lease(k, lambda: self.running and run_id == self.run_id) as admitted:
                                if not admitted: return
                                initial,_,_,_=api_snapshot(c,k,template,[],timeout_ms=4800)
                        page_ids=set(self.pid_of(x) for x in self.urls(c))
                        valid=[self.pid_of(x) for x in initial if self.pid_of(x) in page_ids]
                        if len(valid)<min(3,len(initial)):
                            raise ApiError('learn','API and DOM list IDs are not aligned yet; retry verification without accepting unknown listings')
                        if template.get('bare_url_candidate'):
                            # A plain /rent or /buy URL is not itself proof of
                            # owner/latest. Its freshly observed POST is owner-
                            # locked; additionally require a STRONG match to
                            # the currently rendered results, not merely 3
                            # coincidentally shared property IDs.
                            required = min(8, len(initial))
                            if len(valid) < required or len(initial) < 3:
                                raise ApiError('learn',
                                    'Queryless list has not yet proved owner/latest against visible results; will retry with no unverified listings')
                            self.write('[28-OWNER-DOM-VERIFIED] %s · 無URL參數列表：實際POST為業主＋最新，DOM重合%d/%d' %
                                       (label, len(valid), len(initial)))
                        self.write("[API-VERIFY] %s · API和DOM重合 %d/%d；不会再刷新列表页面" % (label,len(valid),len(initial)))
                        # Apply renderer life-cycle/focus emulation ONCE after
                        # owner/latest verification. No bringToFront, window.focus,
                        # or extra HTTP refresh; minimizes hidden-tab suspension.
                        try:
                            for method, params in (
                                ('Emulation.setFocusEmulationEnabled', {'enabled': True}),
                                ('Page.setWebLifecycleState', {'state': 'active'}),
                            ):
                                if c.dead: break
                                try: c.call(method, params, timeout=0.9)
                                except Exception: break
                            if not c.dead:
                                self.write('[28-BG-ACTIVE] %s · 後台分頁保持 active／不搶前台焦點' % label)
                        except Exception:
                            pass
                        self.api_template_cache[k]={'url':template['url'],'body':template['body']}
                        learn_errors = 0
                        ready = getattr(self, 'api_capture_ready', {}).get(k)
                        if ready is not None: ready.set()  # Release deferred phone bridge.

                    with self.lock:
                        known_top=[self.pid_of(u) for u in self.http_latest[k][:20]]
                    known_top=[x for x in known_top if x]
                    # Reuse the verified POST in the existing browser tab: its
                    # Chromium networking stack reuses existing HTTP connections.
                    # Rent and buy can overlap, but ONE lane cannot overlap itself.
                    py_poll_t0=time.perf_counter()
                    api_call_t0 = py_poll_t0
                    # Each lane is strictly single-flight; rent and buy can
                    # execute concurrently, without a shared normal-operation
                    # FIFO.  429's shared cooldown/recovery probes still apply.
                    with self.api_429_guard.slot(lambda: self.running and run_id == self.run_id) as allowed:
                        if not allowed: break
                        with self.api_adaptive_scheduler.lease(k, lambda: self.running and run_id == self.run_id) as admitted:
                            if not admitted: break
                            api_call_t0 = time.perf_counter()
                            urls,byte_count,list_meta,timing=api_snapshot(c,k,template,known_top,timeout_ms=4800)
                    if self.api_rate_limit_event.is_set():
                        # Another lane just received 429: don't process or act
                        # on a response that arrived after the global pause.
                        break
                    succeeded = True
                    self.api_adaptive_scheduler.success()
                    # The 8s option is now a stale-data watchdog, not an extra
                    # query after a successful ordinary poll. Preserves 429 backoff.
                    rechecks.completed(poll_kind)
                    if poll_kind == 'extra':
                        self.write('[API-RECHECK] %s · 上次成功查詢已逾8秒；本輪正常查詢補上，不增加輪次' % label)
                    # Previous versions reported FIFO/429-gate waiting as API
                    # response latency. Separate real Runtime.evaluate/fetch
                    # time from the time spent waiting for our own scheduler.
                    poll_done_at = time.perf_counter()
                    elapsed_ms=int((poll_done_at-api_call_t0)*1000)
                    queue_wait_ms=max(0, int((api_call_t0-py_poll_t0)*1000))
                    round_ms=int((poll_done_at-py_poll_t0)*1000)
                    timeout_streak=0
                    learn_errors=0
                    last_good_ms=max(100,min(4000,timing.get("js_total_ms") or elapsed_ms))
                    interval=self.api_poll_interval(k)

                    ids=[self.pid_of(u) for u in urls if self.pid_of(u)]
                    with self.lock:
                        if timing.get("early"):
                            # Aborted after the first NEW fragment: old top IDs
                            # are still valid. Do not replace the full last
                            # listing by the one-item early detection result.
                            old_urls=self.http_latest[k]
                            self.http_latest[k]=list(dict.fromkeys(list(urls)+list(old_urls)))[:25]
                        else:
                            self.http_latest[k]=list(urls)
                        self.http_stats[k]["polls"]+=1;self.http_stats[k]["last_ms"]=elapsed_ms;self.http_stats[k]["last_ok"]=time.time()
                        self.detect_stats[k].update({"first_byte_ms":timing.get("first_byte_ms",0),"first_id_ms":timing.get("first_id_ms",0),"first_new_ms":timing.get("first_new_ms",0),"return_ms":elapsed_ms})

                    if timing.get("early"):
                        self.write("[API-STREAM-NEW] %s · %d NEW · 首NEW %dms · Python返回 %dms；中止本轮剩余JSON读取" %
                                   (label,len(timing.get("new_urls") or []),int(timing.get("first_new_ms") or 0),elapsed_ms))
                    if time.monotonic()-last_scan_log_at>=15.0:
                        self.write("[API-LIST-OK] %s · %d 房源%s · 首ID %dms · API %dms · 排隊 %dms · 整輪 %dms · 已知前排 %d" %
                                   (label,len(ids),"（提前结束）" if timing.get("early") else "",int(timing.get("first_id_ms") or 0),elapsed_ms,queue_wait_ms,round_ms,len(known_top)))
                        # Performance breakdown comes from the *same* fetch.
                        # No extra diagnostic request/CDP roundtrip is created.
                        self.write('[28-API-TIMING] %s · HTTP頭 %dms · 資料讀取 %dms · JSON解析 %dms · 瀏覽器JS %dms · CDP返回 %dms · 排隊 %dms · 連線建立 %dms · 伺服器等待 %dms' % (
                            label, int(timing.get('headers_ms') or 0),
                            int(timing.get('stream_ms') or 0),int(timing.get('json_ms') or 0),
                            int(timing.get('js_total_ms') or 0),
                            max(0, elapsed_ms-int(timing.get('js_total_ms') or elapsed_ms)),
                            queue_wait_ms, int(timing.get('connect_ms') or 0),
                            int(timing.get('server_wait_ms') or 0)))
                        self.write("[LIST-IDS] %s · %s" % (label, ",".join(ids[:10])))
                        last_scan_log_at=time.monotonic()
                    if not baseline_done:
                        with self.lock:self.seen[k].update(ids);self.processed[k].update(ids)
                        listing_delta.seed(k, [(u, self.pid_of(u)) for u in urls])
                        baseline_done=True
                        rechecks.next_at = time.monotonic() + 8.0
                        self.write("✓ %s DetectionRace 历史基线 %d 个 Property ID" % (label,len(ids)))
                    else:
                        stream_new=timing.get("new_urls") or []
                        candidates=stream_new if stream_new else urls
                        # Zero network overhead: filter already observed list IDs
                        # before acquiring the shared hot-path mutex. The full
                        # source response is still inspected (no skipped deep rows).
                        fresh_pairs=listing_delta.candidates(k, [(u,self.pid_of(u)) for u in candidates])
                        new=[]
                        with self.lock:
                            known_before=set(self.seen[k])
                            for u, _pid in fresh_pairs:
                                pid=self.pid_of(u)
                                if pid and pid not in known_before and pid not in self.processed[k] and pid not in self.inflight[k]:
                                    self.processed[k].add(pid);self.inflight[k].add(pid);new.append(u)
                            self.seen[k].update(ids)
                        listing_delta.confirm(k, [(u, self.pid_of(u)) for u in candidates])
                        if new:
                            first_new_ms=int(timing.get("first_new_ms") or timing.get("first_id_ms") or 0)
                            dispatch = [(u, time.perf_counter()) for u in new[:12]]
                            for u, detected_t0 in dispatch:
                                # Queue every phone BEFORE Tk/logging work.
                                self.phone_jobs[k].put((u,detected_t0))
                            self.write("[DETECT-NEW] %s · 首字节 %dms · 首NEW %dms · Python返回 %dms · %d帖" % (label,int(timing.get("first_byte_ms") or 0),first_new_ms,elapsed_ms,len(new)))
                            for u, _ in dispatch:
                                self.show_detected_row(k, u)
                                self.write("[NEW] %s %s" % (label,u))

                    now=time.monotonic()
                    if now-last_status_at>=1.2:
                        with self.lock:
                            rs=dict(self.http_stats["rent"]);bs=dict(self.http_stats["buy"]);rd=dict(self.detect_stats["rent"]);bd=dict(self.detect_stats["buy"])
                            rrace=self.race_stats["rent"].get("last_total_ms",0);brace=self.race_stats["buy"].get("last_total_ms",0)
                        self.status("DetectionRace · 租首ID %dms/返回%dms 抢号%dms · 售首ID %dms/返回%dms 抢号%dms" % (rd.get("first_id_ms",0),rs.get("last_ms",0),rrace,bd.get("first_id_ms",0),bs.get("last_ms",0),brace))
                        last_status_at=now
                    last_error=""
                except TimeoutError as exc:
                    # Python CDP command timeout can retire its socket. Unlike
                    # an API fetch timeout, ONLY this needs transport repair.
                    timeout_streak += 1
                    interval = min(8.0, 1.5 * (2 ** min(timeout_streak-1, 3)))
                    gap = self.api_adaptive_scheduler.transport_timeout()
                    now = time.monotonic()
                    if now-last_error_at >= 3.0:
                        self.write('[28-CDP-TIMEOUT] %s · CDP逾時；第%d次僅本路等待%.1fs；正常查詢設定不變' %
                                   (label, timeout_streak, interval)); last_error_at=now
                    if windows_session_locked() and park_failed_cdp_until_unlock():
                        continue
                    if c is not None and c.dead:
                        drop_bridge()
                        self.write('[28-CDP-REATTACH] %s · 只重接原分頁；保留新帖基線，不重載詳情頁' % label)
                    elif not self._cdp_base_alive():
                        drop_bridge()
                    # No extra second health-check CDP roundtrip during congestion.
                    # The next cycle uses the existing verified template if alive.
                except ApiError as e:
                    if run_id!=self.run_id or not self.running:
                        break  # Old run must never change a new run's state.
                    if e.kind in ('timeout', 'network', 'http', 'transient'):
                        timeout_streak += 1
                        gap = self.api_adaptive_scheduler.slow_or_timeout(e.kind)
                        interval = min(8.0, 1.5 * (2 ** min(timeout_streak-1, 3)))
                        now = time.monotonic()
                        if now-last_error_at >= 3.0:
                            self.write('[28-API-CONGESTION] %s · %s，本路等待%.1fs；保留已驗證CDP／模板，正常間隔不變' %
                                       (label,e.kind,interval)); last_error_at=now
                        # No drop_bridge, API-LEARN or DOM verification needed.
                        continue_after_api_error = True
                    else:
                        continue_after_api_error = False
                    if continue_after_api_error:
                        pass
                    elif e.kind == 'closed-tab':
                        # The user closed their monitor tab. Wait for a manually
                        # reopened owner/latest tab; never create a replacement.
                        drop_bridge()
                        self.write('[28-TAB-WAIT] %s · 原監控頁已關閉，等待用戶手動開啟' % label)
                        time.sleep(1.5)
                        continue
                    # A healthy browser can temporarily fail to expose its
                    # search control when several site workers share the CDP
                    # port. One transient "learn" error must not kill rent and
                    # buy forever. Never retry challenge/rate/filter this way.
                    if not continue_after_api_error and e.kind == 'learn':
                        # A valid POST with a stale DOM is NOT accepted; release
                        # the previous temporary bridge and verify from scratch.
                        drop_bridge()
                        learn_errors += 1
                        interval = min(30.0, 2.5 * (2 ** min(learn_errors - 1, 4)))
                        self.write('[API-LEARN-RETRY] %s · 有效業主＋最新 POST 未取得：%s；%.1f秒後自動重新學習（第%d次，不永久停止）' %
                                   (label, str(e)[:130], interval, learn_errors))
                        if self.api_rate_limit_event.wait(interval):
                            break
                        continue
                    if not continue_after_api_error and e.kind in ('challenge','rate','filter','learn','invalid-list','invalid-json'):
                        if e.kind == 'rate':
                            # The slot has already registered the 429 before it
                            # released the shared recovery gate. For 429s from
                            # template capture, register it here instead.
                            remaining = self.api_429_guard.remaining()
                            if remaining <= 0:
                                remaining, _, _ = self.api_429_guard.rate_limited(e.retry_after)
                            next_gap = self.api_adaptive_scheduler.rate_limited()
                            self.write('[API-429-RETRY] %s · HTTP 429；租售共用等候%.1fs，之後自動重試；遵從Retry-After，不永久停止；730不受影響' % (label,remaining))
                            self.status('28Hse HTTP 429：租售暫停 %.1f 秒後低頻試探' % remaining)
                            if callable(getattr(self, 'on_28_api_cooldown', None)):
                                self.on_28_api_cooldown(label, remaining)
                            # Do not mark this lane terminal or clear its
                            # baseline; proceed through the shared cooldown.
                            timeout_streak = 0
                            interval = self.api_poll_interval(k)
                            continue
                        else:
                            self._record_28_api_pause(k, e.kind, str(e)[:140])
                            self.write('[API-PAUSE] %s · %s：%s；本路已停止，無自動重試' % (label,e.kind,str(e)[:140]))
                            self.status('28Hse %s 已暫停：%s' % (label,e.kind))
                            self.toast('28Hse %s 已暫停' % label,
                                       '驗證或資料異常。請人工核對後再開始。')
                        break
                    if not continue_after_api_error:
                        timeout_streak += 1
                        gap = self.api_adaptive_scheduler.slow_or_timeout(e.kind)
                        interval = min(8.0, 1.5 * (2 ** min(timeout_streak-1, 3)))
                        self.write('[API-RETRY] %s · %s，%.1f秒後重試；正常查詢間隔不變' % (label,e.kind,interval))
                except PermissionError as e:
                    self.write("[API-PAUSE] %s · %s；等待手动处理，禁止自动重播" % (label,str(e)[:160]))
                    break
                except Exception as e:
                    msg=str(e);now=time.monotonic()
                    if msg!=last_error or now-last_error_at>=5.0:
                        self.write("[API-ERROR] %s · %s" % (label,msg[:170]));last_error=msg;last_error_at=now
                    timeout_streak += 1
                    gap = self.api_adaptive_scheduler.slow_or_timeout('unexpected')
                    interval = min(8.0, 1.5 * (2 ** min(timeout_streak-1, 3)))
                    if windows_session_locked() and park_failed_cdp_until_unlock():
                        continue
                    if c is None or c.dead or not self._cdp_base_alive():
                        if not self._cdp_base_alive():
                            drop_bridge()
                            self.write('[28-RECONNECT-WAIT] %s · CDP端口失效；等候已啟動瀏覽器自動重連' % label)
                            time.sleep(1.5)
                            continue
                        if c is None:
                            # Re-fetch the SAME user-opened list's fresh target
                            # descriptor next round. Never /browser/open or
                            # Target.createTarget for monitor pages.
                            learn_errors += 1
                            interval = min(15.0, 2.5 * (2 ** min(learn_errors - 1, 3)))
                            if learn_errors <= 3 or now-last_error_at >= 12.0:
                                self.write('[28-CDP-REATTACH] %s · 舊socket已丟棄，%.1f秒後重接已開列表（第%d次）；0新分頁' %
                                           (label, interval, learn_errors))
                            # capture_template owns and closes its temporary
                            # socket on error; the outer loop obtains a NEW one.
                        else:
                            if any(x in msg for x in ('CDP_TRANSPORT_LOST', 'CDP_CALL_TIMEOUT',
                                                     'CDP_CALL_DEADLINE')) and repair_private_bridge(msg):
                                continue
                            drop_bridge()
                            self.write('[28-RECONNECT-WAIT] %s · 原列表仍開啟則持續重連CDP；若已關閉，等待手動重開' % label)
                            time.sleep(1.5)
                            continue
                wait=interval-(time.monotonic()-round_started)
                # Per-lane cadence: never stack another request in the same lane.
                if poll_kind == 'extra' and succeeded and not rechecks.deduplicate:
                    wait = 0.0
                elif succeeded:
                    # Start-to-start target: user input + independently sampled
                    # 100–300ms on every successful list request.
                    wait += random.uniform(.100, .300)
                    wait = rechecks.wait(wait, baseline_done)
                # Errors keep their backoff; 429 is controlled by shared cooldown.
                if wait>0:
                    # An event wakes the other lane immediately when any 28
                    # request receives HTTP 429, instead of sleeping blindly.
                    self.api_rate_limit_event.wait(wait)
        finally:
            if self.api_rate_limit_event.is_set() and run_id==self.run_id:
                self._record_28_api_pause(k, 'rate')
            if c:
                try:c.close()
                except Exception:pass
            # tid identifies a user-opened list. Never close it on Stop.

    def _wait_document_ready(self, c, timeout=6.0, property_id=None):
        """Wait until the target has a usable DOM; optionally require the property id in URL."""
        deadline = time.monotonic() + timeout
        last = ""
        while time.monotonic() < deadline:
            try:
                state = c.ev("({href:location.href,ready:document.readyState,title:document.title||''})", timeout=0.55) or {}
                href = str(state.get("href") or "")
                ready = str(state.get("ready") or "")
                last = href or last
                if ready in ("interactive", "complete"):
                    if not property_id or ("property-" + str(property_id)) in href:
                        return True, href
            except Exception:
                pass
            time.sleep(.04)
        return False, last

    def _real_click_rect(self, c, rect, modifiers=0):
        if not isinstance(rect, dict):
            return False
        try:
            x, y = float(rect.get("x")), float(rect.get("y"))
        except Exception:
            return False
        try:
            base = {"x": x, "y": y, "modifiers": int(modifiers or 0)}
            c.call("Input.dispatchMouseEvent", dict(base, type="mouseMoved"))
            time.sleep(.010)
            c.call("Input.dispatchMouseEvent", dict(base, type="mousePressed", button="left", buttons=1, clickCount=1))
            time.sleep(.018)
            c.call("Input.dispatchMouseEvent", dict(base, type="mouseReleased", button="left", buttons=0, clickCount=1))
            return True
        except Exception:
            return False

    def _find_property_target(self, pid, exclude_ids=None):
        exclude_ids = set(exclude_ids or ())
        needle = "/property-" + str(pid)
        try:
            for t in self.targets():
                if t.get("id") in exclude_ids:
                    continue
                u = str(t.get("url") or "")
                if needle in u:
                    return t
        except Exception:
            pass
        return None

    def _wake_contact_section(self, c, t0=None):
        """Fast contact discovery: avoid massive document.body.innerText/layout scans."""
        deadline = time.monotonic() + 0.95
        attempted_jump = False
        js = r'''(()=>{
          const labels=['放盤聯絡人','放盘联络人'];
          const btns=document.querySelectorAll('a[attr="phone"],a[href^="tel:"],button,a,[role="button"]');
          for(const el of btns){
            const t=(el.textContent||'').trim();
            if(el.matches('a[attr="phone"],a[href^="tel:"]')||t==='致電'||t==='致电')
              return {ready:true};
          }
          const hs=document.querySelectorAll('h1,h2,h3,h4,h5,strong,b,span,div');
          for(const e of hs){
            if(e.childElementCount>3)continue;
            if(labels.includes((e.textContent||'').trim())){
              e.scrollIntoView({block:'center',behavior:'instant'});
              return {ready:false,heading:true};
            }
          }
          const jumps=document.querySelectorAll('a,button,[role="button"]');
          for(const e of jumps){
            const t=(e.textContent||'').trim();
            if(t.length<70&&/按此直接至聯絡人資料|按此直接至联络人资料|直接至聯絡人資料|直接至联络人资料/.test(t)){
              e.scrollIntoView({block:'center',behavior:'instant'});
              const r=e.getBoundingClientRect();
              return {ready:false,jump:{x:r.left+r.width/2,y:r.top+r.height/2}};
            }
          }
          window.scrollBy(0,Math.max(700,innerHeight));
          return {ready:false};
        })()'''
        while time.monotonic() < deadline:
            try:
                result = c.ev(js, timeout=0.45) or {}
            except Exception:
                break
            if result.get("ready") or result.get("heading"):
                return True
            if not attempted_jump and result.get("jump"):
                attempted_jump = True
                self._real_click_rect(c, result["jump"])
            time.sleep(.035)
        return False

    def open_detail_background_cdp(self, k, url, t0=None, warm_target=None):
        """Pure-CDP fallback for a known property URL.

        V1.39 removes the old 5-second wait for the hidden list DOM to contain the
        just-detected property link. LiteHTTP already gave us the canonical URL;
        if the rendered hidden list is a little behind, waiting for that same link
        only makes us slower. We try a real background Ctrl+Click very briefly,
        then immediately navigate the SAME hidden target with a list-page referrer.
        """
        pid = self.pid_of(url)
        if not pid:
            raise RuntimeError("房源链接没有 property id")
        list_url = self.list_url(k)
        list_t = None
        list_c = None
        list_tid = None
        returned_tid = None

        def prep(c):
            c.call("Page.enable")
            c.call("Runtime.enable")
            self.block_nonessential(c)
            try:
                c.call("Network.enable")
            except Exception:
                pass
            try:
                c.call("Emulation.setFocusEmulationEnabled", {"enabled": True})
            except Exception:
                pass
            try:
                c.call("Page.setWebLifecycleState", {"state": "active"})
            except Exception:
                pass

        def close_list_if_needed():
            nonlocal list_t, list_c
            if list_c:
                try:
                    list_c.close()
                except Exception:
                    pass
                list_c = None
            if list_t and list_t.get("id"):
                self.close_target_id(list_t.get("id"))
                list_t = None

        def direct_hidden_target(reason):
            self.write('[BG-CDP] %s%s -> 直接后台进入详情' % (
                (('%.3fs：' % (time.perf_counter()-t0)) if t0 else ''), reason))
            using_warm = warm_target is not None
            if using_warm:
                detail_t, detail_c = warm_target
                # The last listing may have set a per-detail deadline. Clear it
                # before navigating, otherwise the reused target immediately fails.
                detail_c.deadline = None
            else:
                detail_t = self.create_background_target('about:blank')
                detail_c = self.cdp(detail_t)
            try:
                if not using_warm:
                    prep(detail_c)
                rr = detail_c.call('Page.navigate', {
                    'url': url,
                    'referrer': list_url,
                    'transitionType': 'link',
                }, timeout=2.5) or {}
                if rr.get('errorText'):
                    raise RuntimeError(rr.get('errorText'))
                ok3, href3 = self._wait_document_ready(detail_c, 3.5, pid)
                if not ok3:
                    raise RuntimeError('后台详情加载失败；当前页面：' + (href3 or '未知'))
                # DOM selectors in detail() see off-screen elements. A blind
                # scrolling/wake loop here only burns latency and can trigger
                # a separate CDP timeout. Scroll only if the selector misses.
                if using_warm:
                    self.write('[DETAIL-WARM-HIT] %s %s · 复用预热Target，直接读取联络人' % (k, pid))
                return detail_t, detail_c
            except Exception:
                if not using_warm:
                    try: detail_c.close()
                    except Exception: pass
                    if detail_t.get('id'):
                        self.close_target_id(detail_t.get('id'))
                raise

        # V1.45.1: DetectionRace already supplies a canonical property URL.
        # Opening the list again and searching for the same ID adds round trips,
        # can land on stale content and is unnecessary for this fallback.
        # Preserve the requested referrer and keep this target hidden.
        return direct_hidden_target("已有房源URL，跳过重复列表导航")

        try:
            list_t = self.create_background_target(list_url)
            list_tid = list_t.get("id")
            list_c = self.cdp(list_t)
            prep(list_c)

            self.write("[BG-CDP] %s隐藏 Target 已加载%s列表" % (
                (("%.3fs：" % (time.perf_counter()-t0)) if t0 else ""),
                "租盘" if k == "rent" else "售盘"))

            ok, href = self._wait_document_ready(list_c, 3.0)
            if not ok:
                close_list_if_needed()
                return direct_hidden_target("列表DOM未及时就绪")

            # Old code waited up to 5 seconds here. The exact property URL is
            # already known from LiteHTTP, so wait only ~150ms for a clickable DOM.
            click_info = None
            click_deadline = time.monotonic() + 0.15
            while time.monotonic() < click_deadline:
                try:
                    click_info = list_c.ev(r"""((pid)=>{
                      const as=[...document.querySelectorAll('a[href*="property-"]')];
                      const a=as.find(x=>{try{return new URL(x.href,location.href).pathname.includes('/property-'+pid)}catch(e){return false}});
                      if(!a)return null;
                      a.removeAttribute('download');
                      a.scrollIntoView({block:'center',inline:'nearest'});
                      const r=a.getBoundingClientRect(),cs=getComputedStyle(a);
                      if(r.width<2||r.height<2||cs.display==='none'||cs.visibility==='hidden')return null;
                      return {x:r.left+r.width/2,y:r.top+r.height/2,href:a.href};
                    })(%s)""" % json.dumps(str(pid)))
                except Exception:
                    click_info = None
                if click_info:
                    break
                time.sleep(.02)

            if click_info and self._real_click_rect(list_c, click_info, modifiers=2):
                self.write("[BG-CDP] %sCtrl+Click 后台点击帖子 %s" % (
                    (("%.3fs：" % (time.perf_counter()-t0)) if t0 else ""), pid))
                child_deadline = time.monotonic() + 0.75
                while time.monotonic() < child_deadline:
                    child = self._find_property_target(pid, exclude_ids={list_tid})
                    if child:
                        cc = None
                        try:
                            cc = self.cdp(child)
                            prep(cc)
                            ok2, href2 = self._wait_document_ready(cc, 2.5, pid)
                            if ok2:
                                returned_tid = child.get("id")
                                close_list_if_needed()
                                self._wake_contact_section(cc, t0)
                                return child, cc
                        except Exception:
                            if cc:
                                try:
                                    cc.close()
                                except Exception:
                                    pass
                    time.sleep(.025)

            why = "列表DOM暂未出现该新帖链接" if not click_info else "Ctrl+Click未及时产生详情Target"
            self.write("[BG-CDP] %s%s；立即用已知URL继续" % (
                (("%.3fs：" % (time.perf_counter()-t0)) if t0 else ""), why))

            # Navigate the already-loaded hidden LIST target itself. This keeps
            # the profile/session and sends the list page as the referrer.
            try:
                nav = list_c.call("Page.navigate", {
                    "url": url,
                    "referrer": list_url,
                    "transitionType": "link",
                }) or {}
                if nav.get("errorText"):
                    raise RuntimeError(nav.get("errorText"))
                ok4, href4 = self._wait_document_ready(list_c, 4.0, pid)
                if ok4:
                    returned_tid = list_tid
                    self._wake_contact_section(list_c, t0)
                    return list_t, list_c
            except Exception:
                # If the renderer changed, reattach to the same targetId.
                try:
                    if list_c:
                        list_c.close()
                except Exception:
                    pass
                list_c = None
                try:
                    current = next((x for x in self.targets() if x.get("id") == list_tid), None)
                    if current:
                        list_c = self.cdp(current)
                        prep(list_c)
                        ok5, href5 = self._wait_document_ready(list_c, 1.5, pid)
                        if ok5:
                            list_t = current
                            returned_tid = list_tid
                            self._wake_contact_section(list_c, t0)
                            return current, list_c
                except Exception:
                    pass

            close_list_if_needed()
            return direct_hidden_target("同一隐藏Target导航未完成")

        except Exception:
            if list_c:
                try:
                    list_c.close()
                except Exception:
                    pass
            if list_t and list_t.get("id") and list_t.get("id") != returned_tid:
                self.close_target_id(list_t.get("id"))
            raise

    def visible_phones_dom(self, c):
        """Read existing Tel text through CDP DOM domain when JS is slow.

        Every CDP operation has a short timeout; do not re-run an expensive
        Runtime.evaluate on a renderer which already timed out.
        """
        try:
            doc = c.call('DOM.getDocument', {'depth': 1, 'pierce': False}, timeout=0.60)
            root = ((doc or {}).get('root') or {}).get('nodeId')
            if not root:
                return []
            selectors = ('.content_phone_information,[class*="contact_information"],'
                         '[class*="contact-info"],[class*="contactInformation"]')
            nodes = c.call('DOM.querySelectorAll', {'nodeId': root, 'selector': selectors}, timeout=0.60)
            ids = (nodes or {}).get('nodeIds') or []
            for node in ids[:5]:
                try:
                    dom = c.call('DOM.getOuterHTML', {'nodeId': node}, timeout=0.65)
                    rows = extract_visible_phones((dom or {}).get('outerHTML') or '')
                    if rows:
                        self.write('[FAST-TEL-DOM] 房源联络区有 %d 个现成电话，跳过致电' % len(rows))
                        return rows
                except Exception:
                    continue
            # Last resort: the heading is present but parent CSS changed.
            # Never scrape unrelated sidebars/ads by a whole-page phone regex.
            html_element = c.call('DOM.querySelector', {'nodeId': root, 'selector': 'html'}, timeout=0.40)
            html_node = (html_element or {}).get('nodeId')
            if not html_node:
                return []
            doc_html = c.call('DOM.getOuterHTML', {'nodeId': html_node}, timeout=0.75)
            raw_html = (doc_html or {}).get('outerHTML') or ''
            if '放盤聯絡人' not in raw_html and '放盘联络人' not in raw_html:
                return []
            rows = extract_visible_phones(raw_html)
            if rows:
                self.write('[FAST-TEL-DOM] 依放盤聯絡人標題讀取 %d 個電話，無需點擊' % len(rows))
            return rows
        except Exception as exc:
            self.write('[FAST-TEL-DOM] DOM備援未取得資料：%s' % (str(exc)[:85]))
            return []

    def reveal_contact_once(self, c, idx, wait_ms=850):
        """Click the exact Call control once and observe its Tel: mutation.

        One Runtime.evaluate roundtrip replaces repeated click/read/poll calls.
        Refuses tel: navigation: an already-present tel URI is parsed, not clicked.
        A single attempt is important because an unacknowledged click may still
        have succeeded on the website. Never blindly retry it.
        """
        script = r'''(async(idx, waitMs)=>{
          const norm=v=>{
            const m=String(v||'').match(/(?:^|\D)(?:\+?852[\s-]*)?([2-9]\d{3}[\s-]?\d{4})(?!\d)/);
            return m?m[1].replace(/\D/g,''):'';
          };
          const a=document.querySelector('[data-pm-contact-index="'+idx+'"]');
          if(!a||!a.isConnected)return {clicked:false,phone:'',state:'button-gone'};
          const link=a.closest('a[href]');
          const href=link?link.getAttribute('href')||'':'';
          if(/^tel:/i.test(href))return {clicked:false,phone:norm(href),state:'tel-href'};
          if(/^(?:https?:)?\/\//i.test(href)&&/wa\.me|whatsapp/i.test(href))
            return {clicked:false,phone:'',state:'non-phone-link'};
          // Prefer the smallest contact card with one Tel. A broad common parent
          // can contain TWO contacts and previously returned person #1's phone
          // for person #2's click.
          const rx=/(?:Tel\.?|電話|电话)\s*[:：]\s*(?:\+?852[\s-]*)?([2-9]\d{3}[\s-]?\d{4})(?!\d)/ig;
          let region=a.parentElement||a, chosen=null, broad=null;
          for(let p=region,d=0;p&&p!==document.body&&d<6;p=p.parentElement,d++){
            const txt=(p.textContent||'').slice(0,2600);
            const hits=[...txt.matchAll(rx)];
            if(hits.length===1){chosen=p;break}
            if(hits.length>1&&broad===null)broad=p;
            if(txt.length>1800)break;
            region=p;
          }
          region=chosen||broad||region;
          const read=()=>{
            const text=(region.textContent||'').slice(0,2600), matches=[...text.matchAll(rx)];
            if(matches.length===1)return norm(matches[0][0]);
            // If the markup has no per-contact wrapper, use button order,
            // never silently borrow a different person's phone.
            const tagged=[...region.querySelectorAll('[data-pm-contact-index]')];
            const localIdx=tagged.indexOf(a);
            if(matches.length>1){
              if(tagged.length===matches.length&&localIdx>=0)return norm(matches[localIdx][0]);
              return ''; // uncertain association: never steal another person's phone
            }
            const links=[...region.querySelectorAll('a[href^="tel:"]')];
            if(links.length===1)return norm(links[0].getAttribute('href')||'');
            if(links.length>1&&tagged.length===links.length&&localIdx>=0)
              return norm(links[localIdx].getAttribute('href')||'');
            return '';
          };
          const existing=read();
          if(existing)return {clicked:false,phone:existing,state:'already-visible'};
          return await new Promise(resolve=>{
            let finished=false,obs=null,timer=null;
            const end=(state,phone='')=>{
              if(finished)return;
              finished=true;
              if(obs)obs.disconnect();
              if(timer!==null)clearTimeout(timer);
              resolve({clicked:true,phone,state});
            };
            obs=new MutationObserver(()=>{const v=read();if(v)end('revealed',v)});
            obs.observe(region,{subtree:true,childList:true,characterData:true,attributes:true,attributeFilter:['href']});
            timer=setTimeout(()=>end('not-revealed'),waitMs);
            try{
              a.click();
              const immediate=read();if(immediate)end('revealed-sync',immediate);
            }catch(e){end('click-error:'+String(e).slice(0,60))}
          });
        })(__IDX__,__WAIT__)'''.replace('__IDX__', str(int(idx))).replace('__WAIT__', str(int(wait_ms)))
        rr = c.call('Runtime.evaluate', {
            'expression': script,
            'awaitPromise': True,
            'returnByValue': True,
            'userGesture': True,
        }, timeout=max(0.20, wait_ms / 1000 + 0.50))
        result = ((rr or {}).get('result') or {}).get('value')
        return result if isinstance(result, dict) else None

    # ---------------- Detail / phone ----------------
    def detail(self, k, url, test_mode=False, wa_test=False, race_t0=None, warm_target=None):
        tid = None
        c = None
        t0 = time.perf_counter()
        detail_deadline = time.monotonic() + 9.0
        self.write("[ULTRA-TEST] 0.000s：模拟NEW -> 创建详情" if test_mode else "[ULTRA] 0.000s：NEW -> 创建详情")
        try:
            if warm_target is None:
                t, c = self.open_detail_background_cdp(k, url, t0)
            else:
                t, c = self.open_detail_background_cdp(k, url, t0, warm_target=warm_target)
            tid = t.get("id")
            c.deadline = detail_deadline
            self.write("[ULTRA] %.3fs：纯CDP后台已进入详情并连接隐藏 Target" % (time.perf_counter() - t0))

            # Fast path: 28Hse sometimes already renders `Tel: 852-xxxxxxxx`
            # before/without another click. Read it directly from the contact section
            # so a visible phone can never be missed just because the button selector changed.
            # V1.46.1: 28Hse renders some phones as plain text (Tel: 852-...)
            # beneath the heading, without any tel: anchor or a predictable
            # .content_phone_information class. Read that contact panel BEFORE
            # searching for or clicking a Call button.
            visible_js = r'''(()=>{
              const clean=s=>String(s||'').replace(/\s+/g,' ').trim();
              const bad=e=>!!e.closest('.recommend,.recommendation,.related,.advertisement,.ads,aside,[class*="similar-property"],[class*="related-property"]');
              const telRx=/(?:Tel\.?|電話|电话)\s*[:：]\s*(?:\+?852[\s-]*)?([2-9]\d{3}[\s-]?\d{4})(?!\d)/ig;
              const norm=v=>{const m=String(v||'').match(/(?:^|\D)(?:\+?852[\s-]*)?([2-9]\d{3}[\s-]?\d{4})(?!\d)/);return m?m[1].replace(/\D/g,''):''};
              const contactNameFromSegment=(segment,fallback='未知')=>{
                          let t=String(segment||'').replace(/放盤聯絡人|放盘联络人|(?:致[電电]|撥打電話|拨打电话|WhatsApp|發訊|发讯|複製|复制)/ig,' ').trim();
                          const titled=[...t.matchAll(/([\u3400-\u9fff]{1,5}(?:太太|先生|小姐|女士|太|姐|生)(?:\s*[A-Za-z][A-Za-z .]{0,35})?)/g)];
                          if(titled.length)return titled[titled.length-1][1].trim();
                          const english=[...t.matchAll(/\b(?:Mrs|Ms|Miss|Mr)\.?\s*[A-Za-z][A-Za-z .]{0,35}/gi)];
                          if(english.length)return english[english.length-1][0].trim();
                          const lines=t.split(/[\n\r]+/).map(x=>x.trim()).filter(Boolean);
                          const last=lines[lines.length-1]||'';
                          if(last.length>=2&&last.length<=60&&/[A-Za-z]/.test(last)&&
                            !/Tel\s*[:：]|電話|电话|^https?:|房源|(?:^|\s)Phone/i.test(last))return last;
                          return fallback;
                        };
                        const textTelephoneRows=(t,defaultName='未知')=>{
                          const rows=[],rx=/(?:Tel\.?|電話|电话)\s*[:：]\s*(?:\+?852[\s-]*)?([2-9]\d{3}[\s-]?\d{4})(?!\d)/ig;
                          let cursor=0;
                          for(const m of String(t||'').matchAll(rx)){
                            const segment=String(t).slice(cursor,m.index);
                            const name=contactNameFromSegment(segment,rows.length?'未知':defaultName);
                            rows.push({name,phone:m[1].replace(/\D/g,'')});
                            cursor=m.index+m[0].length;
                          }
                          return rows;
                        };
                        
              const panels=[];
              const add=p=>{if(p&&!bad(p)&&!panels.includes(p)&&p!==document.body&&p.textContent.length<12000)panels.push(p)};
              document.querySelectorAll('.content_phone_information,[class*="contact_information"],[class*="contact-info"],[class*="contactInformation"]').forEach(add);
              // This heading may be a div/span, not an h2; it may contain an
              // already-visible Tel line even if there is no Call button.
              const hs=[...document.querySelectorAll('h2,h3,h4,h5,strong,b,span,div')];
              for(const e of hs){
                if(e.childElementCount>2||bad(e))continue;
                if(!/^(放盤聯絡人|放盘联络人)$/.test(clean(e.textContent)))continue;
                for(let p=e.parentElement,d=0;p&&p!==document.body&&d<7;p=p.parentElement,d++){
                  const txt=(p.textContent||'').slice(0,9500);
                  if(/Tel\.?\s*[:：]|電話\s*[:：]|电话\s*[:：]/i.test(txt)||p.querySelector('a[attr="phone"],a[href^="tel:"]')){add(p);break}
                }
                break;
              }
              const results=[],seen=new Set();
              for(const panel of panels.slice(0,5)){
                const text=(panel.textContent||'').slice(0,8500);
                const named=panel.querySelector('[class*="contact-name"],[class*="contact_name"],[class*="contactName"],[class*="person-name"]');
                const defaultName=(named&&(named.textContent||'').trim())||'未知';
                const telRows=textTelephoneRows(text,defaultName);
                const addPhone=(name,p)=>{const v=norm(p);if(v&&!seen.has(v)){seen.add(v);results.push({name:name||'未知',phone:v})}};
                for(const item of telRows)addPhone(item.name,item.phone);
                for(const a of panel.querySelectorAll('a[href^="tel:"]')){
                  const context=(a.parentElement&&a.parentElement.textContent)||'';
                  addPhone(contactNameFromSegment(context.split(/Tel\s*[:：]/i)[0],telRows.length?'未知':defaultName),a.getAttribute('href'));
                }
              }
              return results.slice(0,8);
            })()'''
            # A runtime exception on this target must not cause 2-3 more
            # Runtime.evaluate timeouts in the same already-stalled renderer.
            visible_rows = []
            runtime_slow = False
            try:
                visible_rows = c.ev(visible_js, timeout=0.60) or []
            except TimeoutError as exc:
                runtime_slow = True
                self.write('[FAST-TEL] Runtime讀取超時，改用DOM通訊直接讀取已顯示電話')
            except (RuntimeError, ValueError):
                pass
            if not visible_rows and runtime_slow:
                visible_rows = self.visible_phones_dom(c) or []
            if visible_rows:
                # Fast first: name and phone arrive as one value; no click/no
                # scroll/no extra page navigation is necessary.
                n0 = visible_rows[0].get('name') or '未知'
                if n0 != '未知' and not (test_mode or wa_test):
                    self.set_listing_contact_name(k, url, n0)
            elif runtime_slow:
                # The browser's renderer is not responding. Extra JS clicking
                # and DOM scans would just burn the whole deadline again.
                self.write('[FAST-TEL] Runtime未回應且DOM無公開電話，保留補抓而不重複卡死')
                return False, '頁面Runtime無回應，DOM亦未找到已顯示電話'
            if visible_rows:
                got_any = True  # even a duplicate/filtered visible phone must not trigger redundant CDP retries
                self.write("[FAST-TEL] %.3fs：页面已显示 %d 个号码，直接提取" % (time.perf_counter() - t0, len(visible_rows)))
                fail_reasons = []
                accepted_any = False
                success_reason = ""
                for vr in visible_rows:
                    vp = self.normalize_phone(vr.get("phone") or "")
                    if len(vp) == 8 and vp[:1] in ("2", "3"):
                        fail_reasons.append("%s 以2/3开头，已过滤" % vp)
                        continue
                    if not vp:
                        fail_reasons.append("页面号码格式无效")
                        continue
                    ok, reason = self.result(k, vr.get("name") or "未知", vp, url, test_mode=test_mode,
                                             wa_test=wa_test, race_t0=race_t0,
                                             extra_phones=[r for r in visible_rows if r is not vr])
                    if ok:
                        accepted_any = True
                        success_reason = success_reason or reason
                        if len(visible_rows) > 1 and not (test_mode or wa_test):
                            for extra in visible_rows:
                                if extra is vr: continue
                                self.bg(self.publish_secondary_phone, k, url,
                                        extra.get('name') or vr.get('name') or '未知', extra.get('phone') or '')
                        return True, reason
                    elif reason:
                        fail_reasons.append(reason)
                if accepted_any:
                    return True, success_reason or "抓号成功"
                return False, "；".join(x for x in fail_reasons if x) or "页面有号码，但没有可用的有效号码"

            discover = r'''(()=>{
              const clean=s=>String(s||'').replace(/\s+/g,' ').trim();
              const isAd=e=>!!e.closest('.recommend,.recommendation,.related,.advertisement,.ads,[class*="similar-property"],[class*="related-property"]');
              const isCall=e=>{
                const t=clean(e.textContent), a=clean(e.getAttribute('aria-label')||e.getAttribute('title')||'');
                const href=clean(e.getAttribute('href')||'').toLowerCase();
                const combined=clean(t+' '+a).toLowerCase();
                if(/whatsapp|wa\.me|微信|發訊|发讯|email|電郵|电邮/i.test(combined+' '+href))return false;
                if(e.matches('a[attr="phone"],a[href^="tel:"]'))return true;
                return /^(致[電电]|撥打電話|拨打电话|顯示電話|显示电话|顯示號碼|显示号码|call)(?:\s|$)/i.test(combined);
              };
              const scopeSel='a[attr="phone"],a[href^="tel:"],a,button,span,[role="button"],[onclick],[class*="phone"],[class*="call"]';
              const direct=[...document.querySelectorAll('.content_phone_information,[class*="contact_information"],[class*="contact-info"],[class*="contactInformation"]')].filter(x=>!isAd(x));
              let panels=direct.filter(p=>[...p.querySelectorAll(scopeSel)].some(isCall)).slice(0,8);
              // Find the heading using short leaf elements only; never compute
              // innerText for every div/span on a busy listing page.
              if(!panels.length){
                const hs=[...document.querySelectorAll('h2,h3,h4,h5,strong,b,[class*="contact-title"],[class*="contact_title"]')];
                const h=hs.find(e=>e.childElementCount<=2 && /^(放盤聯絡人|放盘联络人)$/.test(clean(e.textContent)));
                if(h){for(let p=h.parentElement,d=0;p&&p!==document.body&&d<7;p=p.parentElement,d++){
                  if([...p.querySelectorAll(scopeSel)].some(isCall)){panels=[p];break;}
                }}
              }
              if(!panels.length){
                // The current 28Hse layout may omit the header. Accept a call
                // button only if a nearby container explicitly describes this
                // listing's contact details; never pick a recommended ad.
                for(const e of document.querySelectorAll('a[attr="phone"],a[href^="tel:"],button,[role="button"],[onclick]')){
                  if(isAd(e)||!isCall(e))continue;
                  for(let p=e.parentElement,d=0;p&&p!==document.body&&d<5;p=p.parentElement,d++){
                    const own=clean(p.textContent||'').slice(0,450);
                    if(/放盤聯絡人|放盘联络人|聯絡人|联络人|業主|业主/.test(own)){
                      panels=[p];break;
                    }
                  }
                  if(panels.length)break;
                }
              }
              const buttons=[];
              for(const panel of panels){
                if(!panel||isAd(panel))continue;
                for(const x of panel.querySelectorAll(scopeSel)){
                  if(!isCall(x)||isAd(x))continue;
                  const target=x.closest('a,button,[role="button"],[onclick]')||x;
                  if(!buttons.some(y=>y===target||y.contains(target)||target.contains(y)))buttons.push(target);
                }
              }
              const rows=[];
              for(const b of buttons.slice(0,8)){
                const i=rows.length;
                b.setAttribute('data-pm-contact-index',String(i));
                let name='未知';
                for(let p=b.parentElement,d=0;p&&p!==document.body&&d<4;p=p.parentElement,d++){
                  const t=(p.innerText||p.textContent||'').trim();
                  if(t.length>450)break;
                  const lines=t.split(/\n+/).map(clean).filter(Boolean);
                  const at=lines.findIndex(x=>/^(致[電电]|call)/i.test(x));
                  const names=(at<0?lines:lines.slice(0,at)).map(x=>clean(x.replace(/致[電电].*$/i,''))).filter(x=>x.length<=65&&/[\p{L}]/u.test(x)&&
                    !/放盤聯絡人|放盘联络人|致[電电]|WhatsApp|發訊|发讯|電郵|电邮|電話|电话|按此|聯絡|联络|複製|复制|Tel:/i.test(x));
                  if(names.length){name=names[names.length-1];break;}
                }
                rows.push({i,name});
              }
              return {rows,noPhone:false,waiting:!rows.length,
                hasContactSection:!!panels.length,ready:document.readyState,
                candidateCount:buttons.length};
            })()'''
            info = {}
            end = min(time.monotonic() + 2.2, detail_deadline)
            while time.monotonic() < end and (self.running or test_mode or wa_test):
                info = c.ev(discover, timeout=0.65) or {}
                if info.get("rows") or info.get("noPhone"):
                    break
                c.ev("window.scrollBy(0,Math.max(750,innerHeight));true", timeout=0.35)
                time.sleep(.025)

            rows = info.get("rows") or []
            if rows and not (test_mode or wa_test):
                self.set_listing_contact_name(k, url, rows[0].get("name") or "未知")
                self.write("[CONTACT-FOUND] %s %s · %d 位联系人 / %s" % (k, self.pid_of(url), len(rows), rows[0].get("name") or "未知"))
            if not rows:
                late_visible = self.visible_phones_dom(c) or []
                if late_visible:
                    got_any = True
                    self.write('[CONTACT-LATE-DOM] 最終掃描發現 %d 個已顯示電話' % len(late_visible))
                    accepted = False
                    for i, item in enumerate(late_visible):
                        phone = self.normalize_phone(item.get('phone') or '')
                        if not phone or phone[0] in ('2', '3'):
                            continue
                        ok, reason = self.result(k, item.get('name') or '未知', phone, url,
                            test_mode=test_mode, wa_test=wa_test, race_t0=race_t0,
                            extra_phones=late_visible[i+1:])
                        if ok:
                            accepted = True
                            accepted_any = True  # finally: no unnecessary retry
                            if not (test_mode or wa_test):
                                for extra in late_visible[i+1:]:
                                    self.bg(self.publish_secondary_phone, k, url,
                                        extra.get('name') or '未知', extra.get('phone') or '')
                            return True, reason
                    if not accepted:
                        self.set_listing_status(k, url, '電話已重複或過濾')
                        return False, '已讀取公开号碼，但均已去重或過濾'
                self.write("[CONTACT-SCAN] %s %s · 联系区=%s · 页面=%s · 致电候选=%s" % (
                    k, self.pid_of(url), bool(info.get("hasContactSection")),
                    info.get("ready", "?"), info.get("candidateCount", 0)))
                label = "无公开电话" if info.get("noPhone") else "未提取到"
                self.write("! 未发现可用致电控件 / " + label)
                return False, ("房源没有公开电话号码" if info.get("noPhone") else "纯CDP后台已进入帖子并滚到联络人区域，但没有找到“致电”控件，也没有提取到电话号码")

            got_any = False
            accepted_any = False
            fail_reasons = []
            for row in rows:
                if time.monotonic() >= detail_deadline:
                    self.write("[DETAIL-DEADLINE] 后台详情达到9秒处理预算，停止继续点击；不阻塞其他新帖")
                    break
                idx = int(row.get("i", 0))
                name = row.get("name") or "未知"
                phone = ""
                read_one = r'''((idx)=>{
                  const norm=v=>{const m=String(v||'').match(/(?:\+?852[\s-]*)?([2-9]\d{3}[\s-]?\d{4})(?!\d)/);return m?m[1].replace(/\D/g,''):''};
                  const a=document.querySelector('[data-pm-contact-index="'+idx+'"]');
                  if(!a)return '';
                  const own=norm(a.getAttribute('href')||'')||norm(a.textContent||'');
                  if(own)return own;
                  let box=a.parentElement||a;
                  for(let d=0;d<5&&box&&box!==document.body;d++,box=box.parentElement){
                    for(const tel of box.querySelectorAll('a[href^="tel:"]')){
                      const p=norm(tel.getAttribute('href'));if(p)return p;
                    }
                    const t=box.textContent||'';
                    const m=t.match(/(?:Tel|電話|电话)\s*[:：]\s*(?:\+?852[\s-]*)?[2-9]\d{3}[\s-]?\d{4}(?!\d)/i);
                    if(m)return norm(m[0]);
                    if(t.length>700)break;
                  }
                  return '';
                })(%d)''' % idx

                # Phone-first: an already-visible tel: always wins. An ordinary
                # DOM click is much cheaper for a hidden renderer than three CDP
                # Input events. Fall back to a trusted mouse click only if the
                # reveal did not appear after the first click.
                deadline = min(time.monotonic() + 2.6, detail_deadline)
                next_click = 0.0
                dom_attempted = False
                mouse_attempted = False
                mouse_disabled = (k, self.pid_of(url)) in self.cdp_mouse_unhealthy
                click_no = 0
                while time.monotonic() < deadline and (self.running or test_mode or wa_test):
                    try:
                        raw = c.ev(read_one, timeout=0.48)
                    except TimeoutError:
                        # A timed-out renderer makes DOM.getDocument equally
                        # expensive. Stop rather than issuing multiple commands
                        # against an unresponsive hidden Target.
                        raise RuntimeError('CONTACT_RUNTIME_STALLED')
                    if raw:
                        phone = str(raw)
                        break
                    now = time.monotonic()
                    if now >= next_click:
                        if not dom_attempted:
                            dom_attempted = True
                            # Wait for a real DOM mutation after the Call click;
                            # do not poll/roundtrip CDP every 12ms while the
                            # website is rendering the newly revealed Tel.
                            try:
                                observed = self.reveal_contact_once(c, idx, wait_ms=850)
                            except TimeoutError as exc:
                                # The click may already have occurred. Do not
                                # send another physical click on an unresponsive
                                # Target; preserve the listing for later retry.
                                self.write('[CONTACT-REVEAL-TIMEOUT] %s %s · %s' %
                                           (k, self.pid_of(url), str(exc)))
                                raise RuntimeError('CONTACT_REVEAL_ACK_TIMEOUT') from exc
                            if isinstance(observed, dict):
                                revealed = self.normalize_phone(observed.get('phone') or '')
                                if revealed:
                                    phone = revealed
                                    self.write('[CONTACT-REVEALED] %s %s · %s · %s' %
                                               (k, self.pid_of(url), name, observed.get('state', 'ok')))
                                    break
                                clicked = bool(observed.get('clicked'))
                                if clicked:
                                    click_no += 1
                                    self.write('[CONTACT-CLICK] %s %s · %s · 单次点击后未揭号' %
                                               (k, self.pid_of(url), name))
                                    # No reveal appeared during the observer window.
                                    # On the next loop read once more, then try a
                                    # single trusted CDP mouse click if the DOM
                                    # click was ignored by site event handlers.
                                    # Direct tel: links were already handled above.
                                    next_click = time.monotonic()
                                else:
                                    next_click = time.monotonic()
                                continue
                            # Compatibility path for older CDP mock/renderer
                            # versions that do not return a by-value result.
                            direct = c.ev(r'''((idx)=>{
                              const a=document.querySelector('[data-pm-contact-index="'+idx+'"]');
                              if(!a || !a.isConnected)return false;
                              const txt=(a.textContent||'').trim().toLowerCase();
                              const href=(a.closest('a[href]')||a).getAttribute('href')||'';
                              if(txt.includes('whatsapp')||/^(tel:|https?:.*(?:wa\.me|whatsapp))/i.test(href))return false;
                              a.click();return true;
                            })(%d)''' % idx, timeout=0.85)
                            click_no += 1 if direct else 0
                            self.write("[CONTACT-CLICK] %s %s · %s DOM点击致电：%s" %
                                       (k, self.pid_of(url), name, "已触发" if direct else "未命中"))
                            next_click = time.monotonic() + (0.25 if direct else 0.01)
                            continue
                        if not mouse_attempted and not mouse_disabled:
                            mouse_attempted = True
                            hit = c.ev(r'''((idx)=>{
                              const a=document.querySelector('[data-pm-contact-index="'+idx+'"]');
                              if(!a || !a.isConnected)return null;
                              a.scrollIntoView({block:'center',inline:'nearest',behavior:'instant'});
                              const r=a.getBoundingClientRect(),cs=getComputedStyle(a);
                              if(r.width<2||r.height<2||cs.visibility==='hidden'||cs.display==='none')return null;
                              const x=r.left+r.width/2,y=r.top+r.height/2,top=document.elementFromPoint(x,y);
                              const unobstructed=!!top&&(top===a||a.contains(top)||top.contains(a));
                              return {x,y,unobstructed};
                            })(%d)''' % idx, timeout=0.75)
                            if hit and hit.get("unobstructed"):
                                x, y = float(hit["x"]), float(hit["y"])
                                try:
                                    # No mouseMoved round trip. Each CDP Input
                                    # command has its own 550ms hard cap.
                                    c.call("Input.dispatchMouseEvent", {"type": "mousePressed", "x": x, "y": y, "button": "left", "buttons": 1, "clickCount": 1}, timeout=0.55)
                                    c.call("Input.dispatchMouseEvent", {"type": "mouseReleased", "x": x, "y": y, "button": "left", "buttons": 0, "clickCount": 1}, timeout=0.55)
                                    click_no += 1
                                    self.write("[CONTACT-CLICK] %s %s · %s CDP鼠标点击已确认" % (k, self.pid_of(url), name))
                                except TimeoutError as e:
                                    # A missing CDP reply is not a failed website
                                    # click. Do NOT re-send an uncertain click.
                                    with self.lock:
                                        self.cdp_mouse_unhealthy.add((k, self.pid_of(url)))
                                    self.write("[CONTACT-MOUSE-TIMEOUT] %s %s · %s；后续重试禁用CDP鼠标，保留DOM/HTTP" %
                                               (k, self.pid_of(url), str(e)))
                                    raise RuntimeError("CONTACT_MOUSE_ACK_TIMEOUT") from e
                            elif hit:
                                self.write("[CONTACT-CLICK] 致电按钮被遮挡；不点其他元素，只等已触发的DOM点击")
                            # After at most one attempt with each click type,
                            # continue reading phone without repeated click storm.
                            next_click = deadline + 1
                        else:
                            next_click = deadline + 1
                    time.sleep(.012)

                # Some 28Hse components replace the original button node after
                # reveal, so the indexed selector may disappear. Read the actual
                # listing's contact panel once more before declaring failure.
                if not phone and dom_attempted:
                    try:
                        final_visible = c.ev(visible_js, timeout=0.65) or []
                        if final_visible:
                            phone = str(final_visible[0].get("phone") or "")
                    except (TimeoutError, RuntimeError):
                        pass

                if phone:
                    got_any = True
                    digits = self.normalize_phone(phone)
                    if len(digits) == 8 and digits[:1] in ("2", "3"):
                        self.write("[CONTACT %d/%d] %.3fs：%s / %s（2/3开头，已过滤，不送EXE）" % (idx + 1, len(rows), time.perf_counter() - t0, name, digits))
                        continue
                    self.write("[CONTACT %d/%d] %.3fs：%s / %s" % (idx + 1, len(rows), time.perf_counter() - t0, name, digits or phone))
                    ok, reason = self.result(k, name, digits or phone, url, test_mode=test_mode, wa_test=wa_test, race_t0=race_t0)
                    if ok:
                        accepted_any = True
                        if test_mode or wa_test:
                            return True, reason
                    elif reason:
                        fail_reasons.append(reason)
                else:
                    self.write("[CONTACT %d/%d] %s：未提取到" % (idx + 1, len(rows), name))
                    fail_reasons.append("联系人 %s：点击致电后仍未提取到号码" % name)

            if accepted_any:
                return True, "抓号成功"
            if not got_any:
                self.write("! 本帖联系人均未提取到公开号码")
                return False, "已找到联系人，但点击“致电”后均未提取到公开号码"
            return False, "；".join(x for x in fail_reasons if x) or "找到了电话号码，但全部未通过过滤或复制步骤"
        except Exception as e:
            reason = str(e) or e.__class__.__name__
            if "CDP_CALL_" in reason or reason == "CONTACT_MOUSE_ACK_TIMEOUT":
                self.write("[DETAIL-DEADLINE] %s · %s · %dms；中止失效 Target" % (k, self.pid_of(url), int((time.perf_counter()-t0)*1000)))
            self.write("! 详情异常：" + reason)
            return False, "详情页处理异常：" + reason
        finally:
            pid = self.pid_of(url)
            if pid and not test_mode:
                # Do not mark a network/CDP failure as successfully processed.
                # Bound retries to 2; schedule outside the hot detection loop.
                retry = False
                with self.lock:
                    self.inflight[k].discard(pid)
                    if not locals().get("accepted_any", False):
                        n = self.retry_count[k].get(pid, 0) + 1
                        self.retry_count[k][pid] = n
                        retry = (n <= 1 and self.running and not self.cdp_fault_event.is_set()
                                 and not locals().get("got_any", False))
                    self.processed[k].add(pid)
                if retry:
                    self.set_listing_status(k, url, "补抓中…")
                    self.write("[DETAIL-RETRY] %s %s · 第%d次延后补抓；不阻塞DetectionRace" % (k,pid,n))
                    run_id = self.run_id
                    def delayed_retry():
                        time.sleep(min(8, 2*n))
                        if self.running and self.run_id == run_id and self.phone_api_allow_detail:
                            self.queue_cdp_fallback(k, url, race_t0 or time.perf_counter())
                    self.bg(delayed_retry)
                elif self.retry_count[k].get(pid, 0) > 1:
                    if locals().get('got_any', False):
                        self.set_listing_status(k, url, '電話已重複或過濾')
                        self.write('[DETAIL-SKIP] %s %s · 已取得號碼但去重或過濾，不標記取號失敗' % (k,pid))
                    else:
                        self.set_listing_status(k, url, "取号失败")
                    self.write("[DETAIL-FAIL] %s %s · 后台补抓一次仍失败；保留原帖供手动核对" % (k,pid))
            if c and warm_target is None:
                c.close()
            elif c:
                # Worker retains this background page for the next property.
                c.deadline = None
            if tid and warm_target is None:
                try:
                    _LOCAL_OPENER.open(self._debug_url("/json/close/" + str(tid)), timeout=3).read()
                except Exception:
                    pass

    # ---------------- Result row / post helpers ----------------
    def show_detected_row(self, k, url):
        """Make detection visible immediately, even when phone extraction fails."""
        pid = self.pid_of(url)
        if not pid: return
        key = (k, pid)
        def ui():
            if key in self.listing_rows and self.tree.exists(self.listing_rows[key]): return
            source = "28租盘" if k == "rent" else "28售盘"
            iid = self.tree.insert("", 0, values=(source, "取号中…", "未知", "待处理", "打开"))
            self.listing_rows[key] = iid
            self.row_urls[iid] = url
        self.after(0, ui)

    def remove_duplicate_listing_row(self, k, url):
        """Do not keep a duplicate-phone placeholder in the results list."""
        pid = self.pid_of(url)
        if not pid:
            return
        def ui():
            iid = self.listing_rows.get((k, pid))
            if not iid or not self.tree.exists(iid):
                return
            current = self.tree.item(iid, 'values') or ()
            # In an HTTP/CDP race, the loser may report DUP *after* the winner
            # updated the same listing with a phone. Never delete that winner.
            existing = self.normalize_phone(current[1]) if len(current) > 1 else ''
            if len(existing) == 8:
                return
            self.listing_rows.pop((k, pid), None)
            self.tree.delete(iid)
            self.row_urls.pop(iid, None)
            self.data_timings.pop(iid, None)
        self.after(0, ui)

    def set_listing_contact_name(self, k, url, name):
        """Optional post-detection UI backfill; never blocks phone/clipboard."""
        name = self.clean_contact_name(name)
        if name == "未知":
            return
        if callable(getattr(self, 'note_wa_contact', None)):
            self.note_wa_contact(url, name, final=True)
        pid = self.pid_of(url)
        if not pid:
            return
        def ui():
            iid = self.listing_rows.get((k, pid))
            if iid and self.tree.exists(iid):
                vals = list(self.tree.item(iid, "values") or ())
                if len(vals) >= 5 and vals[2] in ("未知", "补充中…", ""):
                    vals[2] = name
                    self.tree.item(iid, values=vals)
        self.after(0, ui)

    def set_listing_status(self, k, url, status):
        pid = self.pid_of(url)
        if not pid: return
        def ui():
            iid = self.listing_rows.get((k, pid))
            if not iid or not self.tree.exists(iid): return
            vals = list(self.tree.item(iid, 'values'))
            if len(vals) < 5: return
            if vals[1] not in ('取号中…', '补抓中…', '取号失败', '未公开号码', '号码重复', '正在揭号…', '取号排队超时', '等候揭号…'):
                return  # Never overwrite a successful phone
            vals[1] = status
            self.tree.item(iid, values=vals)
        self.after(0, ui)

    def update_row_field(self, iid, index, value):
        if not iid:
            return
        def apply():
            try:
                if not self.tree.exists(iid):
                    return
                vals = list(self.tree.item(iid, "values") or ())
                while len(vals) < 5:
                    vals.append("")
                vals[index] = str(value or "")
                self.tree.item(iid, values=vals)
                self._finish_data_timing(iid, vals)
            except Exception:
                pass
        self.after(0, apply)

    def _finish_data_timing(self, iid, values):
        """UI-thread-only. Final means backfill and WA have settled, not that data exists."""
        meta = self.data_timings.get(iid)
        if not meta or meta.get("done"):
            return
        name = str(values[2] if len(values) > 2 else "").strip()
        wa = str(values[3] if len(values) > 3 else "").strip()
        name_pending = name in ("", "补充中…", "待补充")
        wa_pending = wa in ("", "待发送", "发送中", "测试发送中")
        if name_pending or wa_pending:
            return
        meta["done"] = True
        elapsed = max(0, round((time.perf_counter() - meta["t0"]) * 1000))
        complete = name not in ("未知", "未提供") and not wa.startswith("失败")
        self.write("[RACE] NEW→ALL_DATA %dms · %s · 联系人=%s · WA=%s%s" % (
            elapsed, meta["source"], name, wa, "" if complete else " · 部分资料不可用"))
        self.data_timings.pop(iid, None)

    def initial_wa_status(self, wa_test=False):
        if wa_test:
            return "测试发送中"
        if not self.wa_enable.get():
            return "未启用"
        try:
            return "待发送" if self.in_wa_window() else "时段外"
        except Exception:
            return "设置错误"

    def on_tree_click(self, event):
        try:
            row = self.tree.identify_row(event.y)
            col = self.tree.identify_column(event.x)
            if not row or col != "#5":
                return
            url = self.row_urls.get(row)
            if url:
                self.bg(self.open_original_post, url)
        except Exception:
            pass

    def open_original_post(self, url):
        try:
            if not self.cdp_base:
                self.connect_browser()
            if not self.cdp_base:
                raise RuntimeError("浏览器未连接")
            with _LOCAL_OPENER.open(self._debug_url("/json/version"), timeout=3) as r:
                ver = json.loads(r.read().decode(errors="replace"))
            bws = ver.get("webSocketDebuggerUrl")
            if not bws:
                raise RuntimeError("浏览器没有返回 browser websocket")
            bc = CDP(bws)
            bc.connect()
            try:
                rr = bc.call("Target.createTarget", {"url": url, "background": False}) or {}
                if not rr.get("targetId"):
                    raise RuntimeError("未能创建原帖标签页")
            finally:
                bc.close()
            self.write("[OPEN] 已打开原帖：" + url)
        except Exception as e:
            self.write("[OPEN] 打开原帖失败：" + str(e))
            self.after(0, lambda: messagebox.showerror("打开原帖失败", str(e), parent=self))

    def backfill_contact_name(self, k, url, phone, iid):
        # Low priority: already dispatched after clipboard; no artificial wait.
        t = c = None
        tid = None
        try:
            if not self.cdp_base or not iid:
                return
            t, c = self.open_http_bridge(k)
            tid = t.get("id")
            expr = r'''(async()=>{
              const url=__URL__, wanted=__PHONE__;
              const norm=v=>{
                let d=((v||'')+'').replace(/\D/g,'');
                if(d.startsWith('00852'))d=d.slice(5);
                else if(d.length===11&&d.startsWith('852'))d=d.slice(3);
                return d;
              };
              const ctl=new AbortController(), timer=setTimeout(()=>ctl.abort(),1800);
              try{
                const r=await fetch(url,{credentials:'include',cache:'no-store',signal:ctl.signal,
                  headers:{'Cache-Control':'no-cache','Pragma':'no-cache'}});
                if(!r.ok)return '';
                const html=await r.text();
                const doc=new DOMParser().parseFromString(html,'text/html');
                for(const block of doc.querySelectorAll('.content_phone_information')){
                  const txt=block.textContent||'';
                  const vals=[];
                  for(const a of block.querySelectorAll('a[href^="tel:"]')) vals.push(norm(a.getAttribute('href')||''));
                  for(const x of block.querySelectorAll('.fullPhone')) vals.push(norm(x.textContent||''));
                  for(const line of txt.split(/\n+/)) if(/Tel\s*[:：]/i.test(line)) vals.push(norm(line));
                  if(!vals.includes(wanted))continue;
                  const lines=txt.split(/\n+/).map(x=>x.trim()).filter(Boolean);
                  for(const x of lines){
                    if(x.length>100||/致電|致电|WhatsApp|電郵|电邮|發訊|发讯|Tel\s*[:：]/i.test(x)||norm(x)||/^\d+$/.test(x))continue;
                    return x;
                  }
                }
                return '';
              }catch(e){return ''}finally{clearTimeout(timer)}
            })()'''.replace('__URL__', json.dumps(url, ensure_ascii=False)).replace('__PHONE__', json.dumps(phone))
            rr = c.call("Runtime.evaluate", {"expression": expr, "awaitPromise": True, "returnByValue": True}) or {}
            name = self.clean_contact_name(((rr.get("result") or {}).get("value")) or "")
            if callable(getattr(self, 'note_wa_contact', None)):
                self.note_wa_contact(url, name, final=True)
            if name and name not in ("未知", "补充中…"):
                self.update_row_field(iid, 2, name)
                self.write("[NAME] 后补联系人：%s / %s" % (phone, name))
            else:
                self.update_row_field(iid, 2, "未知")
        except Exception:
            if callable(getattr(self, 'note_wa_contact', None)):
                self.note_wa_contact(url, '未知', final=True)
            self.update_row_field(iid, 2, "未知")
        finally:
            if c:
                try:
                    c.close()
                except Exception:
                    pass
            if tid:
                try:
                    self.close_target_id(tid)
                except Exception:
                    pass

    # ---------------- WhatsApp schedule ----------------
    @staticmethod
    def _parse_hhmm(s):
        m = re.fullmatch(r"\s*(\d{1,2}):(\d{2})\s*", str(s))
        if not m:
            raise ValueError("时间请使用 HH:MM，例如 23:30")
        h, minute = int(m.group(1)), int(m.group(2))
        if not (0 <= h <= 23 and 0 <= minute <= 59):
            raise ValueError("时间超出范围")
        return h * 60 + minute

    def in_wa_window(self):
        if not self.wa_enable.get():
            return False
        s = self._parse_hhmm(self.wa_start.get())
        e = self._parse_hhmm(self.wa_end.get())
        now = datetime.now().hour * 60 + datetime.now().minute
        if s == e:
            return True  # same time means whole day
        if s < e:
            return s <= now < e
        return now >= s or now < e

    def maybe_whatsapp(self, phone, url, source, row_id=None, *, window_approved=False):
        try:
            if not self.wa_enable.get():
                self.update_row_field(row_id, 3, "未启用")
                return
            # UnifiedApp checks the time window when the new listing is
            # detected. Name recovery may finish after that window closes;
            # do not reject a message that was eligible at detection time.
            if not window_approved and not self.in_wa_window():
                self.update_row_field(row_id, 3, "时段外")
                self.write("[WA] 时段外，不发送：%s" % phone)
                return
            key = "%s|%s" % (phone, url)
            with self.lock:
                if key in self.wa_sent:
                    self.update_row_field(row_id, 3, "已处理")
                    return
                self.wa_sent.add(key)
            self.update_row_field(row_id, 3, "发送中")
            ok, msg = self.whatsapp_send(phone, url)
            if ok:
                self.update_row_field(row_id, 3, "已发送")
                self.write("[WA] ✓ 已打招呼：%s" % phone)
                self.toast("WhatsApp 已发送", "%s · %s" % (source, phone), 3200)
            else:
                if not str(msg or "").startswith("可能已发送"):
                    with self.lock:
                        self.wa_sent.discard(key)
                short = str(msg or "发送失败").replace("\n", " ").strip()
                if len(short) > 26:
                    short = short[:26] + "…"
                if str(msg or "").startswith("可能已发送"):
                    self.update_row_field(row_id, 3, "待确认")
                    self.write("[WA] ? %s：%s" % (phone, msg))
                else:
                    self.update_row_field(row_id, 3, "失败：" + short)
                    self.write("[WA] ✗ %s：%s" % (phone, msg))
        except Exception as e:
            short = str(e or "异常").replace("\n", " ").strip()
            if len(short) > 26:
                short = short[:26] + "…"
            self.update_row_field(row_id, 3, "失败：" + short)
            self.write("[WA] ✗ 异常：" + str(e))

    def whatsapp_send(self, phone, url, message=None):
        """Send through background CDP. Never report success before observing a new outgoing bubble."""
        if not self.cdp_base:
            return False, "浏览器未连接"
        phone_digits = re.sub(r"\D", "", str(phone))
        if len(phone_digits) == 8:
            phone_digits = "852" + phone_digits
        if len(phone_digits) < 8:
            return False, "电话号码无效"

        msg = (self.wa_text.get() if message is None else str(message)).replace("{url}", url)
        if not msg.strip():
            return False, "WhatsApp 消息内容为空"
        wa_url = "https://web.whatsapp.com/send?phone=%s&text=%s" % (
            phone_digits, parse.quote(msg, safe=""))

        # Fetch both the composer and the last outgoing bubbles. The current composer
        # being cleared is not sufficient evidence of sending (navigation can clear it).
        wa_state_js = r'''(()=>{
          const b=document.querySelector('#main footer [contenteditable="true"],footer [contenteditable="true"],#main [data-testid="conversation-compose-box-input"]');
          const body=document.body?.innerText||'';
          if(/phone number shared via url is invalid|电话号码无效|電話號碼無效/i.test(body))return {s:'invalid'};
          if(!b){if(/use whatsapp on your computer|使用 WhatsApp 網頁版|使用 WhatsApp 网页版/i.test(body))return {s:'login'};
            return {s:'wait'};}
          const normalize=s=>(s||'').replace(/\s+/g,' ').trim();
          const draft=normalize(b.innerText||b.textContent||'');
          const list=[...document.querySelectorAll('.message-out,[data-testid="msg-outgoing"],[data-testid="message-out"]')];
          const expected=__EXPECTED__;
          const wanted=normalize(expected);
          const prefix=normalize(expected.split(/https?:\/\//)[0]);
          const matchText=s=>{const v=normalize(s);return v.includes(wanted)||(prefix.length>=5&&v.includes(prefix)&&(!wanted.includes('http')||v.includes(normalize(expected.match(/https?:\/\/\S+/)?.[0]||''))))};
          const last=list.slice(-12);
          return {s:'ready',draft: draft, outgoingCount:list.length,
            outgoingMatch:last.some(x=>matchText(x.innerText||x.textContent||'')),
            composerReady: !!b, focused:document.activeElement===b};
        })()'''.replace('__EXPECTED__', json.dumps(msg, ensure_ascii=False))

        # WhatsApp Web can render the send arrow as an icon nested inside a
        # clickable div/span, rather than a <button> below the editor. Resolve
        # the *actual* send icon first, inside the active chat composer only.
        # The bottom-right fallback is confined to the composer row and requires
        # a single unambiguous candidate; never click attachment/microphone UI.
        wa_button_js = r'''(()=>{
          const main=document.querySelector('#main');
          if(!main)return {found:false,why:'active chat missing'};
          const editor=main.querySelector('footer [contenteditable="true"], [data-testid="conversation-compose-box-input"]');
          if(!editor)return {found:false,why:'composer editor missing'};
          const footer=editor.closest('footer')||main.querySelector('footer');
          if(!footer)return {found:false,why:'composer footer missing'};
          const er=editor.getBoundingClientRect(),fr=footer.getBoundingClientRect();
          const visible=el=>{
            if(!el||!el.isConnected)return false;
            const r=el.getBoundingClientRect(),s=getComputedStyle(el);
            return r.width>=8&&r.height>=8&&r.right>0&&r.bottom>0&&r.left<innerWidth&&r.top<innerHeight
              &&s.visibility!=='hidden'&&s.display!=='none'&&s.pointerEvents!=='none'
              &&!el.disabled&&el.getAttribute('aria-disabled')!=='true';
          };
          const isSendName=s=>/^(send|send-filled|send-message|compose-btn-send|send-button|send-btn|send message|發送|发送|傳送|发送消息|傳送訊息)$/i.test(String(s||'').trim());
          const blacklist=/(attach|attachment|microphone|voice|audio|emoji|plus|add|record|cancel|search|close|back|forward)/i;
          const resolve=icon=>{
            let el=icon.closest('button,[role="button"],[tabindex="0"]');
            if(!el||!footer.contains(el))el=icon;
            return el;
          };
          let found=null,kind='',from='';
          // Actual send glyph first. Do not use arbitrary right-most controls
          // before looking for icon-only WhatsApp layouts.
          for(const n of footer.querySelectorAll('[data-icon],[data-testid],[aria-label],[title]')){
            if(n===editor||editor.contains(n))continue;
            const name=[n.getAttribute('data-icon'),n.getAttribute('data-testid'),n.getAttribute('aria-label'),n.getAttribute('title')].find(isSendName);
            if(!name)continue;
            const el=resolve(n);
            if(!visible(el)||!visible(n))continue;
            const r=el.getBoundingClientRect();
            if((r.top+r.bottom)/2 < Math.max(er.top-40,fr.bottom-105))continue;
            if(r.right < er.left+er.width*.6)continue;
            found=el;kind='send-icon';from=String(name).slice(0,35);break;
          }
          if(!found){
            const controls=[...footer.querySelectorAll('button,[role="button"],[tabindex="0"]')]
              .filter(el=>el!==editor&&!editor.contains(el)&&visible(el));
            const named=controls.filter(el=>{
              const names=[el.getAttribute('aria-label'),el.getAttribute('title'),el.getAttribute('data-testid')];
              return names.some(isSendName)&&!names.some(x=>blacklist.test(x||''));
            });
            if(named.length===1){found=named[0];kind='named-control';}
          }
          if(!found){
            const controls=[...footer.querySelectorAll('button,[role="button"]')]
              .filter(el=>el!==editor&&!editor.contains(el)&&visible(el));
            const row=controls.filter(el=>{
              const r=el.getBoundingClientRect();
              const cy=(r.top+r.bottom)/2;
              if(cy < er.top-12 || cy > Math.max(er.bottom+30,fr.bottom+2))return false;
              if(r.right < er.right-30)return false;
              const label=[el.getAttribute('aria-label'),el.getAttribute('title'),el.getAttribute('data-testid'),el.getAttribute('data-icon')].join(' ');
              if(blacklist.test(label))return false;
              return true;
            });
            // Only fall back when there is exactly one plausible right-hand
            // send control. Never click an arbitrary icon if ambiguous.
            if(row.length===1){found=row[0];kind='unique-right-control';}
          }
          if(!found)return {found:false,why:'no unambiguous send control'};
          const r=found.getBoundingClientRect();
          return {found:true,kind,x:r.left+r.width/2,y:r.top+r.height/2,
            from:from, label:(found.getAttribute('aria-label')||found.getAttribute('data-testid')||'').slice(0,35)};
        })()'''

        # DOM click is tried before background mouse events. WhatsApp's React
        # handlers work with .click() on a resolved button even when BitBrowser
        # keeps the target tab in the background. Both use exactly one attempt,
        # and the composer is observed before any later method is attempted.
        wa_dom_send_js = r'''(()=>{
          const main=document.querySelector('#main');
          const editor=main?.querySelector('footer [contenteditable="true"], [data-testid="conversation-compose-box-input"]');
          const footer=editor?.closest('footer')||main?.querySelector('footer');
          if(!editor||!footer)return {clicked:false,why:'no composer'};
          const isSend=s=>/^(send|send-filled|send-message|compose-btn-send|send-button|send-btn|send message|發送|发送|傳送|发送消息|傳送訊息)$/i.test(String(s||'').trim());
          for(const n of footer.querySelectorAll('[data-icon],[data-testid],[aria-label],[title]')){
            if(n===editor||editor.contains(n))continue;
            if(![n.getAttribute('data-icon'),n.getAttribute('data-testid'),n.getAttribute('aria-label'),n.getAttribute('title')].some(isSend))continue;
            const target=n.closest('button,[role="button"],[tabindex="0"]')||n;
            const r=target.getBoundingClientRect(),s=getComputedStyle(target);
            if(!footer.contains(target)||r.width<8||r.height<8||r.right<=0||r.bottom<=0||s.display==='none'||s.visibility==='hidden'||s.pointerEvents==='none')continue;
            if(r.right<editor.getBoundingClientRect().right-30)continue;
            target.click();return {clicked:true,kind:'explicit-send-icon'};
          }
          return {clicked:false,why:'no explicit send icon'};
        })()'''

        wa_focus_js = r'''(()=>{const b=document.querySelector('#main footer [contenteditable="true"],footer [contenteditable="true"]');
          if(!b)return false;b.focus();const sel=window.getSelection();try{sel.selectAllChildren(b);sel.collapseToEnd()}catch(e){}return true})()'''

        with self.wa_lock:
            c = None
            try:
                t = None
                if self.wa_tid:
                    for p in self.targets():
                        if p.get("id") == self.wa_tid:
                            t = p
                            break
                if t is None:
                    t = self.create_background_target(wa_url)
                    self.wa_tid = t.get("id")
                c = self.cdp(t)
                c.call("Page.enable")
                # CDP-only background focus emulation; never activate the browser window.
                self.keep_bridge_active(c)
                if t.get("url") != wa_url:
                    c.call("Page.navigate", {"url": wa_url})

                deadline = time.monotonic() + 23.0
                attempt = 0
                last_attempt_at = 0.0
                blank_since = None
                first_ready = None
                baseline_count = None
                baseline_match = False
                ever_cleared = False
                cleared_at = None
                methods = ("dom-click", "cdp-mouse", "focused-enter")
                while time.monotonic() < deadline:
                    state = c.ev(wa_state_js) or {}
                    if state.get("s") == "invalid":
                        return False, "号码无 WhatsApp / 号码无效"
                    if state.get("s") == "login":
                        return False, "WhatsApp Web 未登录"
                    if state.get("s") != "ready":
                        time.sleep(.15)
                        continue
                    now = time.monotonic()
                    if first_ready is None:
                        first_ready = now
                        baseline_count = int(state.get("outgoingCount", 0))
                        baseline_match = bool(state.get("outgoingMatch"))

                    draft = str(state.get("draft") or "")
                    count = int(state.get("outgoingCount", 0))
                    matched = bool(state.get("outgoingMatch"))
                    if attempt > 0 and matched and (count > baseline_count or not baseline_match):
                        self.write("[WA-VERIFY] 聊天记录已出现新发出的匹配消息")
                        return True, "已确认发送"
                    if attempt > 0 and not draft:
                        ever_cleared = True
                        if cleared_at is None:
                            cleared_at = now
                        # Do NOT click again: a cleared composer may indicate a message was sent.
                        if now - cleared_at > 3.5:
                            return False, "可能已发送：输入框清空，但未核实新消息（为防重复禁止自动重发）"
                        time.sleep(.18)
                        continue

                    if attempt == 0 and not draft:
                        # Allow WhatsApp to populate the URL-provided draft first.
                        if blank_since is None:
                            blank_since = now
                        if now - blank_since < .65:
                            time.sleep(.13)
                            continue
                        if c.ev(wa_focus_js):
                            c.call("Input.insertText", {"text": msg})
                            self.write("[WA-COMPOSE] 网址参数未自动填入，使用 CDP 插入消息")
                        time.sleep(.2)
                        continue

                    expected_normalized = re.sub(r"\s+", " ", msg).strip()
                    if draft and draft != expected_normalized:
                        # A user-authored or partially changed draft must not be overwritten.
                        return False, "输入框内容与拟发送消息不一致；已保留草稿，未发送"
                    if attempt and now - last_attempt_at < .9:
                        time.sleep(.12)
                        continue
                    if attempt >= len(methods):
                        return False, "输入框仍有消息，三种发送方式均未触发（请查看 [WA55-SEND] 日志）"

                    method = methods[attempt]
                    if method == "dom-click":
                        result = c.ev(wa_dom_send_js) or {}
                        self.write("[WA55-SEND] 显式图示 DOM 点击：%s" %
                                   (result.get("kind", "已点击") if result.get("clicked") else "未定位到图示:" + str(result.get("why", "unknown"))))
                    elif method == "cdp-mouse":
                        hit = c.ev(wa_button_js) or {}
                        if hit.get("found"):
                            x,y=float(hit["x"]),float(hit["y"])
                            c.call("Input.dispatchMouseEvent", {"type":"mouseMoved","x":x,"y":y})
                            c.call("Input.dispatchMouseEvent", {"type":"mousePressed","x":x,"y":y,"button":"left","buttons":1,"clickCount":1})
                            c.call("Input.dispatchMouseEvent", {"type":"mouseReleased","x":x,"y":y,"button":"left","buttons":0,"clickCount":1})
                            self.write("[WA55-SEND] CDP 点击：%s (%d,%d)" % (hit.get("kind","button"), x, y))
                        else:
                            self.write("[WA55-SEND] CDP 未定位到发出按钮：%s" % hit.get("why", "unknown"))
                    else:
                        if c.ev(wa_focus_js):
                            c.call("Input.dispatchKeyEvent", {"type":"rawKeyDown","key":"Enter","code":"Enter","windowsVirtualKeyCode":13,"nativeVirtualKeyCode":13})
                            c.call("Input.dispatchKeyEvent", {"type":"keyUp","key":"Enter","code":"Enter","windowsVirtualKeyCode":13,"nativeVirtualKeyCode":13})
                            self.write("[WA55-SEND] 编辑框已聚焦，尝试 Enter 发送")
                        else:
                            self.write("[WA55-SEND] 未找到编辑框，无法执行 Enter")
                    attempt += 1
                    last_attempt_at = time.monotonic()
                    time.sleep(.35)
                if ever_cleared:
                    # Treat as indeterminate; caller must not automatically resend.
                    return False, "可能已发送：输入框清空，但未核实新消息（为防重复禁止自动重发）"
                if attempt:
                    return False, "输入框仍有消息，发送未成功；请查看 [WA55-SEND] 日志"
                return False, "等待 WhatsApp 聊天加载超时"
            except Exception as e:
                return False, "WhatsApp CDP 操作失败：" + str(e)
            finally:
                if c:
                    c.close()

    # ---------------- V1.50.45 multi-number clipboard ----------------
    def _28_clipboard_key(self, k, url):
        return (k, self.pid_of(url) or str(url or '').rstrip('/'))

    def _28_eligible_extra_phones(self, primary, rows):
        """Keep only valid, previously unused supplementary numbers in API order."""
        unique = set((primary,))
        candidates = []
        for item in rows or ():
            raw = item.get('phone') if isinstance(item, dict) else item
            digits = self.normalize_phone(raw)
            if (len(digits) != 8 or digits[0] in ('2', '3')
                    or digits in unique):
                continue
            unique.add(digits)
            candidates.append(digits)
        if not candidates:
            return []
        with self.phone_lock:
            return [num for num in candidates
                    if num not in self.seen_phones
                    and num not in self.pending_copy_phones]

    def _28_add_extra_to_clipboard(self, k, url, phone):
        """Extend only the *current* listing's clipboard, never an older one.

        Called after persisting an additional, previously unseen 28Hse number.
        Uses the same gate as normal/manual writes and the Win+L retry lane.
        """
        gate = getattr(self, 'clipboard_deferred_lock', None)
        if gate is None:
            return False
        with gate:
            group = getattr(self, 'latest_28_clipboard_group', None)
            if not group or group['key'] != self._28_clipboard_key(k, url):
                return False
            if (group['generation'] != self.clipboard_copy_generation
                    or group['run_id'] != self.run_id):
                return False
            if phone in group['phones']:
                return True  # It was already included with the primary API response.
            group['phones'].append(phone)
            new_text = '\n'.join(num[-4:] for num in group['phones'])
            extender = getattr(self, 'extend_auto_clipboard_group', None)
            if callable(extender):
                if extender(group['key'], new_text):
                    self.write('[28-MULTI-COPY] 同帖主號＋附加號已合併至剪貼簿隊列')
                    return True
                return False
            if self._copy_text_raw(new_text):
                pending = group.get('pending_primary')
                if pending:
                    with self.phone_lock:
                        self.seen_phones.add(pending)
                        self.pending_copy_phones.discard(pending)
                    group['pending_primary'] = None
                    self.bg(self.save_seen_phones_deferred)
                self.write('[28-MULTI-COPY] 同帖合併尾四位：%s' %
                           ' / '.join(num[-4:] for num in group['phones']))
                return True
            if (not hasattr(self, '_auto_clipboard') and os.name == 'nt'
                    and (windows_session_locked()
                    or 'busy' in getattr(self.clipboard_error_local, 'error', '').lower())):
                self._28_defer_group_clipboard_locked(group)
            return False

    def _28_defer_group_clipboard_locked(self, group):
        """Caller holds clipboard_deferred_lock; one repair job per generation."""
        if group.get('retrying'):
            return
        group['retrying'] = True
        self.bg(self._28_retry_group_clipboard_after_lock,
                group['generation'], group['run_id'], group['key'])

    def _28_retry_group_clipboard_after_lock(self, generation, run_id, key):
        """Windows locked/busy: recover combined tails only if still latest."""
        try:
            deadline = time.monotonic() + 12 * 60 * 60
            last_try = 0.0
            while time.monotonic() < deadline and self.running and run_id == self.run_id:
                with self.clipboard_deferred_lock:
                    group = getattr(self, 'latest_28_clipboard_group', None)
                    if (not group or group['key'] != key
                            or group['generation'] != generation
                            or self.clipboard_copy_generation != generation):
                        return
                    if not windows_session_locked() and time.monotonic() - last_try >= 3:
                        last_try = time.monotonic()
                        contents = '\n'.join(x[-4:] for x in group['phones'])
                        if self._copy_text_raw(contents):
                            pending = group.get('pending_primary')
                            if pending:
                                with self.phone_lock:
                                    self.seen_phones.add(pending)
                                    self.pending_copy_phones.discard(pending)
                                group['pending_primary'] = None
                                self.bg(self.save_seen_phones_deferred)
                            self.write('[28-MULTI-COPY-RECOVER] 已補複製同帖所有尾四位')
                            return
                time.sleep(2)
        finally:
            with self.clipboard_deferred_lock:
                group = getattr(self, 'latest_28_clipboard_group', None)
                if group and group['key'] == key and group['generation'] == generation:
                    group['retrying'] = False

    def publish_secondary_phone(self, k, url, name, phone):
        """Persist/display a supplementary number and join it to the same post's
        clipboard only when no newer post or manual copy has taken ownership.
        """
        phone = self.normalize_phone(phone)
        if len(phone) != 8 or phone[0] in ('2', '3'):
            return False
        with self.phone_lock:
            if phone in self.seen_phones or phone in self.pending_copy_phones:
                return False
            self.seen_phones.add(phone)
        # If this supplementary phone arrives after the primary was copied,
        # atomically refresh the clipboard to "main\nextra".  Later posts and
        # manual copies always win through the generation guard.
        merged = self._28_add_extra_to_clipboard(k, url, phone)
        self.bg(self.save_seen_phones_deferred)
        name = self.clean_contact_name(name)
        source = ('28租盘' if k == 'rent' else '28售盘') + ' · 附加号码'
        def ui():
            # Secondary number uses its own row; the primary property's row
            # continues to show the first copied number.
            for iid in self.tree.get_children(''):
                old = self.tree.item(iid, 'values') or ()
                if len(old) >= 2 and old[1] == phone:
                    return
            iid = self.tree.insert('', 0, values=(source, phone, name, self.initial_wa_status(), '打开'))
            self.row_urls[iid] = url
            # Secondary numbers may belong to a DIFFERENT contact person.
            # Run the configured female-only WA gate against THIS name, never
            # reuse the first contact's cached name for the entire property.
            if callable(getattr(self, 'maybe_whatsapp_contact', None)):
                self.bg(self.maybe_whatsapp_contact, phone, url, source, iid, name)
        self.after(0, ui)
        self.write('[FAST-TEL-EXTRA] 同房源补充号码 %s：另列展示；%s' % (
            phone, '同帖尾四位已合併／原始批次已包含' if merged else '較新剪貼簿優先，不覆蓋'))
        return True

    # ---------------- Results ----------------
    def result(self, k, n, p, u, test_mode=False, wa_test=False,
               race_t0=None, extra_phones=()):
        digits_guard = self.normalize_phone(p)
        if len(digits_guard) == 8 and digits_guard[:1] in ("2", "3"):
            if not (test_mode or wa_test): self.set_listing_status(k, u, "号码过滤")
            reason = "%s：号码以 2/3 开头，按规则已过滤" % digits_guard
            self.write("[FILTER] " + reason + "；不显示、不复制、不发WhatsApp")
            return False, reason
        if not digits_guard:
            reason = "没有提取到有效电话号码"
            if str(p or "").strip():
                reason += "（页面结果：%s）" % str(p).strip()
            return False, reason

        persist_needed = False
        reserved_copy = False
        if not test_mode and not wa_test:
            with self.phone_lock:
                if digits_guard in self.seen_phones or digits_guard in self.pending_copy_phones:
                    reason = "%s：号码已在永久去重库或正在处理" % digits_guard
                    self.remove_duplicate_listing_row(k, u)
                    self.write("[DUP] " + reason + "，跳过 EXE / 复制 / 提示 / WhatsApp")
                    return False, reason
                self.pending_copy_phones.add(digits_guard)
                reserved_copy = True
        elif digits_guard in self.seen_phones:
            self.write("[TEST] %s 已存在于去重库；测试模式仍继续复制/提示，不写入数据库" % digits_guard)

        p = digits_guard
        source = "28租盘" if k == "rent" else "28售盘"
        display_source = source + (" · 测试" if (test_mode or wa_test) else "")
        tail = p[-4:] if len(p) >= 4 else p

        # HOT PATH: copy ALL known numbers of THIS listing as one atomic text
        # block, primary first.  Extras that only appear later are merged by
        # publish_secondary_phone without touching a newer listing's clipboard.
        extras = (self._28_eligible_extra_phones(p, extra_phones)
                  if not (test_mode or wa_test) and extra_phones else [])
        initial_phones = [p] + extras
        copy_payload = '\n'.join(number[-4:] for number in initial_phones)
        with (getattr(self, 'clipboard_deferred_lock', None) or nullcontext()):
            if tail and not (test_mode or wa_test) and callable(getattr(self, 'copy_auto_text', None)):
                copy_ok = self.copy_auto_text(copy_payload, listing_key=self._28_clipboard_key(k, u))
            else:
                copy_ok = self.copy_text(copy_payload) if tail else False
            auto_queued = bool(getattr(self.clipboard_error_local, 'queued', False)) if not (test_mode or wa_test) else False
            if not (test_mode or wa_test) and hasattr(self, 'clipboard_copy_generation'):
                self.latest_28_clipboard_group = {
                    'key': self._28_clipboard_key(k, u),
                    'phones': initial_phones,
                    'generation': self.clipboard_copy_generation,
                    'run_id': self.run_id,
                    'retrying': False,
                    'pending_primary': None,
                }
        # Phone uniqueness is independent of the Windows clipboard.  A real
        # number must remain deduplicated even if Windows is locked/busy.
        # The unified latest-only clipboard handles its own busy retries;
        # do not schedule the older copy recovery in parallel.
        managed_retry = bool(getattr(self, '_auto_clipboard', None)) and auto_queued
        defer_clipboard = (reserved_copy and not copy_ok and not managed_retry
                           and os.name == 'nt'
                           and ('busy' in getattr(self.clipboard_error_local, 'error', '').lower()
                                or windows_session_locked()))
        if reserved_copy:
            with self.phone_lock:
                self.pending_copy_phones.discard(digits_guard)
                self.seen_phones.add(digits_guard)
                persist_needed = True
        if defer_clipboard:
            # Keep the original primary's persistent dedup reservation and
            # recover the up-to-date composite text after Win+L.
            with self.clipboard_deferred_lock:
                group = getattr(self, 'latest_28_clipboard_group', None)
                if group and group['key'] == self._28_clipboard_key(k, u):
                    self._28_defer_group_clipboard_locked(group)
                else:
                    self.bg(self._retry_clipboard_after_lock, digits_guard,
                            copy_payload, self.clipboard_copy_generation, self.run_id)
        if persist_needed:
            self.bg(self.save_seen_phones_deferred)
        if race_t0 and copy_ok and not auto_queued:
            total_ms = int((time.perf_counter() - race_t0) * 1000)
            with self.lock:
                st = self.race_stats[k]
                st["last_total_ms"] = total_ms
                if not st.get("best_total_ms") or total_ms < st["best_total_ms"]:
                    st["best_total_ms"] = total_ms
            self.write("[RACE] NEW→CLIPBOARD %dms · 尾四位" % total_ms)
        if copy_ok:
            self.write("✓ 已立即複製最新尾四位：" + copy_payload.replace('\n', ' / ') +
                       (" [TEST]" if (test_mode or wa_test) else ""))
        elif auto_queued:
            self.write('[CLIPBOARD-PENDING] 剪貼簿忙碌；最新尾號待重試：' + copy_payload.replace('\n', ' / '))
        else:
            self.write("[CLIPBOARD-ERROR] 尾四位尚未寫入剪貼簿：%s（電話已保存去重，可在面板手動複製）" %
                       getattr(self.clipboard_error_local, "error", "unknown"))

        # Nonessential events run only after the first real clipboard attempt.
        # They must never delay NEW -> CLIPBOARD on a newly detected listing.
        if reserved_copy:
            callback = getattr(self, 'on_new_28_phone', None)
            if callable(callback):
                try: callback(k, digits_guard)
                except Exception as exc:
                    self.write('[PHONE-EVENT-WARN] 背景事件排隊失敗：%s' % type(exc).__name__)

        # POST-PROCESSING: never allowed to delay clipboard.
        raw_name = self.clean_contact_name(n)
        if callable(getattr(self, 'note_wa_contact', None)):
            self.note_wa_contact(u, raw_name, final=(raw_name != '未知'))
        name = raw_name if raw_name != "未知" else "补充中…"
        wa_status = self.initial_wa_status(wa_test=wa_test)

        def ui():
            self.latest_phone.set(p)
            if hasattr(self, 'show_28_phone_popup'):
                # Unified GUI uses the same dark Windows popup style as House730.
                self.show_28_phone_popup(k, p, tail, u, test_mode or wa_test)
            else:
                self.toast(
                    "28Hse 测试抓号" if (test_mode or wa_test) else "28Hse 抓到号码",
                    "%s · %s\n联系人：%s\n完整号码 %s" % (
                        source, p, raw_name or "待补充", "已取號" if copy_ok else "複製失敗"
                    )
                )
            # Keep just the newest simulated result for the same source + phone.
            # Never touch production records or the durable dedup store.
            if test_mode or wa_test:
                for old_iid in self.tree.get_children(""):
                    old_values = self.tree.item(old_iid, "values") or ()
                    if len(old_values) >= 2 and old_values[0] == display_source and old_values[1] == p:
                        self.tree.delete(old_iid)
                        self.row_urls.pop(old_iid, None)
                        self.data_timings.pop(old_iid, None)
            key = (k, self.pid_of(u)) if not (test_mode or wa_test) else None
            iid = self.listing_rows.get(key) if key else None
            if iid and self.tree.exists(iid):
                self.tree.item(iid, values=(display_source, p, name, wa_status, "打开"))
            else:
                iid = self.tree.insert("", 0, values=(display_source, p, name, wa_status, "打开"))
                if key: self.listing_rows[key] = iid
            self.row_urls[iid] = u
            self.data_timings[iid] = {"t0": race_t0 or time.perf_counter(), "source": display_source, "done": False}
            self._finish_data_timing(iid, (display_source, p, name, wa_status, "打开"))

            if name == "补充中…":
                self.bg(self.backfill_contact_name, k, u, p, iid)

            if wa_test:
                self.bg(self.manual_whatsapp_send, p, u, source, iid)
            else:
                self.bg(self.maybe_whatsapp, p, u, source, iid)

        self.after(0, ui)

        if wa_test:
            return True, "已抓到号码 %s，尾四位已自動複製；正在发送 WhatsApp 测试消息" % p
        if not copy_ok:
            if auto_queued:
                return True, "抓号成功：%s；剪貼簿暫忙，僅最新尾四位背景補複製；資料已去重保存" % p
            return False, "已抓到号码 %s，但尾四位複製到剪貼板失敗" % p
        return True, "抓号成功：%s；尾四位已自動複製；联系人/WA状态后台补充" % p

    def manual_whatsapp_send(self, phone, url, source, row_id=None):
        try:
            self.update_row_field(row_id, 3, "测试发送中")
            ok, msg = self.whatsapp_send(phone, url)
            if ok:
                self.update_row_field(row_id, 3, "测试成功")
                reason = "%s · %s\n%s" % (source, phone, msg or "已发送")
                self.write("[WA-TEST] ✓ 已实际发送：%s" % phone)
                self.toast("WhatsApp 测试已发送", "%s · %s" % (source, phone), 3200)
                self.test_popup("WhatsApp 打招呼测试", True, reason)
            else:
                short = str(msg or "发送失败").replace("\n", " ").strip()
                if len(short) > 26:
                    short = short[:26] + "…"
                self.update_row_field(row_id, 3, "测试失败：" + short)
                reason = str(msg or "发送失败，网站没有返回明确原因")
                self.write("[WA-TEST] ✗ %s：%s" % (phone, reason))
                self.toast("WhatsApp 测试失败", reason, 3500)
                self.test_popup("WhatsApp 打招呼测试", False, reason)
        except Exception as e:
            reason = str(e) or e.__class__.__name__
            short = reason.replace("\n", " ")
            if len(short) > 26:
                short = short[:26] + "…"
            self.update_row_field(row_id, 3, "测试失败：" + short)
            self.write("[WA-TEST] ✗ 异常：" + reason)
            self.test_popup("WhatsApp 打招呼测试", False, reason)

    def copy(self, tail=False):
        s = self.tree.selection()
        if not s:
            return
        vals = self.tree.item(s[0], "values")
        p = self.normalize_phone(vals[1] if len(vals) > 1 else "")
        self.copy_text(p)


if __name__ == "__main__":
    App().mainloop()
