# -*- coding: utf-8 -*-
"""Offline regression for request-header replay and privacy-safe diagnostics."""
import asyncio
from house730_light_api import House730LightAPI, PollError, safe_json_shape

class FakeRequest:
    url = 'https://api.house730.com/Property/QueryProperty'
    resource_type = 'xhr'
    method = 'POST'
    post_data = '{"owner":true,"sort":"latest"}'
    headers = {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'AppKey': 'SECRETKEY',
        'AppSignature': 'SECRETSIGNATURE',
        'language': 'zh-hk',
        'platform': 'wap',
        'cityen': 'hk',
        'X-Client-Key': 'SECRETX',
        'Cookie': 'SESSION_SECRET',
        'Origin': 'https://www.house730.com',
        'User-Agent': 'Browser',
    }

class FakePage:
    def __init__(self):
        self.handlers = {}
        self.reply = {'status':200, 'host':'api.house730.com', 'truncated':False,
                      'content_type':'application/json',
                      'body':'{"data":[{"url":"https://www.house730.com/rent-property-1234567/a/"}]}' }
    def on(self, event, fn): self.handlers[event] = fn
    def remove_listener(self, event, fn): self.handlers.pop(event,None)
    def is_closed(self): return False
    async def evaluate(self, script, params):
        h=params['headers']
        assert h['AppKey']=='SECRETKEY' and h['AppSignature']=='SECRETSIGNATURE'
        assert h['language']=='zh-hk' and h['platform']=='wap'
        assert h['X-Client-Key']=='SECRETX'
        assert 'Cookie' not in h and 'Origin' not in h and 'User-Agent' not in h
        assert params['body']==FakeRequest.post_data
        return self.reply

async def main():
    page=FakePage()
    api=House730LightAPI(page,'租')
    api._on_request(FakeRequest())
    assert api.ready
    assert len(await api.query())==1
    page.reply['body']='{"code":400,"Message":"SECRET_ABC","data":[]}'
    try:
        await api.query()
    except PollError as exc:
        assert exc.kind=='invalid-json-list'
        assert 'SECRET_ABC' not in str(exc)
        assert 'data=list[0]' in str(exc)
    else:
        raise AssertionError('Application-level failure must not be a success')
    assert 'SECRET_ABC' not in safe_json_shape(page.reply['body'])
    page.reply['body']='{"data":[{"url":"https://www.house730.com/buy-property-8888888/a/"}]}'
    try:
        await api.query()
    except PollError as exc:
        assert '其他交易類型樓盤=1' in str(exc)
    else:
        raise AssertionError('Wrong deal must not be accepted')
    api.detach()
    print('PASS: site headers preserved in RAM; browser headers excluded; JSON safe diagnostic; rent/buy isolation')

asyncio.run(main())
