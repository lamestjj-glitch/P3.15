"""Fast, reliable Windows CF_UNICODETEXT clipboard writer for background workers.

Uses a real app HWND as the clipboard owner. OpenClipboard(NULL) is purposely
never used because EmptyClipboard can then clear clipboard ownership and make
SetClipboardData fail. No Tk calls are made from worker threads.
"""
import ctypes
import time
from ctypes import wintypes


def copy_unicode_to_clipboard(text, owner_hwnd, *, user32=None, kernel32=None,
                              sleeper=time.sleep, retries=12):
    """Write Unicode text or raise OSError containing the failed Win32 call.

    user32/kernel32 and sleeper may be injected for platform-independent tests.
    """
    text = str(text or "")
    if not text:
        raise ValueError("clipboard text empty")
    if not isinstance(owner_hwnd, int) or owner_hwnd <= 0:
        raise OSError("clipboard owner HWND unavailable; refusing NULL owner")
    if user32 is None or kernel32 is None:
        if not hasattr(ctypes, 'WinDLL'):
            raise OSError("Windows clipboard is not available on this platform")
        user32 = user32 or ctypes.WinDLL('user32', use_last_error=True)
        kernel32 = kernel32 or ctypes.WinDLL('kernel32', use_last_error=True)

    HANDLE = ctypes.c_void_p
    HWND = wintypes.HWND
    UINT = wintypes.UINT
    BOOL = wintypes.BOOL
    SIZE_T = ctypes.c_size_t
    def proto(module, name, args, returns):
        f = getattr(module, name)
        f.argtypes = args
        f.restype = returns
        return f

    is_window = proto(user32, 'IsWindow', [HWND], BOOL)
    open_clipboard = proto(user32, 'OpenClipboard', [HWND], BOOL)
    empty_clipboard = proto(user32, 'EmptyClipboard', [], BOOL)
    set_clipboard_data = proto(user32, 'SetClipboardData', [UINT, HANDLE], HANDLE)
    close_clipboard = proto(user32, 'CloseClipboard', [], BOOL)
    global_alloc = proto(kernel32, 'GlobalAlloc', [UINT, SIZE_T], HANDLE)
    global_lock = proto(kernel32, 'GlobalLock', [HANDLE], HANDLE)
    global_unlock = proto(kernel32, 'GlobalUnlock', [HANDLE], BOOL)
    global_free = proto(kernel32, 'GlobalFree', [HANDLE], HANDLE)

    if not is_window(owner_hwnd):
        raise OSError("clipboard owner HWND is no longer a valid Windows window")

    get_error = getattr(ctypes, 'get_last_error', lambda: 0)
    data = (text + '\0').encode('utf-16-le')
    opened = False
    mem = None
    try:
        for attempt in range(retries):
            if open_clipboard(owner_hwnd):
                opened = True
                break
            if attempt + 1 < retries:
                sleeper(min(.004 * (attempt + 1), .02))
        if not opened:
            raise OSError('OpenClipboard busy; winerror=%d' % get_error())
        mem = global_alloc(0x0002, len(data))  # GMEM_MOVEABLE
        if not mem:
            raise OSError('GlobalAlloc failed; winerror=%d' % get_error())
        dest = global_lock(mem)
        if not dest:
            raise OSError('GlobalLock failed; winerror=%d' % get_error())
        try:
            ctypes.memmove(dest, data, len(data))
        finally:
            global_unlock(mem)
        if not empty_clipboard():
            raise OSError('EmptyClipboard failed; winerror=%d' % get_error())
        if not set_clipboard_data(13, mem):  # CF_UNICODETEXT
            raise OSError('SetClipboardData failed; winerror=%d' % get_error())
        mem = None  # Ownership transferred to Windows.
    finally:
        if mem:
            global_free(mem)
        if opened:
            close_clipboard()
    return True
