PandaMonitor V1.50.50 — 730 恢復穩定＋診斷（無 Signal）

基於 V1.50.49。請解壓完整 ZIP，再雙擊 START.bat。不要刪除原來的 C:\Users\Admin\PandaMonitor_28Hse 與 %LOCALAPPDATA%\House730Standalone173 目錄；新版不會重設數據庫。

對應 2026-10-18 日誌問題：
1. 730 在 08:49–08:58 兩路不停 [730-TRANSPORT-RECOVER] browser-execution，原先每3秒重試，沒有恢復。
2. 730 10:00 後租盤 Page.reload: Timeout 8500ms，多次重接同一頁。
3. 730 09:08／09:21 觸發真實 HTTP429 共用冷卻 600／3600 秒。
4. 28Hse 列表正常查詢相對快：不修改正常取號或查詢流程。

修改：
- 730 瀏覽器執行異常：同路按 3、6、12、24、30 秒漸進等待（最長30秒）；只在錯誤持續或狀態發生意義改變時記錄。
- 已真實成功過的 730 獨立原生 HTTP 列表通道，在瀏覽器 Renderer 失敗後可於下一輪嘗試接回；至少45秒內不反覆切換。若曾被網站拒絕 JSON 格式，不嘗試；不能繞過 HTTP 429。
- 初次 Reload 失敗但原頁有效 DOM 已經有至少兩條正確房源連結時，先保留 DOM 歷史基線，進入 HTML 退路；稍後再正常學習真正 JSON 模板。若 DOM 同樣無效，沿用原監督器恢復流程。
- 只有學習模板所需的頁面 Reload 會使用導航鎖，避免同時對同一 BitBrowser 發出多次導航；租售正常 JSON API 仍各自 single-flight 並行。
- 監督器重接間隔漸進增加，上限30秒，避免每幾秒無止境 Reload；已有房源／完整電話去重資訊不清空。
- 成功的 730 JSON 列表每10次輸出 [730-API-TIMING]：平均ms、最慢ms、執行通道。

不變：
28Hse 兩路獨立並行、500ms/其他自訂設定＋100–300ms 抖動、電話優先及多號碼換行複製、28Hse 永久 SQLite 歷史；730 自訂間隔和兩路並行；真實429遵守 Retry-After 並共用冷卻；WA 姓名核對（28＋730）、Ctrl+V 後100–300ms候補複製、跨站完整電話去重、無 Signal。

注意：網站實際返回429/Retry-After 不能靠程式『加速恢復』。若頻繁出現 600／3600 秒冷卻，請適度提高 730 輸入的查詢間隔，而非縮得更短。

離線測試：TEST_V1550_730_RECOVERY_OPTIMIZATION.py 及既有 730/WA/28Hse 相關回歸測試。
需要 Windows 10/BitBrowser 實機監控驗證；離線測試不保證網站端不再限流。
