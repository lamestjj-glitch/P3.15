PandaMonitor V1.50.32 — Signal CLI 啟動診斷／保護既有設定

本版從 V1.50.31 完整包修改，28Hse、House730、WhatsApp、DirectPhone、智能排程未修改。

1. 不再於啟動時自動匯入 signal-sender.zip 並覆寫 Signal 設定。既有帳號、群組／ID、852.jpg、CLI 路徑照舊。
2. 按「檢查帳號／查找群組」及「實際測試發圖」不再暗中保存 config.json；只有明確按保存設定或其他正常程式存檔操作時才寫入。
3. SIGNAL_DIAG.bat 全程只讀。Signal --version 等待上限由 12 秒升到 45 秒，與原 CLI 位置相同的 cwd；檢查 Java 啟動耗時；只有 --version 成功才查群組。
4. 不能因 --version 超時推斷 Signal Desktop／CLI 使用不同帳號；程序會明確指出這一點。
5. 這是診斷與設定保護修正，無法保證解決 Windows 端 Java／signal-cli 啟動卡住；實際原因需這份新診斷的結果確認。

測試時先退出 PandaMonitor，再雙擊 SIGNAL_DIAG.bat。不要修改、重連或重新註冊帳號。
圖像發送仍需 GUI 按「實際測試發圖」並由使用者明確確認，診斷工具不發送。
