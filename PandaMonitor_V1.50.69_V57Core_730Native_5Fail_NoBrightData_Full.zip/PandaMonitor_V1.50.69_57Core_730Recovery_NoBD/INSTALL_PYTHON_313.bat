@echo off
setlocal EnableExtensions
cd /d "%~dp0"
echo =======================================================
echo Install official Python 3.13 with Tkinter for Windows
 echo =======================================================
echo This is OPTIONAL. It installs Python 3.13 alongside 3.15.
echo No uninstall is needed; PandaMonitor will prefer 3.13.
echo.
where winget >nul 2>nul
if errorlevel 1 goto no_winget
choice /C YN /N /M "Install Python 3.13 via Windows Package Manager now? [Y/N] "
if errorlevel 2 exit /b 0
winget install --id Python.Python.3.13 -e --source winget --accept-source-agreements --accept-package-agreements
if errorlevel 1 goto install_failed
echo.
echo Install command finished. Close this window, reopen START.bat.
echo To verify the installation, run DIAG_PYTHON.bat.
pause
exit /b 0
:no_winget
echo Windows Package Manager (winget) is missing.
echo Download the official Windows Python 3.13 installer from:
echo https://www.python.org/downloads/windows/
echo IMPORTANT: Make sure Tcl/Tk and IDLE are selected in the installer.
start "" "https://www.python.org/downloads/windows/"
pause
exit /b 2
:install_failed
echo.
echo Automatic install did not finish. Try the installer at:
echo https://www.python.org/downloads/windows/
echo Select Tcl/Tk and IDLE during installation.
pause
exit /b 3
