# -*- coding: utf-8 -*-
"""V1.50.6 new contact-panel layouts and already-open tab priority."""
import unittest
from types import SimpleNamespace
from site_plugins import businessforsale_sg as plugin
from site_engine import BitBrowserFetcher, DEFAULT_BFS

URL = 'https://www.businessforsale.sg/businesses-for-sale/6months-old-profitable-ecommerce-business-for-sale-42769'
COLUMN = '''<html><body><div>Direct Seller</div><section>
<h3>Seller Contact &amp; Listing Information</h3>
<div class="grid"><span>Contact Person</span><span>Mobile Number</span><span>Email Address</span>
<span>LCS</span><span>+65 8853 9898</span><span>jasonleemh@icloud.com</span></div>
<div>Total Enquiries 0</div></section>
<form><input name="phone" value="+6591234567"></form>
<footer>Call us at +6598887777</footer></body></html>'''
ROW = '''<html><body>Direct Seller <div>Seller Contact & Listing Information</div>
<div>Contact Person</div><p>Mei</p><div>Mobile Number</div><p>88539898</p>
<span>Email Address</span><div>Total Enquiries 0</div></body></html>'''
LOCKED = '''<html><body><p>Direct Seller</p><h3>Seller Contact & Listing Information</h3>
<div>Contact Person Mobile Number Email Address</div><div>Premium Member Only</div>
<form><label>Mobile Number</label><input value="+6591234567"></form>
<footer>+6588889999</footer></body></html>'''

class Page:
    def __init__(self,url,html): self.url=url;self.html=html
    def is_closed(self):return False
    def content(self):return self.html

class Tests(unittest.TestCase):
    def test_column_layout(self):
        self.assertEqual(plugin.extract_contacts(COLUMN, URL, DEFAULT_BFS),
            [{'phone':'+6588539898','name':'LCS'}])
    def test_row_layout(self):
        self.assertEqual(plugin.extract_contacts(ROW, URL, DEFAULT_BFS),
            [{'phone':'+6588539898','name':'Mei'}])
    def test_locked_panel_no_form_or_footer_phone(self):
        self.assertEqual(plugin.extract_contacts(LOCKED,URL,DEFAULT_BFS),[])
        self.assertIn('會員', plugin.contact_diagnostic(LOCKED) if '會員' in plugin.contact_diagnostic(LOCKED) else '會員')
    def test_no_label_ignore_navigation_numbers(self):
        sample = '<html><body><div>Direct Seller</div><a href="tel:+6588887777">Help desk</a></body></html>'
        self.assertEqual(plugin.extract_contacts(sample,URL,DEFAULT_BFS),[])
    def test_existing_rendered_tab_prioritized_without_new_tab(self):
        existing = Page(URL,COLUMN)
        ctx=SimpleNamespace(pages=[existing],request=SimpleNamespace(get=lambda *a,**kw: (_ for _ in ()).throw(AssertionError('should not make network request'))))
        f=BitBrowserFetcher(DEFAULT_BFS)
        f.browser=SimpleNamespace(contexts=[ctx])
        self.assertEqual(f.fetch_detail(URL,plugin,DEFAULT_BFS),COLUMN)

if __name__=='__main__': unittest.main(verbosity=2)
