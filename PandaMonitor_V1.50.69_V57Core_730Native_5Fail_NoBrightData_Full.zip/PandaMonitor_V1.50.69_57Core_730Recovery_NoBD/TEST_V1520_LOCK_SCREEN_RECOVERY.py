# -*- coding: utf-8 -*-
"""Regression: lock-safe, attach-only recovery and clipboard latest-wins."""
import asyncio
import inspect
import threading
from unittest.mock import patch

from house730_engine import lock_safe_list_reload, PollError, Engine
from panda28_core import App
from windows_session_state import is_locked, locked_state

assert locked_state() is None  # Linux test host; does not invent a Windows state
assert not is_locked()

class Page:
    url = 'https://www.house730.com/rent/s1u14/'
    called = 0
    closed = False
    def is_closed(self): return self.closed
    async def reload(self, **kwargs):
        self.called += 1
        assert kwargs['wait_until'] == 'commit'
        return 'success'

async def check_lock():
    p = Page()
    with patch('house730_engine.windows_session_locked', return_value=True):
        try: await lock_safe_list_reload(p, '租')
        except PollError as e: assert e.kind == 'windows-locked'
        else: raise AssertionError('Locked session must not force navigation')
    assert p.called == 0
    with patch('house730_engine.windows_session_locked', return_value=False):
        assert await lock_safe_list_reload(p, '租') == 'success'
    assert p.called == 1
    p.url = 'chrome-error://chromewebdata/'
    with patch('house730_engine.windows_session_locked', return_value=False):
        try: await lock_safe_list_reload(p, '租')
        except PollError as e: assert e.kind == 'list-not-ready'
        else: raise AssertionError('Wrong owner-filter URL should not be navigated')
    assert p.called == 1
asyncio.run(check_lock())

source = inspect.getsource(Engine._run)
listing = source.split('            async def list_loop(deal):',1)[1].split('            async def detail_worker',1)[0]
assert 'await page.goto(url' not in listing
assert 'await lock_safe_list_reload(page, deal' in listing
assert 'context.new_page()' not in listing
assert '[730-LOCK-WAIT]' in listing

worker_source = inspect.getsource(App.worker)
assert 'park_failed_cdp_until_unlock()' in worker_source
assert 'windows_session_locked()' in worker_source
assert 'self.close_target_id(tid)' not in worker_source

class FakeApp:
    running = True
    run_id = 9
    clipboard_copy_generation = 10
    clipboard_deferred_lock = threading.RLock()
    phone_lock = threading.Lock()
    pending_copy_phones = {'61234567'}
    seen_phones = set()
    calls = []
    messages = []
    def _copy_text_raw(self, value):
        self.calls.append(value)
        return True
    def bg(self, fn, *args):
        if getattr(fn, '__name__', '') == 'save_seen_phones_deferred': return
        raise AssertionError('Unexpected bg task')
    def write(self, line): self.messages.append(line)
    def save_seen_phones_deferred(self): pass
app = FakeApp()
with patch('panda28_core.windows_session_locked', return_value=False):
    App._retry_clipboard_after_lock(app, '61234567', '4567', 10, 9)
assert app.calls == ['4567']
assert '61234567' in app.seen_phones and not app.pending_copy_phones
# A later user/manual or new automatic copy cancels the previous delayed write.
app.calls.clear(); app.pending_copy_phones = {'69998888'}; app.clipboard_copy_generation = 11
with patch('panda28_core.windows_session_locked', return_value=False):
    App._retry_clipboard_after_lock(app, '69998888', '8888', 10, 9)
assert app.calls == [] and not app.pending_copy_phones
print('PASS V1.50.20: Win+L lock-safe 730 navigation, zero extra tabs, 28 CDP parking, clipboard latest-wins')
