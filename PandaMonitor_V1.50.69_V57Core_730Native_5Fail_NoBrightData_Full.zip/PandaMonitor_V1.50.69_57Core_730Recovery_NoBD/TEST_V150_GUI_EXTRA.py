# -*- coding: utf-8 -*-
"""End-to-end GUI smoke test (run with xvfb-run or on Windows desktop)."""
from __future__ import annotations
import tempfile
import threading
import time
from http.server import HTTPServer, BaseHTTPRequestHandler
from unified_gui import UnifiedApp
from site_engine import SiteConfigStore, SiteManager, DEFAULT_BFS

page={'body':'<a href="/listing/old">old</a>'}
class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        payload=('<a href="tel:+6581234567">Phone</a>' if self.path.startswith('/listing/') else page['body']).encode()
        self.send_response(200);self.send_header('Content-Type','text/html; charset=utf-8');self.end_headers();self.wfile.write(payload)
    def log_message(self,*_):pass

srv=HTTPServer(('127.0.0.1',0),Handler)
threading.Thread(target=srv.serve_forever,daemon=True).start()
app=UnifiedApp()
try:
    app.withdraw()
    app.rent.set(False);app.buy.set(False);app.house_rent.set(False);app.house_buy.set(False)
    s=dict(DEFAULT_BFS, id='gui-test-local',name='GUI EXTRA', plugin='',link_selector='a[href]',
           href_contains='/listing/', url=f'http://127.0.0.1:{srv.server_port}/list',mode='http',interval=0.5,enabled=True)
    with tempfile.TemporaryDirectory() as tmp:
        app.site_store=SiteConfigStore(tmp)
        with app.phone_lock: app.seen_phones.discard('6581234567')
        app.extra_sites=[s]
        app.site_manager=None
        app.start()
        assert app._site_alive(), 'Site manager should run without 28/730'
        wait=time.monotonic()+2
        while time.monotonic()<wait:
            app.update();time.sleep(.03)
        page['body'] += '<a href="/listing/new">new</a>'
        wait=time.monotonic()+8
        success=False
        while time.monotonic()<wait:
            app.update()
            if any('gui-test-local' in x for x in app.tree.get_children('')):
                success=True;break
            time.sleep(.03)
        assert success,'new site result not propagated to shared UI'
        print('PASS: extra site only mode, baseline, new result added to shared tree')
        app.site_manager.halt()
finally:
    app.destroy()
    srv.shutdown();srv.server_close()
