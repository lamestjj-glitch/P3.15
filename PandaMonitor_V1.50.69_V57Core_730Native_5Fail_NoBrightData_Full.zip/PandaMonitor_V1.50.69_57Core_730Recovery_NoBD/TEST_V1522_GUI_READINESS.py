"""28Hse UI must not claim API ready before verified results are available."""
import os, tempfile
with tempfile.TemporaryDirectory() as home:
    os.environ['HOME'] = home
    from unified_gui import UnifiedApp
    app=UnifiedApp()
    app.rent.set(True)
    app.buy.set(True)
    app.running=True
    app.http_stats['rent']['last_ok']=0.0
    app.http_stats['buy']['last_ok']=0.0
    app.set_monitor_controls(True)
    assert app.card_28r.get()=='等待列表 API 驗證',app.card_28r.get()
    assert app.card_28b.get()=='等待列表 API 驗證',app.card_28b.get()
    app.http_stats['rent']['last_ok']=1.0
    app._house_tick()
    assert app.card_28r.get()=='API 監控中',app.card_28r.get()
    assert app.card_28b.get()=='等待列表 API 驗證',app.card_28b.get()
    app.running=False
    app.destroy()
print('PASS V1.50.22 GUI: running versus verified API states')
