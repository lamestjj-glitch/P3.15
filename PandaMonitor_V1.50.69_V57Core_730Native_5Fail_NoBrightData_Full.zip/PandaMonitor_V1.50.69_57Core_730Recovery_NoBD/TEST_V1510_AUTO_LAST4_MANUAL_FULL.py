# -*- coding: utf-8 -*-
"""Offline regression test: automatic last 4, explicit user actions full phone."""
import re
import threading
from types import SimpleNamespace
from panda28_core import App
from unified_gui import UnifiedApp

class Holder:
    def __init__(self, value=None): self.value = value
    def set(self, value): self.value = value
    def get(self): return self.value

class Fake28:
    def __init__(self):
        self.copied = []
        self.seen_phones = set()
        self.pending_copy_phones = set()
        self.phone_lock = threading.Lock()
        self.logs = []
        self.clipboard_error_local = SimpleNamespace(error='')
    def normalize_phone(self, phone): return re.sub(r'\D', '', phone)
    def copy_text(self, text): self.copied.append(text); return True
    def write(self, text): self.logs.append(text)
    def clean_contact_name(self, name): return name
    def initial_wa_status(self, wa_test=False): return '未聯絡'
    def after(self, delay, fn): pass

f = Fake28()
ok, msg = App.result(f, 'rent', 'Alice', '61822314',
                     'https://www.28hse.com/rent/apartment/property-123', test_mode=True)
assert ok and f.copied == ['2314'], (ok, msg, f.copied)
assert '尾四位已自動複製' in msg, msg

class Fake730:
    def __init__(self):
        self.copied = []
        self.latest_phone = Holder()
        self.house_session = 0
        self.house_popup = Holder(False)
        self.wa_730_enable = Holder(False)
        self.logs = []
    def _show_house_row(self, data): pass
    def copy_text(self, text): self.copied.append(text); return True
    def write(self, text): self.logs.append(text)
    def update_row_field(self, *args, **kwargs): pass
    def normalize_phone(self, phone): return re.sub(r'\D', '', phone)

h = Fake730()
UnifiedApp._new_house_result(h, {'phone': '94609811', 'deal': '售', 'pid': '9292554',
                               'url': 'https://house730.com/buy-property-9292554'})
assert h.copied == ['9811'], h.copied
assert h.latest_phone.get() == '94609811'

class FakeTree:
    def __init__(self): self.rows = []; self.selection_data = ('row1',)
    def insert(self, *args, **kwargs): self.rows.append(kwargs); return 'row1'
    def selection(self): return self.selection_data
    def item(self, iid, arg):
        assert arg == 'values'
        return self.rows[0]['values']

class FakeSite:
    def __init__(self):
        self.copied = []
        self.phone_lock = threading.Lock()
        self.seen_phones = set()
        self.pending_copy_phones = set()
        self.latest_phone = Holder()
        self.win_notify = Holder(False)
        self.site_rows = {}
        self.tree = FakeTree()
        self.row_urls = {}
        self.logs = []
    def normalize_phone(self, phone): return re.sub(r'\D', '', phone)
    def copy_text(self, text): self.copied.append(text); return True
    def bg(self, *args, **kwargs): pass
    def save_seen_phones_deferred(self): pass
    def write(self, text): self.logs.append(text)

s = FakeSite()
UnifiedApp._new_site_result(s, {'phone': '94609811', 'site_id': '852house-buy',
    'url': 'https://852.house/zh/properties/412919?pricetype=buy',
    'id': 'B412919', 'title': 'Example', 'site_name': '852.house', 'contact': '陳先生'})
assert s.copied == ['9811'], s.copied
assert s.tree.rows[0]['values'][1] == '94609811', 'Full number remains visible'
assert s.tree.rows[0]['values'][6] == '9811', 'Tail remains visible'

# Explicit manual selection of list row copies full phone, not last 4.
UnifiedApp.copy(s, False)
assert s.copied == ['9811', '94609811'], s.copied

# Base 28Hse manual `copy` remains full-length, not automatically truncated.
f.tree = FakeTree()
f.tree.rows = [{'values': ('28租盤', '61822314')}]
App.copy(f, False)
assert f.copied == ['2314', '61822314'], f.copied

# Static guard on popup button callbacks and test-phone handling.
from pathlib import Path
source = (Path(__file__).parent / 'unified_gui.py').read_text('utf-8')
assert "copy_auto_tail_with_defer" in source
assert "lambda:self.copy_text(self.normalize_phone(phone))" in source
assert "lambda: self.copy_text(self.normalize_phone(data.get('phone', '')))" in source
print('PASS V1.50.10: all automatic copy paths last 4; explicit manual actions full phone')
