# -*- coding: utf-8 -*-
"""28Hse rent/buy independent single-flight list scheduler (V1.50.46).

Rent and buy may have ONE active HTTP list request each, concurrently.
A single lane cannot overlap itself, even if a second worker for that lane
attempts to enter.  No gradually increasing cadence or origin-wide FIFO is
imposed here.  Shared HTTP429 cooldown / serial recovery probes are enforced
by the independent RateCooldown slot in panda28_core.
"""
from contextlib import contextmanager
import threading
import time


class AdaptiveListScheduler:
    def __init__(self, clock=None, initial_gap=0.0, floor=0.0, ceiling=8.0):
        self.clock = clock or time.monotonic
        self.floor = 0.0
        self.ceiling = max(0.0, float(ceiling))
        self.initial_gap = 0.0
        self._cv = threading.Condition(threading.RLock())
        self.reset()

    def set_user_floor(self, seconds):
        from math import isfinite
        if not isfinite(float(seconds)) or float(seconds) <= 0:
            raise ValueError('expected a finite positive cadence')
        return False

    def reset(self):
        with self._cv:
            self.gap = 0.0
            self._active_lanes = set()
            self._ticket = 0
            self._waiting = []   # (ticket, lane), FIFO only within each lane
            self._healthy = 0
            self._timeouts = 0
            self._rate_hits = 0
            self._cdp_timeouts = 0
            self._successes = 0
            self._last_reason = 'two-lane-single-flight+jitter'
            self._cv.notify_all()

    def report(self):
        with self._cv:
            return {'gap_ms': 0, 'successes': self._successes,
                    'timeouts': self._timeouts, 'cdp_timeouts': self._cdp_timeouts,
                    'rate_hits': self._rate_hits, 'healthy': self._healthy,
                    'pending': len(self._waiting),
                    'active_lanes': tuple(sorted(self._active_lanes)),
                    'reason': self._last_reason}

    @contextmanager
    def lease(self, lane, active):
        if lane not in ('rent', 'buy'):
            raise ValueError('Unexpected 28Hse API lane')
        admitted = False
        with self._cv:
            self._ticket += 1
            entry = (self._ticket, lane)
            self._waiting.append(entry)
            try:
                while active():
                    same_lane_first = next((x for x in self._waiting if x[1] == lane), None)
                    if same_lane_first == entry and lane not in self._active_lanes:
                        self._waiting.remove(entry)
                        self._active_lanes.add(lane)
                        admitted = True
                        break
                    self._cv.wait(timeout=.05)
            finally:
                if not admitted and entry in self._waiting:
                    self._waiting.remove(entry)
                    self._cv.notify_all()
        try:
            yield admitted
        finally:
            if admitted:
                with self._cv:
                    self._active_lanes.discard(lane)
                    self._cv.notify_all()

    def success(self):
        with self._cv:
            self._successes += 1
            self._healthy += 1
            self._timeouts = 0
            self._last_reason = 'two-lane-single-flight+jitter'
        return False

    def transport_timeout(self):
        with self._cv:
            self._cdp_timeouts += 1
            self._last_reason = 'cdp-transport'
        return 0.0

    def slow_or_timeout(self, kind='timeout'):
        if kind in ('cdp-timeout', 'cdp-transport'):
            return self.transport_timeout()
        with self._cv:
            self._timeouts += 1
            self._healthy = 0
            self._last_reason = str(kind)
        return 0.0

    def rate_limited(self):
        with self._cv:
            self._rate_hits += 1
            self._healthy = 0
            self._last_reason = 'HTTP429-cooldown'
        return 0.0
