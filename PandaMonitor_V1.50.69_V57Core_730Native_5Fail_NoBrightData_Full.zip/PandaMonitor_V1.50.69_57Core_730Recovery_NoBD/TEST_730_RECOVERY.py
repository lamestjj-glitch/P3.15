# -*- coding: utf-8 -*-
"""Offline non-network recovery tests: invalid JSON, HTTP limits, and pending claims."""
import asyncio
import tempfile
from pathlib import Path
from house730_light_api import House730LightAPI, PollError, safe_json_shape
from house730_engine import Store, expected_list_url

class FakePage:
    def __init__(self, reply):
        self.reply = reply
        self.handlers = {}
    def on(self, name, fn): self.handlers[name] = fn
    def remove_listener(self, name, fn): self.handlers.pop(name, None)
    def is_closed(self): return False
    async def evaluate(self, expr, params):
        assert params['method'] == 'POST'
        assert params['body'] == '{"filters":true}'
        return self.reply

async def run_api():
    p = FakePage({'status': 200, 'host': 'api.house730.com', 'content_type': 'application/json',
                  'body': '{"code":400,"error":"not valid signature","appsignature":"SECRET-DO-NOT-LOG"}',
                  'truncated': False})
    api = House730LightAPI(p, '租')
    api.template = {'url': 'https://api.house730.com/Property/QueryProperty',
                    'method': 'POST', 'headers': {}, 'body': '{"filters":true}'}
    try:
        await api.query()
    except PollError as e:
        assert e.kind == 'invalid-json-list'
        assert e.cooldown == 0
        assert 'SECRET' not in str(e)
        assert 'root keys=' in str(e)
    else: raise AssertionError('200 but empty JSON must not be treated as success')
    assert api._internal_query is False
    p.reply['body'] = '{"Result":[{"url":"https://www.house730.com/rent-property-9876543/a/"}]}'
    assert len(await api.query()) == 1
    p.reply['status'] = 429
    try:
        await api.query()
    except PollError as e:
        assert e.cooldown >= 180 and e.status == 429
    else: raise AssertionError('rate limiting must trigger backoff')
    api.detach()

asyncio.run(run_api())
assert expected_list_url('https://www.house730.com/rent/s1u14/', '租')
assert expected_list_url('https://www.house730.com/buy/s1u14/?x=1', '售')
assert not expected_list_url('https://www.house730.com/rent/', '租')
assert not expected_list_url('https://www.house730.com/buy/s1u14/', '租')
with tempfile.TemporaryDirectory() as temp:
    db = Store(Path(temp) / 'test.db')
    u1 = 'https://www.house730.com/rent-property-9876543/demo/'
    u2 = 'https://www.house730.com/rent-property-9876544/demo/'
    assert db.claim('租', u1)
    assert len(db.pending_claims()) == 1
    db.finish('租', u1, 'saved')
    assert db.pending_claims() == []
    assert db.claim('租', u2)
    assert db.pending_claims()[0][2] == '9876544'
print('PASS: JSON error fallback classification, token-safe diagnostics, 429 backoff, valid owner filters, queued recovery')
