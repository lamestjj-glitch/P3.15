# -*- coding: utf-8 -*-
"""House730 API phone-first capture from the browser's genuine detail request.

The verified network endpoint is /Property/GetPropertyUserInfoById.
This module does NOT invent URL parameters, replay unknown signatures or click
phone-reveal buttons. It listens for the *site's own* response during normal
background detail navigation. If no full phone is available the caller may
use its existing DOM reveal fallback. Credentials/raw network responses are
not written to disk or diagnostic logs.
"""
from __future__ import annotations

import asyncio
import re
from urllib.parse import urlsplit

API_HOST = 'api.house730.com'
API_PATH = '/property/getpropertyuserinfobyid'


def is_phone_api(url):
    try:
        uri = urlsplit(str(url))
        return uri.hostname == API_HOST and uri.path.lower().rstrip('/') == API_PATH
    except Exception:
        return False


def phone_clean(value):
    # Require the *whole* phone field to be a number, not a substring from a
    # long token or an agency's description. Ignore HK fixed-line 2/3 prefix.
    if isinstance(value, bool) or value is None or isinstance(value, (dict, list)):
        return ''
    value = str(value).strip()
    if not re.fullmatch(r'(?:\+?852[\s.()-]*)?[0-9\s.()-]{8,22}', value):
        return ''
    digits = re.sub(r'\D', '', value)
    if digits.startswith('852') and len(digits) == 11:
        digits = digits[3:]
    if len(digits) == 8 and digits[0] in '456789':
        return digits
    return ''


def contacts_from_api(data):
    if not isinstance(data, dict):
        return []
    result = data.get('result')
    if isinstance(result, dict):
        if 'telphone' in result or 'customerTel' in result:
            result = [result]
        else:
            result = next((result[k] for k in ('contacts','list','items','data','results')
                           if isinstance(result.get(k), list)), [])
    if not isinstance(result, list):
        return []
    contacts = []
    seen = set()
    for contact in result[:40]:
        if not isinstance(contact, dict) or contact.get('isShowTel') is False:
            continue
        number = phone_clean(contact.get('telphone')) or phone_clean(contact.get('customerTel'))
        if not number or number in seen:
            continue
        seen.add(number)
        cn = str(contact.get('contactNameCN') or '').strip()
        en = str(contact.get('contactNameEN') or '').strip()
        name = ' '.join(dict.fromkeys(x for x in (cn,en) if x)) or '未提供'
        contacts.append((name[:80], number))
    return contacts


class DetailPhoneCapture:
    """Capture first eligible contact API response without polling/clicking.

    Install BEFORE page.goto(); stop listening promptly after the decision.
    """
    def __init__(self, page):
        self.page = page
        self.loop = asyncio.get_running_loop()
        self.future = self.loop.create_future()
        self.tasks = set()
        self.received = 0
        self.requested = 0
        self.blocked_http = None
        self._active = False

    def start(self):
        if not self._active:
            self._active = True
            self.page.on('request', self._on_request)
            self.page.on('response', self._on_response)
        return self

    def _on_request(self, request):
        if self._active and is_phone_api(request.url):
            self.requested += 1

    def _on_response(self, response):
        if not self._active or not is_phone_api(response.url):
            return
        self.received += 1
        task = self.loop.create_task(self._parse(response))
        self.tasks.add(task)
        task.add_done_callback(self.tasks.discard)

    async def _parse(self, response):
        try:
            if response.status in (401, 403, 429):
                self.blocked_http = response.status
                if not self.future.done():
                    self.future.set_result([])
                return
            if response.status != 200:
                return
            payload = await asyncio.wait_for(response.json(), timeout=4)
            contacts = contacts_from_api(payload)
            if contacts and not self.future.done():
                self.future.set_result(contacts)
        except (asyncio.TimeoutError, ValueError, TypeError, RuntimeError):
            pass
        except Exception:
            # Network interception is opportunistic. Fail closed to the existing
            # DOM reveal code; never mark the listing successful from a bad API.
            pass

    async def first(self, timeout=7.0):
        try:
            return await asyncio.wait_for(asyncio.shield(self.future), timeout)
        except asyncio.TimeoutError:
            return []

    async def close(self):
        self._active = False
        try:
            self.page.remove_listener('request', self._on_request)
            self.page.remove_listener('response', self._on_response)
        except Exception:
            pass
        for task in list(self.tasks):
            task.cancel()
        if self.tasks:
            await asyncio.gather(*self.tasks, return_exceptions=True)


async def fast_phone_first(capture):
    """Avoid 3.5s dead time when a listing did not request the contact API.

    An observed API request retains the original overall 3.5-second budget.
    The caller still checks 401/403/429 before any DOM fallback.
    """
    contacts = await capture.first(timeout=2.0)
    if not contacts and capture.requested and capture.blocked_http is None:
        contacts = await capture.first(timeout=1.5)
    return contacts
