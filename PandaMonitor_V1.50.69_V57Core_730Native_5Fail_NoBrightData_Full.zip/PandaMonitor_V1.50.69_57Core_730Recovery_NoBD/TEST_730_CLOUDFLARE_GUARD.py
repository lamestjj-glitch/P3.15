# -*- coding: utf-8 -*-
"""Offline test: pause both sources, do not reload verification, stable recovery."""
import asyncio
import threading
from house730_cf_guard import ChallengeGuard, is_challenge

class Clock:
    value=0.
    def __call__(self): return self.value
    def jump(self,n): self.value += n

class FakePage:
    def __init__(self,url,title='',body=''):
        self.url=url; self._title=title; self.body=body
        self.loads=0
    def is_closed(self): return False
    async def title(self): return self._title
    def locator(self,_): return self
    async def inner_text(self,timeout=0): return self.body
    async def goto(self,*args,**kw):
        self.loads+=1
        raise AssertionError('Cloudflare verification must not trigger reload')

async def run():
    c=Clock(); events=[]; logs=[]
    states={k:{'mode':'ready', 'last':'—'} for k in ('租','售')}
    guard=ChallengeGuard(states,lambda event,**kw:events.append((event,kw)),
        logs.append,threading.Event(),clock=c,initial_hold=30,stable_seconds=10,check_every=0)
    rent=FakePage('https://www.house730.com/rent/s1u14/','Just a moment...')
    buy=FakePage('https://www.house730.com/buy/s1u14/','','正常')
    guard.register('租',rent);guard.register('售',buy)
    assert await is_challenge(rent)
    assert not await is_challenge(buy)
    assert await is_challenge(FakePage('https://challenges.cloudflare.com/turnstile'))
    assert await is_challenge(FakePage('https://www.house730.com/rent/s1u14/', 'house730.com', '驗證您是人類'))
    guard.trip('租','Cloudflare 自動檢查')
    assert guard.active and all(v['mode']=='cloudflare-wait' for v in states.values())
    assert len([e for e in events if e[0]=='challenge'])==1
    guard.trip('售','相同驗證事件')
    assert len([e for e in events if e[0]=='challenge'])==1
    async def valid(page,deal):return 'just a moment' not in page._title.lower()
    await guard._observe(valid)
    c.jump(31)
    await guard._observe(valid)
    assert guard.active, 'Challenge must not clear from time alone'
    rent._title='House730 正常列表'
    await guard._observe(valid)
    assert guard.active, 'Single healthy glimpse must not release the guard'
    c.jump(9)
    await guard._observe(valid)
    assert guard.active
    c.jump(2)
    await guard._observe(valid)
    assert not guard.active and guard.slow_mode
    assert len([e for e in events if e[0]=='challenge_cleared'])==1
    assert guard.effective_interval(1,60)==60
    assert rent.loads==buy.loads==0, 'No page reload during challenge'
    guard.trip('售','又被要求驗證')
    assert guard.active and guard.incidents==2 and guard.hold_until==c()+60
    print('PASS: dual-source pause, recognition, no refresh, stable recovery, escalating cooldown')

asyncio.run(run())
