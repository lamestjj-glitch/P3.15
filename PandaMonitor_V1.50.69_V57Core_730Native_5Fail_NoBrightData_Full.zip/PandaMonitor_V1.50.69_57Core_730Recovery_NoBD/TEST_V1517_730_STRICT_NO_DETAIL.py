# -*- coding: utf-8 -*-
"""Offline guard: neither new listing nor test may automatically open 730 detail."""
import inspect
from house730_engine import Engine
from house730_direct_api import DirectPhoneLookup

src=inspect.getsource(Engine._run)
worker=src.split('            async def detail_worker(index):',1)[1].split('            async def supervise_list(deal):',1)[0]
test=src.split("                        elif cmd in ('test', 'test_wa')",1)[1].split("                    await asyncio.sleep(.25)",1)[0]
manual=src.split("                        elif cmd == 'open'",1)[1].split("                        elif cmd in ('test', 'test_wa')",1)[0]

for label,code in [('normal NEW worker',worker),('first-listing test',test)]:
    assert 'direct_api.query(' in code, label
    assert 'context.new_page(' not in code, label
    assert 'lane.acquire(' not in code, label
    assert 'lane.discard(' not in code, label
    assert 'DetailPhoneCapture(' not in code, label
    assert 'reveal_phone(' not in code, label
    assert 'page.goto(' not in code, label
    assert '[730-DIRECT-NO-DETAIL]' in code, label
assert 'context.new_page()' in manual, 'Explicit click on Open original must continue working'
assert '[730-STRICT-API]' in src
assert 'await q.put((deal,url,pid,tries))' in worker, 'No list tab must keep a pending claim'
assert "'api-no-phone'" in worker, 'No-public-phone must not loop without bound'
assert 'GetPropertyUserInfoById' in inspect.getsource(DirectPhoneLookup.query) or 'phone_url_for_id' in inspect.getsource(DirectPhoneLookup.query)
print('PASS V1.50.17: 730 NEW and test zero auto detail/new_page/reveal; queued reattach; explicit open preserved')
