# -*- coding: utf-8 -*-
"""Offline regression for 1.50.38. No live browsing, API, Signal, or WA sends."""
import asyncio
import threading
import time
from hse28_adaptive import AdaptiveListScheduler
from house730_adaptive_rate import SharedHouse730Rate
from panda28_api import capture_template, owner_lock, existing_list_url_kind
from panda28_core import App


def test_28_scheduler():
    scheduler = AdaptiveListScheduler()
    assert scheduler.report()['gap_ms'] == 0, scheduler.report()
    scheduler.set_user_floor(.25)
    assert scheduler.report()['gap_ms'] == 0
    for _ in range(100):
        scheduler.success()
    scheduler.slow_or_timeout('network')
    scheduler.rate_limited()
    assert scheduler.report()['gap_ms'] == 0, 'Old ramp or shared 1.5s floor is back'
    starts, holding, gate = [], set(), threading.Barrier(2)
    lock=threading.Lock()
    def lease(label):
        with scheduler.lease(label, lambda: True) as allowed:
            assert allowed
            with lock:
                assert label not in holding, 'Same-lane overlap'
                holding.add(label)
                starts.append(time.monotonic())
            gate.wait(timeout=1.5)  # Both lanes must overlap.
            time.sleep(.025)
            with lock: holding.remove(label)
    th=[threading.Thread(target=lease,args=(x,)) for x in ('rent','buy')]
    for t in th:t.start()
    for t in th:t.join(timeout=2)
    assert not any(t.is_alive() for t in th)
    assert len(starts)==2 and not holding
    assert abs(starts[1]-starts[0])<.5, 'Rent/buy did not run concurrently'
    assert 'random.uniform(.100, .300)' in __import__('inspect').getsource(App.worker)


class Clock:
    def __init__(self): self.now=1000.0
    def __call__(self): return self.now
    async def sleep(self,seconds):
        self.now += seconds
        await asyncio.sleep(0)


async def test_730_fixed():
    clock=Clock();stop=threading.Event();logs=[]
    setting=[.25]
    jig=iter((.1,.2,.3,.1,.2))
    rate=SharedHouse730Rate(lambda:setting[0],stop,logs.append,clock=clock,
                            sleeper=clock.sleep,jitter=lambda:next(jig))
    assert abs(rate.spacing-.25)<1e-9, rate.spacing
    starts=[]
    for i in range(4):
        async with rate.slot("租"):
            starts.append(clock())
            rate.success()
        if i==1:setting[0]=.5
    gaps=[round(starts[i+1]-starts[i],3) for i in range(3)]
    assert gaps==[.35,.7,.8], gaps
    assert not any('RATE-ADAPT' in x for x in logs)
    rate.limit(3600,deal="租")
    assert rate.in_cooldown("租") and not rate.in_cooldown("售")
    async with rate.slot("租"):
        assert not rate.in_cooldown('租'), '3s retry did not expire'
    assert not stop.is_set(), '429 permanently stopped the worker'


class FakeCDP:
    def __init__(self):
        self.event_handler=None
        self.calls=[]
        self.body='form_data=%7B%22landlordAgency%22%3A%22LANDLORD%22%2C%22sortBy%22%3A%22latest%22%7D'
        self.href='https://www.28hse.com/rent?landlordAgency=LANDLORD&sortBy=latest'
    def call(self,m,p=None,timeout=None):
        self.calls.append(m)
        if m=='Page.reload':
            self.event_handler({'method':'Network.requestWillBeSent', 'params':{
                'requestId':'REQ-1','request':{'url':'https://www.28hse.com/property/dosearch',
                'method':'POST', 'postData':'form_data=%7B%22landlordAgency%22%3A%22AGENT%22%7D'}}})
        if m=='Network.getRequestPostData':
            return {'postData':self.body}
        if m=='Runtime.evaluate':
            if (p or {}).get('expression')=='location.href':
                return {'result':{'value':self.href}}
            return {'result':{}}
        return {}
    def ev(self,*args,**kwargs):return False
    def pump_event(self,timeout=0.3):
        time.sleep(timeout)
        return False
    def close(self):pass

class FakeApp:
    def __init__(self):self.c=FakeCDP()
    def target(self,trade):return {'id':'already-open','url':self.c.href}
    def cdp(self,t):return self.c


def test_28_postdata_recovery():
    app=FakeApp()
    target,cdp,template = capture_template(app,'rent',lambda:True)
    assert owner_lock(template['body'])
    assert cdp.calls.count('Network.getRequestPostData')==1
    assert 'Page.reload' in cdp.calls
    assert 'Network.enable' in cdp.calls
    assert not any(x in cdp.calls for x in ('Target.createTarget','Page.navigate','Input.dispatchMouseEvent'))
    assert existing_list_url_kind(app.c.href,'rent')=='explicit'
    assert 'api_rate_limit_event.set(' not in __import__('inspect').getsource(App.worker)


if __name__=='__main__':
    test_28_scheduler()
    asyncio.run(test_730_fixed())
    test_28_postdata_recovery()
    print('PASS V1.50.38 fixed cadence+jitter, no ramp, per-lane single-flight, concurrent rent/buy, Retry-After, early POST recovery, owner lock')
