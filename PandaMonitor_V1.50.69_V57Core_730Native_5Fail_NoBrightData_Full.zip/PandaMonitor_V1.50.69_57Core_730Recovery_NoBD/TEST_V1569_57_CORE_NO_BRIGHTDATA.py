# -*- coding: utf-8 -*-
"""Offline source-only checks for reverted 57 scraping core and 730 recovery."""
from pathlib import Path
p = Path(__file__).parent
s = (p/'house730_engine.py').read_text(encoding='utf-8')
light = (p/'house730_light_api.py').read_text(encoding='utf-8')
proc = (p/'house730_process.py').read_text(encoding='utf-8')
root = (p/'panda28_core.py').read_text(encoding='utf-8')
gui = (p/'unified_gui.py').read_text(encoding='utf-8')
assert 'House730LightAPI(page,deal,prefer_native=bool(self.cfg.get(\'shared_28_active\',False)))' in s
assert '[730-NATIVE-API-OK]' in s
assert 'if transport_error_streak >= 5:' in s
assert 'startup_failure_streak[deal] >= 5' in s
assert 'tab_recovery.replace(' in s
assert '[730-STARTUP-RECOVER]' in s
assert 'brightdata' not in light.lower()
assert 'brightdata' not in proc.lower()
assert 'brightdata' not in root.lower()
assert 'brightdata' not in gui.lower()
assert not [x for x in p.iterdir() if x.is_file() and 'brightdata' in x.name.lower() and x != Path(__file__)]
assert 'signal_cli' not in gui.lower() and 'send_signal' not in gui.lower()  # historical removal log is harmless
print('PASS V1.50.69: original 57 list & direct phone paths, native 730, 5-fail recovery, zero paid-proxy integration')
