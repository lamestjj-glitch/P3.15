# -*- coding: utf-8 -*-
"""V1.50.7 regression: newer premium statistics and filtered owner details."""
import unittest
from site_plugins import businessforsale_sg as p
from site_engine import DEFAULT_BFS

URL = 'https://www.businessforsale.sg/businesses-for-sale/singapores-premium-sparkling-tea-brand-halal-champagne-alternative-28398'
C = dict(DEFAULT_BFS, _verified_listing_ids={'28398'})

VISIBLE = '''<html><body><h1>Premium Access</h1><section>
<p>Seller Contact And Listing Statistics</p><div>Secure access</div>
<div>Contact Person</div><div>Contact Number</div><div>Email Address</div>
<div>Priscilla</div><span>+65 9123 4567</span><div>seller@example.com</div>
<div>Total Enquiries 3</div><div>Date Published 13/10/2026</div>
</section><form><label>Mobile Number</label><input value="+65 8888 9999"/></form>
<footer>Hotline: +65 8111 1111</footer></body></html>'''
LOCKED = '''<html><body><h3>Premium Member Access</h3>
<h3>Seller Contact And Listing Statistics</h3>Secure access
Contact Person Premium Only Contact Number Premium Only Email Address Premium Only
Total Enquiries Premium Only
<form>Mobile Number <input value="+65 8888 9999"></form>
<footer>+65 8111 1111</footer></body></html>'''

class TestBFSV157(unittest.TestCase):
    def test_newer_statistics_layout_with_visible_seller_phone(self):
        self.assertEqual(p.extract_contacts(VISIBLE, URL, C),
                         [{'phone':'+6591234567','name':'Priscilla'}])
    def test_locked_newer_statistics_is_not_false_phone(self):
        self.assertEqual(p.extract_contacts(LOCKED, URL, C), [])
        self.assertIn('會員鎖定', p.contact_diagnostic(LOCKED))
    def test_verified_owner_source_2_allows_direct_detail_without_label(self):
        self.assertTrue(p.accept_detail(VISIBLE,URL,C))
        self.assertFalse(p.accept_detail(VISIBLE,URL,dict(DEFAULT_BFS)))
    def test_filtered_but_unverified_id_rejected(self):
        self.assertFalse(p.accept_detail(VISIBLE,URL,dict(DEFAULT_BFS,_verified_listing_ids={'42769'})))
    def test_non_owner_source_does_not_approve_id(self):
        self.assertFalse(p.accept_detail(VISIBLE,URL,dict(C,url='https://www.businessforsale.sg/businesses-for-sale?source=1&sort=2')))
    def test_premium_upsell_does_not_count_as_owner_badge(self):
        sample = '<p>Premium Member</p><p>Direct seller phone and email</p>'
        self.assertFalse(p.accept_detail(sample,URL,dict(DEFAULT_BFS)))
    def test_current_public_page_text_diagnoses_locked(self):
        sample = '<div>Premium Member Access</div><h3>Seller Contact And Listing Statistics</h3><div>Contact Person Premium Only</div><div>Contact Number Premium Only</div>'
        self.assertEqual(p.extract_contacts(sample, URL,C),[])
        self.assertIn('會員鎖定',p.contact_diagnostic(sample))

if __name__ == '__main__': unittest.main(verbosity=2)
