# -*- coding: utf-8 -*-
"""Offline connection/startup regressions; uses no BitBrowser/local network."""
from panda28_core import App
import panda28_core

class TestProfile:
    def __init__(self, pages):
        self.pages = pages
        self.calls = []
    def bit_call(self, path, body):
        assert path == '/browser/list'
        assert set(body) == {'page', 'pageSize'}
        self.calls.append(body)
        return {'data': {'list': self.pages[body['page']]}}
    _find_bit_profile = App._find_bit_profile

def main():
    # seq 173 not on first page; avoid selecting another browser.
    b = TestProfile([[{'seq': x, 'id': 'profile' + str(x)} for x in range(100)],
                     [{'seq': 173, 'id': 'correct'}]])
    assert b._find_bit_profile('173')['id'] == 'correct'
    assert len(b.calls) == 2
    b = TestProfile([[{'seq': 172, 'id': 'other'}]])
    try: b._find_bit_profile('173')
    except RuntimeError as exc:
        assert '找不到' in str(exc)
    else: raise AssertionError('wrong profile selected')
    assert all('seq' not in x for x in b.calls)
    # An explicit error result must not be treated as a valid empty listing.
    b = TestProfile([])
    b.bit_call = lambda path, body: {'success': False, 'code': 400}
    try: b._find_bit_profile('173')
    except RuntimeError as exc:
        assert '/browser/list' in str(exc)
    else: raise AssertionError('failed API response accepted')
    # Correct no-proxy local opener, never the system default opener.
    assert not any(isinstance(h, panda28_core.request.ProxyHandler)
                   for h in panda28_core._LOCAL_OPENER.handlers)
    print('PASS BitBrowser startup profile lookup / 2 pages / mismatch / rejected call / no proxy')

if __name__ == '__main__': main()
