# -*- coding: utf-8 -*-
"""Latest-first automatic phone clipboard with a safe busy-clipboard retry.

A new phone is copied synchronously as soon as it is detected.  A previous
phone never blocks it waiting for Ctrl+V.  Only the *latest* failed write is
retried, and user/manual clipboard changes cancel delayed writes.  All phone
history and deduplication belong to the monitoring engines, not this class.
"""
from __future__ import annotations

import threading
import time


class PasteClipboardQueue:
    """Compatible API for the old queue; now latest-wins, without paste gating."""

    def __init__(self, writer, get_sequence, log, *, clock=None, jitter=None):
        self.write = writer
        self.get_sequence = get_sequence
        self.log = log
        self.clock = clock or time.monotonic
        # Keep the old jitter argument for offline callers; never wait for paste.
        self.jitter = jitter
        self.lock = threading.RLock()
        self.active = None
        self.pending = ()   # Legacy introspection: no queued old phones.
        self.held = False
        self.paste_due = None
        self.paste_sequence = None
        self.retry_due = 0.0
        self.paused_external = False
        self._external_logged = False

    def _sequence(self):
        try:
            return int(self.get_sequence())
        except Exception:
            return 0

    @staticmethod
    def _unchanged(before, after):
        # A zero sequence means the API was unavailable: do not falsely detect
        # an external change, but never replay an already successful copy.
        return not (before and after and before != after)

    def _attempt_write(self, item):
        # Record the clipboard state before trying, so a delayed retry cannot
        # overwrite an unrelated manual copy made after the failed attempt.
        before = self._sequence()
        if not self.write(item['text']):
            item['ready'] = False
            item['sequence'] = before
            self.retry_due = self.clock() + .15
            return False
        item['ready'] = True
        item['sequence'] = self._sequence()
        self.retry_due = 0.0
        return True

    def submit(self, value, identity):
        """Copy NOW; returns 'copied' only on a successful clipboard write."""
        value = str(value or '').strip()
        if not value:
            return 'invalid'
        with self.lock:
            if self.active and self.active['key'] == identity:
                if self.active['text'] == value and self.active['ready']:
                    return 'copied'
            # Supersede old failures: only the latest new listing gets retries.
            self.active = {'key': identity, 'text': value,
                           'ready': False, 'sequence': 0}
            self.paused_external = False
            self._external_logged = False
            if self._attempt_write(self.active):
                return 'copied'
            self.log('[CLIPBOARD-BUSY] 最新尾號未寫入；只重試最新號碼，不等待 Ctrl+V')
            return 'queued'

    def extend(self, identity, new_text):
        """Merge extra tails only for the newest listing (never an older one)."""
        new_text = str(new_text or '').strip()
        if not new_text:
            return False
        with self.lock:
            item = self.active
            if not item or item['key'] != identity:
                return False
            if item['text'] == new_text:
                return True
            if item['ready']:
                if self.paused_external or not self._unchanged(
                        item['sequence'], self._sequence()):
                    return False
            item['text'] = new_text
            if not self._attempt_write(item):
                self.log('[CLIPBOARD-BUSY] 同帖附加尾號暫未寫入，稍後只重試最新組合')
            return True

    def manual_override(self):
        """Explicit GUI copy cancels any pending automatic retry."""
        with self.lock:
            self.active = None
            self.retry_due = 0.0
            self.paused_external = False
            self._external_logged = False

    def poll(self, ctrl=False, v=False):
        """Only retry temporarily unavailable clipboard; Ctrl+V is irrelevant."""
        with self.lock:
            item = self.active
            if item is None or self.paused_external:
                return
            if item['ready']:
                # Someone changed clipboard after our successful copy: stop
                # touching it until the next real NEW result arrives.
                if not self._unchanged(item['sequence'], self._sequence()):
                    self.paused_external = True
                return
            if not self._unchanged(item['sequence'], self._sequence()):
                self.paused_external = True
                if not self._external_logged:
                    self.log('[CLIPBOARD-HOLD] 剪貼簿已被其他程式更改，不重試舊號碼')
                    self._external_logged = True
                return
            if self.retry_due and self.clock() >= self.retry_due:
                if self._attempt_write(item):
                    self.log('[CLIPBOARD-RECOVER] 已補複製最新尾號：' +
                             item['text'].replace('\n', ' / '))

    def pending_count(self):
        with self.lock:
            return int(self.active is not None and not self.active['ready']
                       and not self.paused_external)
