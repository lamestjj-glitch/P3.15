# -*- coding: utf-8 -*-
"""Run offline. No BitBrowser, website, Signal message, or saved settings changed."""
import asyncio
import inspect
import time
import tkinter as tk
from background_renderer import keep_background_renderer_active
from performance import PRIORITIZED_WORKERS
from panda28_core import App
from house730_engine import Engine

class FakeSession:
    def __init__(self):
        self.commands = []
        self.detached = False
    async def send(self, command, args):
        self.commands.append((command, args))
    async def detach(self):
        self.detached = True

class FakeContext:
    def __init__(self): self.session = FakeSession(); self.count=0
    async def new_cdp_session(self, page):
        self.count+=1
        return self.session

class FakePage:
    def __init__(self, closed=False): self.context=FakeContext(); self.closed=closed
    def is_closed(self): return self.closed

async def check_focus():
    p=FakePage()
    assert await keep_background_renderer_active(p)
    assert p.context.count==1
    cmds=[x[0] for x in p.context.session.commands]
    assert cmds==['Emulation.setFocusEmulationEnabled','Page.setWebLifecycleState']
    assert p.context.session.detached
    assert not any('bringToFront' in x or 'navigate' in x for x in cmds)
    p2=FakePage(closed=True)
    assert not await keep_background_renderer_active(p2)
    assert p2.context.count==0
asyncio.run(check_focus())

assert PRIORITIZED_WORKERS == {'phone_worker'}, 'Listing threads should not starve browser CPU'
code=inspect.getsource(App.worker)
assert "time.monotonic() + 10.0" in code
assert "'Emulation.setFocusEmulationEnabled'" in code
assert "'Page.setWebLifecycleState'" in code
assert 'self.phone_jobs[k].put((u,detected_t0))' in code
code730=inspect.getsource(Engine._run)
assert 'await keep_background_renderer_active(page)' in code730
assert 'Page.bringToFront' not in inspect.getsource(keep_background_renderer_active)

# High volume log batching on real Tk widgets, entirely in-memory.
app=tk.Tk(); app.withdraw()
app.log=tk.Text(app)
app._log_buffer=None
# Exercise real App.write/_flush_log_buffer with a minimal duck-typed object
# (no App.__init__ => no BitBrowser or config use).
class Dummy:
    write=App.write
    _flush_log_buffer=App._flush_log_buffer
    def __init__(self, log): self.log=log; self.calls=[]
    def after(self, delay, callback): self.calls.append((delay,callback))
d=Dummy(app.log)
for i in range(3000):
    d.write('info %d' % i)
assert len(d.calls)==1, len(d.calls)
assert len(d._log_buffer)<=1800
# pending buffer is deliberately bounded to prevent unbounded RAM growth
d._flush_log_buffer()
assert int(app.log.index('end-1c').split('.')[0])<=1810
for i in range(300): d.write('later %d'%i)
assert len(d.calls)==2
# emulate next scheduled Tk frame
d._flush_log_buffer()
assert int(app.log.index('end-1c').split('.')[0])<=1600
app.destroy()
print('PASS V1.50.37: no-focus page lifecycle, no focus stealing, GUI log batch/bound, 28+730 phone priority, 10s CDP probes')
