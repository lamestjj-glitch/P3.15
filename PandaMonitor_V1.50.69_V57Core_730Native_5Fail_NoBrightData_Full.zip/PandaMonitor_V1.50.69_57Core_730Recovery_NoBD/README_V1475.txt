PandaMonitor V1.47.5 | 28Hse + House730 | UNIFIED SETTINGS, INDEPENDENT WA
==========================================================================
This is a complete SOURCE distribution for Windows 10 + Python 3.12/3.13.
No precompiled .exe is included. Compile via BUILD_EXE.cmd on Windows.

ONE settings tab, not two separate 28/730 settings tabs:
 - BitBrowser Local API / Token / environment sequence shared (default seq 173)
 - Site switches for 28Hse rent/buy and House730 rent/buy
 - Shared Windows notifications, listing/phone dedupe and combined result list
 - Separate WHATSAPP CONTROLS for 28Hse and House730:
   28Hse enable, schedule, message, reveal test, WhatsApp SEND test
   House730 enable, schedule, message, rent reveal test, buy reveal test,
   rent WhatsApp SEND test, buy WhatsApp SEND test
 - Each WhatsApp test requires explicit confirmation before real sending.
 - Automation starts OFF for House730 by default.
 - Changes to House730 WA never change 28Hse WA fields; the original
   28Hse V1.46.5 greeting behavior remains unchanged.

LAUNCH
1. Stop older PandaMonitor copies to avoid duplicated monitors.
2. Unzip into a NEW folder; don't run from inside the ZIP viewer.
3. Open BitBrowser and environment 173.
4. Double-click START.bat. It has an error log and should not silently close.
5. Open Unified Settings and save your preferred WA settings.
6. Select four site switches and press Start.
7. To build an EXE on Windows, run BUILD_EXE.cmd.

DATA:
 28Hse config, de-dupe etc stay in the original PandaMonitor_28Hse folder.
 House730 has its own pre-existing House730Standalone173 config/database.
 The shared BitBrowser credential inputs are saved for both engines.
 No old phone database is intentionally deleted or reset.

LIMITS:
 House730 API list parsing is not verified against your current live page;
 after a JSON list failure it may fall back to HTML (default 60 seconds).
 A 1-second setting is a target, not a promise that House730 accepts 120
 requests per minute. It will back off on throttling.
 Real BitBrowser 173 + WhatsApp Web integration must be tested on your PC.
 Offline tests alone do not confirm actual outgoing WhatsApp delivery.

OFFLINE CHECKS:
 python TEST_730_OFFLINE.py
 python TEST_730_RECOVERY.py
 python launch.py --self-test    (requires a desktop display)

ENTRYPOINT: START.bat, launch.py, unified_gui.py
