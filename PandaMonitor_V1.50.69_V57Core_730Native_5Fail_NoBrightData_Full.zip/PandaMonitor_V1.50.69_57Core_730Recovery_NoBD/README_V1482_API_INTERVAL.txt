PandaMonitor V1.48.2 - 28Hse API Poll Interval

1. In Unified Settings > Four-source monitoring/speed, set 28Hse Rent API and 28Hse Buy API separately to 1 or 0.5 seconds.
2. Selecting a rate saves it immediately in the existing config.json (api_rent_interval and api_buy_interval). Your selection survives app restarts.
3. A change while monitoring takes effect from the next successful polling cycle. No browser reload, mouse movement or keyboard input is performed.
4. Each lane is strictly single-flight: if a request takes 750ms, selecting 0.5s will not start a second request while the previous request is pending.
5. Cloudflare/403/429/invalid owner or sort condition still triggers pause. Timeout backoff remains in force, overriding the configured target where necessary.
6. The 730 rate selection, 730 Cloudflare protection, PhoneFirst, WA, deduplication, four-way GUI and popups are unchanged.
7. These are requested minimum target periods from request start, not guarantees of detecting a listing within that time. 0.5 seconds can increase the risk of site rate limits or Cloudflare blocking.

Run START.bat. New logs: [API-CADENCE] and API-ONLY ... 500ms/1000ms.
