PandaMonitor V1.50.35 | Based on V1.50.34 complete archive
==========================================================
This release DOES NOT remove House730's server-issued HTTP 429 rate limits.
It fixes an actual V1.50.34 recovery bug and makes 429 status visible.

1. HTTP 429 during list HTML reload or JSON-template re-learning is now
   registered in the shared rent/buy cooldown BEFORE releasing the list gate.
   Previously the re-learning exception was caught in a local retry handler,
   leaving the other lane free to issue further queries during the site limit.
2. Startup HTML reloads observe actual Retry-After headers when available.
3. Re-learning 429 no longer silently becomes a local 60/180-second wait only;
   both lanes wait for the shared rate budget, then resume conservatively.
4. The dashboard distinguishes genuine 429 cooldown, transport errors and
   other API backoff. It does not imply the website limit can be removed.
5. No bypass, no proxy/user-agent rotation, no CAPTCHA solving and no
   parallel retry path. Never turn 429 into success or discard it.
6. No user configuration files are read/written by the update package itself;
   Signal profile, group, original 852.jpg path, WhatsApp, BitBrowser browser
   ID, 28Hse and phone dedup code are carried forward byte-for-byte.

IMPORTANT: The log supplied on 2026-10-16 had a V1.50.33 startup marker,
not V1.50.34. For this patch you must close the old process, extract the
complete new ZIP to a NEW folder, run its START.bat, and verify that the
log includes '[MERGE] V1.50.35'.

Offline checks: python TEST_V1535_730_RELEARN_429.py
Windows/BitBrowser and actual site limits were not live-tested here.
