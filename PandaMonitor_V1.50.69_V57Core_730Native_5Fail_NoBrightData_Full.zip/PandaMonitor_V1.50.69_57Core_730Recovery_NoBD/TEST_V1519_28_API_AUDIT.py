"""Offline regression for separate 28Hse API tests, resource & retry cleanup."""
import threading
from unittest import mock
from types import SimpleNamespace
from panda28_core import App

class Dummy:
    def __init__(self):
        self.api_rate_limit_event=threading.Event()
        self.cdp_base='http://127.0.0.1:12345'
        self.running=True
        self.run_id=1
        self.api_source_enabled={'rent':True,'buy':True}
        self.lock=threading.Lock()
        self.http_latest={'rent':['https://www.28hse.com/rent/apartment/property-3414271',
                                  'https://www.28hse.com/rent/apartment/property-3125421'],
                          'buy':['https://www.28hse.com/buy/apartment/property-4054671']}
        self.messages=[];self.popups=[];self.closed=[];self.calls=[];self.bridge_count=0
    def _cdp_base_alive(self):return True
    def pid_of(self, u):return App.pid_of(self,u)
    def write(self,msg):self.messages.append(msg)
    def test_popup(self,*args):self.popups.append(args)
    def open_http_bridge(self,k):
        self.bridge_count+=1
        return ({'id':'test-target'},SimpleNamespace(dead=False,close=lambda:None))
    def close_target_id(self,tid):self.closed.append(tid)
    def http_phone_direct(self,c,k,url,test_mode=False,**kw):
        self.calls.append((k,self.pid_of(url),test_mode))
        if self.pid_of(url)=='3414271':return False,False,'no-full-phone'
        return True,True,'成功'

# Rent falls through only its own cached IDs; sale independent.
d=Dummy()
App.api_test_28(d,'rent')
assert d.calls==[('rent','3414271',True),('rent','3125421',True)],d.calls
assert d.popups[-1][1] is True
assert d.closed==['test-target']
d.calls.clear()
App.api_test_28(d,'buy')
assert d.calls==[('buy','4054671',True)],d.calls
assert d.bridge_count==2
assert d.closed==['test-target','test-target']

# With no cache yet, the test waits for the already-running detection lane.
# Do not issue a separate list request, and do not show a false error.
d=Dummy();d.http_latest['rent']=[]
original_write = d.write
def add_delayed_cache(msg):
    original_write(msg)
    if '[28-API-TEST-WAIT]' in msg:
        d.http_latest['rent']=['https://www.28hse.com/rent/apartment/property-3414271',
                               'https://www.28hse.com/rent/apartment/property-3125421']
d.write=add_delayed_cache
App.api_test_28(d,'rent')
assert d.calls==[('rent','3414271',True),('rent','3125421',True)]
assert d.bridge_count==1 and d.popups[-1][1] is True
assert any('[28-API-TEST-WAIT]' in msg for msg in d.messages)

# If monitoring stopped during initialization, don't wait 25 seconds.
d=Dummy();d.http_latest['rent']=[]
def stop_during_wait(msg):
    d.messages.append(msg)
    if '[28-API-TEST-WAIT]' in msg:d.running=False
d.write=stop_during_wait
App.api_test_28(d,'rent')
assert not d.calls and not d.bridge_count
assert d.popups[-1][1] is False and '取消' in d.popups[-1][2]

# A blocked response halts the probe immediately rather than trying others.
d=Dummy()
def blocked(c,k,url,**kw):
    d.calls.append((k,d.pid_of(url)))
    return True,False,'HTTP 429 限流'
d.http_phone_direct=blocked
App.api_test_28(d,'rent')
assert len(d.calls)==1
assert d.closed==['test-target']

# Temporary bridge must be closed on CDP connect failure (previous target leak).
e=Dummy()
e.http_target_ids=set()
e.create_background_target=lambda anchor:{'id':'leaky-target'}
e.cdp=lambda target: (_ for _ in ()).throw(ConnectionError('socket retired'))
e.close_target_id=lambda tid:e.closed.append(tid)
with mock.patch.object(__import__('panda28_core').time,'sleep',lambda _:None):
    try: App.open_http_bridge(e,'rent')
    except ConnectionError:pass
    else:raise AssertionError('Expected a CDP connection failure')
assert e.closed==['leaky-target']

# A cancelled delayed HTTP retry must clear inflight rather than blocking it.
e=Dummy()
e.http_retry_attempts={'rent':{},'buy':{}}
e.inflight={'rent':{'3414271'},'buy':set()}
e.running=True;e.run_id=17;e.cdp_fault_event=threading.Event();e.cdp_fault_event.set()
e.bg=lambda callback,*a:callback(*a)
e.set_listing_status=lambda *a:None
with mock.patch.object(__import__('panda28_core').time,'sleep',lambda _:None):
    App.no_detail_phone_fallback(e,'rent','https://www.28hse.com/rent/apartment/property-3414271',None,'timeout',17)
assert not e.inflight['rent'],e.inflight
print('PASS V1.50.19: independent rent/buy direct API tests; strict zero detail; 429 early stop; bridge cleanup; cancelled retry cleanup')
