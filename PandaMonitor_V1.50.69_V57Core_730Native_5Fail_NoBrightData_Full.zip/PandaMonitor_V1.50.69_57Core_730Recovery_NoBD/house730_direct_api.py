# -*- coding: utf-8 -*-
"""House730 direct contact lookup without navigating to a property detail.

Evidence: GetPropertyUserInfoById uses public `propertyId` and returned a
full HK number before a reveal click (user's captured diagnostics).

Requests originate from an already-open filtered House730 list tab and use the
site's current browser session. A genuine contact-request template, if seen,
may be held in RAM and used for future property IDs. Nothing sensitive is
stored in a config, log or URL printed to the UI. 403/429 are never bypassed.
This is an opportunistic, bounded optimization: the existing detail path is
still required until the direct path has been validated in the user's browser.
"""
from __future__ import annotations

import asyncio
import re
from dataclasses import dataclass
from urllib.parse import urlsplit, parse_qsl, urlencode, urlunsplit

from house730_phone_first import API_HOST, API_PATH, is_phone_api, contacts_from_api

API_URL = 'https://api.house730.com/Property/GetPropertyUserInfoById'
# App headers observed on ordinary list requests, which may have different
# signing semantics from a contact request. Do not copy a list POST signature
# or reuse ephemeral list timestamps for this GET.
STABLE_APP_HEADERS = frozenset({
    'accept', 'authorization', 'language', 'lang', 'platform', 'cityen',
    'appkey', 'app-key', 'appversion', 'version', 'channel', 'region', 'locale'
})
# A genuine contact request may carry additional application headers. They
# are only kept in RAM and never added to logs, reports or files.
CONTACT_APP_HEADERS = frozenset({
    *STABLE_APP_HEADERS, 'appsignature', 'app-signature',
    'timestamp', 'apptimestamp', 'clientid', 'apikey'
})


def safe_id(value):
    value = str(value or '')
    return value if re.fullmatch(r'\d{1,15}', value) else None


def phone_url_for_id(pid, template=None):
    pid = safe_id(pid)
    if not pid:
        raise ValueError('Bad property ID')
    if not template:
        return API_URL + '?' + urlencode({'propertyId':pid})
    u = urlsplit(template['url'])
    if u.hostname != API_HOST or u.path.lower().rstrip('/') != API_PATH:
        raise ValueError('Invalid phone API template')
    items = parse_qsl(u.query, keep_blank_values=True)
    if not any(k.lower() == 'propertyid' for k, _ in items):
        raise ValueError('Phone request lacks propertyId')
    # Preserve the browser's authentic parameter names and current template.
    # The only thing changed is the verified public listing ID.
    params = [(k, pid if k.lower() == 'propertyid' else v) for k,v in items]
    return urlunsplit(('https', API_HOST, u.path, urlencode(params), ''))


def mismatched_property(payload, pid):
    """Reject explicit property identity contradictions in a response."""
    if not isinstance(payload, dict):
        return False
    parent = payload.get('result')
    checks = [payload]
    if isinstance(parent, dict): checks.append(parent)
    for d in checks:
        for key in ('propertyId', 'PropertyId', 'propertyID', 'listingId', 'ListingId'):
            if key in d and str(d[key] or '') not in ('', str(pid)):
                return True
    return False



def observed_public_params(list_api):
    """Only optional public language/platform/city values observed in site's
    genuine LIST request; NEVER copy signing/token/query secrets into a URL.
    """
    if not getattr(list_api, 'ready', False):
        return {}
    template = getattr(list_api, 'template', {}) or {}
    accepted = ('language', 'platform', 'cityen')
    found = {}
    # Accept genuine query parameters first, then genuine app headers.
    try:
        pairs = parse_qsl(urlsplit(template.get('url') or '').query, keep_blank_values=True)
    except Exception:
        pairs = []
    pairs.extend((str(k), str(v)) for k,v in (template.get('headers') or {}).items())
    for k,v in pairs:
        key=k.lower()
        if key in accepted and key not in found and 0 < len(v) <= 48 and re.fullmatch(r'[A-Za-z0-9_.-]+',v):
            found[key] = v
    return found


def response_diagnostic(payload):
    """Return reason tags ONLY, never a number, name, message or API token."""
    if not isinstance(payload, dict):
        return 'invalid-root'
    result = payload.get('result')
    if isinstance(result, dict) and ('telphone' in result or 'customerTel' in result):
        result = [result]
    elif isinstance(result, dict):
        result = next((result[x] for x in ('contacts','list','items','data','results')
                       if isinstance(result.get(x), list)), None)
    if not isinstance(result,list):
        return 'missing-result-list'
    if not result:
        return 'empty-contact-list'
    entries = [r for r in result[:40] if isinstance(r,dict)]
    if not entries:
        return 'invalid-contact-items'
    if all(r.get('isShowTel') is False for r in entries):
        return 'phone-not-displayed-by-site'
    phone_fields = [str(r.get(key) or '').strip() for r in entries
                    if r.get('isShowTel') is not False for key in ('telphone','customerTel')]
    phone_fields = [x for x in phone_fields if x]
    if not phone_fields:
        return 'empty-phone-fields'
    if any('*' in x or 'x' in x.lower() for x in phone_fields):
        return 'masked-phone'
    # Entire fields only; do not log or extract substrings from private descriptions.
    if any(re.fullmatch(r'(?:\+?852[\s.()-]*)?[0-9\s.()-]{8,22}',x)
           for x in phone_fields):
        return 'no-eligible-mobile'
    return 'unrecognized-phone-format'


@dataclass
class DirectResult:
    contacts: list
    status: int = 0
    reason: str = ''
    used_template: bool = False
    diagnostic: str = ''   # non-sensitive result classification only
    attempts: int = 1


class DirectPhoneLookup:
    """Captures real contact request templates from this BitBrowser context."""

    def __init__(self, context):
        self.context = context
        self.template = None
        self._closed = False
        self._direct_request_active = 0
        # One direct GET does not have to wait behind continuous list POSTs.
        # Limit concurrent contact calls independently, without new browser tabs.
        self._phone_gate = asyncio.Semaphore(2)
        context.on('request', self._on_request)

    def _on_request(self, req):
        if self._closed or self._direct_request_active:
            return
        try:
            if req.method.upper() != 'GET' or not is_phone_api(req.url):
                return
            pairs = parse_qsl(urlsplit(req.url).query, keep_blank_values=True)
            if not any(k.lower() == 'propertyid' and safe_id(v) for k,v in pairs):
                return
            headers = {k:v for k,v in req.headers.items()
                       if k.lower() in CONTACT_APP_HEADERS or k.lower().startswith('x-')}
            self.template = {'url':req.url, 'headers':headers}
        except Exception:
            pass

    async def query(self, page, pid, list_api=None, *, timeout_ms=3200):
        """Priority GET from the already-open filtered list page; zero detail tabs.

        The phone GET must not wait for the list POST lock: the previous 0.8s
        lock deadline was incorrectly producing 'list-busy' failures when list
        polling was active. A separate phone-only semaphore limits bursts.
        """
        if self._closed or not safe_id(pid) or page is None or page.is_closed():
            return DirectResult([], reason='no-list-tab')
        t = self.template
        try:
            url = phone_url_for_id(pid, t)
        except ValueError:
            t = None
            url = phone_url_for_id(pid)
        headers = (t or {}).get('headers', {})
        if not t and list_api is not None and getattr(list_api, 'ready', False):
            headers = {k:v for k,v in (list_api.template.get('headers') or {}).items()
                       if k.lower() in STABLE_APP_HEADERS}
        urls = [url]
        # Genuine list traffic occasionally has public query fields also used by
        # contact requests. Try them only if the first GET has no usable phone.
        # Never invent language/platform values and never reuse signing fields.
        if not t:
            public = observed_public_params(list_api)
            if public:
                parsed = urlsplit(url)
                aux = urlunsplit((parsed.scheme, parsed.netloc, parsed.path,
                                  urlencode([('propertyId',str(pid)),*public.items()]), ''))
                if aux != url:
                    urls.append(aux)
        async with self._phone_gate:
            for i, request_url in enumerate(urls):
                self._direct_request_active += 1
                try:
                    res = await page.evaluate('''async p => {
                        const c = new AbortController();
                        const timer = setTimeout(() => c.abort(), p.timeout_ms);
                        try {
                            const r = await fetch(p.url, {method:'GET', headers:p.headers,
                                credentials:'include', mode:'cors', cache:'no-store', signal:c.signal});
                            const contentType = r.headers.get('content-type') || '';
                            const finalURL = new URL(r.url);
                            if (finalURL.hostname !== 'api.house730.com')
                                return {status:r.status,reason:'redirect'};
                            if (r.status !== 200) return {status:r.status,reason:'http'};
                            if (!contentType.toLowerCase().includes('json'))
                                return {status:r.status,reason:'non-json'};
                            const text = await r.text();
                            if (text.length > 200000) return {status:r.status,reason:'oversize'};
                            try {return {status:r.status,payload:JSON.parse(text)}}
                            catch (_) {return {status:r.status,reason:'invalid-json'}}
                        } finally {clearTimeout(timer)}
                    }''', {'url':request_url,'headers':headers,'timeout_ms':timeout_ms})
                except Exception as e:
                    return DirectResult([], reason='network-'+type(e).__name__,
                                        used_template=bool(t), attempts=i+1)
                finally:
                    self._direct_request_active -= 1
                if not isinstance(res, dict):
                    return DirectResult([], reason='invalid-response', used_template=bool(t), attempts=i+1)
                status = int(res.get('status') or 0)
                if status != 200 or 'payload' not in res:
                    # Never retry a restricted/rejected result with other parameters.
                    return DirectResult([], status=status, reason=res.get('reason','no-payload'),
                                        used_template=bool(t), attempts=i+1)
                data = res['payload']
                if mismatched_property(data,pid):
                    return DirectResult([], status=status, reason='property-mismatch',
                                        used_template=bool(t), attempts=i+1)
                contacts = contacts_from_api(data)
                diag = 'full-mobile' if contacts else response_diagnostic(data)
                if contacts:
                    return DirectResult(contacts, status=status, reason='success',
                                        used_template=bool(t), diagnostic=diag, attempts=i+1)
                # Retrying with authentic optional parameters is useful if the
                # root is empty / malformed, but not if the site explicitly says
                # no public/eligible phone. This prevents needless API volume.
                if i + 1 >= len(urls) or diag not in ('missing-result-list','empty-contact-list','empty-phone-fields'):
                    return DirectResult([], status=status, reason='no-full-phone',
                                        used_template=bool(t), diagnostic=diag, attempts=i+1)
            return DirectResult([], status=200, reason='no-full-phone', used_template=bool(t))

    def close(self):
        self._closed = True
        try: self.context.remove_listener('request',self._on_request)
        except Exception: pass
        self.template = None
