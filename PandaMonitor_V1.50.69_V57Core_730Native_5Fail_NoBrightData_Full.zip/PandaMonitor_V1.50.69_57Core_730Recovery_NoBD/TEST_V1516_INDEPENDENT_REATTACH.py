# -*- coding: utf-8 -*-
"""V1.50.16: offline attach-only, no hidden list throttle, guard reattachment."""
import asyncio
import inspect
import threading
from panda28_core import App
from panda28_api import capture_template, ApiError
from house730_engine import Engine
from house730_cf_guard import ChallengeGuard
from site_engine import BitBrowserFetcher

class ListTabs:
    target = App.target
    _list_tab_alive = App._list_tab_alive
    def __init__(self): self.items=[]
    def targets(self): return self.items

p = ListTabs()
assert p.target('rent') is None
p.items = [dict(id='A', url='https://www.28hse.com/rent?landlordAgency=LANDLORD&sortBy=latest')]
assert p.target('rent')['id'] == 'A'
assert p.target('buy') is None
assert p._list_tab_alive('rent','A')
p.items = []
assert not p._list_tab_alive('rent','A')
p.items = [dict(id='B', url='https://www.28hse.com/rent?landlordAgency=LANDLORD&sortBy=latest')]
assert p.target('rent')['id'] == 'B'
assert not p._list_tab_alive('rent','A')
# A wrong filter may never be accepted as a monitoring source.
p.items = [dict(id='BAD',url='https://www.28hse.com/rent?landlordAgency=AGENT&sortBy=latest')]
assert p.target('rent') is None

api_source=inspect.getsource(capture_template)
assert 'create_background_target(' not in api_source
assert 'app.close_target_id(' not in api_source
assert 'app.target(trade)' in api_source
worker=inspect.getsource(App.worker)
assert 'origin_query_gate' not in worker
assert 'self.api_poll_interval(k)' in worker
assert '[28-TAB-WAIT]' in worker and '[28-RECONNECTED]' in worker
assert "last_browser_info.get('id') != tid" in worker and 'next_tab_healthcheck' in worker
assert 'self.close_target_id(tid)' not in worker

# House730: the LIST task never creates a tab. Details/manual user actions
# remain independent and are outside this scope.
house=inspect.getsource(Engine._run)
list_code=house.split('            async def list_loop(deal):',1)[1].split('            async def detail_worker',1)[0]
assert 'context.new_page()' not in list_code
assert 'lock_safe_list_reload(page, deal' in list_code
assert '[730-TAB-WAIT]' in list_code and '[730-TAB-REATTACH]' in list_code
assert 'async def supervise_list(deal)' in house

class Browser:
    def is_connected(self): return True
class Page:
    def __init__(self,closed):
        self.closed=closed
        self.url='https://www.house730.com/rent/s1u14/'
    def is_closed(self): return self.closed
    async def title(self): return 'House730'
    def locator(self,x): return self
    async def inner_text(self,timeout=None): return 'owner listing'

old=Page(True); new=Page(False)
states={'租':{'mode':'waiting'}}
guard=ChallengeGuard(states, lambda *a,**k:None, lambda *a:None, threading.Event())
guard.register('租',old)
guard.existing_page_finder = lambda deal: new
assert asyncio.run(guard._healthy_pages(lambda page,deal: asyncio.sleep(0,result=True)))
assert guard.pages['租'] is new

f=BitBrowserFetcher.__new__(BitBrowserFetcher)
f.browser=Browser()
f._open_list_page=lambda url: None
f._read_list_without_new_tab=lambda url: None
f._open_list_snapshot=lambda url: None
try:
    f.fetch('https://www.businessforsale.sg/')
except RuntimeError as e:
    assert '[SITE-TAB-WAIT]' in str(e)
else:
    raise AssertionError('Missing BitBrowser list must not be opened')
f._open_list_page=lambda url: object()
f._read_list_without_new_tab=lambda url: '<html>fresh</html>'
assert f.fetch('https://www.businessforsale.sg/')=='<html>fresh</html>'

print('PASS V1.50.16: rent/buy independent cadence, 28 attach-only/no-close, 730 no new list, manual reattach, CF guard, plugins')
