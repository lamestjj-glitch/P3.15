# -*- coding: utf-8 -*-
"""Offline House730 millisecond-cadence tests; no BitBrowser/API calls."""
import json
import tempfile
from pathlib import Path
import house730_engine as engine
from house730_cadence import parse_house730_cadence, display_house730_cadence, valid_edit

for raw, expected in [('0.001',.001), ('0.05',.05), ('0.125',.125),
                      ('0.500',.5), ('1',1), ('1.250',1.25), ('30',30),
                      ('300.000',300),('.5',.5)]:
    assert parse_house730_cadence(raw) == expected, raw
    assert parse_house730_cadence(display_house730_cadence(raw)) == expected

for bad in ['', '0', '0.000', '0.0001', '1.1234', '300.001', '500',
            'nan', 'inf', '1e-3', '-1', 'abc', '1,5', '0.0010', True]:
    try: parse_house730_cadence(bad)
    except ValueError: pass
    else: raise AssertionError('should reject '+repr(bad))

assert all(valid_edit(s) for s in ('', '0', '0.', '0.125', '1', '.5'))
assert all(not valid_edit(s) for s in ('1.2345', '-0.5', '1e-3', 'abc'))

with tempfile.TemporaryDirectory() as d:
    original=engine.CFG_PATH
    try:
        engine.CFG_PATH=Path(d)/'house730_config.json'
        cfg=engine.read_config()
        cfg['poll_seconds']=.125
        engine.save_config(cfg)
        assert json.loads(engine.CFG_PATH.read_text())['poll_seconds']==.125
        assert engine.read_config()['poll_seconds']==.125, 'read_config clamped to 1.0'
        cfg['poll_seconds']=.001
        engine.save_config(cfg)
        assert engine.read_config()['poll_seconds']==.001
        cfg['poll_seconds']='99999'
        engine.save_config(cfg)
        assert engine.read_config()['poll_seconds']==1.0, 'corrupt config not safely defaulted'
    finally: engine.CFG_PATH=original

# Regression guard: real scheduler must not impose a fixed 50ms floor on a valid
# fractional interval. Protection mode still has explicit >=60s floor.
code=Path(engine.__file__).read_text(encoding='utf-8')
assert 'await self._pause(max(0.0,required-elapsed))' in code
assert "max(float(self.cfg['poll_seconds'])," in code

# Ensure GUI saves a floating-point value, not max(1, int(...)).
from unified_gui import UnifiedApp
class Var:
    def __init__(self,v):self.v=v
    def get(self):return self.v
    def set(self,v):self.v=v
class Stub:
    house_interval=Var('0.125')
    house_cfg={'poll_seconds':1.0}
    house_engine=None
    def _house_alive(self):return False
st=Stub()
import unified_gui
original_save=unified_gui.save_config
try:
    saved=[]
    unified_gui.save_config=lambda cfg:saved.append(dict(cfg))
    assert UnifiedApp.update_house_interval(st)
    assert saved[-1]['poll_seconds']==0.125
    assert st.house_interval.get()=='0.125'
finally: unified_gui.save_config=original_save
print('PASS V1.50.12: decimals, validation, config persistence, runtime scheduler and GUI commit')
