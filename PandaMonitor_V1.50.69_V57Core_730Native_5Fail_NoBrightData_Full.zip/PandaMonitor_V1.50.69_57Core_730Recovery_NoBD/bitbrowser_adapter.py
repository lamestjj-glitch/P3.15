import asyncio
import json
import urllib.error
import urllib.request
import os
import threading
import time
from pathlib import Path
from typing import Any, Dict, Optional


def _resolve_api_token(cfg: Optional[Dict[str, Any]] = None) -> str:
    cfg = cfg or {}
    token = str(cfg.get('bitbrowser_api_token') or '').strip()
    if token:
        return token
    token = str(os.environ.get('BITBROWSER_API_TOKEN') or '').strip()
    if token:
        return token
    token_file = str(cfg.get('bitbrowser_api_token_file') or 'bitbrowser_api_token.txt').strip()
    path = Path(token_file)
    if not path.is_absolute():
        path = Path(__file__).resolve().parent / path
    try:
        return path.read_text(encoding='utf-8').strip()
    except Exception:
        return ''


def _post(base_url: str, path: str, payload: Optional[dict] = None,
          timeout: float = 15.0, token: str = '') -> dict:
    """POST JSON to the BitBrowser Local API without using any system proxy.

    Localhost API calls must never be sent through HTTP_PROXY/HTTPS_PROXY or a Windows
    proxy. Some proxy software returns an unrelated HTTP 400, which looks like an API error.
    """
    url = base_url.rstrip('/') + path
    body = json.dumps(payload or {}, ensure_ascii=False, separators=(',', ':')).encode('utf-8')
    headers = {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'User-Agent': 'House730Standalone/BitBrowser',
    }
    if token:
        # Use the spelling shown by current BitBrowser Local API documentation/UI.
        headers['x-api-key'] = token

    req = urllib.request.Request(url, data=body, headers=headers, method='POST')
    # Explicit empty ProxyHandler: bypass env/system proxy for 127.0.0.1.
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    try:
        with opener.open(req, timeout=timeout) as resp:
            raw = resp.read().decode('utf-8', errors='replace')
    except urllib.error.HTTPError as e:
        raw = e.read().decode('utf-8', errors='replace') if e.fp else str(e)
        raise RuntimeError(
            f'BitBrowser API {path} HTTP {e.code}: {raw[:500]} '
            f'[api={base_url}; token_len={len(token)}; body={payload or {}}]'
        ) from e
    except Exception as e:
        raise RuntimeError(f'無法連接 BitBrowser 本地 API {url}: {e}') from e

    try:
        result = json.loads(raw) if raw else {}
    except Exception as e:
        raise RuntimeError(f'BitBrowser API {path} 回傳不是 JSON: {raw[:500]}') from e
    return result


async def _apost(base_url: str, path: str, payload: Optional[dict] = None,
                 timeout: float = 15.0, token: str = '') -> dict:
    return await asyncio.to_thread(_post, base_url, path, payload, timeout, token)


def _ok(resp: dict) -> bool:
    if not isinstance(resp, dict) or not resp:
        return False
    if resp.get('success') is False:
        return False
    # A few versions use code/statusCode rather than success.
    if 'code' in resp:
        try:
            return int(resp.get('code')) == 0
        except Exception:
            pass
    if 'statusCode' in resp:
        try:
            if int(resp.get('statusCode')) >= 400:
                return False
        except Exception:
            pass
    return True


def _data(resp: dict) -> Any:
    return resp.get('data') if isinstance(resp, dict) else None


def _extract_profiles(resp: dict) -> list:
    data = _data(resp)
    if isinstance(data, dict):
        for key in ('list', 'rows', 'items'):
            if isinstance(data.get(key), list):
                return data[key]
    if isinstance(data, list):
        return data
    return []


def _exact_seq(profile: dict, seq: int) -> bool:
    try:
        return int(profile.get('seq')) == int(seq)
    except Exception:
        return False


def _extract_endpoint(open_resp: dict) -> Optional[str]:
    data = _data(open_resp)
    if not isinstance(data, dict):
        return None
    # Prefer websocket address for Playwright CDP; fall back to HTTP debugger endpoint.
    for key in ('ws', 'webdriver', 'http'):
        value = data.get(key)
        if not isinstance(value, str) or not value.strip():
            continue
        endpoint = value.strip()
        if endpoint.startswith(('ws://', 'wss://', 'http://', 'https://')):
            return endpoint
        if key == 'http' and ':' in endpoint:
            return 'http://' + endpoint
        return endpoint
    return None


def _extract_port_from_ports(resp: dict, browser_id: str) -> Optional[int]:
    data = _data(resp)

    def parse_obj(obj: dict) -> Optional[int]:
        oid = str(obj.get('id') or obj.get('browserId') or obj.get('browser_id') or '')
        if oid and oid != str(browser_id):
            return None
        for k in ('port', 'debugPort', 'remoteDebuggingPort', 'remoteDebuggingPortNumber'):
            try:
                v = int(obj.get(k))
                if 1 <= v <= 65535:
                    return v
            except Exception:
                pass
        return None

    if isinstance(data, list):
        for item in data:
            if isinstance(item, dict):
                p = parse_obj(item)
                if p:
                    return p
    elif isinstance(data, dict):
        for k, v in data.items():
            if str(k) == str(browser_id):
                try:
                    p = int(v)
                    if 1 <= p <= 65535:
                        return p
                except Exception:
                    if isinstance(v, dict):
                        p = parse_obj(v)
                        if p:
                            return p
        for key in ('list', 'rows', 'items', 'ports'):
            arr = data.get(key)
            if isinstance(arr, list):
                for item in arr:
                    if isinstance(item, dict):
                        p = parse_obj(item)
                        if p:
                            return p
    return None


def _normalize_endpoint(value: Any) -> Optional[str]:
    if not isinstance(value, str):
        return None
    value = value.strip()
    if not value:
        return None
    if value.startswith(('ws://', 'wss://', 'http://', 'https://')):
        return value
    # debuggerAddress is often returned as 127.0.0.1:PORT
    if ':' in value and '/' not in value:
        host, _, port = value.rpartition(':')
        try:
            n = int(port)
            if host and 1 <= n <= 65535:
                return 'http://' + value
        except Exception:
            pass
    return None


def _extract_endpoint_candidates(resp: dict, browser_id: str = '') -> list:
    """Extract every plausible CDP endpoint from BitBrowser response variants.

    BitBrowser client versions have returned ws/http/debuggerAddress at different
    nesting levels.  Collect them all instead of assuming one exact schema.
    """
    out = []
    seen = set()
    endpoint_keys = {
        'ws', 'websocket', 'websocketurl', 'websocketdebuggerurl', 'wsendpoint',
        'http', 'webdriver', 'debuggeraddress', 'debugger_address', 'cdp', 'cdpurl'
    }
    port_keys = {'port', 'debugport', 'remotedebuggingport', 'remotedebuggingportnumber'}

    def add_endpoint(v):
        ep = _normalize_endpoint(v)
        if ep and ep not in seen:
            seen.add(ep); out.append(ep)

    def walk(obj, under_target=False):
        if isinstance(obj, dict):
            oid = str(obj.get('id') or obj.get('browserId') or obj.get('browser_id') or '')
            target_here = under_target or (browser_id and oid == str(browser_id))
            for k, v in obj.items():
                lk = str(k).replace('-', '').replace('_', '').lower()
                child_target = target_here or (browser_id and str(k) == str(browser_id))
                if lk in endpoint_keys:
                    add_endpoint(v)
                elif lk in port_keys and (target_here or not oid):
                    try:
                        n = int(v)
                        if 1 <= n <= 65535:
                            add_endpoint(f'http://127.0.0.1:{n}')
                    except Exception:
                        pass
                walk(v, child_target)
        elif isinstance(obj, list):
            for x in obj:
                walk(x, under_target)
        elif under_target and isinstance(obj, str):
            add_endpoint(obj)

    walk(resp)
    return out


async def _query_port_endpoints(base_url: str, token: str, browser_id: str) -> list:
    out = []
    seen = set()
    for payload in ({'ids': [browser_id]}, {'id': browser_id}, {}):
        try:
            resp = await _apost(base_url, '/browser/ports', payload, timeout=8, token=token)
            if not _ok(resp):
                continue
            candidates = _extract_endpoint_candidates(resp, browser_id)
            # Keep compatibility with older simple port response shapes.
            port = _extract_port_from_ports(resp, browser_id)
            if port:
                candidates.append(f'http://127.0.0.1:{port}')
            for ep in candidates:
                if ep and ep not in seen:
                    seen.add(ep); out.append(ep)
        except Exception:
            pass
    return out


async def _try_connect_cdp(playwright, endpoints: list, timeout_ms: int = 9000):
    errors = []
    for endpoint in endpoints:
        if not endpoint:
            continue
        try:
            browser = await playwright.chromium.connect_over_cdp(endpoint, timeout=timeout_ms)
            # A just-started profile can expose CDP a moment before BrowserContext.
            for _ in range(15):
                contexts = browser.contexts
                if contexts:
                    return browser, contexts[0], endpoint, errors
                await asyncio.sleep(0.10)
            errors.append(f'{endpoint}: connected but no BrowserContext')
        except Exception as e:
            errors.append(f'{endpoint}: {e}')
    return None, None, None, errors


async def _find_profile_by_seq(base_url: str, token: str, seq: int) -> dict:
    """List profiles with the minimal documented body, then match seq locally.

    We intentionally do not pass seq to /browser/list because some client/API builds return
    HTTP 400 for optional filtering fields even though the basic list endpoint works.
    """
    # Start with the strict documented max. If a client build dislikes 100, retry 50/10.
    last_error = None
    first_resp = None
    for page_size in (100, 50, 10):
        try:
            first_resp = await _apost(
                base_url, '/browser/list',
                {'page': 0, 'pageSize': page_size},
                timeout=15, token=token,
            )
            if _ok(first_resp):
                break
            last_error = RuntimeError(str(first_resp))
        except Exception as e:
            last_error = e
            first_resp = None
    if not first_resp or not _ok(first_resp):
        raise RuntimeError(
            'BitBrowser /browser/list 連最小參數 {page,pageSize} 都失敗。'
            f' API={base_url}；Token 長度={len(token)}。最後錯誤: {last_error}. '
            '請核對 BitBrowser「系統設定 → Local API」顯示的 URL/Port，'
            '以及 bitbrowser_api_token.txt 是否為目前的 Token。'
        )

    profiles = _extract_profiles(first_resp)
    for item in profiles:
        if isinstance(item, dict) and _exact_seq(item, seq):
            return item

    # If the requested seq is not on page 0, paginate using the same working page size.
    data = _data(first_resp)
    total = None
    if isinstance(data, dict):
        for k in ('totalNum', 'total', 'count'):
            try:
                total = int(data.get(k))
                break
            except Exception:
                pass
    page_size = max(1, len(profiles)) if profiles else 100
    max_pages = min(100, ((total + page_size - 1) // page_size) if total else 20)
    for page in range(1, max_pages):
        resp = await _apost(
            base_url, '/browser/list',
            {'page': page, 'pageSize': min(page_size, 100)},
            timeout=15, token=token,
        )
        if not _ok(resp):
            break
        rows = _extract_profiles(resp)
        if not rows:
            break
        for item in rows:
            if isinstance(item, dict) and _exact_seq(item, seq):
                return item

    visible = []
    for p in profiles[:20]:
        if isinstance(p, dict):
            visible.append(str(p.get('seq', '?')))
    raise RuntimeError(
        f'BitBrowser API 已連通，但列表中找不到序號 {seq}。'
        f' 第一頁可見 seq: {", ".join(visible) or "(none)"}'
    )


def _extract_pid_values(resp: dict, browser_id: str) -> list:
    """Best-effort PID extraction for the different /browser/pids response shapes."""
    data = _data(resp)
    found = set()

    def add(v):
        try:
            n = int(v)
            if n > 0:
                found.add(n)
        except Exception:
            pass

    def walk(obj, under_target=False):
        if isinstance(obj, dict):
            for k, v in obj.items():
                key = str(k)
                target = under_target or key == str(browser_id)
                if key.lower() in {'pid', 'processid', 'process_id'}:
                    if isinstance(v, list):
                        for x in v: add(x)
                    else:
                        add(v)
                elif target and isinstance(v, (int, str)):
                    add(v)
                else:
                    walk(v, target)
        elif isinstance(obj, list):
            for item in obj:
                if under_target and isinstance(item, (int, str)):
                    add(item)
                else:
                    walk(item, under_target)
        elif under_target:
            add(obj)

    walk(data)
    return sorted(found)


def _hide_windows_for_pids(pids: list) -> int:
    """Hide visible top-level Windows that belong to the BitBrowser profile PIDs."""
    if os.name != 'nt' or not pids:
        return 0
    import ctypes
    from ctypes import wintypes

    user32 = ctypes.WinDLL('user32', use_last_error=True)
    EnumWindows = user32.EnumWindows
    GetWindowThreadProcessId = user32.GetWindowThreadProcessId
    IsWindowVisible = user32.IsWindowVisible
    ShowWindow = user32.ShowWindow

    WNDENUMPROC = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
    EnumWindows.argtypes = [WNDENUMPROC, wintypes.LPARAM]
    EnumWindows.restype = wintypes.BOOL
    GetWindowThreadProcessId.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.DWORD)]
    GetWindowThreadProcessId.restype = wintypes.DWORD
    IsWindowVisible.argtypes = [wintypes.HWND]
    IsWindowVisible.restype = wintypes.BOOL
    ShowWindow.argtypes = [wintypes.HWND, ctypes.c_int]
    ShowWindow.restype = wintypes.BOOL

    wanted = {int(x) for x in pids if int(x) > 0}
    hidden = {'count': 0}
    SW_HIDE = 0

    @WNDENUMPROC
    def callback(hwnd, lparam):
        pid = wintypes.DWORD(0)
        GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        if int(pid.value) in wanted and IsWindowVisible(hwnd):
            ShowWindow(hwnd, SW_HIDE)
            hidden['count'] += 1
        return True

    EnumWindows(callback, 0)
    return int(hidden['count'])


def _start_persistent_window_hider(pids: list) -> None:
    """Keep profile windows hidden after launch without touching user keyboard/mouse.

    BitBrowser can create/recreate its top-level Chromium HWND a little after CDP is ready,
    so a one-shot ShowWindow(SW_HIDE) is sometimes too early. This daemon re-applies hide
    periodically for the lifetime of the EXE.
    """
    roots = sorted({int(x) for x in pids if str(x).isdigit() and int(x) > 0})
    if os.name != 'nt' or not roots:
        return

    def run():
        # Fast phase while Chromium finishes creating windows, then a cheap maintenance phase.
        for _ in range(40):
            try:
                _hide_windows_for_pids(roots)
            except Exception:
                pass
            time.sleep(0.20)
        while True:
            try:
                _hide_windows_for_pids(roots)
            except Exception:
                pass
            time.sleep(1.0)

    threading.Thread(target=run, name='BitBrowserWindowHider', daemon=True).start()


async def _query_profile_pids(base_url: str, token: str, browser_id: str, open_resp: Optional[dict] = None) -> list:
    # Different BitBrowser client generations accept slightly different /browser/pids bodies.
    # Try the common variants and merge every PID we can safely parse.
    found = set(_extract_pid_values(open_resp or {}, browser_id))
    payloads = [
        {'ids': [browser_id]},
        {'id': browser_id},
        {'ids': browser_id},
        {},
    ]
    for payload in payloads:
        try:
            resp = await _apost(base_url, '/browser/pids', payload, timeout=8, token=token)
            if _ok(resp):
                found.update(_extract_pid_values(resp, browser_id))
        except Exception:
            pass
        if found:
            # One working response is enough, but try at least the first two shapes before exit.
            if payload != {'ids': [browser_id]}:
                break
    return sorted(found)


async def connect_bitbrowser_context(playwright, cfg: Dict[str, Any]):
    seq = int(cfg.get('bitbrowser_seq', 173))
    # Two monitoring processes may attach to the SAME already-open BitBrowser
    # profile. Reusing 28Hse's healthy CDP endpoint avoids a second /browser/open
    # during bootstrap, which previously could rotate the port mid-detection.
    shared = str(cfg.get('shared_cdp_endpoint') or '').strip()
    if shared.startswith(('http://127.0.0.1:', 'ws://127.0.0.1:',
                           'http://localhost:', 'ws://localhost:')):
        try:
            browser = await playwright.chromium.connect_over_cdp(shared, timeout=3500)
            if browser.contexts:
                return browser, browser.contexts[0], {
                    'backend': 'BitBrowser', 'seq': seq, 'endpoint': shared,
                    'background_requested': False, 'background_effective': False,
                    'background_mode': 'reuse_28_cdp', 'background_warning': ''}
            # Do not call Browser.close() on another monitor's existing profile.
            # The Playwright connection will be cleaned up by its own context.
        except Exception as e:
            # V1.50.16: the shared port may rotate after a MANUAL browser
            # restart. Discover the existing live profile via read-only
            # /browser/list + /browser/ports; NEVER /browser/open or new_page.
            try:
                base_url = str(cfg.get('bitbrowser_api_url', 'http://127.0.0.1:54345')).rstrip('/')
                token = _resolve_api_token(cfg)
                if token:
                    profile = await _find_profile_by_seq(base_url, token, seq)
                    browser_id = str(profile.get('id') or '').strip()
                    if browser_id:
                        endpoints = [x for x in await _query_port_endpoints(base_url, token, browser_id)
                                     if x != shared]
                        browser, context, endpoint, _ = await _try_connect_cdp(
                            playwright, endpoints[:6], timeout_ms=3000)
                        if browser is not None and context is not None:
                            return browser, context, {
                                'backend':'BitBrowser','seq':seq,'endpoint':endpoint,
                                'background_requested':False,'background_effective':False,
                                'background_mode':'reattach_existing_profile',
                                'background_warning':''}
            except Exception:
                pass
            raise RuntimeError('共享CDP暫時失聯；等待已開BitBrowser恢復，不自動開環境／分頁：%s' % type(e).__name__) from e
        raise RuntimeError('共享CDP沒有可用Context；只等待已開環境，不調用/browser/open')
    base_url = str(cfg.get('bitbrowser_api_url', 'http://127.0.0.1:54345')).rstrip('/')
    token = _resolve_api_token(cfg)
    if not token:
        raise RuntimeError(
            '找不到 BitBrowser Local API Token。請先執行 SET_BITBROWSER_TOKEN.cmd。'
        )

    profile = await _find_profile_by_seq(base_url, token, seq)
    browser_id = str(profile.get('id') or '').strip()
    if not browser_id:
        raise RuntimeError(f'BitBrowser 序號 {seq} 沒有返回有效 id: {profile}')

    # BitBrowser background mode (stable Windows strategy):
    # Do NOT pass --headless here. Some BitBrowser profile/kernel combinations can fail to
    # start when launched with Chrome headless flags even though normal /browser/open works.
    # We always open the real profile normally, connect over CDP, then (on Windows) hide only
    # that profile's top-level windows by PID. This keeps the full browser rendering/session
    # behavior while avoiding a visible profile window.
    env_headless = str(os.environ.get('OPM_BITBROWSER_HEADLESS', '')).strip().lower()
    if env_headless in {'1','true','yes','on'}:
        background_requested = True
    elif env_headless in {'0','false','no','off'}:
        background_requested = False
    else:
        background_requested = bool(cfg.get('bitbrowser_headless', False))

    # Always use a standard visible-mode API launch. Background hiding happens after CDP attach.
    open_payload = {'id': browser_id, 'queue': True}
    open_resp = await _apost(
        base_url, '/browser/open', open_payload, timeout=60, token=token,
    )
    endpoint = _extract_endpoint(open_resp) if _ok(open_resp) else None

    if not endpoint:
        # Some client builds dislike queue=True. Retry the minimal documented body.
        try:
            open_resp = await _apost(
                base_url, '/browser/open', {'id': browser_id}, timeout=60, token=token,
            )
            endpoint = _extract_endpoint(open_resp) if _ok(open_resp) else None
        except Exception:
            endpoint = None

    if not endpoint:
        try:
            ports_resp = await _apost(base_url, '/browser/ports', {}, timeout=10, token=token)
            port = _extract_port_from_ports(ports_resp, browser_id) if _ok(ports_resp) else None
            if port:
                endpoint = f'http://127.0.0.1:{port}'
        except Exception:
            endpoint = None

    if not endpoint:
        raise RuntimeError(
            f'已找到 BitBrowser 序號 {seq} (id={browser_id})，但 /browser/open 沒有返回 CDP 地址。'
            f' 回應: {open_resp}'
        )

    try:
        browser = await playwright.chromium.connect_over_cdp(endpoint, timeout=30000)
    except Exception as e:
        raise RuntimeError(f'BitBrowser 環境已打開，但 Playwright 無法接管 {endpoint}: {e}') from e

    contexts = browser.contexts
    if not contexts:
        raise RuntimeError(f'BitBrowser 序號 {seq} 已連接，但沒有可用 BrowserContext。')
    context = contexts[0]

    hidden_pids = []
    background_effective = False
    background_warning = ''
    if background_requested and os.name == 'nt':
        try:
            # BitBrowser provides the live process IDs for a profile. Wait briefly because the
            # window may appear a fraction of a second after /browser/open returns.
            for _ in range(16):
                hidden_pids = await _query_profile_pids(base_url, token, browser_id, open_resp)
                if hidden_pids:
                    break
                await asyncio.sleep(0.20)
            if hidden_pids:
                # Repeatedly hide during the first seconds: a single one-shot hide can occur
                # before BitBrowser creates the final Chromium top-level window.
                hidden_count = 0
                for _ in range(16):
                    hidden_count += await asyncio.to_thread(_hide_windows_for_pids, hidden_pids)
                    if hidden_count > 0:
                        background_effective = True
                    await asyncio.sleep(0.16)
                _start_persistent_window_hider(hidden_pids)
                if not background_effective:
                    background_warning = '已取得 BitBrowser PID，背景隱藏守護已啟動；窗口如稍後出現會自動再隱藏。'
            else:
                background_warning = 'BitBrowser 已啟動，但 API 未返回 PID；無法自動隱藏窗口，監控仍會繼續。'
        except Exception as e:
            background_warning = f'BitBrowser 已啟動，但隱藏窗口失敗：{e}'
    elif background_requested:
        background_warning = 'BitBrowser 背景隱藏目前只支援 Windows；已用一般模式啟動。'
    info = {
        'backend': 'BitBrowser',
        'seq': seq,
        'id': browser_id,
        'api': base_url,
        'endpoint': endpoint,
        'name': profile.get('name', ''),
        'headless': False,
        'background_requested': background_requested,
        'background_effective': background_effective,
        'background_mode': 'hidden_window' if background_requested else 'visible',
        'hidden_pids': hidden_pids,
        'background_warning': background_warning,
    }
    return browser, context, info
