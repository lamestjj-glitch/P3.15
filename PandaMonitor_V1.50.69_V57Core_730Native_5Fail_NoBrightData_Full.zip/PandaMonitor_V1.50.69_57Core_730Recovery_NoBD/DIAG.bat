@echo off
call "%~dp0START.bat"
echo.
echo Diagnostic launcher finished.
pause
