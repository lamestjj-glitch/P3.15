# -*- coding: utf-8 -*-
"""28Hse owner-only/latest JSON list detector.

The request template is observed once from an ordinary 28Hse search in a
background BitBrowser target, kept in memory, and never written to disk/logs.
The verifier deliberately refuses to guess field names or fall back to HTML
list polling when the template cannot be proven.
"""
from __future__ import annotations
import json
import re
import time
from urllib.parse import parse_qs, unquote_plus, urlsplit, parse_qsl

API_PATH = '/property/dosearch'
MAX_HTML = 3_000_000


def existing_list_url_kind(href, trade):
    """Classify only an already-open rent/buy list, never a property detail.

    A queryless /rent or /buy is only a *candidate*: an actual owner/latest
    POST and API-vs-DOM list match are mandatory before monitoring starts.
    URL parameters explicitly specifying another filter are always rejected.
    """
    if trade not in ('rent', 'buy'):
        return None
    try:
        parsed = urlsplit(str(href or ''))
        if (parsed.scheme not in ('http', 'https') or
                parsed.hostname not in ('28hse.com', 'www.28hse.com') or
                parsed.path.rstrip('/') != '/'+trade):
            return None
        q = dict(parse_qsl(parsed.query, keep_blank_values=True))
        if q.get('landlordAgency') == 'LANDLORD' and q.get('sortBy') == 'latest':
            return 'explicit'
        # Screenshot/site behavior: owner + latest can be held in the search
        # form even while the address bar remains /rent or /buy.  Such pages
        # are NOT trusted until a live owner-locked POST has been captured.
        if not parsed.query:
            return 'bare'
        return None
    except (ValueError, TypeError):
        return None


class ApiError(RuntimeError):
    def __init__(self, kind, message, retry_after=None):
        self.kind = kind
        self.retry_after = retry_after
        super().__init__(message)


def _walk_filter(obj, depth=0):
    """Parse fields recursively; require both filter values in the actual body."""
    if depth > 6:
        return {}
    if isinstance(obj, str):
        obj = obj.strip()
        if len(obj) > 300_000:
            return {}
        try:
            obj = json.loads(obj)
        except Exception:
            if '=' not in obj:
                return {}
            obj = {k: vs[0] for k, vs in parse_qs(obj, keep_blank_values=True).items() if vs}
    found = {}
    if isinstance(obj, dict):
        for key, value in obj.items():
            if key in ('landlordAgency','sortBy') and isinstance(value,str):
                found[key] = value
            elif isinstance(value,(dict,list,str)):
                found.update(_walk_filter(value, depth+1))
    elif isinstance(obj,list):
        for value in obj[:50]:
            found.update(_walk_filter(value,depth+1))
    return found


def owner_lock(body):
    flags = _walk_filter(body)
    return flags.get('landlordAgency') == 'LANDLORD' and flags.get('sortBy') == 'latest'


def extract_property_urls(fragment, trade):
    """Extract property links only from the expected rent/buy category."""
    if not isinstance(fragment, str) or len(fragment) > MAX_HTML:
        return []
    content = fragment.replace('\\/', '/').replace('&amp;', '&')
    content = content.replace('&#47;','/').replace('&#x2F;', '/')
    # HTML can use absolute or relative URLs. The result is a canonical URL.
    rgx = re.compile(r'(?:(?:https?:)?//(?:www\.)?28hse\.com)?/(rent|buy)/([a-z0-9_-]+)/property-(\d{6,10})(?=[/?#\s"\'<>]|$)',re.I)
    seen=set(); out=[]
    for match in rgx.finditer(content):
        kind, cat, pid = match.groups()
        if kind.lower()!=trade:
            continue
        url=f'https://www.28hse.com/{trade}/{cat}/property-{pid}'
        if pid not in seen:
            out.append(url)
            seen.add(pid)
    return out


def parse_api_reply(reply, trade):
    if not isinstance(reply,dict):
        raise ApiError('invalid-json','28Hse API did not return JSON object')
    if any(k in str(reply.get('error','')).lower() for k in ('captcha','cloudflare')):
        raise ApiError('challenge','28Hse API challenge')
    results=((reply.get('data') or {}).get('results') or {}) if isinstance(reply.get('data'),dict) else {}
    if not isinstance(results,dict):
        raise ApiError('invalid-json','28Hse JSON results missing')
    html=results.get('resultContentHtml')
    if not isinstance(html,str):
        raise ApiError('invalid-json','28Hse JSON missing resultContentHtml')
    low=html[:20000].lower()
    if any(v in low for v in ('verify you are human','checking your browser','cf-turnstile','人機驗證','人机验证')):
        raise ApiError('challenge','Cloudflare challenge page in JSON')
    urls=extract_property_urls(html,trade)
    if not urls:
        raise ApiError('invalid-list','API did not contain valid owner-only list URLs')
    rd=results.get('resultData') or {}
    br=rd.get('buyRent') if isinstance(rd,dict) else None
    if isinstance(br,str) and br.lower() in ('rent','buy') and br.lower()!=trade:
        raise ApiError('filter','API returned wrong trade')
    return urls


def _challenge_dom(c):
    try:
        return bool(c.ev(r'''(()=>{
          const t=((document.title||'')+' '+(document.body&&document.body.innerText||'')).slice(0,5000).toLowerCase();
          return /verify you are human|checking your browser|just a moment|cf-turnstile|人機驗證|人机验证/.test(t)
              || !!document.querySelector('iframe[src*="challenges.cloudflare.com"]');
        })()''', timeout=2.5))
    except (ConnectionError, TimeoutError):
        # Never reinterpret a broken CDP socket as a healthy page without a
        # challenge. The outer 28Hse worker must reattach to this open tab.
        raise
    except Exception:
        return False


# V1.48.1: DOM-only trigger in a dedicated background CDP Target.
# Never calls mouse/keyboard dispatch, brings a tab to the front, or touches
# the user's visible browsing session. The site may refuse programmatic clicks;
# in that case we fail closed instead of stealing physical input.
_SEARCH_CONTROL_JS = r"""((execute)=>{
  // Private background Target only. No OS input or foreground activation.
  const norm=s=>String(s||'').replace(/\s+/g,' ').trim().toLowerCase();
  const simplify=s=>norm(s).replace(/\s+/g,'');
  const accepted=new Set(['搜尋','搜索','搜寻','search','搜尋樓盤','搜尋房源',
    '搜索房源','搜尋物業','搜尋物件','查詢樓盤','查找房源']);
  const all=[...document.querySelectorAll('button,input[type="submit"],input[type="button"],[role="button"],a')].slice(0,1400);
  let visible=0, matching=0, formCandidates=0;
  const list=[];
  const hasFilter=(f)=>!!(f&&f.querySelector('[name="landlordAgency"],[name="sortBy"],[name="form_data"]'));
  const searchScope=e=>e.closest('form,[id*="search" i],[class*="search" i],'+
    '[id*="filter" i],[class*="filter" i]');
  for(const e of all){
    if(e.disabled||e.getAttribute('aria-disabled')==='true'||e.closest('[hidden],[inert],[aria-hidden="true"]'))continue;
    const style=getComputedStyle(e), r=e.getBoundingClientRect();
    if(style.display==='none'||style.visibility==='hidden'||+style.opacity===0||r.width<3||r.height<3)continue;
    visible++;
    const f=e.closest('form'), parent=searchScope(e);
    const label=simplify(e.innerText||e.textContent||e.value||e.getAttribute('aria-label')||e.title);
    const attrs=norm([e.id,e.className,e.getAttribute('name'),e.getAttribute('data-testid'),
      e.getAttribute('aria-label'),e.title,parent&&parent.id,parent&&parent.className].join(' '));
    const literal=accepted.has(label);
    const nearby=!!parent && /(search|搜尋|搜索|filter|查詢|筛选|篩選)/i.test(attrs);
    const semantic=/(^|[-_\s])(search|submit|query|searchbtn|searchbutton)(?:[-_\s]|$)|搜尋|搜索|查詢/i.test(attrs);
    const formHasFilters=hasFilter(f);
    const submit=e.matches('button[type="submit"],input[type="submit"]');
    // Never activate unknown icons or unrelated controls. A no-text search
    // control must have a strong search identity AND belong to a search form.
    if(!literal && !(nearby&&semantic&&submit&&formHasFilters))continue;
    matching++;
    const main=!!e.closest('main,#main,.main-content,#search-form,.search-form,.search-container,.search-panel');
    const score=(literal?100:0)+(formHasFilters?60:0)+(nearby?15:0)+
      (semantic?12:0)+(main?8:0)+(submit?4:0);
    list.push({e,score,label,reason:literal?'label':'semantic-form'});
  }
  list.sort((a,b)=>b.score-a.score);
  const highest=list[0];
  const ties=list.filter(x=>x.score===(highest&&highest.score));
  // Diagnostic fields are counts and page state only. Never return HTML,
  // request bodies, cookies, phone numbers or other page content.
  const base={count:list.length,visible,matching,ready:document.readyState,
    body:!!document.body,buttons:all.length,
    forms:document.forms.length};
  if(!highest)return {...base,ok:false,reason:'no-visible-search-control'};
  if(ties.length!==1)return {...base,ok:false,reason:'ambiguous-visible-search-controls',topScore:highest.score,ties:ties.length};
  if(!execute)return {...base,ok:true,topScore:highest.score,method:highest.reason};
  try { highest.e.click();return {...base,ok:true,method:'background-dom-click'}; }
  catch(err){return {...base,ok:false,reason:'dom-click-failed',error:String(err&&err.name||err).slice(0,45)};}
})"""


def _search_control(c, execute=False, timeout=2.0):
    # Runtime.evaluate, explicitly userGesture=False.  No Input.dispatch*.
    ret=c.call('Runtime.evaluate',{
        'expression':_SEARCH_CONTROL_JS+'('+('true' if execute else 'false')+')',
        'returnByValue':True,'userGesture':False,
    },timeout=timeout) or {}
    value=(ret.get('result') or {}).get('value')
    return value if isinstance(value,dict) else {'ok':False,'reason':'no-runtime-result'}


def capture_template(app, trade, is_running, cached=None, allow_reload=True):
    """Attach to an existing owner/latest tab and capture a real API template.

    Never create or close a user list tab. At most one initial in-place reload
    is allowed by the worker; further retries observe/trigger the existing DOM
    without repeatedly refreshing and losing its owner/latest selection.
    """
    # V1.50.16: monitoring is ATTACH-ONLY. Never create a list Target.
    # If a user closes the list tab, callers wait for a matching manually
    # opened tab. CDP websocket attachment itself does not open a tab.
    t = app.target(trade)
    if not t:
        raise ApiError('closed-tab', '等待手動開啟 28Hse %s 業主＋最新列表分頁' % trade)
    tid = t.get('id')
    original_kind = existing_list_url_kind(t.get('url'), trade)
    c = None
    found, observed, missing_post_data = [], [], []
    used_cache = False

    def on_event(ev):
        if ev.get('method') != 'Network.requestWillBeSent':
            return
        p = ev.get('params') or {}
        req = p.get('request') or {}
        url = str(req.get('url') or '')
        if not re.match(r'^https://(?:www\.)?28hse\.com/property/(?:dosearch|doaction|dosearch_squarefoot_aside)(?:\?.*)?$', url, re.I):
            return
        path=url.split('/property/',1)[-1].split('?',1)[0]
        observed.append(path)
        if path != 'dosearch' or (req.get('method') or '').upper() != 'POST':
            return
        body = req.get('postData')
        if isinstance(body, str) and len(body) < 300000 and owner_lock(body):
            found.append({'url': url.split('?', 1)[0], 'body': body})
            return
        # CDP can provide a partial/encoded body even when postData exists.
        # The full original body may be retrievable by its exact requestId.
        rid = p.get('requestId')
        if rid:
            missing_post_data.append(rid)

    def resolve_pending_posts():
        # CDP may omit/truncate postData in requestWillBeSent while the original
        # requestId still exposes the complete POST. Check immediately after
        # network events; don't waste another DOM click or reload first.
        while not found and missing_post_data and is_running():
            rid = missing_post_data.pop(0)
            try:
                v = c.call('Network.getRequestPostData', {'requestId': rid}, timeout=1.2) or {}
                body = v.get('postData')
                if isinstance(body, str) and len(body) < 300000 and owner_lock(body):
                    found.append({'url':'https://www.28hse.com/property/dosearch','body':body})
                    return
            except (TimeoutError, ConnectionError):
                raise
            except Exception:
                pass

    def pump(seconds, check_dom=False):
        # Network.requestWillBeSent events are pushed to the websocket. Do not
        # force a Runtime.evaluate every 100ms while a 28Hse page is reloading:
        # this used to cause two 1-second timeouts and "socket retired".
        deadline = time.monotonic() + seconds
        if check_dom and _challenge_dom(c):
            raise ApiError('challenge', 'Cloudflare verification during API learning')
        while is_running() and time.monotonic() < deadline and not found:
            c.pump_event(timeout=min(.35, max(.02, deadline-time.monotonic())))
        if check_dom and not found and _challenge_dom(c):
            raise ApiError('challenge', 'Cloudflare verification during API learning')
        resolve_pending_posts()

    try:
        c = app.cdp(t)
        c.event_handler = on_event
        c.call('Network.enable', {'maxPostDataSize':300000}, timeout=3)
        c.call('Page.enable', timeout=3)
        c.call('Runtime.enable', timeout=3)
        # Reuse the already-open, correctly-filtered page. A previously
        # verified request can be revalidated WITHOUT reloading the page.
        if original_kind == 'explicit' and isinstance(cached, dict) and owner_lock(cached.get('body', '')):
            # A request learned and API/DOM-verified earlier in this SAME
            # application/profile can be reused after Stop/Start. It remains
            # memory-only. The worker MUST still verify API IDs against the
            # current background document before monitoring.
            path=urlsplit(str(cached.get('url', '')))
            if path.scheme=='https' and path.hostname in ('28hse.com','www.28hse.com') and path.path==API_PATH:
                found.append({'url':'https://www.28hse.com'+API_PATH,'body':cached['body']})
                used_cache=True
        if not found and original_kind == 'explicit' and allow_reload:
            # URL-verified list: one permitted in-place reload to learn the
            # actual XHR. A queryless owner/latest form MUST NOT be reloaded:
            # reload can discard its chosen filters before POST capture.
            c.call('Page.reload', {'ignoreCache':False}, timeout=7)
            pump(3.0, check_dom=True)
        if not found:
            # Wait for client-side search listeners to initialize. A DOM click
            # executed before hydration is a no-op on some 28Hse versions.
            deadline=time.monotonic()+13.0
            probe={'ok':False,'reason':'background-document-not-ready'}
            last_page_state={}
            eval_errors=0
            stable_since=None
            while is_running() and time.monotonic() < deadline:
                if _challenge_dom(c):
                    raise ApiError('challenge','Cloudflare verification during API learning')
                try:
                    state=c.call('Runtime.evaluate',{'expression':
                        "({ready:document.readyState,href:location.href})",'returnByValue':True,'userGesture':False},timeout=1.5) or {}
                    val=(state.get('result') or {}).get('value') or {}
                    if not isinstance(val,dict):val={}
                    u=val.get('href','')
                    url_kind = existing_list_url_kind(u, trade)
                    last_page_state={'ready':str(val.get('ready') or '?')[:14],
                                     'urlOwner': url_kind == 'explicit',
                                     'bareListCandidate': url_kind == 'bare'}
                    if not url_kind:
                        raise ApiError('filter','Existing list URL is neither owner/latest nor an unparameterized rent/buy candidate')
                    probe=_search_control(c,execute=False,timeout=1.5)
                    if probe.get('ok') and val.get('ready') in ('interactive', 'complete'):
                        if stable_since is None:stable_since=time.monotonic()
                        if time.monotonic()-stable_since>=0.65:break
                    else:stable_since=None
                except ApiError:raise
                except (ConnectionError, TimeoutError):
                    # Outer worker will attach a fresh websocket to this SAME
                    # user page. Never reuse the timed-out runtime socket.
                    raise
                except Exception as exc:
                    eval_errors+=1
                    probe={'ok':False,'reason':'waiting-for-background-DOM',
                           'detail':type(exc).__name__}
                time.sleep(.30)
            if not is_running():
                raise ApiError('stopped','Monitor stopped')
            if not probe.get('ok'):
                # No guessed click and no repeated navigation. Supply only
                # safe diagnostics to identify layout versus CDP readiness.
                diag={key:probe.get(key) for key in ('ready','buttons','visible','matching','forms','count','ties','detail')
                      if key in probe}
                diag.update(last_page_state)
                diag['cdpErrors']=eval_errors
                raise ApiError('learn','Background search control unavailable (%s); diag=%s; no input sent' %
                               (probe.get('reason','unknown'),str(diag)[:220]))
            click=_search_control(c,execute=True,timeout=3.5)
            if not click.get('ok'):
                raise ApiError('learn','Background DOM search rejected (%s); no input sent' % click.get('reason','unknown'))
            pump(9.0,check_dom=True)
        # Also recheck any POST that arrived while the DOM click was returning.
        if not found:
            resolve_pending_posts()
        if not found:
            summary=','.join(sorted(set(observed))) or 'no-property-XHR'
            raise ApiError('learn','No verified owner/latest /property/dosearch POST; observed=%s, requests=%d; check selected filters/search; no mouse/keyboard used' %
                           (summary, len(observed)))
        if not is_running():
            raise ApiError('stopped','Monitor stopped')
        item=found[-1].copy()
        item['reused'] = used_cache
        # Final destination must still be the exact owner/latest list.
        # A redirect or consent page must never validate a captured XHR.
        site=c.call('Runtime.evaluate',{'expression':'location.href','returnByValue':True,'userGesture':False},timeout=2) or {}
        href=(site.get('result') or {}).get('value') or ''
        final_kind=existing_list_url_kind(href, trade)
        if not final_kind:
            raise ApiError('filter','List final URL changed to a different filter/page; API disabled')
        if not owner_lock(item['body']):
            raise ApiError('filter','OWNERLOCK missing in captured POST')
        if final_kind == 'bare' and used_cache:
            raise ApiError('filter','Queryless list requires a fresh owner/latest POST; cached template rejected')
        item['bare_url_candidate'] = final_kind == 'bare'
        return t,c,item
    except BaseException:
        if c:
            try:c.close()
            except Exception:pass
        # User-owned list tab is NEVER closed, including when learning fails.
        raise
    finally:
        if c:c.event_handler=None

def api_snapshot(c,trade,template,known_ids,timeout_ms=3500):
    """Fetch one verified XHR and return only compact property URLs over CDP.

    Fast path: when a verified JSON response's resultContentHtml starts to
    stream and contains a new URL, abort remaining body to free the lane.
    Full path: for baseline/no NEW, validate the entire JSON in the renderer.
    In both cases, never send the entire HTML/JSON across CDP.
    """
    if trade not in ('rent','buy') or not owner_lock(template.get('body','')):
        raise ApiError('filter','Captured API template lost OWNERLOCK')
    known = list(dict.fromkeys(str(x) for x in (known_ids or []) if str(x).isdigit()))[:120]
    expression = r"""(async()=>{
      const started=performance.now(), limit=__TIMEOUT__;
      const ctl=new AbortController(), tm=setTimeout(()=>ctl.abort(),limit);
      const kind=__TRADE__, known=new Set(__KNOWN__);
      const target='"resultContentHtml"';
      const rx=/(?:https?:\/\/(?:www\.)?28hse\.com)?\/(rent|buy)\/([a-z0-9_-]+)\/property-(\d{6,10})(?=[^0-9]|$)/gi;
      const base='https://www.28hse.com/';
      function extract(text){
        // The real JSON encodes '/' as either '/' or '\\/' in HTML strings.
        const cleaned=String(text||'').replace(/\\\//g,'/').replace(/\\u002f/gi,'/').replace(/&amp;/g,'&');
        const urls=[], ids=new Set(); let m;
        rx.lastIndex=0;
        while((m=rx.exec(cleaned))!==null){
          if(m[1].toLowerCase()!==kind || ids.has(m[3]))continue;
          ids.add(m[3]);urls.push(base+kind+'/'+m[2]+'/property-'+m[3]);
          if(urls.length>=35)break;
        }
        return urls;
      }
      const elapsed=()=>Math.max(1,Math.round(performance.now()-started));
      // Browser fetch() uses the existing Chromium connection pool.  Do not
      // open a second HTTP client or re-create an authenticated session.
      const resourceTiming=()=>{
        try{
          const entries=performance.getEntriesByName(__URL__, 'resource');
          const last=entries.length ? entries[entries.length-1] : null;
          if(!last || last.startTime < started-100) return {};
          return {networkConnectMs:Math.max(0,Math.round(last.connectEnd-last.connectStart)),
                  networkWaitMs:Math.max(0,Math.round(last.responseStart-last.requestStart))};
        }catch(e){return {}}
      };
      try{
        const r=await fetch(__URL__,{method:'POST',body:__BODY__,credentials:'include',cache:'no-store',
          signal:ctl.signal,headers:{'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8',
          'X-Requested-With':'XMLHttpRequest','Accept':'application/json, text/javascript, */*; q=0.01'}});
        const head=elapsed();
        if(r.status===429)return {ok:false,kind:'rate',status:429,retryAfter:r.headers.get('Retry-After')||''};
        if(r.status===401||r.status===403)return {ok:false,kind:'challenge',status:r.status};
        if(!r.ok)return {ok:false,kind:'http',status:r.status};
        const ct=(r.headers.get('Content-Type')||'').toLowerCase();
        if(!ct.includes('json'))return {ok:false,kind:'challenge',status:r.status};
        // Single reader / request. Do not queue a second fetch while one runs.
        const reader=r.body&&r.body.getReader?r.body.getReader():null;
        let raw='', firstId=0, firstNew=0, firstChunk=0, early=null;
        if(reader){
          const decoder=new TextDecoder();
          while(true){
            const chunk=await reader.read();
            if(chunk.done)break;
            if(!firstChunk)firstChunk=elapsed();
            raw+=decoder.decode(chunk.value,{stream:true});
            if(raw.length>3200000)return {ok:false,kind:'oversize'};
            // Only inspect URLs inside resultContentHtml: menu/related items are
            // not necessarily part of the owner-only results.
            const start=raw.indexOf(target);
            if(start>=0){
              const links=extract(raw.slice(start+target.length));
              if(links.length&&!firstId)firstId=elapsed();
              if(known.size){
                const newLinks=links.filter(u=>!known.has(u.split('property-').pop()));
                if(newLinks.length){
                  firstNew=elapsed(); early=newLinks.slice(0,12);
                  // A complete listing JSON normally arrives in one response;
                  // only stop before the end for genuinely new listing IDs.
                  try{await reader.cancel('new property detected')}catch(e){}
                  return {ok:true,urls:early,newUrls:early,headMs:firstChunk||head,
                    headerMs:head,streamMs:Math.max(0,elapsed()-head),jsonMs:0,
                    ...resourceTiming(),firstIdMs:firstId||firstNew,
                    firstNewMs:firstNew,totalMs:elapsed(),early:true};
                }
              }
            }
          }
          raw+=decoder.decode();
        }else{raw=await r.text();firstChunk=elapsed()}
        const bodyDone=elapsed();
        let data;try{data=JSON.parse(raw)}catch(e){return {ok:false,kind:'invalid-json'}}
        const jsonDone=elapsed();
        const results=data&&data.data&&data.data.results;
        if(!results||typeof results.resultContentHtml!=='string')return {ok:false,kind:'invalid-json'};
        const body=results.resultContentHtml;
        if(/verify you are human|checking your browser|cf-turnstile|人機驗證|人机验证/i.test(body.slice(0,20000)))
          return {ok:false,kind:'challenge'};
        const br=results.resultData&&results.resultData.buyRent;
        if((br==='rent'||br==='buy')&&br!==kind)return {ok:false,kind:'filter'};
        const urls=extract(body);
        if(!urls.length)return {ok:false,kind:'invalid-list'};
        const newUrls=urls.filter(u=>!known.has(u.split('property-').pop()));
        const total=elapsed();
        return {ok:true,urls,newUrls,headMs:firstChunk||head,
          headerMs:head,streamMs:Math.max(0,bodyDone-head),
          jsonMs:Math.max(0,jsonDone-bodyDone),...resourceTiming(),
          firstIdMs:firstId||total,firstNewMs:newUrls.length?(firstNew||total):0,
          totalMs:total,early:false};
      }catch(e){return {ok:false,kind:e&&e.name==='AbortError'?'timeout':'network'}}
      finally{clearTimeout(tm)}
    })()""".replace('__URL__',json.dumps(template['url']))\
      .replace('__BODY__',json.dumps(template['body']))\
      .replace('__TRADE__',json.dumps(trade))\
      .replace('__KNOWN__',json.dumps(known))\
      .replace('__TIMEOUT__',str(int(timeout_ms)))
    rr=c.call('Runtime.evaluate',{'expression':expression,'awaitPromise':True,
       'returnByValue':True,'userGesture':False},timeout=max(4.0,timeout_ms/1000+1.5)) or {}
    value=(rr.get('result') or {}).get('value')
    if not isinstance(value,dict):
        raise ApiError('invalid-json','28Hse API returned no compact result')
    if not value.get('ok'):
        kind=value.get('kind','network')
        raise ApiError(kind,'28Hse JSON '+kind+' HTTP '+str(value.get('status') or 0),retry_after=value.get('retryAfter'))
    urls=value.get('urls') or []
    if not isinstance(urls,list) or not urls or len(urls)>35:
        raise ApiError('invalid-list','Empty or malformed compact result')
    # Defense in depth: renderer's extracted result must still be canonical,
    # of the expected source, and have an actual numeric property ID.
    if any(not re.fullmatch(r'https://www\.28hse\.com/'+trade+r'/[a-z0-9_-]+/property-\d{6,10}',u or '', re.I)
           for u in urls):
        raise ApiError('filter','28Hse API response contained unexpected URL')
    newurls=value.get('newUrls') or []
    newurls=[u for u in newurls if u in urls]
    ms=max(1,int(value.get('totalMs') or 0))
    timing={'first_byte_ms':int(value.get('headMs') or ms),
       'first_id_ms':int(value.get('firstIdMs') or ms),
       'first_new_ms':int(value.get('firstNewMs') or 0),
       'js_total_ms':ms,'new_urls':newurls,'early':bool(value.get('early')),
       'headers_ms':int(value.get('headerMs') or 0),
       'stream_ms':int(value.get('streamMs') or 0),
       'json_ms':int(value.get('jsonMs') or 0),
       'connect_ms':int(value.get('networkConnectMs') or 0),
       'server_wait_ms':int(value.get('networkWaitMs') or 0)}
    return urls,0,{},timing
