# -*- coding: utf-8 -*-
import unittest
from unittest.mock import patch
from types import SimpleNamespace
from site_engine import BitBrowserFetcher, SiteManager, SiteConfigStore, DEFAULT_BFS
from site_plugins import businessforsale_sg
from pathlib import Path
import tempfile
import threading
import time

URL = DEFAULT_BFS['url']
DETAIL = 'https://www.businessforsale.sg/businesses-for-sale/owner-listing-42769'
LIST = '<html><body><a href="/businesses-for-sale/owner-listing-42769">Business A</a></body></html>'
CONTACT = '''<html><body><h3>Direct Seller</h3><div>Seller Contact & Listing Information
Contact Person LCS Mobile Number +6588539898 Email Address x@example.com Total Enquiries 0</div></body></html>'''

class MockPage:
    def __init__(self, url=URL, data=LIST):
        self.url, self.data, self.evals = url, data, 0
        self.closed = False
    def is_closed(self): return self.closed
    def evaluate(self, js, url):
        self.evals += 1
        return {'url':url, 'html': self.data}
    def set_default_navigation_timeout(self, t): pass
    def goto(self, url, **kwargs): self.url=url
    def locator(self, what): return SimpleNamespace(first=SimpleNamespace(wait_for=lambda **kw:None))
    def content(self): return self.data
    def close(self): self.closed=True

class MockContext:
    def __init__(self, existing, response_html=CONTACT):
        self.pages=[existing]; self.new_count=0
        self.response_html = response_html
        self.request=SimpleNamespace(get=lambda *args,**kw:SimpleNamespace(ok=True, headers={'content-type':'text/html'},text=lambda:self.response_html))
    def new_page(self):
        self.new_count += 1
        p=MockPage('about:blank', CONTACT)
        self.pages.append(p)
        return p

class Tests(unittest.TestCase):
    def test_existing_tab_fresh_fetch_and_authenticated_detail_without_any_new_tabs(self):
        ctx=MockContext(MockPage())
        f=BitBrowserFetcher(DEFAULT_BFS)
        f.browser=SimpleNamespace(contexts=[ctx])
        self.assertEqual(f.fetch(URL), LIST)
        self.assertEqual(f.last_fetch_mode,'browser-fetch')
        self.assertEqual(f.fetch_detail(DETAIL,businessforsale_sg,DEFAULT_BFS), CONTACT)
        self.assertEqual(ctx.new_count,0)
        self.assertEqual(f._open_list_snapshot(URL), LIST)
    def test_rendered_detail_uses_one_reusable_private_tab(self):
        existing=MockPage()
        ctx=MockContext(existing,'<html><body>loading</body></html>')
        f=BitBrowserFetcher(DEFAULT_BFS);f.browser=SimpleNamespace(contexts=[ctx])
        self.assertIn('Mobile Number',f.fetch_detail(DETAIL,businessforsale_sg,DEFAULT_BFS))
        self.assertIn('Mobile Number',f.fetch_detail(DETAIL,businessforsale_sg,DEFAULT_BFS))
        self.assertEqual(ctx.new_count,1)
        self.assertTrue(existing.evals==0)
    def test_auto_detail_only_for_new_post_and_never_navigate_list_page_to_detail(self):
        # Plug into worker with fake authenticated browser; no real network.
        with tempfile.TemporaryDirectory() as d:
            store=SiteConfigStore(d)
            store.write_seen({'businessforsale-sg':set()})
            mgr=SiteManager(store)
            calls=[]
            class FakeBrowser:
                last_fetch_mode='browser-fetch'
                def __init__(self,cfg): pass
                def __enter__(self):return self
                def __exit__(self,*args):pass
                def fetch(self,url):
                    self.last_fetch_mode='browser-fetch'
                    calls.append(('list',url))
                    return LIST
                def fetch_detail(self,url,plugin,cfg):
                    calls.append(('detail',url))
                    mgr.stop_event.set()
                    return CONTACT
                def open_details(self,cfg): return []
            cfg=dict(DEFAULT_BFS,enabled=True,interval=0.1)
            with patch('site_engine.BitBrowserFetcher', FakeBrowser):
                mgr._worker(cfg)
            self.assertEqual([kind for kind,url in calls],['list','detail'])
            self.assertEqual(calls[1][1],DETAIL)
            events=list(mgr.out.queue)
            self.assertTrue(any(e['event']=='new' and e['data'].get('phone')=='+6588539898' for e in events))

if __name__=='__main__':unittest.main(verbosity=2)
