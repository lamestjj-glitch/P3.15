PandaMonitor V1.50.47 — 28Hse 歷史記錄修復

問題：舊版 28Hse 僅把號碼寫入 seen_phones.json，重開時 UI 只恢復 House730 SQLite 列表。
修復：28Hse 新抓到的每條真實號碼另外寫入 28hse_history.sqlite3（房源種類、ID、電話、連結、聯絡人、日期、WA 狀態及附加號碼）。
程式重新啟動時恢復 28Hse 和 House730 的歷史列表，不影響 seen_phones.json 電話去重。
重要：以前的 seen_phones.json 沒有來源標記，因此不能可靠還原舊 28Hse 房源資料；不會把未知來源號碼偽造成 28Hse 歷史。
兩路並行、28Hse 100–300ms 隨機延遲、House730 監控、WhatsApp 和無 Signal 狀態不變。
歷史保存位置：%USERPROFILE%\PandaMonitor_28Hse\28hse_history.sqlite3
檢查新啟動日誌：[28-HISTORY-READY] / [28-HISTORY-ERROR]
