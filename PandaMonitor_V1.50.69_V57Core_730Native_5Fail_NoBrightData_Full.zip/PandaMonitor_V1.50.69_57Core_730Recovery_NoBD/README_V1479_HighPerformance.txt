PandaMonitor V1.47.9 — i7-10750H / 16GB 高效能分程序版
=======================================================
目標：優先減少 28Hse NEW -> CLIPBOARD 耗時超過 500ms 的情況；不能保證每筆都低於 500ms。

一、背景架構（只有一個統一 UI）
  * Python 主程序：統一 UI、28Hse 租售監控、尾四位剪貼板、跨站去重、Windows 通知與 28 WA。
  * 獨立 Python 子程序：House730 租售監控及其驗證等待／退避；730 WA 仍由共用 UI 按自己的設定執行。
  * 28Hse 的偵測、HTTP 揭號、CDP 備援線程：Windows ABOVE_NORMAL 線程優先級。
  * 730 子程序：Windows NORMAL 優先級。沒有鎖死 CPU 核心、不使用 REALTIME、不強行增加輪詢頻率。
  * 租／售仍嚴格同來源單請求、保留現有超時退避；不重寫 28Hse 揭號流程。

二、CDP 連線
  * 28Hse 先完成 BitBrowser 173 CDP 連線（至多等 8 秒）。
  * 730 子程序優先連接同一個已存在的 CDP 端口，避免第二次 /browser/open。
  * 如果端口已失效，730 仍可經既有的 BitBrowser API 重新尋找連線；此時可能發生恢復延遲。
  * 這只是分離 Python 執行環境，兩者若指定同一個 BitBrowser 173，底層瀏覽器仍會共享資源。

三、跨站電話去重
  * 730 子程序揭號後，透過 IPC 向主程序要求儲存。
  * 主程序持有原 28Hse phone_lock，檢查雙方歷史號碼，先 SQLite 寫入，再通知 730 成功。
  * 成功之後才更新 UI、複製尾四碼、Windows 彈窗／排隊 730 WA。
  * 原本的兩份去重資料及設定不會被初始化或清空。

四、電腦分配建議
  * i7-10750H：6 核心 / 12 線程。只提升 28 偵測及揭號線程優先級；交由 Windows 分配核心。
  * 16GB：避免同時啟動其他吃 RAM 的指紋環境；建議 Windows 仍保留 3-4GB 可用記憶體。
  * 使用充電器，Windows 電源模式選「最佳效能」，檢查散熱及 CPU 降頻。
  * 不要用任務管理員將 BitBrowser 或 Python 設為「即時」優先級。

五、運行／排查
  1. 完全關閉舊版 PandaMonitor；先開 BitBrowser 173，再雙擊 START.bat。
  2. 先只選 28Hse 兩路測一段，再加 730 兩路，比較 [RACE] NEW->CLIPBOARD。
  3. 看到 [PERF] 730 獨立 Python 子程序已啟動，表示新架構啟用。
  4. 730 遇 Cloudflare 會停止高頻查詢並顯示置頂通知，等待人工驗證。
  5. 停止及重啟時，如提示「730 正在結束」，等數秒再按開始。
  6. 用 python TEST_HIGH_PERFORMANCE.py 做離線子程序／去重通訊測試（不接網站）。

限制：已通過離線及 Linux GUI 測試，未在你的 Windows 10 / BitBrowser 173 真機測試。
ZIP 是完整 Python 原始碼與打包腳本，非預先編譯的 Windows EXE。
