# -*- coding: utf-8 -*-
"""Offline test: no website, no tokens, no contact data transmitted."""
from hse28_adaptive import AdaptiveListScheduler
from hse28_429_cooldown import RateCooldown
from panda28_api import ApiError
from panda28_core import App
import threading,time,inspect

class Clock:
    now=1000.0
    def __call__(self): return self.now
    def advance(self,seconds): self.now+=seconds

clock=Clock()
p=AdaptiveListScheduler(clock=clock)
assert p.report()['gap_ms']==0
for _ in range(84): p.success()
assert p.report()['gap_ms']==0
p.slow_or_timeout('timeout')
p.slow_or_timeout('timeout')
p.rate_limited()
assert p.report()['gap_ms']==0 and p.report()['rate_hits']==1
p.reset()
assert p.report()['gap_ms']==0 and p.report()['rate_hits']==0

# Rent/buy can overlap; same source remains strictly single-flight.
s=AdaptiveListScheduler()
active=set(); highest=0; same_overlap=[]; starts=[]; mutex=threading.Lock()
def hit(kind):
    global highest
    with s.lease(kind,lambda:True) as ok:
        assert ok
        with mutex:
            if kind in active:same_overlap.append(kind)
            active.add(kind)
            highest=max(highest,len(active));starts.append((kind,time.monotonic()))
        time.sleep(.06)
        with mutex:active.remove(kind)
threads=[threading.Thread(target=hit,args=(v,)) for v in ('rent','buy','rent')]
for t in threads:t.start()
for t in threads:t.join(4)
assert not any(t.is_alive() for t in threads)
assert not same_overlap
assert highest==2, (highest,starts)
assert len(starts)==3
assert any(abs(a[1]-b[1])<.055 for a,b in zip(starts,starts[1:])), starts
# Cancellation while queued doesn't leak a lease or future requests.
with s.lease('rent',lambda:False) as allowed: assert not allowed
with s.lease('buy',lambda:True) as allowed: assert allowed

# Shared 429 cooldown still enforces server Retry-After independently of pacer.
r=RateCooldown(clock=clock,jitter=lambda:0)
secs,*_=r.rate_limited('35')
assert secs>=35
assert r.remaining()>=35

src=inspect.getsource(App.worker)
assert 'self.api_adaptive_scheduler.lease' in src
assert 'self.api_adaptive_scheduler.slow_or_timeout(e.kind)' in src
assert 'self.api_429_guard.slot' in src
assert 'capture_template(self,k' in src and 'api_snapshot(c,k,template,known_top' in src
assert 'self.phone_jobs[k].put((u,detected_t0))' in src
assert 'api_rate_limit_event' in src
assert 'RateCooldown' in inspect.getsource(__import__('panda28_core'))
# Direct phone API remains part of a separate worker, not delayed by FIFO list gate.
phone=inspect.getsource(App.phone_worker)
assert 'self.http_phone_direct' in phone and 'api_adaptive_scheduler.lease' not in phone
print('PASS V1.50.27: per-lane single-flight and concurrent rent/buy, no old ramp/fixed gap, 429 cooldown, cancel, owner lock, direct phone unchanged')
