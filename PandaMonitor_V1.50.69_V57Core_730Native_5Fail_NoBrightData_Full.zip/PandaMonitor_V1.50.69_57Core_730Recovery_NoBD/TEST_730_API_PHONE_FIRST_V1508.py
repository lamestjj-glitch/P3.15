# -*- coding: utf-8 -*-
"""Offline regression tests for House730 phone-before-click capture."""
import asyncio
from house730_phone_first import contacts_from_api, phone_clean, is_phone_api, DetailPhoneCapture

def test_parse():
    assert is_phone_api('https://api.house730.com/Property/GetPropertyUserInfoById?abc=123')
    assert not is_phone_api('https://www.house730.com/Property/GetPropertyUserInfoById')
    assert phone_clean('+852 6123 4567') == '61234567'
    assert phone_clean('91234567') == '91234567'
    assert not phone_clean('912345xx')
    assert not phone_clean('21234567')
    assert not phone_clean('31234567')
    assert not phone_clean('id=91234567')
    assert contacts_from_api({'result':[{'contactNameCN':'陳先生','telphone':'94609811','customerTel':'','isShowTel':True,'isVirtualNumber':False}]}) == [('陳先生','94609811')]
    assert contacts_from_api({'result':[{'contactNameEN':'Alice','telphone':'61234567','isShowTel':False}]}) == []
    assert contacts_from_api({'result':[{'contactNameEN':'Alice','telphone':'61234567'},
                                          {'contactNameEN':'Mandy','telphone':'61234567'},
                                          {'contactNameEN':'Lucy','telphone':'91234567'}]}) == [('Alice','61234567'),('Lucy','91234567')]

class FakePage:
    def __init__(self): self.listeners = {}
    def on(self, name, callback): self.listeners[name] = callback
    def remove_listener(self, name, callback):
        if self.listeners.get(name) == callback: self.listeners.pop(name)
    def emit(self, resp): self.listeners['response'](resp)

class FakeResponse:
    def __init__(self, data=None, status=200):
        self.url = 'https://api.house730.com/Property/GetPropertyUserInfoById?id=test'
        self.status = status
        self.data = data or {}
    async def json(self): return self.data

async def test_collector():
    p=FakePage()
    c=DetailPhoneCapture(p).start()
    p.emit(FakeResponse({'result':[{'telphone':'94609811', 'contactNameCN':'陳先生','isShowTel':True}]}))
    r=await c.first(.3)
    assert r == [('陳先生','94609811')]
    await c.close()
    assert not p.listeners
    c=DetailPhoneCapture(p).start()
    p.emit(FakeResponse({'result':[{'telphone':'xxxxxx11'}]}))
    assert await c.first(.04) == []
    await c.close()
    c=DetailPhoneCapture(p).start()
    p.emit(FakeResponse(status=429))
    assert await c.first(.3) == [] and c.blocked_http == 429
    await c.close()

if __name__ == '__main__':
    test_parse()
    asyncio.run(test_collector())
    print('PASS 730 API-FIRST: full phone, disabled/duplicate/invalid, capture before click, fallback, HTTP 429')
