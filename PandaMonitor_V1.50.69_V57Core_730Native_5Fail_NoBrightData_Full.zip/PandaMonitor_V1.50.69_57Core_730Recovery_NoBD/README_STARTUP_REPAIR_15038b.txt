﻿PandaMonitor V1.50.38b — Windows startup SyntaxError fix
============================================================

Root cause confirmed from user log (2026-10-17):
  WIN_LAUNCH.ps1 of V1.50.38a passed a Python `-c` code argument
  through Windows PowerShell 5.1. Embedded double quotes were removed,
  causing `SyntaxError: '(' was never closed` for every detected Python.
  The installed Python 3.13 executable was already found correctly.

Changes:
  - WINDOWS_LAUNCH.ps1 now runs python_runtime_probe.py as a real file
    instead of passing a quotation-sensitive `-c` code argument.
  - The standalone probe prints Python version and checks Tkinter + Tcl.
  - Retains lookup of Python 3.13, 3.12, 3.14, 3.15 and saved settings.
  - No engine, rate, user settings, phone extraction, Signal or WA changes.

How to run:
  Extract ZIP completely -> PandaMonitor_V1.50.39 -> START.bat.
  Recommended interpreter: installed Python 3.13. No need to uninstall
  Python 3.15 or reinstall Python 3.13.
  If START.bat still fails, run START_DIRECT_PY313.bat to use the
  existing Python 3.13 directly without PowerShell probe.
  If unsuccessful: run DIAG_PYTHON.bat and send python_diag.log,
  plus start_console.log if available.
  Log folder: %LOCALAPPDATA%\PandaMonitor_28Hse_House730\logs

Tested offline with syntax + probe runtime tests. Actual Windows launch,
BitBrowser and site-specific operation require testing on your PC.
