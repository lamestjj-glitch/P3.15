PandaMonitor V1.50.14：28Hse Direct API PhoneFirst（零開帖）
======================================================

根據 HSE28_API_PARAM_MAP(1).json 在已登入 BitBrowser 173 的實測：
  樓盤 B #3125421 的電話可使用以下欄位直接查到，並匹配原樓盤電話：
  POST https://www.28hse.com/property/detail/doaction
  action=statistic_inc / user_action=phone / ad_id=<樓盤 ID>
  event_name=property_contact_phone
  不需要 uid_code、timeStamp。

新版取號順序：
  1) 28Hse 租售列表 JSON 得到新帖 ID（業主＋最新過濾不變）
  2) 在已登入 28Hse 後台 HTTP bridge 裡，直接 POST 電話 API
     不需要 GET 該樓盤的詳情 HTML；不建立詳情分頁；不點擊致電
  3) 若 API 未提供電話，使用原來的純 HTTP 讀取詳情 HTML＋doaction 路徑
     HTTP 備援依然不開詳情分頁
  4) 預設停用 CDP 背景詳情揭號；HTTP 失敗 2 秒後只補試 1 次
     可在「統一設定 → 四路監控與速度」手動開啟 CDP 背景開帖備援

設定：
  [x] 28Hse：新帖 ID 直接電話 API（預設開啟）
  [ ] 允許 CDP 背景開帖揭號（預設關閉）
  設定保存在既有 config.json，兩個設置會跨重啟保留。

主要日誌：
  [28-DIRECT] rent 3125421 · 252ms API · NEW→PHONE 380ms · 成功・0詳情頁・0揭號點擊
  [28-DIRECT-FALLBACK] ... · 直接 API 無公開電話，嘗試原純 HTTP
  [28-DIRECT-BLOCKED] ... · 429／驗證，停止本帖請求，不嘗試繞過
  [28-HTTP-RETRY] ... · 2秒後再試一次 HTTP（零開帖模式）
  [28-NO-DETAIL] ... · HTTP未取號，禁止開詳情
  [RACE] NEW→CLIPBOARD ...ms · 尾四位

不變：
  - 28Hse 租售獨立刷新、強制業主＋最新、8秒補查、single-flight。
  - 730 Direct API PhoneFirst；小數秒間隔、Cloudflare 保護。
  - 全站電話永久去重、2/3開頭排除、女性 WA TXT、插件。
  - 自動複製尾四位、手動複製完整電話。

注意：
  - 現有證據證實 28Hse 在一次已登入會話可只靠 ID＋固定欄位取 B 的電話，
    不代表其他新帖及新會話一定成功；請以現場 [28-DIRECT] 日誌確認。
  - 電話 API 可能增加站方瀏覽/揭號統計，不要把間隔設得超出網站容許範圍。
  - 不繞過驗證；403／429／503 直接停止當帖嘗試，按網站限制處理。
  - 本版已完成離線回歸，沒有 BitBrowser 173 實站連線驗證。

安裝：退出前版，解壓整個 ZIP，執行 START_一鍵啟動.cmd 或 START_OneClick.cmd。
