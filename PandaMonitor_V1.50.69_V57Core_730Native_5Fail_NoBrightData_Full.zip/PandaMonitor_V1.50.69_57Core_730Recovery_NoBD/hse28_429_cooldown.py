# -*- coding: utf-8 -*-
"""Shared 28Hse HTTP 429 backoff: 8 +/- 8 seconds with server-aware floor.

No identity/IP rotation, challenge circumvention, or unconditional retry storm.
Rent and buy share an origin-wide cooldown. Post-cooldown requests are
single-file for four successful probes before returning to independent cadence.
"""
from contextlib import contextmanager
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
import random
import threading
import time


def retry_after_seconds(value, now=None):
    """Return seconds from standard Retry-After header, or zero if absent."""
    if not value:
        return 0.0
    value = str(value).strip()
    try:
        return max(0.0, float(value))
    except (TypeError, ValueError):
        try:
            date = parsedate_to_datetime(value)
            if date.tzinfo is None:
                date = date.replace(tzinfo=timezone.utc)
            now = now if now is not None else datetime.now(timezone.utc)
            return max(0.0, (date - now).total_seconds())
        except (TypeError, ValueError, OverflowError):
            return 0.0


class RateCooldown:
    def __init__(self, *, clock=None, jitter=None):
        self.clock = clock or time.monotonic
        self.jitter = jitter or (lambda: random.uniform(-8.0, 8.0))
        self._cv = threading.Condition(threading.RLock())
        self._until = 0.0
        self._strikes = 0
        self._recovery_left = 0
        self._probe_active = False
        self._last_probe = float('-inf')
        self._healthy_count = 0
        self._delay = 0.0

    def reset(self):
        with self._cv:
            self._until = 0.0
            self._strikes = 0
            self._recovery_left = 0
            self._probe_active = False
            self._last_probe = float('-inf')
            self._healthy_count = 0
            self._delay = 0.0
            self._cv.notify_all()

    def remaining(self):
        with self._cv:
            return max(0.0, self._until - self.clock())

    def recovery(self):
        with self._cv:
            return self._recovery_left > 0

    def rate_limited(self, retry_after=None):
        """Called after a *real* 429 response. Never immediately reissues it."""
        with self._cv:
            self._strikes = min(7, self._strikes + 1)
            base = min(120.0, 8.0 * (2 ** (self._strikes - 1)))
            randomized = max(2.0, base + float(self.jitter()))
            server_floor = retry_after_seconds(retry_after)
            seconds = max(randomized, server_floor)
            self._until = max(self._until, self.clock() + seconds)
            self._recovery_left = 4
            self._healthy_count = 0
            self._delay = max(0.0, self._until - self.clock())
            self._cv.notify_all()
            return self._delay, self._strikes, server_floor

    @contextmanager
    def slot(self, active):
        """Gate list API calls only during 429 cooldown/recovery.

        'active' must be a cheap cancellation predicate checking run ID.
        Each lane already uses its own single-flight worker; this prevents
        simultaneous rent/buy retries just after a global 429.
        """
        recovery_slot = False
        admitted = False
        with self._cv:
            while active():
                now = self.clock()
                cooldown = max(0.0, self._until - now)
                needs_serial = self._recovery_left > 0
                probe_gap = max(0.0, self._last_probe + 1.5 - now) if needs_serial else 0.0
                if not cooldown and (not needs_serial or (not self._probe_active and not probe_gap)):
                    if needs_serial:
                        self._probe_active = True
                        self._last_probe = now
                        recovery_slot = True
                    admitted = True
                    break
                self._cv.wait(min(.2, max(.01, cooldown, probe_gap)))
        if not admitted:
            yield False
            return
        try:
            yield True
        except Exception as err:
            if getattr(err, 'kind', '') == 'rate':
                self.rate_limited(getattr(err, 'retry_after', None))
            raise
        else:
            with self._cv:
                self._healthy_count += 1
                if recovery_slot and self._recovery_left > 0:
                    self._recovery_left -= 1
                if self._recovery_left == 0 and self._healthy_count >= 8:
                    self._strikes = 0
                    self._until = 0.0
        finally:
            if recovery_slot:
                with self._cv:
                    self._probe_active = False
                    self._cv.notify_all()
