"""Verify actual Tk widgets show two independent 28Hse direct API tests."""
import os, tempfile
from tkinter import Button
with tempfile.TemporaryDirectory() as home:
    os.environ['HOME'] = home
    from unified_gui import UnifiedApp
    a = UnifiedApp()
    def children(node):
        for w in node.winfo_children():
            yield w
            yield from children(w)
    matches=[w for w in children(a) if isinstance(w,Button) and '28Hse' in str(w.cget('text')) and 'API 測試' in str(w.cget('text'))]
    texts=[str(w.cget('text')) for w in matches]
    assert '28Hse 租盤 API 測試' in texts,texts
    assert '28Hse 售盤 API 測試' in texts,texts
    assert not any('模擬揭號測試' in str(w.cget('text')) for w in children(a) if isinstance(w,Button))
    assert 'V1.50.56' in a.title()
    a.destroy()
print('PASS V1.50.19 GUI: separate 28Hse rent/buy direct API test controls')
