# -*- coding: utf-8 -*-
"""Offline WhatsApp send-action regressions. Does not connect to browser or send WA."""
import threading
from pathlib import Path
from panda28_core import App


class Value:
    def __init__(self, value):
        self.value = value
    def get(self):
        return self.value


class CDP:
    def __init__(self, kind='dom'):
        self.kind = kind
        self.closed = False
        self.calls = []
        self.dom_attempts = 0
        self.outgoing = False
        self.url = ''

    def call(self, method, args=None, **kwargs):
        self.calls.append((method, args))
        if method == 'Page.navigate':
            self.url = (args or {}).get('url', '')
        if method == 'Input.dispatchMouseEvent' and args.get('type') == 'mouseReleased':
            self.outgoing = True

    def ev(self, expression):
        if 'outgoingMatch:last.some' in expression:
            return {'s':'ready','draft':'' if self.outgoing else self.expected,
                    'outgoingCount':int(self.outgoing), 'outgoingMatch':self.outgoing}
        if "kind:'explicit-send-icon'" in expression:
            self.dom_attempts += 1
            if self.kind == 'dom':
                self.outgoing = True
                return {'clicked':True,'kind':'explicit-send-icon'}
            return {'clicked':False, 'why':'not found'}
        if "kind='send-icon'" in expression:
            return {'found':True,'x':405,'y':602,'kind':'send-icon'}
        if 'sel.collapseToEnd()' in expression:
            return True
        raise AssertionError('unexpected JS eval ' + expression[:140])

    def close(self):
        self.closed = True


class Fake:
    def __init__(self, kind):
        self.cdp_base='http://127.0.0.1:9222'
        self.wa_text = Value('你好，想了解更多資料。 {url}')
        self.wa_lock=threading.Lock()
        self.wa_tid = None
        self.c = CDP(kind)
        self.c.expected = self.wa_text.get().replace('{url}','https://www.house730.com/rent-property-9298176/')
        self.logs = []
    def targets(self):
        return []
    def create_background_target(self,url):
        return {'id':'t1','url':url}
    def cdp(self,target):
        return self.c
    def keep_bridge_active(self,conn):
        pass
    def write(self,line):
        self.logs.append(line)


def test_dom_send():
    f=Fake('dom')
    result=App.whatsapp_send(f,'51234567','https://www.house730.com/rent-property-9298176/')
    assert result[0] and f.c.dom_attempts == 1, result
    assert f.c.closed
    assert not [c for c in f.c.calls if c[0] == 'Input.dispatchMouseEvent']
    assert any('[WA55-SEND] 显式图示 DOM 点击' in line for line in f.logs)
    assert any('[WA-VERIFY]' in line for line in f.logs)


def test_mouse_fallback():
    f=Fake('mouse')
    result=App.whatsapp_send(f,'51234567','https://www.house730.com/rent-property-9298176/')
    assert result[0] and f.c.dom_attempts == 1, result
    assert [c[0] for c in f.c.calls].count('Input.dispatchMouseEvent') == 3
    assert not [c for c in f.c.calls if c[0] == 'Input.dispatchKeyEvent']
    assert any('CDP 点击：send-icon' in line for line in f.logs)


def test_code_rejects_ambiguous_buttons():
    s=Path(__file__).with_name('panda28_core.py').read_text('utf-8')
    assert "if(row.length===1)" in s
    assert "no unambiguous send control" in s
    assert "no explicit send icon" in s
    assert 'methods = ("dom-click", "cdp-mouse", "focused-enter")' in s
    assert '[WA55-SEND]' in s
    assert '[WA-VERIFY]' in s
    assert 'send?phone=' in s
    assert 'if attempt > 0 and matched and (count > baseline_count or not baseline_match)' in s
    assert '訊息內容' not in s # never logs actual message content

if __name__=='__main__':
    test_dom_send();test_mouse_fallback();test_code_rejects_ambiguous_buttons()
    print('PASS V1.50.55: explicit send icon, DOM click, CDP fallback, outgoing confirmation and no double-send')
