PandaMonitor V1.50.43 — 不含 Signal 的完整版本

以 V1.50.42 為基礎，只移除 Signal 功能。

保留：
- 28Hse 租/售業主盤，輸入間隔 + 隨機 100–300ms，原有 429 自動恢復、直接 API 取號。
- House730 完全沿用 V1.50.37 核心，含租售共用排程、429 冷卻、背景監控和直接 API 取號。
- WhatsApp、Windows 通知、電話/帖子去重、尾四位剪貼簿、擴展網站、BitBrowser、設定。
- Windows 啟動器 (Python 3.13/3.15 檢測)。

移除：
- Signal 自動發送／手動測試／群組查詢／設定介面／背景工作程序。
- signal-cli 依賴、Signal 專用測試腳本及診斷工具。

兼容：
- 啟動時不再讀取或啟動 Signal 設定；下次保存 config.json 時會清除 signal_* 舊鍵。
- 不會刪除用戶自己安裝的 Signal Desktop、signal-cli 或 Signal 帳號資料。

啟動：解壓後使用 START.bat；如啟動器誤判，可使用 START_DIRECT_PY313.bat。
