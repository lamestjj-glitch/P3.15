# -*- coding: utf-8 -*-
"""Offline regression tests for precise 730 rent/buy tab rebuild on five failures."""
import asyncio
from pathlib import Path
from house730_tab_recovery import MonitorTabRecovery, SharedCDPUnavailable
from house730_engine import expected_list_url, SOURCES


class FakeTab:
    def __init__(self, url, fail_close=False, fail_nav=False):
        self.url = url
        self.closed = False
        self.close_calls = 0
        self.fail_close = fail_close
        self.fail_nav = fail_nav
    def is_closed(self):
        return self.closed
    async def close(self, run_before_unload=False):
        assert run_before_unload is False
        self.close_calls += 1
        if self.fail_close: raise RuntimeError('cannot close')
        self.closed = True
    async def goto(self, url, wait_until, timeout):
        assert wait_until == 'commit'
        if self.fail_nav: raise RuntimeError('site temporarily unavailable')
        self.url = url


class FakeSession:
    async def send(self, command):
        assert command == 'Browser.getVersion'
        return {'product':'Chrome/147.0.7727.57'}
    async def detach(self): pass


class FakeBrowser:
    def __init__(self, broken=False): self.broken=broken
    def is_connected(self): return True
    async def new_browser_cdp_session(self):
        if self.broken: raise RuntimeError('CDP bad')
        return FakeSession()


class FakeContext:
    def __init__(self): self.created=[]
    async def new_page(self):
        tab=FakeTab('about:blank')
        self.created.append(tab)
        return tab


class FakeGuard:
    active=False
    def __init__(self, pages): self.pages=dict(pages)


class FakeStop:
    def is_set(self): return False


async def run():
    logs=[]
    current_time=[1000]
    recovery=MonitorTabRecovery(SOURCES, expected_list_url, logs.append,
                                clock=lambda:current_time[0], cooldown_seconds=90)
    rent=FakeTab(SOURCES['租'])
    buy=FakeTab(SOURCES['售'])
    unrelated=FakeTab('https://www.28hse.com/rent')
    tab_map={'租':rent, '售':buy}
    guard=FakeGuard(tab_map)
    ctx=FakeContext()
    browser=FakeBrowser()
    stop=FakeStop()
    async def challenge(page): return False
    async def replace(deal, page, **kw):
        return await recovery.replace(deal,page,browser=kw.get('browser',browser),
              context=ctx,guard=guard,stop=stop,challenge_check=kw.get('challenge',challenge),tab_map=tab_map)
    # Cannot mistakenly close other source's page or a non-monitor tab.
    assert not await replace('租', buy)
    assert not await replace('租', unrelated)
    assert buy.close_calls==0 and unrelated.close_calls==0
    # Challenge and shared CDP failure suppress destructive tab close.
    assert not await replace('租',rent,challenge=lambda p: asyncio.sleep(0, result=True))
    assert rent.close_calls==0
    try: await replace('租',rent,browser=FakeBrowser(broken=True))
    except SharedCDPUnavailable: pass
    else: raise AssertionError('CDP-wide failure must bubble up')
    assert rent.close_calls==0
    # A genuine stuck attached source tab gets replaced once.
    assert await replace('租',rent)
    assert rent.closed and rent.close_calls==1
    assert len(ctx.created)==1 and tab_map['租'] is ctx.created[0]
    assert tab_map['售'] is buy and not buy.closed
    assert guard.pages.get('租') is None
    assert expected_list_url(ctx.created[0].url,'租')
    assert not await replace('租',ctx.created[0]), 'cooldown prevents tab storms'
    current_time[0] += 91
    assert await replace('租',ctx.created[0])
    assert len(ctx.created)==2
    # Pure source integration checks: five failures, independent rent/buy,
    # never counts HTTP429/403/verification as a transport failure.
    code=Path(__file__).with_name('house730_engine.py').read_text(encoding='utf8')
    assert 'if transport_error_streak >= 5:' in code
    assert 'transport_error_streak = 0' in code
    assert "startup_failure_streak[deal] >= 5" in code
    assert 'tab_recovery.replace(' in code
    assert code.index("elif e.status == 429:") < code.index("elif e.kind in ('native-transport', 'native-shape', 'browser-execution'")
    assert 'await tab_recovery.replace(' in code
    assert '[730-TAB-RECOVER-OK]' in '\n'.join(logs)
    print('PASS V1.50.67: isolated exact-owner-list tab rebuild, lock, cooldown, CDP probe, challenge guard')


if __name__ == '__main__':
    asyncio.run(run())
