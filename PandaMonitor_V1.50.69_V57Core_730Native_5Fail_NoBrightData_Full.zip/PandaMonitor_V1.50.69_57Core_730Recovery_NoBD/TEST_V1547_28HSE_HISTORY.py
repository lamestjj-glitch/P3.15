# -*- coding: utf-8 -*-
"""Offline persistent history regression: no network, no UI startup, no Signal."""
import tempfile
from hse28_history import Hse28History
from unified_gui import UnifiedApp


class FakeTree:
    def __init__(self):
        self.items = {}
    def exists(self, iid):
        return iid in self.items
    def insert(self, parent, position, iid, values):
        assert iid not in self.items
        self.items[iid] = values
        return iid


class FakeUI:
    def __init__(self, store):
        self.hse28_history=store
        self.tree=FakeTree()
        self.row_urls={}
        self.listing_rows={}
        self.logs=[]
    def write(self, msg): self.logs.append(msg)


def run():
    with tempfile.TemporaryDirectory() as tmp:
        db = Hse28History(tmp)
        url='https://www.28hse.com/buy/apartment/property-3871960'
        assert db.save('buy',url,'98261369','未知')
        assert db.save('buy',url,'95116993','Mandy',is_extra=True)
        assert not db.save('buy',url,'98261369','未知')
        db.update_contact('buy',url,'Alice')
        db.update_wa('buy',url,'98261369','已聯絡')
        assert db.save('rent','https://www.28hse.com/rent/property-4059346', '92381246','Ms Chan')
        assert not db.save('buy','http://example.com/buy/test','93559999')
        assert db.count()==3
        oldstamp = {r['phone']:r['detected_at'] for r in db.rows()}
        # Database survives process restart and keeps original timestamps.
        newdb=Hse28History(tmp)
        assert newdb.count()==3
        assert {r['phone']:r['detected_at'] for r in newdb.rows()} == oldstamp
        fake=FakeUI(newdb)
        UnifiedApp._load_28_history(fake)
        assert len(fake.tree.items)==3
        assert ('buy','3871960') in fake.listing_rows
        assert ('rent','4059346') in fake.listing_rows
        restored=list(fake.tree.items.values())
        assert any(r[0]=='28售盘' and r[1]=='98261369' and r[2]=='Alice' and r[3]=='已聯絡' for r in restored)
        assert any(r[0].endswith('附加号码') and r[1]=='95116993' for r in restored)
        assert any(r[0]=='28租盘' and r[1]=='92381246' for r in restored)
        assert all(iid in fake.row_urls for iid in fake.tree.items)
        assert any('[28-HISTORY-READY]' in log for log in fake.logs)
        # Exercise the actual UnifiedApp interception without a browser or Tk.
        from unittest.mock import patch
        from panda28_core import App as Panda28App
        instance=object.__new__(UnifiedApp)
        instance.hse28_history=newdb
        instance.write=lambda msg: fake.logs.append(msg)
        u='https://www.28hse.com/buy/apartment/property-4059999'
        with patch.object(Panda28App, 'result', return_value=(True, 'OK')):
            assert UnifiedApp.result(instance,'buy','女士','98261111',u)[0]
            assert UnifiedApp.result(instance,'buy','女士','98262222',u,test_mode=True)[0]
        with patch.object(Panda28App,'publish_secondary_phone',return_value=True):
            assert UnifiedApp.publish_secondary_phone(instance,'buy',u,'Mary','95112222')
        assert newdb.count()==5
        assert all(r['phone'] != '98262222' for r in newdb.rows())
        # On startup, 730-only history is not incorrectly categorized as 28Hse.
        # Test-only captures are filtered by the GUI result override, verified by source guard.
        import inspect
        source=inspect.getsource(UnifiedApp.result)
        assert 'not test_mode and not wa_test' in source
        assert 'super().result' in source
        print('PASS: 28Hse history persists with primary+extra, timestamps, contact/WA, restore, test guards')

if __name__=='__main__': run()
