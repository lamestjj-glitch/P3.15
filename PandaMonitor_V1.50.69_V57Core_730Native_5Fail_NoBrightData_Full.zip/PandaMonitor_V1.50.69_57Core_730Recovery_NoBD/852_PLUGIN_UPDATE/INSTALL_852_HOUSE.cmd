@echo off
chcp 65001 >nul
cd /d "%~dp0"
py -3 INSTALL_852_HOUSE.py
if errorlevel 1 (
  echo.
  echo Python Launcher unavailable or installation failed. Try: python INSTALL_852_HOUSE.py
)
pause
