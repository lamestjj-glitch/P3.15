關閉 PandaMonitor，雙擊 INSTALL_852_HOUSE.cmd。更新已安裝在 C 盤 site_plugins 的插件；租售保持5秒，設定會備份。
