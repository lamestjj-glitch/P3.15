# -*- coding: utf-8 -*-
"""852.house owner-only rent / buy adapter for PandaMonitor V1.50.3+.

PandaMonitor automatically calls:
    extract_listings(html, listing_url, config)
    accept_detail(html, detail_url, config)
    extract_contacts(html, detail_url, config)

Each rental/sale source gets its *own* 5-second worker via extra_sites.json.
This plugin contains no HTTP traffic, browser tab creation, WA or clipboard calls.
"""
from __future__ import annotations

import re
from urllib.parse import urljoin, urlsplit, parse_qs
from bs4 import BeautifulSoup

HOSTS = {'852.house', 'www.852.house'}
DETAIL_PATH = re.compile(r'^/(?:zh/)?properties/(?P<id>\d{4,12})/?$', re.I)
PROPERTY_CODE = re.compile(r'(?<![A-Za-z0-9])(?:B|D)\s*(\d{4,12})(?!\d)', re.I)
PHONE_RE = re.compile(r'(?<!\d)(?:\+?852[\s.\-]*)?([4-9](?:[\s.\-]*\d){7})(?!\d)')
PERSON_RE = re.compile(
    r'^(?:[\u4e00-\u9fff·]{1,12}(?:先生|小姐|女士|太太|夫人|阿姨|姐|太)|'
    r'(?:Mr|Mrs|Ms|Miss)\.?\s*[A-Za-z][A-Za-z .\-]{0,28}|'
    r'(?:聯絡人|聯絡|Contact\s*(?:Person)?)\s*[:：]\s*[^\d]{2,35})$', re.I
)
CUT_AT = ('附近相似單位推介', '附近相似', '更多相關', '查詢熱線', '聯絡我們',
          '近90天最新成交數據', '相關樓盤', 'Similar Properties')
CONTACT_CUT_AT = ('物業詳細資料', '物业详细资料', '附近相似單位推介',
                  '近90天最新成交數據', '查詢熱線', 'Similar Properties')


def _clean(node):
    soup = BeautifulSoup(node, 'html.parser')
    for el in soup.select('script,style,template,noscript,footer,nav,form,select'):
        el.decompose()
    return soup


def _valid_detail_link(link, url, requested_kind):
    dest = urlsplit(urljoin(url, link))
    if dest.scheme not in ('http', 'https') or dest.hostname not in HOSTS:
        return None
    match = DETAIL_PATH.fullmatch(dest.path)
    if not match:
        return None
    kind = parse_qs(dest.query).get('pricetype', [''])[0].lower()
    if kind and kind != requested_kind:
        return None
    # Preserve the site's original link, but explicitly include pricetype if absent.
    if not kind:
        target = 'https://852.house/zh/properties/%s?pricetype=%s' % (match['id'], requested_kind)
    else:
        target = 'https://852.house/zh/properties/%s?pricetype=%s' % (match['id'], requested_kind)
    return match['id'], target


def _card_for_anchor(anchor, ident):
    """Find smallest enclosing card with this ID *and* the owner label.

    Stop at broad multi-listing containers, so an agency card can't inherit the
    '業主盤' label of another card elsewhere on the page.
    """
    for parent in list(anchor.parents)[:11]:
        if parent.name in ('html', 'body'):
            break
        text = parent.get_text(' ', strip=True)
        if len(text) > 3000:
            break
        other_ids = {
            m.group('id') for a in parent.select('a[href*="/properties/"]')
            for m in [DETAIL_PATH.fullmatch(urlsplit(a.get('href','')).path)] if m
        }
        if len(other_ids) > 1 or (other_ids and ident not in other_ids):
            break
        if '業主盤' not in text or '代理盤' in text:
            continue
        codes = {m.group(1) for m in PROPERTY_CODE.finditer(text)}
        if ident not in codes:
            # Some cards omit the B/D display ID, but show the publish timestamp.
            if not re.search(r'20\d{2}[-/]\d{1,2}[-/]\d{1,2}', text):
                continue
        return parent
    return None


def extract_listings(html, url, cfg):
    """Return ONLY explicit owner cards in the site's displayed listing order."""
    path = urlsplit(url).path.rstrip('/')
    if urlsplit(url).hostname not in HOSTS or path not in ('/zh/rent','/zh/buy'):
        return []
    requested_kind = path.rsplit('/',1)[-1]
    # Do not interpret unrelated / unfiltered pages as an owner-only feed.
    query = parse_qs(urlsplit(url).query)
    if query.get('features[0]') != ['業主盤'] or query.get('order') != ['publishtime|desc']:
        return []
    soup = BeautifulSoup(html, 'html.parser')
    results, seen = [], set()
    for anchor in soup.select('a[href*="/properties/"]'):
        match = _valid_detail_link(anchor.get('href',''), url, requested_kind)
        if match is None:
            continue
        ident, detail_url = match
        if ident in seen:
            continue
        card = _card_for_anchor(anchor, ident)
        if card is None:
            continue
        title = anchor.get_text(' ', strip=True)
        if not title:
            for selector in ('h2','h3','h4','h5','.title'):
                heading = card.select_one(selector)
                if heading:
                    title = heading.get_text(' ', strip=True)
                    break
        if not title:
            title = re.sub(r'\s+', ' ', card.get_text(' ',strip=True))[:120]
        seen.add(ident)
        results.append({'id':ident, 'url':detail_url,
                        'title':('%s｜%s' % ('租' if requested_kind=='rent' else '售',title[:175]))})
    return results


def _detail_body(html):
    soup = _clean(html)
    # Remove recommendations and helpdesk so their numbers/names are not used.
    return soup


def _head_text(soup, markers):
    snippets = []
    for node in soup.stripped_strings:
        string = str(node).strip()
        if any(cut.lower() in string.lower() for cut in markers):
            break
        snippets.append(string)
        if len(snippets) >= 450:
            break
    return snippets


def _verified_owner_feed(cfg, kind):
    """Require the installed list to still be owner-only and latest."""
    feed = urlsplit(str((cfg or {}).get('url') or ''))
    q = parse_qs(feed.query)
    return (feed.hostname in HOSTS and feed.path.rstrip('/') == '/zh/' + kind
            and q.get('features[0]') == ['業主盤']
            and q.get('order') == ['publishtime|desc'])


def accept_detail(html, url, cfg):
    parsed = urlsplit(url)
    match = DETAIL_PATH.fullmatch(parsed.path)
    if parsed.hostname not in HOSTS or match is None:
        return False
    soup = _detail_body(html)
    head = ' '.join(_head_text(soup, CUT_AT))
    # Reject a clearly agent-marked detail, regardless of fallback.
    if re.search(r'(?:特色|特點|Features)\s*代理盤', head, re.I):
        return False
    feature_match = re.search(r'(?:特色|特點|Features)\s*(.{0,250})', head, re.I)
    if feature_match and '業主盤' in feature_match.group(1):
        return True
    if '業主盤' in head and '代理盤' not in head:
        return True
    # The live site renders the seller/phone ABOVE the property details,
    # whereas the owner badge may be missing in a partial response. Permit
    # that early public contact only for our verified owner-filtered feed,
    # never for an arbitrary detail URL or an explicitly agent-marked page.
    kind = parse_qs(parsed.query).get('pricetype', [''])[0]
    if kind not in ('rent', 'buy') or not _verified_owner_feed(cfg, kind):
        return False
    if '代理盤' in head:
        return False
    code = re.search(r'(?<!\w)[BD]\s*' + re.escape(match.group('id')) + r'(?!\d)', head, re.I)
    return bool(code and ('物業詳細資料' in head or '樓盤編號' in head)
                and any(_name(x) for x in _head_text(soup, CONTACT_CUT_AT))
                and any(_phone_candidates(x) for x in _head_text(soup, CONTACT_CUT_AT)))


def _normal_phone(text):
    match = PHONE_RE.search(text)
    if not match:
        return None
    digits = re.sub(r'\D', '', match.group(1))
    if len(digits) != 8 or digits[:1] in ('2','3'):
        return None
    return digits  # user preference: strip 852 prefix


def _name(s):
    s = re.sub(r'\s+', ' ', str(s)).strip(' :：\u00a0-')
    if not s or len(s) > 45:
        return None
    if PERSON_RE.fullmatch(s):
        s = re.sub(r'^(?:聯絡人|聯絡|Contact\s*(?:Person)?)\s*[:：]\s*', '', s, flags=re.I)
        return s
    return None


def _phone_candidates(s):
    # Can match standalone or label-prefixed numbers, but only in contact header.
    out=[]
    for m in PHONE_RE.finditer(s):
        digits=_normal_phone(m.group())
        if digits and digits not in out:
            out.append((digits, s[:m.start()].strip()))
    return out


def extract_contacts(html, url, cfg):
    """Extract public 852.house seller numbers and match them with their owner.

    Phone matching is limited to the detail header before '物業詳細資料'.
    No arbitrary 8-digit matches in prices, navigation, scripts or footer.
    """
    if not accept_detail(html, url, cfg):
        return []
    soup = _detail_body(html)
    before = _head_text(soup, CONTACT_CUT_AT)
    contacts, index = [], {}

    def add(phone, name):
        if not phone:
            return
        name = name or '未知'
        if phone in index:
            old = contacts[index[phone]]
            if old['name']=='未知' and name!='未知':
                old['name']=name
            return
        index[phone] = len(contacts)
        contacts.append({'name':name, 'phone':phone})

    for i, token in enumerate(before):
        for number, prefix in _phone_candidates(token):
            # The site's contact area places seller's name adjacent to number.
            person = _name(prefix)
            if not person:
                for previous in before[max(0,i-2):i][::-1]:
                    person = _name(previous)
                    if person:
                        break
            if person:
                add(number,person)
            else:
                # A tel: hyperlink may be shown without the seller name.
                # Still accept only an explicit phone-labelled field.
                if re.search(r'(?:電話|聯絡|手機|mobile|phone|tel)\s*[:：]?',prefix,re.I):
                    add(number, '未知')

    # Covers click-to-call anchors in the detail header, not footer/helpdesk.
    # 852.house sometimes provides the number only in href="tel:...".
    for a in soup.select('a[href^="tel:"]'):
        for descendant in [a, *list(a.parents)[:7]]:
            if descendant.name in ('footer','nav','html','body'):
                break
            label = descendant.get_text(' ',strip=True)
            if any(cut in label for cut in CONTACT_CUT_AT):
                break
            if len(label) > 650:
                break
            no = _normal_phone(a.get('href','')[4:])
            if no:
                add(no, _name(label.replace(a.get_text(' ',strip=True),'').strip()) or '未知')
            break
    return contacts
