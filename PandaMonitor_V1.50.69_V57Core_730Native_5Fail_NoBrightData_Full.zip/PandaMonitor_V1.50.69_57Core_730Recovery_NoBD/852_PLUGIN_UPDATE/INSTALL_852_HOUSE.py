# -*- coding: utf-8 -*-
"""Optional one-time installer for PandaMonitor V1.50.3+.

Safely installs the trusted house852_owner.py adapter and merges exactly two
extra-site entries into the user's settings folder. Other sites are untouched.
Run with PandaMonitor CLOSED: python INSTALL_852_HOUSE.py
"""
from pathlib import Path
from datetime import datetime
import json
import os
import shutil
import sys


def main():
    here = Path(__file__).resolve().parent
    config_root = Path(os.environ.get('PANDAMONITOR_CONFIG_DIR') or (Path.home() / 'PandaMonitor_28Hse'))
    config_file = config_root / 'extra_sites.json'
    plugin_source = here / 'house852_owner.py'
    templates = here / '852_house_sites.json'

    if not config_file.is_file():
        raise SystemExit('找不到網站設定：%s\n請先啟動一次 PandaMonitor V1.50.3，關閉後重試。' % config_file)
    if not plugin_source.is_file() or not templates.is_file():
        raise SystemExit('缺少插件或兩站設定樣本。請先完整解壓 ZIP。')

    original = json.loads(config_file.read_text(encoding='utf-8-sig'))
    target = original if isinstance(original, dict) else {'schema': 1,'sites':original}
    existing = target.get('sites', [])
    additions = json.loads(templates.read_text(encoding='utf-8'))['sites']
    if not isinstance(existing,list):
        raise SystemExit('原有 extra_sites.json 格式不正確；未進行修改。')
    by_id = {str(s.get('id','')):i for i,s in enumerate(existing) if isinstance(s,dict)}
    for site in additions:
        site_id=site['id']
        if site_id in by_id:
            # Only update fields explicitly belonging to this same 852.house site.
            row = dict(existing[by_id[site_id]])
            row.update(site)
            existing[by_id[site_id]] = row
        else:
            existing.append(site)
    target['sites'] = existing

    # Validate against the exact V1.50.3 field constraints before saving.
    sys.path.insert(0, str(here))
    for s in additions:
        assert s['id'] and s['plugin'] == 'house852_owner' and s['interval'] == 5.0
        assert s['mode'] == 'http'
    dest_dir = config_root / 'site_plugins'
    dest_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime('%Y%m%d-%H%M%S')
    backup = config_file.with_name('extra_sites.before_852_house_%s.json' % stamp)
    shutil.copy2(config_file, backup)
    dest_plugin = dest_dir / plugin_source.name
    if dest_plugin.is_file():
        shutil.copy2(dest_plugin, dest_plugin.with_suffix('.py.bak'))
    shutil.copy2(plugin_source, dest_plugin)
    temp = config_file.with_suffix('.json.tmp')
    try:
        temp.write_text(json.dumps(target, ensure_ascii=False, indent=2), encoding='utf-8')
        # Atomic replacement, no partial JSON on interruption.
        os.replace(temp, config_file)
    except Exception:
        temp.unlink(missing_ok=True)
        raise
    print('安裝完成：%s' % dest_plugin)
    print('租盤及售盤各 5 秒，已啟用；其他網站設定保留。')
    print('原設定備份：%s' % backup)
    print('現在重新啟動 PandaMonitor，按「開始監控」。')

if __name__=='__main__':
    main()
