# -*- coding: utf-8 -*-
"""House730 per-lane recovery of a genuinely broken owner/latest monitor tab.

Never rotate a proxy, bypass challenges, touch another tab, or reset the
listing baseline.  Deliberately conservative: opening a replacement requires
confirmed closure of the matching tab, a healthy browser CDP connection, and
an authorized owner/latest URL.  Restarts are bounded to avoid a tab storm.
"""
from __future__ import annotations
import asyncio
import time


class SharedCDPUnavailable(RuntimeError):
    """Browser-wide CDP is unhealthy: caller must reconnect rather than close tabs."""


class MonitorTabRecovery:
    def __init__(self, urls, is_expected, logger, *, cooldown_seconds=90, clock=time.monotonic):
        self.urls = urls
        self.is_expected = is_expected
        self.log = logger
        self.cooldown_seconds = cooldown_seconds
        self.clock = clock
        self.next_allowed = {deal: 0.0 for deal in urls}
        self.lock = asyncio.Lock()

    async def _probe_cdp(self, browser):
        """Distinguish browser-wide CDP outage from a single stuck renderer."""
        session = None
        try:
            session = await asyncio.wait_for(browser.new_browser_cdp_session(), timeout=3)
            data = await asyncio.wait_for(session.send('Browser.getVersion'), timeout=3)
            if not isinstance(data, dict) or not data.get('product'):
                raise RuntimeError('Browser.getVersion returned no browser identity')
        except Exception as exc:
            raise SharedCDPUnavailable('CDP Browser.getVersion 健康檢查失敗: ' + type(exc).__name__) from exc
        finally:
            if session is not None:
                try:
                    await asyncio.wait_for(session.detach(), timeout=2)
                except Exception:
                    pass

    async def replace(self, deal, page, *, browser, context, guard, stop,
                      challenge_check, tab_map):
        """Return True only when a new matching monitoring tab was opened.

        After a confirmed closure, a new tab is created even if navigation
        raises; this retains a controlled tab to recover later.  Caller must
        restart the lane to re-learn a fresh request template.
        """
        async with self.lock:
            if stop.is_set() or not browser.is_connected() or getattr(guard, 'active', False):
                self.log(f'{deal}盤 [730-TAB-RECOVER-SKIP] 已停止／瀏覽器失聯／正在網站驗證；不動分頁')
                return False
            if self.clock() < self.next_allowed[deal]:
                wait = int(self.next_allowed[deal] - self.clock() + .99)
                self.log(f'{deal}盤 [730-TAB-RECOVER-WAIT] 距離上次重建太近，{wait}秒後才容許再關閉')
                return False
            if page is None or page.is_closed() or tab_map.get(deal) is not page:
                self.log(f'{deal}盤 [730-TAB-RECOVER-SKIP] 舊分頁已變更；改由監督器重接')
                return False
            if not self.is_expected(page.url, deal):
                self.log(f'{deal}盤 [730-TAB-RECOVER-SKIP] URL 不屬於指定業主＋最新列表；不關閉')
                return False
            other = '售' if deal == '租' else '租'
            if tab_map.get(other) is page:
                self.log(f'{deal}盤 [730-TAB-RECOVER-SKIP] 頁面被另一監控路共用；不關閉')
                return False
            try:
                if await asyncio.wait_for(challenge_check(page), timeout=4):
                    self.log(f'{deal}盤 [730-TAB-RECOVER-SKIP] 偵測到驗證頁；等待手動完成，不關閉')
                    return False
            except asyncio.TimeoutError:
                self.log(f'{deal}盤 [730-TAB-RECOVER-INFO] 驗證頁檢查超時；暫不關閉以免誤關')
                return False
            await self._probe_cdp(browser)
            self.next_allowed[deal] = self.clock() + self.cooldown_seconds
            # Only the EXACT attached monitor tab is closed. No other tab is touched.
            try:
                await asyncio.wait_for(page.close(run_before_unload=False), timeout=6)
            except Exception as exc:
                self.log(f'{deal}盤 [730-TAB-RECOVER-ERROR] 舊監控頁關閉失敗: {type(exc).__name__}；不新開分頁')
            if not page.is_closed():
                return False
            if tab_map.get(deal) is page:
                tab_map.pop(deal, None)
            if getattr(guard, 'pages', {}).get(deal) is page:
                guard.pages.pop(deal, None)
            if stop.is_set() or not browser.is_connected():
                return False
            try:
                new_page = await asyncio.wait_for(context.new_page(), timeout=8)
            except Exception as exc:
                self.log(f'{deal}盤 [730-TAB-RECOVER-ERROR] 已關閉舊頁但無法建立新頁: {type(exc).__name__}')
                raise SharedCDPUnavailable('House730 新分頁建立失敗') from exc
            # Mark as the managed tab immediately, including partial-navigation
            # failure; unlike before, any future close must target THIS one.
            tab_map[deal] = new_page
            try:
                await asyncio.wait_for(new_page.goto(self.urls[deal], wait_until='commit', timeout=13000), timeout=15)
            except Exception as exc:
                self.log(f'{deal}盤 [730-TAB-RECOVER-INFO] 新分頁已開；導航暫未完成: {type(exc).__name__}')
            if self.is_expected(new_page.url, deal):
                self.log(f'{deal}盤 [730-TAB-RECOVER-OK] 已只重建本路監控頁；其他分頁保留；網址={self.urls[deal]}')
                return True
            self.log(f'{deal}盤 [730-TAB-RECOVER-VERIFY] 新分頁尚未到達業主＋最新 URL；不讀取列表，等待頁面恢復')
            return True
